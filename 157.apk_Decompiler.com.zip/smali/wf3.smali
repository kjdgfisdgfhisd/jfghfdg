###### Class defpackage.wf3 (wf3)
.class public final synthetic Lwf3;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lut0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:Lcc/bomber/x/g/c;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;Lcc/bomber/x/g/c;I)V
    .registers 4

    .line 1
    iput p3, p0, Lwf3;->a:I

    .line 2
    .line 3
    iput-object p1, p0, Lwf3;->b:Ljava/lang/String;

    .line 4
    .line 5
    iput-object p2, p0, Lwf3;->c:Lcc/bomber/x/g/c;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 1
    iget v0, p0, Lwf3;->a:I

    .line 2
    .line 3
    iget-object v1, p0, Lwf3;->c:Lcc/bomber/x/g/c;

    .line 4
    .line 5
    iget-object p0, p0, Lwf3;->b:Ljava/lang/String;

    .line 6
    .line 7
    check-cast p1, Lcc/bomber/x/g/c;

    .line 8
    .line 9
    check-cast p2, Lio;

    .line 10
    .line 11
    check-cast p3, Lfg2;

    .line 12
    .line 13
    packed-switch v0, :pswitch_data_56

    .line 14
    .line 15
    .line 16
    invoke-static {p0, v1, p1, p2, p3}, Lcc/bomber/x/i/c;->x6(Ljava/lang/String;Lcc/bomber/x/g/c;Lcc/bomber/x/g/c;Lio;Lfg2;)Lw43;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    return-object p0

    .line 21
    :pswitch_14
    invoke-static {p0, v1, p1, p2, p3}, Lcc/bomber/x/i/c;->I6(Ljava/lang/String;Lcc/bomber/x/g/c;Lcc/bomber/x/g/c;Lio;Lfg2;)Lw43;

    .line 22
    .line 23
    .line 24
    move-result-object p0

    .line 25
    return-object p0

    .line 26
    :pswitch_19
    invoke-static {p0, v1, p1, p2, p3}, Lcc/bomber/x/i/c;->n6(Ljava/lang/String;Lcc/bomber/x/g/c;Lcc/bomber/x/g/c;Lio;Lfg2;)Lw43;

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    return-object p0

    .line 31
    :pswitch_1e
    invoke-static {p0, v1, p1, p2, p3}, Lcc/bomber/x/i/c;->o1(Ljava/lang/String;Lcc/bomber/x/g/c;Lcc/bomber/x/g/c;Lio;Lfg2;)Lw43;

    .line 32
    .line 33
    .line 34
    move-result-object p0

    .line 35
    return-object p0

    .line 36
    :pswitch_23
    invoke-static {p0, v1, p1, p2, p3}, Lcc/bomber/x/i/c;->k1(Ljava/lang/String;Lcc/bomber/x/g/c;Lcc/bomber/x/g/c;Lio;Lfg2;)Lw43;

    .line 37
    .line 38
    .line 39
    move-result-object p0

    .line 40
    return-object p0

    .line 41
    :pswitch_28
    invoke-static {p0, v1, p1, p2, p3}, Lcc/bomber/x/i/c;->A0(Ljava/lang/String;Lcc/bomber/x/g/c;Lcc/bomber/x/g/c;Lio;Lfg2;)Lw43;

    .line 42
    .line 43
    .line 44
    move-result-object p0

    .line 45
    return-object p0

    .line 46
    :pswitch_2d
    invoke-static {p0, v1, p1, p2, p3}, Lcc/bomber/x/i/c;->W5(Ljava/lang/String;Lcc/bomber/x/g/c;Lcc/bomber/x/g/c;Lio;Lfg2;)Lw43;

    .line 47
    .line 48
    .line 49
    move-result-object p0

    .line 50
    return-object p0

    .line 51
    :pswitch_32
    invoke-static {p0, v1, p1, p2, p3}, Lcc/bomber/x/h/a;->v(Ljava/lang/String;Lcc/bomber/x/g/c;Lcc/bomber/x/g/c;Lio;Lfg2;)Lw43;

    .line 52
    .line 53
    .line 54
    move-result-object p0

    .line 55
    return-object p0

    .line 56
    :pswitch_37
    invoke-static {p0, v1, p1, p2, p3}, Lcc/bomber/x/h/a;->K(Ljava/lang/String;Lcc/bomber/x/g/c;Lcc/bomber/x/g/c;Lio;Lfg2;)Lw43;

    .line 57
    .line 58
    .line 59
    move-result-object p0

    .line 60
    return-object p0

    .line 61
    :pswitch_3c
    invoke-static {p0, v1, p1, p2, p3}, Lcc/bomber/x/h/a;->q(Ljava/lang/String;Lcc/bomber/x/g/c;Lcc/bomber/x/g/c;Lio;Lfg2;)Lw43;

    .line 62
    .line 63
    .line 64
    move-result-object p0

    .line 65
    return-object p0

    .line 66
    :pswitch_41
    invoke-static {p0, v1, p1, p2, p3}, Lcc/bomber/x/h/a;->P(Ljava/lang/String;Lcc/bomber/x/g/c;Lcc/bomber/x/g/c;Lio;Lfg2;)Lw43;

    .line 67
    .line 68
    .line 69
    move-result-object p0

    .line 70
    return-object p0

    .line 71
    :pswitch_46
    invoke-static {p0, v1, p1, p2, p3}, Lcc/bomber/x/h/a;->Y(Ljava/lang/String;Lcc/bomber/x/g/c;Lcc/bomber/x/g/c;Lio;Lfg2;)Lw43;

    .line 72
    .line 73
    .line 74
    move-result-object p0

    .line 75
    return-object p0

    .line 76
    :pswitch_4b
    invoke-static {p0, v1, p1, p2, p3}, Lcc/bomber/x/h/a;->G(Ljava/lang/String;Lcc/bomber/x/g/c;Lcc/bomber/x/g/c;Lio;Lfg2;)Lw43;

    .line 77
    .line 78
    .line 79
    move-result-object p0

    .line 80
    return-object p0

    .line 81
    :pswitch_50
    invoke-static {p0, v1, p1, p2, p3}, Lcc/bomber/x/h/a;->f0(Ljava/lang/String;Lcc/bomber/x/g/c;Lcc/bomber/x/g/c;Lio;Lfg2;)Lw43;

    .line 82
    .line 83
    .line 84
    move-result-object p0

    .line 85
    return-object p0

    .line 86
    nop

    .line 87
    :pswitch_data_56
    .packed-switch 0x0
        :pswitch_50
        :pswitch_4b
        :pswitch_46
        :pswitch_41
        :pswitch_3c
        :pswitch_37
        :pswitch_32
        :pswitch_2d
        :pswitch_28
        :pswitch_23
        :pswitch_1e
        :pswitch_19
        :pswitch_14
    .end packed-switch
.end method
