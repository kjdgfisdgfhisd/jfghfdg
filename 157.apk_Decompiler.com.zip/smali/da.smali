###### Class defpackage.da (da)
.class public interface abstract Lda;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# virtual methods
.method public abstract E(IF)V
.end method

.method public abstract e(I)V
.end method

.method public abstract y(I)V
.end method
