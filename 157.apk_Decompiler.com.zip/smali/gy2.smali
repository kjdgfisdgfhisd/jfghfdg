###### Class defpackage.gy2 (gy2)
.class public final Lgy2;
.super Lhy2;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# virtual methods
.method public final d(J)Lhy2;
    .registers 3

    .line 1
    return-object p0
.end method

.method public final f()V
    .registers 1

    .line 1
    return-void
.end method

.method public final g(J)Lhy2;
    .registers 3

    .line 1
    sget-object p1, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    return-object p0
.end method
