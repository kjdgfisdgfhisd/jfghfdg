###### Class defpackage.o20 (o20)
.class public final synthetic Lo20;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ls20;

.field public final synthetic c:Lbk;


# direct methods
.method public synthetic constructor <init>(Ls20;Lbk;I)V
    .registers 4

    .line 1
    iput p3, p0, Lo20;->a:I

    .line 2
    .line 3
    iput-object p1, p0, Lo20;->b:Ls20;

    .line 4
    .line 5
    iput-object p2, p0, Lo20;->c:Lbk;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    .line 1
    iget v0, p0, Lo20;->a:I

    .line 2
    .line 3
    iget-object v1, p0, Lo20;->c:Lbk;

    .line 4
    .line 5
    iget-object p0, p0, Lo20;->b:Ls20;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_12

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0, v1}, Ls20;->a(Lbk;)V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :pswitch_d
    invoke-virtual {p0, v1}, Ls20;->a(Lbk;)V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    nop

    .line 19
    :pswitch_data_12
    .packed-switch 0x0
        :pswitch_d
    .end packed-switch
.end method
