###### Class defpackage.c1 (c1)
.class public final Lc1;
.super La1;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final c:Lwn0;

.field public final synthetic d:Ld1;


# direct methods
.method public constructor <init>(Ld1;Lcm1;)V
    .registers 4

    .line 1
    sget-object v0, Lwn0;->o:Lwn0;

    .line 2
    .line 3
    if-eqz p2, :cond_c

    .line 4
    .line 5
    iput-object p1, p0, Lc1;->d:Ld1;

    .line 6
    .line 7
    invoke-direct {p0, p2}, La1;-><init>(Lcm1;)V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Lc1;->c:Lwn0;

    .line 11
    .line 12
    return-void

    .line 13
    :cond_c
    const/4 p0, 0x0

    .line 14
    invoke-static {p0}, Lc1;->m(I)V

    .line 15
    .line 16
    .line 17
    const/4 p0, 0x0

    .line 18
    throw p0
.end method

.method public static synthetic m(I)V
    .registers 12

    .line 1
    const/16 v0, 0x8

    .line 2
    .line 3
    const/4 v1, 0x5

    .line 4
    const/4 v2, 0x4

    .line 5
    const/4 v3, 0x3

    .line 6
    const/4 v4, 0x2

    .line 7
    const/4 v5, 0x1

    .line 8
    if-eq p0, v5, :cond_16

    .line 9
    .line 10
    if-eq p0, v4, :cond_16

    .line 11
    .line 12
    if-eq p0, v3, :cond_16

    .line 13
    .line 14
    if-eq p0, v2, :cond_16

    .line 15
    .line 16
    if-eq p0, v1, :cond_16

    .line 17
    .line 18
    if-eq p0, v0, :cond_16

    .line 19
    .line 20
    const-string v6, "Argument for @NotNull parameter \'%s\' of %s.%s must not be null"

    .line 21
    .line 22
    goto :goto_18

    .line 23
    :cond_16
    const-string v6, "@NotNull method %s.%s must not return null"

    .line 24
    .line 25
    :goto_18
    if-eq p0, v5, :cond_26

    .line 26
    .line 27
    if-eq p0, v4, :cond_26

    .line 28
    .line 29
    if-eq p0, v3, :cond_26

    .line 30
    .line 31
    if-eq p0, v2, :cond_26

    .line 32
    .line 33
    if-eq p0, v1, :cond_26

    .line 34
    .line 35
    if-eq p0, v0, :cond_26

    .line 36
    .line 37
    move v7, v3

    .line 38
    goto :goto_27

    .line 39
    :cond_26
    move v7, v4

    .line 40
    :goto_27
    new-array v7, v7, [Ljava/lang/Object;

    .line 41
    .line 42
    const-string v8, "kotlin/reflect/jvm/internal/impl/descriptors/impl/AbstractTypeParameterDescriptor$TypeParameterTypeConstructor"

    .line 43
    .line 44
    const/4 v9, 0x0

    .line 45
    packed-switch p0, :pswitch_data_a2

    .line 46
    .line 47
    .line 48
    const-string v10, "storageManager"

    .line 49
    .line 50
    aput-object v10, v7, v9

    .line 51
    .line 52
    goto :goto_45

    .line 53
    :pswitch_34
    const-string v10, "classifier"

    .line 54
    .line 55
    aput-object v10, v7, v9

    .line 56
    .line 57
    goto :goto_45

    .line 58
    :pswitch_39
    const-string v10, "supertypes"

    .line 59
    .line 60
    aput-object v10, v7, v9

    .line 61
    .line 62
    goto :goto_45

    .line 63
    :pswitch_3e
    const-string v10, "type"

    .line 64
    .line 65
    aput-object v10, v7, v9

    .line 66
    .line 67
    goto :goto_45

    .line 68
    :pswitch_43
    aput-object v8, v7, v9

    .line 69
    .line 70
    :goto_45
    const-string v9, "processSupertypesWithoutCycles"

    .line 71
    .line 72
    if-eq p0, v5, :cond_6d

    .line 73
    .line 74
    if-eq p0, v4, :cond_68

    .line 75
    .line 76
    if-eq p0, v3, :cond_63

    .line 77
    .line 78
    if-eq p0, v2, :cond_5e

    .line 79
    .line 80
    if-eq p0, v1, :cond_59

    .line 81
    .line 82
    if-eq p0, v0, :cond_56

    .line 83
    .line 84
    aput-object v8, v7, v5

    .line 85
    .line 86
    goto :goto_71

    .line 87
    :cond_56
    aput-object v9, v7, v5

    .line 88
    .line 89
    goto :goto_71

    .line 90
    :cond_59
    const-string v8, "getSupertypeLoopChecker"

    .line 91
    .line 92
    aput-object v8, v7, v5

    .line 93
    .line 94
    goto :goto_71

    .line 95
    :cond_5e
    const-string v8, "getBuiltIns"

    .line 96
    .line 97
    aput-object v8, v7, v5

    .line 98
    .line 99
    goto :goto_71

    .line 100
    :cond_63
    const-string v8, "getDeclarationDescriptor"

    .line 101
    .line 102
    aput-object v8, v7, v5

    .line 103
    .line 104
    goto :goto_71

    .line 105
    :cond_68
    const-string v8, "getParameters"

    .line 106
    .line 107
    aput-object v8, v7, v5

    .line 108
    .line 109
    goto :goto_71

    .line 110
    :cond_6d
    const-string v8, "computeSupertypes"

    .line 111
    .line 112
    aput-object v8, v7, v5

    .line 113
    .line 114
    :goto_71
    packed-switch p0, :pswitch_data_b8

    .line 115
    .line 116
    .line 117
    const-string v8, "<init>"

    .line 118
    .line 119
    aput-object v8, v7, v4

    .line 120
    .line 121
    goto :goto_85

    .line 122
    :pswitch_79
    const-string v8, "isSameClassifier"

    .line 123
    .line 124
    aput-object v8, v7, v4

    .line 125
    .line 126
    goto :goto_85

    .line 127
    :pswitch_7e
    aput-object v9, v7, v4

    .line 128
    .line 129
    goto :goto_85

    .line 130
    :pswitch_81
    const-string v8, "reportSupertypeLoopError"

    .line 131
    .line 132
    aput-object v8, v7, v4

    .line 133
    .line 134
    :goto_85
    :pswitch_85
    invoke-static {v6, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 135
    .line 136
    .line 137
    move-result-object v6

    .line 138
    if-eq p0, v5, :cond_9b

    .line 139
    .line 140
    if-eq p0, v4, :cond_9b

    .line 141
    .line 142
    if-eq p0, v3, :cond_9b

    .line 143
    .line 144
    if-eq p0, v2, :cond_9b

    .line 145
    .line 146
    if-eq p0, v1, :cond_9b

    .line 147
    .line 148
    if-eq p0, v0, :cond_9b

    .line 149
    .line 150
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 151
    .line 152
    invoke-direct {p0, v6}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 153
    .line 154
    .line 155
    goto :goto_a0

    .line 156
    :cond_9b
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 157
    .line 158
    invoke-direct {p0, v6}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 159
    .line 160
    .line 161
    :goto_a0
    throw p0

    .line 162
    nop

    .line 163
    :pswitch_data_a2
    .packed-switch 0x1
        :pswitch_43
        :pswitch_43
        :pswitch_43
        :pswitch_43
        :pswitch_43
        :pswitch_3e
        :pswitch_39
        :pswitch_43
        :pswitch_34
    .end packed-switch

    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    :pswitch_data_b8
    .packed-switch 0x1
        :pswitch_85
        :pswitch_85
        :pswitch_85
        :pswitch_85
        :pswitch_85
        :pswitch_81
        :pswitch_7e
        :pswitch_85
        :pswitch_79
    .end packed-switch
.end method


# virtual methods
.method public final a()Z
    .registers 1

    .line 1
    const/4 p0, 0x1

    .line 2
    return p0
.end method

.method public final c()Lau;
    .registers 1

    .line 1
    iget-object p0, p0, Lc1;->d:Ld1;

    .line 2
    .line 3
    return-object p0
.end method

.method public final e()Ljava/util/List;
    .registers 1

    .line 1
    sget-object p0, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 2
    .line 3
    if-eqz p0, :cond_5

    .line 4
    .line 5
    return-object p0

    .line 6
    :cond_5
    const/4 p0, 0x2

    .line 7
    invoke-static {p0}, Lc1;->m(I)V

    .line 8
    .line 9
    .line 10
    const/4 p0, 0x0

    .line 11
    throw p0
.end method

.method public final f()Ljava/util/Collection;
    .registers 1

    .line 1
    iget-object p0, p0, Lc1;->d:Ld1;

    .line 2
    .line 3
    invoke-virtual {p0}, Ld1;->L0()Ljava/util/List;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    if-eqz p0, :cond_9

    .line 8
    .line 9
    return-object p0

    .line 10
    :cond_9
    const/4 p0, 0x1

    .line 11
    invoke-static {p0}, Lc1;->m(I)V

    .line 12
    .line 13
    .line 14
    const/4 p0, 0x0

    .line 15
    throw p0
.end method

.method public final g()Lgg1;
    .registers 2

    .line 1
    const/4 p0, 0x0

    .line 2
    new-array p0, p0, [Ljava/lang/String;

    .line 3
    .line 4
    sget-object v0, Lyj0;->g:Lyj0;

    .line 5
    .line 6
    invoke-static {v0, p0}, Lzj0;->c(Lyj0;[Ljava/lang/String;)Lwj0;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    return-object p0
.end method

.method public final h()Lwn0;
    .registers 1

    .line 1
    iget-object p0, p0, Lc1;->c:Lwn0;

    .line 2
    .line 3
    if-eqz p0, :cond_5

    .line 4
    .line 5
    return-object p0

    .line 6
    :cond_5
    const/4 p0, 0x5

    .line 7
    invoke-static {p0}, Lc1;->m(I)V

    .line 8
    .line 9
    .line 10
    const/4 p0, 0x0

    .line 11
    throw p0
.end method

.method public final j(Lau;)Z
    .registers 5

    .line 1
    instance-of v0, p1, Ll23;

    .line 2
    .line 3
    if-eqz v0, :cond_14

    .line 4
    .line 5
    sget-object v0, Lby0;->b:Lby0;

    .line 6
    .line 7
    check-cast p1, Ll23;

    .line 8
    .line 9
    sget-object v1, Ll;->d:Ll;

    .line 10
    .line 11
    iget-object p0, p0, Lc1;->d:Ld1;

    .line 12
    .line 13
    const/4 v2, 0x1

    .line 14
    invoke-virtual {v0, p0, p1, v2, v1}, Lby0;->r(Ll23;Ll23;ZLtt0;)Z

    .line 15
    .line 16
    .line 17
    move-result p0

    .line 18
    if-eqz p0, :cond_14

    .line 19
    .line 20
    return v2

    .line 21
    :cond_14
    const/4 p0, 0x0

    .line 22
    return p0
.end method

.method public final k()Lxf1;
    .registers 1

    .line 1
    iget-object p0, p0, Lc1;->d:Ld1;

    .line 2
    .line 3
    invoke-static {p0}, Lxa0;->e(Lm60;)Lxf1;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    if-eqz p0, :cond_9

    .line 8
    .line 9
    return-object p0

    .line 10
    :cond_9
    const/4 p0, 0x4

    .line 11
    invoke-static {p0}, Lc1;->m(I)V

    .line 12
    .line 13
    .line 14
    const/4 p0, 0x0

    .line 15
    throw p0
.end method

.method public final l(Ljava/util/List;)Ljava/util/List;
    .registers 2

    .line 1
    iget-object p0, p0, Lc1;->d:Ld1;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Ld1;->K0(Ljava/util/List;)Ljava/util/List;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    if-eqz p0, :cond_9

    .line 8
    .line 9
    return-object p0

    .line 10
    :cond_9
    const/16 p0, 0x8

    .line 11
    .line 12
    invoke-static {p0}, Lc1;->m(I)V

    .line 13
    .line 14
    .line 15
    const/4 p0, 0x0

    .line 16
    throw p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 1

    .line 1
    iget-object p0, p0, Lc1;->d:Ld1;

    .line 2
    .line 3
    invoke-virtual {p0}, Ln60;->getName()Ldv1;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    iget-object p0, p0, Ldv1;->a:Ljava/lang/String;

    .line 8
    .line 9
    return-object p0
.end method
