###### Class defpackage.ik3 (ik3)
.class public final Lik3;
.super Lxj3;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lbx0;
.implements Lcx0;


# static fields
.field public static final l:Ltj3;


# instance fields
.field public final e:Landroid/content/Context;

.field public final f:Landroid/os/Handler;

.field public final g:Ltj3;

.field public final h:Ljava/util/Set;

.field public final i:Ly8;

.field public j:Lxn2;

.field public k:Lc6;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    sget-object v0, Lkk3;->a:Ltj3;

    .line 2
    .line 3
    sput-object v0, Lik3;->l:Ltj3;

    .line 4
    .line 5
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lzk3;Ly8;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Lxj3;-><init>()V

    .line 2
    .line 3
    .line 4
    const-string v0, "com.google.android.gms.signin.internal.ISignInCallbacks"

    .line 5
    .line 6
    invoke-virtual {p0, p0, v0}, Landroid/os/Binder;->attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, Lik3;->e:Landroid/content/Context;

    .line 10
    .line 11
    iput-object p2, p0, Lik3;->f:Landroid/os/Handler;

    .line 12
    .line 13
    iput-object p3, p0, Lik3;->i:Ly8;

    .line 14
    .line 15
    iget-object p1, p3, Ly8;->a:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast p1, Ljava/util/Set;

    .line 18
    .line 19
    iput-object p1, p0, Lik3;->h:Ljava/util/Set;

    .line 20
    .line 21
    sget-object p1, Lik3;->l:Ltj3;

    .line 22
    .line 23
    iput-object p1, p0, Lik3;->g:Ltj3;

    .line 24
    .line 25
    return-void
.end method


# virtual methods
.method public final b(I)V
    .registers 3

    .line 1
    iget-object p0, p0, Lik3;->k:Lc6;

    .line 2
    .line 3
    iget-object v0, p0, Lc6;->f:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Ldx0;

    .line 6
    .line 7
    iget-object v0, v0, Ldx0;->m:Ljava/util/concurrent/ConcurrentHashMap;

    .line 8
    .line 9
    iget-object p0, p0, Lc6;->c:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast p0, Lv7;

    .line 12
    .line 13
    invoke-virtual {v0, p0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    check-cast p0, Lzj3;

    .line 18
    .line 19
    if-eqz p0, :cond_26

    .line 20
    .line 21
    iget-boolean v0, p0, Lzj3;->l:Z

    .line 22
    .line 23
    if-eqz v0, :cond_23

    .line 24
    .line 25
    new-instance p1, Lgy;

    .line 26
    .line 27
    const/16 v0, 0x11

    .line 28
    .line 29
    invoke-direct {p1, v0}, Lgy;-><init>(I)V

    .line 30
    .line 31
    .line 32
    invoke-virtual {p0, p1}, Lzj3;->p(Lgy;)V

    .line 33
    .line 34
    .line 35
    return-void

    .line 36
    :cond_23
    invoke-virtual {p0, p1}, Lzj3;->b(I)V

    .line 37
    .line 38
    .line 39
    :cond_26
    return-void
.end method

.method public final c(Lgy;)V
    .registers 2

    .line 1
    iget-object p0, p0, Lik3;->k:Lc6;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lc6;->l(Lgy;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final d()V
    .registers 10

    .line 1
    iget-object v0, p0, Lik3;->j:Lxn2;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    const-string v1, "<<default account>>"

    .line 7
    .line 8
    const/4 v2, 0x0

    .line 9
    const/4 v3, 0x1

    .line 10
    const/4 v4, 0x0

    .line 11
    :try_start_a
    iget-object v5, v0, Lxn2;->D:Ly8;

    .line 12
    .line 13
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    new-instance v5, Landroid/accounts/Account;

    .line 17
    .line 18
    const-string v6, "com.google"

    .line 19
    .line 20
    invoke-direct {v5, v1, v6}, Landroid/accounts/Account;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    iget-object v6, v5, Landroid/accounts/Account;->name:Ljava/lang/String;

    .line 24
    .line 25
    invoke-virtual {v1, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result v1

    .line 29
    if-eqz v1, :cond_6b

    .line 30
    .line 31
    iget-object v1, v0, Lhi;->c:Landroid/content/Context;

    .line 32
    .line 33
    sget-object v6, Lft2;->c:Ljava/util/concurrent/locks/ReentrantLock;

    .line 34
    .line 35
    invoke-static {v1}, Lmw1;->k(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    sget-object v6, Lft2;->c:Ljava/util/concurrent/locks/ReentrantLock;

    .line 39
    .line 40
    invoke-virtual {v6}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V
    :try_end_2a
    .catch Landroid/os/RemoteException; {:try_start_a .. :try_end_2a} :catch_69

    .line 41
    .line 42
    .line 43
    :try_start_2a
    sget-object v7, Lft2;->d:Lft2;

    .line 44
    .line 45
    if-nez v7, :cond_3c

    .line 46
    .line 47
    new-instance v7, Lft2;

    .line 48
    .line 49
    invoke-virtual {v1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    invoke-direct {v7, v1}, Lft2;-><init>(Landroid/content/Context;)V

    .line 54
    .line 55
    .line 56
    sput-object v7, Lft2;->d:Lft2;
    :try_end_39
    .catchall {:try_start_2a .. :try_end_39} :catchall_3a

    .line 57
    .line 58
    goto :goto_3c

    .line 59
    :catchall_3a
    move-exception v0

    .line 60
    goto :goto_65

    .line 61
    :cond_3c
    :goto_3c
    :try_start_3c
    invoke-virtual {v6}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 62
    .line 63
    .line 64
    const-string v1, "defaultGoogleSignInAccount"

    .line 65
    .line 66
    invoke-virtual {v7, v1}, Lft2;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object v1

    .line 70
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 71
    .line 72
    .line 73
    move-result v6

    .line 74
    if-eqz v6, :cond_4c

    .line 75
    .line 76
    goto :goto_6b

    .line 77
    :cond_4c
    new-instance v6, Ljava/lang/StringBuilder;

    .line 78
    .line 79
    const-string v8, "googleSignInAccount:"

    .line 80
    .line 81
    invoke-direct {v6, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 82
    .line 83
    .line 84
    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 85
    .line 86
    .line 87
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 88
    .line 89
    .line 90
    move-result-object v1

    .line 91
    invoke-virtual {v7, v1}, Lft2;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 92
    .line 93
    .line 94
    move-result-object v1
    :try_end_5e
    .catch Landroid/os/RemoteException; {:try_start_3c .. :try_end_5e} :catch_69

    .line 95
    if-eqz v1, :cond_6b

    .line 96
    .line 97
    :try_start_60
    invoke-static {v1}, Lcom/google/android/gms/auth/api/signin/GoogleSignInAccount;->b(Ljava/lang/String;)Lcom/google/android/gms/auth/api/signin/GoogleSignInAccount;

    .line 98
    .line 99
    .line 100
    move-result-object v1
    :try_end_64
    .catch Lorg/json/JSONException; {:try_start_60 .. :try_end_64} :catch_6b
    .catch Landroid/os/RemoteException; {:try_start_60 .. :try_end_64} :catch_69

    .line 101
    goto :goto_6c

    .line 102
    :goto_65
    :try_start_65
    invoke-virtual {v6}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 103
    .line 104
    .line 105
    throw v0

    .line 106
    :catch_69
    move-exception v0

    .line 107
    goto :goto_c2

    .line 108
    :catch_6b
    :cond_6b
    :goto_6b
    move-object v1, v4

    .line 109
    :goto_6c
    new-instance v6, Lyk3;

    .line 110
    .line 111
    iget-object v7, v0, Lxn2;->F:Ljava/lang/Integer;

    .line 112
    .line 113
    invoke-static {v7}, Lmw1;->k(Ljava/lang/Object;)V

    .line 114
    .line 115
    .line 116
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 117
    .line 118
    .line 119
    move-result v7

    .line 120
    const/4 v8, 0x2

    .line 121
    invoke-direct {v6, v8, v5, v7, v1}, Lyk3;-><init>(ILandroid/accounts/Account;ILcom/google/android/gms/auth/api/signin/GoogleSignInAccount;)V

    .line 122
    .line 123
    .line 124
    invoke-virtual {v0}, Lhi;->t()Landroid/os/IInterface;

    .line 125
    .line 126
    .line 127
    move-result-object v0

    .line 128
    check-cast v0, Lmk3;

    .line 129
    .line 130
    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    .line 131
    .line 132
    .line 133
    move-result-object v1

    .line 134
    iget-object v5, v0, Lvj3;->f:Ljava/lang/String;

    .line 135
    .line 136
    invoke-virtual {v1, v5}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    .line 137
    .line 138
    .line 139
    sget v5, Lek3;->a:I

    .line 140
    .line 141
    invoke-virtual {v1, v3}, Landroid/os/Parcel;->writeInt(I)V

    .line 142
    .line 143
    .line 144
    const/16 v5, 0x4f45

    .line 145
    .line 146
    invoke-static {v1, v5}, Lmt3;->v(Landroid/os/Parcel;I)I

    .line 147
    .line 148
    .line 149
    move-result v5

    .line 150
    const/4 v7, 0x4

    .line 151
    invoke-static {v1, v3, v7}, Lmt3;->x(Landroid/os/Parcel;II)V

    .line 152
    .line 153
    .line 154
    invoke-virtual {v1, v3}, Landroid/os/Parcel;->writeInt(I)V

    .line 155
    .line 156
    .line 157
    invoke-static {v1, v8, v6, v2}, Lmt3;->q(Landroid/os/Parcel;ILandroid/os/Parcelable;I)V

    .line 158
    .line 159
    .line 160
    invoke-static {v1, v5}, Lmt3;->w(Landroid/os/Parcel;I)V

    .line 161
    .line 162
    .line 163
    invoke-virtual {v1, p0}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V

    .line 164
    .line 165
    .line 166
    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    .line 167
    .line 168
    .line 169
    move-result-object v5
    :try_end_a9
    .catch Landroid/os/RemoteException; {:try_start_65 .. :try_end_a9} :catch_69

    .line 170
    :try_start_a9
    iget-object v0, v0, Lvj3;->e:Landroid/os/IBinder;

    .line 171
    .line 172
    const/16 v6, 0xc

    .line 173
    .line 174
    invoke-interface {v0, v6, v1, v5, v2}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    .line 175
    .line 176
    .line 177
    invoke-virtual {v5}, Landroid/os/Parcel;->readException()V
    :try_end_b3
    .catchall {:try_start_a9 .. :try_end_b3} :catchall_ba

    .line 178
    .line 179
    .line 180
    :try_start_b3
    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    .line 181
    .line 182
    .line 183
    invoke-virtual {v5}, Landroid/os/Parcel;->recycle()V

    .line 184
    .line 185
    .line 186
    goto :goto_e7

    .line 187
    :catchall_ba
    move-exception v0

    .line 188
    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    .line 189
    .line 190
    .line 191
    invoke-virtual {v5}, Landroid/os/Parcel;->recycle()V

    .line 192
    .line 193
    .line 194
    throw v0
    :try_end_c2
    .catch Landroid/os/RemoteException; {:try_start_b3 .. :try_end_c2} :catch_69

    .line 195
    :goto_c2
    const-string v1, "Remote service probably died when signIn is called"

    .line 196
    .line 197
    const-string v5, "SignInClientImpl"

    .line 198
    .line 199
    invoke-static {v5, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 200
    .line 201
    .line 202
    :try_start_c9
    new-instance v1, Ltk3;

    .line 203
    .line 204
    new-instance v6, Lgy;

    .line 205
    .line 206
    const/16 v7, 0x8

    .line 207
    .line 208
    invoke-direct {v6, v7, v4}, Lgy;-><init>(ILandroid/app/PendingIntent;)V

    .line 209
    .line 210
    .line 211
    invoke-direct {v1, v3, v6, v4}, Ltk3;-><init>(ILgy;Lal3;)V

    .line 212
    .line 213
    .line 214
    new-instance v3, Lyu0;

    .line 215
    .line 216
    const/16 v4, 0x12

    .line 217
    .line 218
    invoke-direct {v3, v4, p0, v1, v2}, Lyu0;-><init>(ILjava/lang/Object;Ljava/lang/Object;Z)V

    .line 219
    .line 220
    .line 221
    iget-object p0, p0, Lik3;->f:Landroid/os/Handler;

    .line 222
    .line 223
    invoke-virtual {p0, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_e1
    .catch Landroid/os/RemoteException; {:try_start_c9 .. :try_end_e1} :catch_e2

    .line 224
    .line 225
    .line 226
    goto :goto_e7

    .line 227
    :catch_e2
    const-string p0, "ISignInCallbacks#onSignInComplete should be executed from the same process, unexpected RemoteException."

    .line 228
    .line 229
    invoke-static {v5, p0, v0}, Landroid/util/Log;->wtf(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 230
    .line 231
    .line 232
    :goto_e7
    return-void
.end method
