###### Class defpackage.rb2 (rb2)
.class public final Lrb2;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public a:I

.field public b:I

.field public c:Z

.field public d:Z
