###### Class defpackage.f0 (f0)
.class public abstract Lf0;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field protected memoizedHashCode:I


# virtual methods
.method public abstract a()I
.end method

.method public final b(Lpj2;)I
    .registers 5

    .line 1
    move-object v0, p0

    .line 2
    check-cast v0, Lkv0;

    .line 3
    .line 4
    iget v1, v0, Lkv0;->memoizedSerializedSize:I

    .line 5
    .line 6
    const/4 v2, -0x1

    .line 7
    if-ne v1, v2, :cond_f

    .line 8
    .line 9
    invoke-interface {p1, p0}, Lpj2;->f(Lf0;)I

    .line 10
    .line 11
    .line 12
    move-result p0

    .line 13
    iput p0, v0, Lkv0;->memoizedSerializedSize:I

    .line 14
    .line 15
    return p0

    .line 16
    :cond_f
    return v1
.end method

.method public abstract c(Lyu;)V
.end method
