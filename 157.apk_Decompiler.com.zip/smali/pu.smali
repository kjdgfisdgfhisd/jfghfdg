###### Class defpackage.pu (pu)
.class public final Lpu;
.super Landroid/animation/AnimatorListenerAdapter;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# virtual methods
.method public final onAnimationCancel(Landroid/animation/Animator;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Landroid/animation/Animator;->end()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
