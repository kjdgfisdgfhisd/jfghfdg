###### Class defpackage.wr (wr)
.class public final Lwr;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field public static final b:Lwr;

.field public static final c:Lwr;


# instance fields
.field public final a:Z


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lwr;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lwr;-><init>(Z)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Lwr;->b:Lwr;

    .line 8
    .line 9
    new-instance v0, Lwr;

    .line 10
    .line 11
    const/4 v1, 0x1

    .line 12
    invoke-direct {v0, v1}, Lwr;-><init>(Z)V

    .line 13
    .line 14
    .line 15
    sput-object v0, Lwr;->c:Lwr;

    .line 16
    .line 17
    return-void
.end method

.method public constructor <init>(Z)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-boolean p1, p0, Lwr;->a:Z

    .line 5
    .line 6
    return-void
.end method
