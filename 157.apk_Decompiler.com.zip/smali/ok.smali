###### Class defpackage.ok (ok)
.class public interface abstract Lok;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# virtual methods
.method public abstract d(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;
.end method

.method public abstract h(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;
.end method

.method public abstract j(Landroid/graphics/Bitmap;)V
.end method

.method public abstract k(I)V
.end method

.method public abstract n()V
.end method
