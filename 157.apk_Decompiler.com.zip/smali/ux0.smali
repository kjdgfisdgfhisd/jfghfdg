###### Class defpackage.ux0 (ux0)
.class public final Lux0;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final a:D

.field public final b:D

.field public final c:D

.field public final d:I


# direct methods
.method public constructor <init>(I)V
    .registers 37

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move/from16 v1, p1

    .line 4
    .line 5
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    iput v1, v0, Lux0;->d:I

    .line 9
    .line 10
    sget-object v2, Lca3;->k:Lca3;

    .line 11
    .line 12
    const/high16 v3, 0xff0000

    .line 13
    .line 14
    and-int/2addr v3, v1

    .line 15
    shr-int/lit8 v3, v3, 0x10

    .line 16
    .line 17
    const v4, 0xff00

    .line 18
    .line 19
    .line 20
    and-int/2addr v4, v1

    .line 21
    shr-int/lit8 v4, v4, 0x8

    .line 22
    .line 23
    and-int/lit16 v5, v1, 0xff

    .line 24
    .line 25
    invoke-static {v3}, Lls0;->q(I)D

    .line 26
    .line 27
    .line 28
    move-result-wide v6

    .line 29
    invoke-static {v4}, Lls0;->q(I)D

    .line 30
    .line 31
    .line 32
    move-result-wide v3

    .line 33
    invoke-static {v5}, Lls0;->q(I)D

    .line 34
    .line 35
    .line 36
    move-result-wide v8

    .line 37
    const-wide v10, 0x3fda63c2e8477c96L    # 0.41233895

    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    mul-double/2addr v10, v6

    .line 43
    const-wide v12, 0x3fd6e341ae4b2c79L    # 0.35762064

    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    mul-double/2addr v12, v3

    .line 49
    add-double/2addr v12, v10

    .line 50
    const-wide v10, 0x3fc71af7273e5d5eL    # 0.18051042

    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    mul-double/2addr v10, v8

    .line 56
    add-double/2addr v10, v12

    .line 57
    const-wide v12, 0x3fcb367a0f9096bcL    # 0.2126

    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    mul-double/2addr v12, v6

    .line 63
    const-wide v14, 0x3fe6e2eb1c432ca5L    # 0.7152

    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    mul-double/2addr v14, v3

    .line 69
    add-double/2addr v14, v12

    .line 70
    const-wide v12, 0x3fb27bb2fec56d5dL    # 0.0722

    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    mul-double/2addr v12, v8

    .line 76
    add-double/2addr v12, v14

    .line 77
    const-wide v14, 0x3f93c8fde0401c25L    # 0.01932141

    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    mul-double/2addr v6, v14

    .line 83
    const-wide v14, 0x3fbe818525c434ceL    # 0.11916382

    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    mul-double/2addr v3, v14

    .line 89
    add-double/2addr v3, v6

    .line 90
    const-wide v6, 0x3fee693974c0c730L    # 0.95034478

    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    mul-double/2addr v8, v6

    .line 96
    add-double/2addr v8, v3

    .line 97
    sget-object v3, Ll60;->a:[[D

    .line 98
    .line 99
    const/4 v4, 0x0

    .line 100
    aget-object v6, v3, v4

    .line 101
    .line 102
    aget-wide v14, v6, v4

    .line 103
    .line 104
    mul-double/2addr v14, v10

    .line 105
    const/4 v7, 0x1

    .line 106
    aget-wide v16, v6, v7

    .line 107
    .line 108
    mul-double v16, v16, v12

    .line 109
    .line 110
    add-double v16, v16, v14

    .line 111
    .line 112
    const/4 v14, 0x2

    .line 113
    aget-wide v18, v6, v14

    .line 114
    .line 115
    mul-double v18, v18, v8

    .line 116
    .line 117
    add-double v18, v18, v16

    .line 118
    .line 119
    aget-object v6, v3, v7

    .line 120
    .line 121
    aget-wide v15, v6, v4

    .line 122
    .line 123
    mul-double/2addr v15, v10

    .line 124
    aget-wide v20, v6, v7

    .line 125
    .line 126
    mul-double v20, v20, v12

    .line 127
    .line 128
    add-double v20, v20, v15

    .line 129
    .line 130
    aget-wide v15, v6, v14

    .line 131
    .line 132
    mul-double/2addr v15, v8

    .line 133
    add-double v15, v15, v20

    .line 134
    .line 135
    aget-object v3, v3, v14

    .line 136
    .line 137
    aget-wide v20, v3, v4

    .line 138
    .line 139
    mul-double v10, v10, v20

    .line 140
    .line 141
    aget-wide v20, v3, v7

    .line 142
    .line 143
    mul-double v12, v12, v20

    .line 144
    .line 145
    add-double/2addr v12, v10

    .line 146
    aget-wide v10, v3, v14

    .line 147
    .line 148
    mul-double/2addr v8, v10

    .line 149
    add-double/2addr v8, v12

    .line 150
    iget-object v3, v2, Lca3;->g:[D

    .line 151
    .line 152
    iget-wide v10, v2, Lca3;->i:D

    .line 153
    .line 154
    iget-wide v12, v2, Lca3;->d:D

    .line 155
    .line 156
    move/from16 v17, v4

    .line 157
    .line 158
    move v6, v5

    .line 159
    iget-wide v4, v2, Lca3;->a:D

    .line 160
    .line 161
    aget-wide v20, v3, v17

    .line 162
    .line 163
    mul-double v20, v20, v18

    .line 164
    .line 165
    aget-wide v18, v3, v7

    .line 166
    .line 167
    mul-double v18, v18, v15

    .line 168
    .line 169
    aget-wide v15, v3, v14

    .line 170
    .line 171
    mul-double/2addr v15, v8

    .line 172
    iget-wide v8, v2, Lca3;->h:D

    .line 173
    .line 174
    invoke-static/range {v20 .. v21}, Ljava/lang/Math;->abs(D)D

    .line 175
    .line 176
    .line 177
    move-result-wide v22

    .line 178
    mul-double v22, v22, v8

    .line 179
    .line 180
    const-wide/high16 v24, 0x4059000000000000L    # 100.0

    .line 181
    .line 182
    move v3, v7

    .line 183
    move-wide/from16 v26, v8

    .line 184
    .line 185
    div-double v7, v22, v24

    .line 186
    .line 187
    move-wide/from16 v22, v4

    .line 188
    .line 189
    move v5, v3

    .line 190
    const-wide v3, 0x3fdae147ae147ae1L    # 0.42

    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    invoke-static {v7, v8, v3, v4}, Ljava/lang/Math;->pow(DD)D

    .line 196
    .line 197
    .line 198
    move-result-wide v7

    .line 199
    invoke-static/range {v18 .. v19}, Ljava/lang/Math;->abs(D)D

    .line 200
    .line 201
    .line 202
    move-result-wide v28

    .line 203
    mul-double v28, v28, v26

    .line 204
    .line 205
    move/from16 v30, v5

    .line 206
    .line 207
    move v9, v6

    .line 208
    div-double v5, v28, v24

    .line 209
    .line 210
    invoke-static {v5, v6, v3, v4}, Ljava/lang/Math;->pow(DD)D

    .line 211
    .line 212
    .line 213
    move-result-wide v5

    .line 214
    invoke-static/range {v15 .. v16}, Ljava/lang/Math;->abs(D)D

    .line 215
    .line 216
    .line 217
    move-result-wide v28

    .line 218
    mul-double v28, v28, v26

    .line 219
    .line 220
    move/from16 v26, v14

    .line 221
    .line 222
    move-wide/from16 v31, v15

    .line 223
    .line 224
    div-double v14, v28, v24

    .line 225
    .line 226
    invoke-static {v14, v15, v3, v4}, Ljava/lang/Math;->pow(DD)D

    .line 227
    .line 228
    .line 229
    move-result-wide v3

    .line 230
    invoke-static/range {v20 .. v21}, Ljava/lang/Math;->signum(D)D

    .line 231
    .line 232
    .line 233
    move-result-wide v14

    .line 234
    const-wide/high16 v20, 0x4079000000000000L    # 400.0

    .line 235
    .line 236
    mul-double v14, v14, v20

    .line 237
    .line 238
    mul-double/2addr v14, v7

    .line 239
    const-wide v27, 0x403b2147ae147ae1L    # 27.13

    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    add-double v7, v7, v27

    .line 245
    .line 246
    div-double/2addr v14, v7

    .line 247
    invoke-static/range {v18 .. v19}, Ljava/lang/Math;->signum(D)D

    .line 248
    .line 249
    .line 250
    move-result-wide v7

    .line 251
    mul-double v7, v7, v20

    .line 252
    .line 253
    mul-double/2addr v7, v5

    .line 254
    add-double v5, v5, v27

    .line 255
    .line 256
    div-double/2addr v7, v5

    .line 257
    invoke-static/range {v31 .. v32}, Ljava/lang/Math;->signum(D)D

    .line 258
    .line 259
    .line 260
    move-result-wide v5

    .line 261
    mul-double v5, v5, v20

    .line 262
    .line 263
    mul-double/2addr v5, v3

    .line 264
    add-double v3, v3, v27

    .line 265
    .line 266
    div-double/2addr v5, v3

    .line 267
    const-wide/high16 v3, 0x4026000000000000L    # 11.0

    .line 268
    .line 269
    mul-double v18, v14, v3

    .line 270
    .line 271
    const-wide/high16 v20, -0x3fd8000000000000L    # -12.0

    .line 272
    .line 273
    mul-double v20, v20, v7

    .line 274
    .line 275
    add-double v20, v20, v18

    .line 276
    .line 277
    add-double v20, v20, v5

    .line 278
    .line 279
    div-double v3, v20, v3

    .line 280
    .line 281
    add-double v18, v14, v7

    .line 282
    .line 283
    const-wide/high16 v20, 0x4000000000000000L    # 2.0

    .line 284
    .line 285
    mul-double v27, v5, v20

    .line 286
    .line 287
    sub-double v18, v18, v27

    .line 288
    .line 289
    const-wide/high16 v27, 0x4022000000000000L    # 9.0

    .line 290
    .line 291
    move-wide/from16 v31, v5

    .line 292
    .line 293
    div-double v5, v18, v27

    .line 294
    .line 295
    const-wide/high16 v18, 0x4034000000000000L    # 20.0

    .line 296
    .line 297
    mul-double v27, v14, v18

    .line 298
    .line 299
    mul-double v7, v7, v18

    .line 300
    .line 301
    add-double v27, v27, v7

    .line 302
    .line 303
    const-wide/high16 v33, 0x4035000000000000L    # 21.0

    .line 304
    .line 305
    mul-double v33, v33, v31

    .line 306
    .line 307
    add-double v33, v33, v27

    .line 308
    .line 309
    div-double v33, v33, v18

    .line 310
    .line 311
    const-wide/high16 v27, 0x4044000000000000L    # 40.0

    .line 312
    .line 313
    mul-double v14, v14, v27

    .line 314
    .line 315
    add-double/2addr v14, v7

    .line 316
    add-double v14, v14, v31

    .line 317
    .line 318
    div-double v14, v14, v18

    .line 319
    .line 320
    invoke-static {v5, v6, v3, v4}, Ljava/lang/Math;->atan2(DD)D

    .line 321
    .line 322
    .line 323
    move-result-wide v7

    .line 324
    invoke-static {v7, v8}, Ljava/lang/Math;->toDegrees(D)D

    .line 325
    .line 326
    .line 327
    move-result-wide v7

    .line 328
    const-wide/16 v18, 0x0

    .line 329
    .line 330
    cmpg-double v16, v7, v18

    .line 331
    .line 332
    const-wide v18, 0x4076800000000000L    # 360.0

    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    if-gez v16, :cond_155

    .line 338
    .line 339
    add-double v7, v7, v18

    .line 340
    .line 341
    goto :goto_15b

    .line 342
    :cond_155
    cmpl-double v16, v7, v18

    .line 343
    .line 344
    if-ltz v16, :cond_15b

    .line 345
    .line 346
    sub-double v7, v7, v18

    .line 347
    .line 348
    :cond_15b
    :goto_15b
    invoke-static {v7, v8}, Ljava/lang/Math;->toRadians(D)D

    .line 349
    .line 350
    .line 351
    move-result-wide v27

    .line 352
    move-wide/from16 v31, v10

    .line 353
    .line 354
    move v11, v9

    .line 355
    iget-wide v9, v2, Lca3;->b:D

    .line 356
    .line 357
    mul-double/2addr v14, v9

    .line 358
    div-double v14, v14, v22

    .line 359
    .line 360
    iget-wide v9, v2, Lca3;->j:D

    .line 361
    .line 362
    mul-double/2addr v9, v12

    .line 363
    invoke-static {v14, v15, v9, v10}, Ljava/lang/Math;->pow(DD)D

    .line 364
    .line 365
    .line 366
    move-result-wide v9

    .line 367
    mul-double v9, v9, v24

    .line 368
    .line 369
    div-double v9, v9, v24

    .line 370
    .line 371
    invoke-static {v9, v10}, Ljava/lang/Math;->sqrt(D)D

    .line 372
    .line 373
    .line 374
    const-wide/high16 v14, 0x4010000000000000L    # 4.0

    .line 375
    .line 376
    add-double v14, v22, v14

    .line 377
    .line 378
    const-wide v22, 0x403423d70a3d70a4L    # 20.14

    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    cmpg-double v16, v7, v22

    .line 384
    .line 385
    if-gez v16, :cond_185

    .line 386
    .line 387
    add-double v18, v7, v18

    .line 388
    .line 389
    goto :goto_187

    .line 390
    :cond_185
    move-wide/from16 v18, v7

    .line 391
    .line 392
    :goto_187
    invoke-static/range {v18 .. v19}, Ljava/lang/Math;->toRadians(D)D

    .line 393
    .line 394
    .line 395
    move-result-wide v18

    .line 396
    add-double v18, v18, v20

    .line 397
    .line 398
    invoke-static/range {v18 .. v19}, Ljava/lang/Math;->cos(D)D

    .line 399
    .line 400
    .line 401
    move-result-wide v18

    .line 402
    const-wide v20, 0x400e666666666666L    # 3.8

    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    add-double v18, v18, v20

    .line 408
    .line 409
    const-wide/high16 v20, 0x3fd0000000000000L    # 0.25

    .line 410
    .line 411
    mul-double v18, v18, v20

    .line 412
    .line 413
    const-wide v20, 0x40ae0c4ec4ec4ec5L    # 3846.153846153846

    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    mul-double v18, v18, v20

    .line 419
    .line 420
    move-wide/from16 v20, v9

    .line 421
    .line 422
    iget-wide v9, v2, Lca3;->e:D

    .line 423
    .line 424
    mul-double v18, v18, v9

    .line 425
    .line 426
    iget-wide v9, v2, Lca3;->c:D

    .line 427
    .line 428
    mul-double v18, v18, v9

    .line 429
    .line 430
    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->hypot(DD)D

    .line 431
    .line 432
    .line 433
    move-result-wide v3

    .line 434
    mul-double v3, v3, v18

    .line 435
    .line 436
    const-wide v5, 0x3fd3851eb851eb85L    # 0.305

    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    add-double v33, v33, v5

    .line 442
    .line 443
    div-double v3, v3, v33

    .line 444
    .line 445
    const-wide v5, 0x3fd28f5c28f5c28fL    # 0.29

    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    iget-wide v9, v2, Lca3;->f:D

    .line 451
    .line 452
    invoke-static {v5, v6, v9, v10}, Ljava/lang/Math;->pow(DD)D

    .line 453
    .line 454
    .line 455
    move-result-wide v5

    .line 456
    const-wide v9, 0x3ffa3d70a3d70a3dL    # 1.64

    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    sub-double/2addr v9, v5

    .line 462
    const-wide v5, 0x3fe75c28f5c28f5cL    # 0.73

    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    invoke-static {v9, v10, v5, v6}, Ljava/lang/Math;->pow(DD)D

    .line 468
    .line 469
    .line 470
    move-result-wide v5

    .line 471
    const-wide v9, 0x3feccccccccccccdL    # 0.9

    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    invoke-static {v3, v4, v9, v10}, Ljava/lang/Math;->pow(DD)D

    .line 477
    .line 478
    .line 479
    move-result-wide v2

    .line 480
    mul-double/2addr v2, v5

    .line 481
    invoke-static/range {v20 .. v21}, Ljava/lang/Math;->sqrt(D)D

    .line 482
    .line 483
    .line 484
    move-result-wide v4

    .line 485
    mul-double/2addr v4, v2

    .line 486
    mul-double v9, v4, v31

    .line 487
    .line 488
    mul-double/2addr v2, v12

    .line 489
    div-double/2addr v2, v14

    .line 490
    invoke-static {v2, v3}, Ljava/lang/Math;->sqrt(D)D

    .line 491
    .line 492
    .line 493
    const-wide v2, 0x3f9758e219652bd4L    # 0.0228

    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    mul-double/2addr v9, v2

    .line 499
    invoke-static {v9, v10}, Ljava/lang/Math;->log1p(D)D

    .line 500
    .line 501
    .line 502
    invoke-static/range {v27 .. v28}, Ljava/lang/Math;->cos(D)D

    .line 503
    .line 504
    .line 505
    invoke-static/range {v27 .. v28}, Ljava/lang/Math;->sin(D)D

    .line 506
    .line 507
    .line 508
    iput-wide v7, v0, Lux0;->a:D

    .line 509
    .line 510
    iput-wide v4, v0, Lux0;->b:D

    .line 511
    .line 512
    shr-int/lit8 v2, v1, 0x10

    .line 513
    .line 514
    and-int/lit16 v2, v2, 0xff

    .line 515
    .line 516
    invoke-static {v2}, Lls0;->q(I)D

    .line 517
    .line 518
    .line 519
    move-result-wide v2

    .line 520
    shr-int/lit8 v1, v1, 0x8

    .line 521
    .line 522
    and-int/lit16 v1, v1, 0xff

    .line 523
    .line 524
    invoke-static {v1}, Lls0;->q(I)D

    .line 525
    .line 526
    .line 527
    move-result-wide v4

    .line 528
    invoke-static {v11}, Lls0;->q(I)D

    .line 529
    .line 530
    .line 531
    move-result-wide v6

    .line 532
    const/4 v1, 0x3

    .line 533
    new-array v1, v1, [D

    .line 534
    .line 535
    aput-wide v2, v1, v17

    .line 536
    .line 537
    aput-wide v4, v1, v30

    .line 538
    .line 539
    aput-wide v6, v1, v26

    .line 540
    .line 541
    sget-object v2, Lls0;->a:[[D

    .line 542
    .line 543
    invoke-static {v1, v2}, Lmw1;->u([D[[D)[D

    .line 544
    .line 545
    .line 546
    move-result-object v1

    .line 547
    aget-wide v2, v1, v30

    .line 548
    .line 549
    div-double v2, v2, v24

    .line 550
    .line 551
    invoke-static {v2, v3}, Lls0;->n(D)D

    .line 552
    .line 553
    .line 554
    move-result-wide v1

    .line 555
    const-wide/high16 v3, 0x405d000000000000L    # 116.0

    .line 556
    .line 557
    mul-double/2addr v1, v3

    .line 558
    const-wide/high16 v3, 0x4030000000000000L    # 16.0

    .line 559
    .line 560
    sub-double/2addr v1, v3

    .line 561
    iput-wide v1, v0, Lux0;->c:D

    .line 562
    .line 563
    return-void
.end method

.method public static a(DDD)Lux0;
    .registers 49

    .line 1
    sget-object v0, Lvs3;->e:[D

    .line 2
    .line 3
    const-wide v1, 0x3f1a36e2eb1c432dL    # 1.0E-4

    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    cmpg-double v3, p2, v1

    .line 9
    .line 10
    if-ltz v3, :cond_3c7

    .line 11
    .line 12
    cmpg-double v1, p4, v1

    .line 13
    .line 14
    if-ltz v1, :cond_3c7

    .line 15
    .line 16
    const-wide v1, 0x4058fffe5c91d14eL    # 99.9999

    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    cmpl-double v1, p4, v1

    .line 22
    .line 23
    if-lez v1, :cond_1a

    .line 24
    .line 25
    goto/16 :goto_3c7

    .line 26
    .line 27
    :cond_1a
    const-wide v1, 0x4076800000000000L    # 360.0

    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    rem-double v3, p0, v1

    .line 33
    .line 34
    const-wide/16 v5, 0x0

    .line 35
    .line 36
    cmpg-double v7, v3, v5

    .line 37
    .line 38
    if-gez v7, :cond_28

    .line 39
    .line 40
    add-double/2addr v3, v1

    .line 41
    :cond_28
    const-wide v1, 0x4066800000000000L    # 180.0

    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    div-double/2addr v3, v1

    .line 47
    const-wide v1, 0x400921fb54442d18L    # Math.PI

    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    mul-double/2addr v3, v1

    .line 53
    invoke-static/range {p4 .. p5}, Lls0;->v(D)D

    .line 54
    .line 55
    .line 56
    move-result-wide v1

    .line 57
    invoke-static {v1, v2}, Ljava/lang/Math;->sqrt(D)D

    .line 58
    .line 59
    .line 60
    move-result-wide v7

    .line 61
    const-wide/high16 v9, 0x4026000000000000L    # 11.0

    .line 62
    .line 63
    mul-double/2addr v7, v9

    .line 64
    sget-object v11, Lca3;->k:Lca3;

    .line 65
    .line 66
    const-wide v12, 0x3fd28f5c28f5c28fL    # 0.29

    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    iget-wide v14, v11, Lca3;->f:D

    .line 72
    .line 73
    invoke-static {v12, v13, v14, v15}, Ljava/lang/Math;->pow(DD)D

    .line 74
    .line 75
    .line 76
    move-result-wide v12

    .line 77
    const-wide v14, 0x3ffa3d70a3d70a3dL    # 1.64

    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    sub-double/2addr v14, v12

    .line 83
    const-wide v12, 0x3fe75c28f5c28f5cL    # 0.73

    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    invoke-static {v14, v15, v12, v13}, Ljava/lang/Math;->pow(DD)D

    .line 89
    .line 90
    .line 91
    move-result-wide v12

    .line 92
    const-wide/high16 v14, 0x3ff0000000000000L    # 1.0

    .line 93
    .line 94
    div-double v12, v14, v12

    .line 95
    .line 96
    const-wide/high16 v16, 0x4000000000000000L    # 2.0

    .line 97
    .line 98
    add-double v18, v3, v16

    .line 99
    .line 100
    invoke-static/range {v18 .. v19}, Ljava/lang/Math;->cos(D)D

    .line 101
    .line 102
    .line 103
    move-result-wide v18

    .line 104
    const-wide v20, 0x400e666666666666L    # 3.8

    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    add-double v18, v18, v20

    .line 110
    .line 111
    const-wide/high16 v20, 0x3fd0000000000000L    # 0.25

    .line 112
    .line 113
    mul-double v18, v18, v20

    .line 114
    .line 115
    const-wide v20, 0x40ae0c4ec4ec4ec5L    # 3846.153846153846

    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    mul-double v18, v18, v20

    .line 121
    .line 122
    move-wide/from16 v20, v5

    .line 123
    .line 124
    iget-wide v5, v11, Lca3;->e:D

    .line 125
    .line 126
    mul-double v18, v18, v5

    .line 127
    .line 128
    iget-wide v5, v11, Lca3;->c:D

    .line 129
    .line 130
    mul-double v18, v18, v5

    .line 131
    .line 132
    invoke-static {v3, v4}, Ljava/lang/Math;->sin(D)D

    .line 133
    .line 134
    .line 135
    move-result-wide v5

    .line 136
    invoke-static {v3, v4}, Ljava/lang/Math;->cos(D)D

    .line 137
    .line 138
    .line 139
    move-result-wide v22

    .line 140
    const/16 v24, 0x0

    .line 141
    .line 142
    move-wide/from16 p0, v9

    .line 143
    .line 144
    move/from16 v9, v24

    .line 145
    .line 146
    :goto_91
    const/4 v10, 0x5

    .line 147
    move-wide/from16 p4, v14

    .line 148
    .line 149
    const-wide/high16 v25, 0x4059000000000000L    # 100.0

    .line 150
    .line 151
    const/16 v28, 0x2

    .line 152
    .line 153
    if-ge v9, v10, :cond_1d0

    .line 154
    .line 155
    const/16 v29, 0x1

    .line 156
    .line 157
    div-double v14, v7, v25

    .line 158
    .line 159
    cmpl-double v30, p2, v20

    .line 160
    .line 161
    if-eqz v30, :cond_b0

    .line 162
    .line 163
    cmpl-double v30, v7, v20

    .line 164
    .line 165
    if-nez v30, :cond_a7

    .line 166
    .line 167
    goto :goto_b0

    .line 168
    :cond_a7
    invoke-static {v14, v15}, Ljava/lang/Math;->sqrt(D)D

    .line 169
    .line 170
    .line 171
    move-result-wide v30

    .line 172
    div-double v30, p2, v30

    .line 173
    .line 174
    :goto_ad
    move-object/from16 v32, v11

    .line 175
    .line 176
    goto :goto_b3

    .line 177
    :cond_b0
    :goto_b0
    move-wide/from16 v30, v20

    .line 178
    .line 179
    goto :goto_ad

    .line 180
    :goto_b3
    mul-double v10, v30, v12

    .line 181
    .line 182
    move-object/from16 v30, v0

    .line 183
    .line 184
    move-wide/from16 v33, v1

    .line 185
    .line 186
    const-wide v0, 0x3ff1c71c71c71c72L    # 1.1111111111111112

    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    invoke-static {v10, v11, v0, v1}, Ljava/lang/Math;->pow(DD)D

    .line 192
    .line 193
    .line 194
    move-result-wide v0

    .line 195
    move-object/from16 v2, v32

    .line 196
    .line 197
    iget-wide v10, v2, Lca3;->a:D

    .line 198
    .line 199
    move-wide/from16 v31, v0

    .line 200
    .line 201
    iget-wide v0, v2, Lca3;->d:D

    .line 202
    .line 203
    div-double v0, p4, v0

    .line 204
    .line 205
    move-wide/from16 v35, v0

    .line 206
    .line 207
    iget-wide v0, v2, Lca3;->j:D

    .line 208
    .line 209
    div-double v0, v35, v0

    .line 210
    .line 211
    invoke-static {v14, v15, v0, v1}, Ljava/lang/Math;->pow(DD)D

    .line 212
    .line 213
    .line 214
    move-result-wide v0

    .line 215
    mul-double/2addr v0, v10

    .line 216
    iget-wide v10, v2, Lca3;->b:D

    .line 217
    .line 218
    div-double/2addr v0, v10

    .line 219
    const-wide v10, 0x3fd3851eb851eb85L    # 0.305

    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    add-double/2addr v10, v0

    .line 225
    const-wide/high16 v14, 0x4037000000000000L    # 23.0

    .line 226
    .line 227
    mul-double/2addr v10, v14

    .line 228
    mul-double v10, v10, v31

    .line 229
    .line 230
    mul-double v14, v14, v18

    .line 231
    .line 232
    mul-double v35, v31, p0

    .line 233
    .line 234
    mul-double v35, v35, v22

    .line 235
    .line 236
    add-double v35, v35, v14

    .line 237
    .line 238
    const-wide/high16 v14, 0x405b000000000000L    # 108.0

    .line 239
    .line 240
    mul-double v14, v14, v31

    .line 241
    .line 242
    mul-double/2addr v14, v5

    .line 243
    add-double v14, v14, v35

    .line 244
    .line 245
    div-double/2addr v10, v14

    .line 246
    mul-double v14, v10, v22

    .line 247
    .line 248
    mul-double/2addr v10, v5

    .line 249
    const-wide v31, 0x407cc00000000000L    # 460.0

    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    mul-double v0, v0, v31

    .line 255
    .line 256
    const-wide v31, 0x407c300000000000L    # 451.0

    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    mul-double v31, v31, v14

    .line 262
    .line 263
    add-double v31, v31, v0

    .line 264
    .line 265
    const-wide/high16 v35, 0x4072000000000000L    # 288.0

    .line 266
    .line 267
    mul-double v35, v35, v10

    .line 268
    .line 269
    add-double v35, v35, v31

    .line 270
    .line 271
    const-wide v31, 0x4095ec0000000000L    # 1403.0

    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    div-double v35, v35, v31

    .line 277
    .line 278
    const-wide v37, 0x408bd80000000000L    # 891.0

    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    mul-double v37, v37, v14

    .line 284
    .line 285
    sub-double v37, v0, v37

    .line 286
    .line 287
    const-wide v39, 0x4070500000000000L    # 261.0

    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    mul-double v39, v39, v10

    .line 293
    .line 294
    sub-double v37, v37, v39

    .line 295
    .line 296
    div-double v37, v37, v31

    .line 297
    .line 298
    const-wide v39, 0x406b800000000000L    # 220.0

    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    mul-double v14, v14, v39

    .line 304
    .line 305
    sub-double/2addr v0, v14

    .line 306
    const-wide v14, 0x40b89c0000000000L    # 6300.0

    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    mul-double/2addr v10, v14

    .line 312
    sub-double/2addr v0, v10

    .line 313
    div-double v0, v0, v31

    .line 314
    .line 315
    invoke-static/range {v35 .. v36}, Lvs3;->r(D)D

    .line 316
    .line 317
    .line 318
    move-result-wide v14

    .line 319
    invoke-static/range {v37 .. v38}, Lvs3;->r(D)D

    .line 320
    .line 321
    .line 322
    move-result-wide v31

    .line 323
    invoke-static {v0, v1}, Lvs3;->r(D)D

    .line 324
    .line 325
    .line 326
    move-result-wide v0

    .line 327
    const/4 v10, 0x3

    .line 328
    new-array v11, v10, [D

    .line 329
    .line 330
    aput-wide v14, v11, v24

    .line 331
    .line 332
    aput-wide v31, v11, v29

    .line 333
    .line 334
    aput-wide v0, v11, v28

    .line 335
    .line 336
    sget-object v0, Lvs3;->d:[[D

    .line 337
    .line 338
    invoke-static {v11, v0}, Lmw1;->u([D[[D)[D

    .line 339
    .line 340
    .line 341
    move-result-object v0

    .line 342
    aget-wide v14, v0, v24

    .line 343
    .line 344
    cmpg-double v1, v14, v20

    .line 345
    .line 346
    if-ltz v1, :cond_17c

    .line 347
    .line 348
    aget-wide v31, v0, v29

    .line 349
    .line 350
    cmpg-double v1, v31, v20

    .line 351
    .line 352
    if-ltz v1, :cond_17c

    .line 353
    .line 354
    aget-wide v35, v0, v28

    .line 355
    .line 356
    cmpg-double v1, v35, v20

    .line 357
    .line 358
    if-gez v1, :cond_168

    .line 359
    .line 360
    goto :goto_17c

    .line 361
    :cond_168
    aget-wide v37, v30, v24

    .line 362
    .line 363
    aget-wide v39, v30, v29

    .line 364
    .line 365
    aget-wide v41, v30, v28

    .line 366
    .line 367
    mul-double v37, v37, v14

    .line 368
    .line 369
    mul-double v39, v39, v31

    .line 370
    .line 371
    add-double v39, v39, v37

    .line 372
    .line 373
    mul-double v41, v41, v35

    .line 374
    .line 375
    add-double v41, v41, v39

    .line 376
    .line 377
    cmpg-double v1, v41, v20

    .line 378
    .line 379
    if-gtz v1, :cond_17f

    .line 380
    .line 381
    :cond_17c
    :goto_17c
    move/from16 v0, v24

    .line 382
    .line 383
    goto :goto_1d7

    .line 384
    :cond_17f
    const/4 v1, 0x4

    .line 385
    if-eq v9, v1, :cond_1a3

    .line 386
    .line 387
    sub-double v14, v41, v33

    .line 388
    .line 389
    invoke-static {v14, v15}, Ljava/lang/Math;->abs(D)D

    .line 390
    .line 391
    .line 392
    move-result-wide v31

    .line 393
    const-wide v35, 0x3f60624dd2f1a9fcL    # 0.002

    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    cmpg-double v1, v31, v35

    .line 399
    .line 400
    if-gez v1, :cond_192

    .line 401
    .line 402
    goto :goto_1a3

    .line 403
    :cond_192
    mul-double/2addr v14, v7

    .line 404
    mul-double v41, v41, v16

    .line 405
    .line 406
    div-double v14, v14, v41

    .line 407
    .line 408
    sub-double/2addr v7, v14

    .line 409
    add-int/lit8 v9, v9, 0x1

    .line 410
    .line 411
    move-wide/from16 v14, p4

    .line 412
    .line 413
    move-object v11, v2

    .line 414
    move-object/from16 v0, v30

    .line 415
    .line 416
    move-wide/from16 v1, v33

    .line 417
    .line 418
    goto/16 :goto_91

    .line 419
    .line 420
    :cond_1a3
    :goto_1a3
    aget-wide v1, v0, v24

    .line 421
    .line 422
    const-wide v5, 0x405900a3d70a3d71L    # 100.01

    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    cmpl-double v7, v1, v5

    .line 428
    .line 429
    if-gtz v7, :cond_17c

    .line 430
    .line 431
    aget-wide v7, v0, v29

    .line 432
    .line 433
    cmpl-double v7, v7, v5

    .line 434
    .line 435
    if-gtz v7, :cond_17c

    .line 436
    .line 437
    aget-wide v7, v0, v28

    .line 438
    .line 439
    cmpl-double v5, v7, v5

    .line 440
    .line 441
    if-lez v5, :cond_1bb

    .line 442
    .line 443
    goto :goto_17c

    .line 444
    :cond_1bb
    invoke-static {v1, v2}, Lls0;->i(D)I

    .line 445
    .line 446
    .line 447
    move-result v1

    .line 448
    aget-wide v5, v0, v29

    .line 449
    .line 450
    invoke-static {v5, v6}, Lls0;->i(D)I

    .line 451
    .line 452
    .line 453
    move-result v2

    .line 454
    aget-wide v5, v0, v28

    .line 455
    .line 456
    invoke-static {v5, v6}, Lls0;->i(D)I

    .line 457
    .line 458
    .line 459
    move-result v0

    .line 460
    invoke-static {v1, v2, v0}, Lls0;->b(III)I

    .line 461
    .line 462
    .line 463
    move-result v0

    .line 464
    goto :goto_1d7

    .line 465
    :cond_1d0
    move-object/from16 v30, v0

    .line 466
    .line 467
    move-wide/from16 v33, v1

    .line 468
    .line 469
    const/16 v29, 0x1

    .line 470
    .line 471
    goto :goto_17c

    .line 472
    :goto_1d7
    if-eqz v0, :cond_1db

    .line 473
    .line 474
    goto/16 :goto_3d3

    .line 475
    .line 476
    :cond_1db
    const/4 v10, 0x3

    .line 477
    new-array v0, v10, [D

    .line 478
    .line 479
    const-wide/high16 v1, -0x4010000000000000L    # -1.0

    .line 480
    .line 481
    aput-wide v1, v0, v24

    .line 482
    .line 483
    aput-wide v1, v0, v29

    .line 484
    .line 485
    aput-wide v1, v0, v28

    .line 486
    .line 487
    move-object v1, v0

    .line 488
    move-wide/from16 v7, v20

    .line 489
    .line 490
    move-wide v11, v7

    .line 491
    move/from16 v2, v24

    .line 492
    .line 493
    move v6, v2

    .line 494
    move/from16 v5, v29

    .line 495
    .line 496
    :goto_1ef
    const/16 v9, 0xc

    .line 497
    .line 498
    if-ge v6, v9, :cond_2c9

    .line 499
    .line 500
    aget-wide v14, v30, v24

    .line 501
    .line 502
    aget-wide v18, v30, v29

    .line 503
    .line 504
    aget-wide v22, v30, v28

    .line 505
    .line 506
    rem-int/lit8 v9, v6, 0x4

    .line 507
    .line 508
    move/from16 v10, v29

    .line 509
    .line 510
    if-gt v9, v10, :cond_202

    .line 511
    .line 512
    move-wide/from16 v9, v20

    .line 513
    .line 514
    goto :goto_204

    .line 515
    :cond_202
    move-wide/from16 v9, v25

    .line 516
    .line 517
    :goto_204
    rem-int/lit8 v31, v6, 0x2

    .line 518
    .line 519
    if-nez v31, :cond_20c

    .line 520
    .line 521
    move-wide/from16 v31, v20

    .line 522
    .line 523
    :goto_20a
    const/4 v13, 0x4

    .line 524
    goto :goto_20f

    .line 525
    :cond_20c
    move-wide/from16 v31, v25

    .line 526
    .line 527
    goto :goto_20a

    .line 528
    :goto_20f
    if-ge v6, v13, :cond_236

    .line 529
    .line 530
    mul-double v18, v18, v9

    .line 531
    .line 532
    sub-double v18, v33, v18

    .line 533
    .line 534
    mul-double v22, v22, v31

    .line 535
    .line 536
    sub-double v18, v18, v22

    .line 537
    .line 538
    div-double v18, v18, v14

    .line 539
    .line 540
    invoke-static/range {v18 .. v19}, Lvs3;->s(D)Z

    .line 541
    .line 542
    .line 543
    move-result v14

    .line 544
    if-eqz v14, :cond_22f

    .line 545
    .line 546
    const/4 v14, 0x3

    .line 547
    new-array v15, v14, [D

    .line 548
    .line 549
    aput-wide v18, v15, v24

    .line 550
    .line 551
    const/16 v29, 0x1

    .line 552
    .line 553
    aput-wide v9, v15, v29

    .line 554
    .line 555
    aput-wide v31, v15, v28

    .line 556
    .line 557
    :goto_22c
    move/from16 v27, v2

    .line 558
    .line 559
    goto :goto_284

    .line 560
    :cond_22f
    const/4 v14, 0x3

    .line 561
    new-array v15, v14, [D

    .line 562
    .line 563
    fill-array-data v15, :array_3da

    .line 564
    .line 565
    .line 566
    goto :goto_22c

    .line 567
    :cond_236
    const/16 v13, 0x8

    .line 568
    .line 569
    if-ge v6, v13, :cond_262

    .line 570
    .line 571
    mul-double v14, v14, v31

    .line 572
    .line 573
    sub-double v13, v33, v14

    .line 574
    .line 575
    mul-double v22, v22, v9

    .line 576
    .line 577
    sub-double v13, v13, v22

    .line 578
    .line 579
    div-double v13, v13, v18

    .line 580
    .line 581
    invoke-static {v13, v14}, Lvs3;->s(D)Z

    .line 582
    .line 583
    .line 584
    move-result v15

    .line 585
    if-eqz v15, :cond_259

    .line 586
    .line 587
    move/from16 v27, v2

    .line 588
    .line 589
    const/4 v15, 0x3

    .line 590
    new-array v2, v15, [D

    .line 591
    .line 592
    aput-wide v31, v2, v24

    .line 593
    .line 594
    const/16 v29, 0x1

    .line 595
    .line 596
    aput-wide v13, v2, v29

    .line 597
    .line 598
    aput-wide v9, v2, v28

    .line 599
    .line 600
    :goto_257
    move-object v15, v2

    .line 601
    goto :goto_284

    .line 602
    :cond_259
    move/from16 v27, v2

    .line 603
    .line 604
    const/4 v15, 0x3

    .line 605
    new-array v2, v15, [D

    .line 606
    .line 607
    fill-array-data v2, :array_3ea

    .line 608
    .line 609
    .line 610
    goto :goto_257

    .line 611
    :cond_262
    move/from16 v27, v2

    .line 612
    .line 613
    const/4 v2, 0x3

    .line 614
    mul-double/2addr v14, v9

    .line 615
    sub-double v13, v33, v14

    .line 616
    .line 617
    mul-double v18, v18, v31

    .line 618
    .line 619
    sub-double v13, v13, v18

    .line 620
    .line 621
    div-double v13, v13, v22

    .line 622
    .line 623
    invoke-static {v13, v14}, Lvs3;->s(D)Z

    .line 624
    .line 625
    .line 626
    move-result v15

    .line 627
    if-eqz v15, :cond_27f

    .line 628
    .line 629
    new-array v15, v2, [D

    .line 630
    .line 631
    aput-wide v9, v15, v24

    .line 632
    .line 633
    const/16 v29, 0x1

    .line 634
    .line 635
    aput-wide v31, v15, v29

    .line 636
    .line 637
    aput-wide v13, v15, v28

    .line 638
    .line 639
    goto :goto_284

    .line 640
    :cond_27f
    new-array v15, v2, [D

    .line 641
    .line 642
    fill-array-data v15, :array_3fa

    .line 643
    .line 644
    .line 645
    :goto_284
    aget-wide v13, v15, v24

    .line 646
    .line 647
    cmpg-double v2, v13, v20

    .line 648
    .line 649
    if-gez v2, :cond_28b

    .line 650
    .line 651
    goto :goto_2ac

    .line 652
    :cond_28b
    invoke-static {v15}, Lvs3;->q([D)D

    .line 653
    .line 654
    .line 655
    move-result-wide v13

    .line 656
    if-nez v27, :cond_297

    .line 657
    .line 658
    move-wide v7, v13

    .line 659
    move-wide v11, v7

    .line 660
    move-object v0, v15

    .line 661
    move-object v1, v0

    .line 662
    const/4 v2, 0x1

    .line 663
    goto :goto_2c3

    .line 664
    :cond_297
    if-nez v5, :cond_2a5

    .line 665
    .line 666
    move-wide/from16 p0, v7

    .line 667
    .line 668
    move-wide/from16 p4, v11

    .line 669
    .line 670
    move-wide/from16 p2, v13

    .line 671
    .line 672
    invoke-static/range {p0 .. p5}, Lvs3;->a(DDD)Z

    .line 673
    .line 674
    .line 675
    move-result v2

    .line 676
    if-eqz v2, :cond_2ac

    .line 677
    .line 678
    :cond_2a5
    move-wide/from16 p2, v3

    .line 679
    .line 680
    move-wide/from16 p0, v7

    .line 681
    .line 682
    move-wide/from16 p4, v13

    .line 683
    .line 684
    goto :goto_2af

    .line 685
    :cond_2ac
    :goto_2ac
    move/from16 v2, v27

    .line 686
    .line 687
    goto :goto_2c3

    .line 688
    :goto_2af
    invoke-static/range {p0 .. p5}, Lvs3;->a(DDD)Z

    .line 689
    .line 690
    .line 691
    move-result v2

    .line 692
    move-wide/from16 v7, p0

    .line 693
    .line 694
    move-wide/from16 v3, p2

    .line 695
    .line 696
    move-wide/from16 v13, p4

    .line 697
    .line 698
    if-eqz v2, :cond_2c0

    .line 699
    .line 700
    move-wide v11, v13

    .line 701
    move-object v1, v15

    .line 702
    :goto_2bd
    move/from16 v5, v24

    .line 703
    .line 704
    goto :goto_2ac

    .line 705
    :cond_2c0
    move-wide v7, v13

    .line 706
    move-object v0, v15

    .line 707
    goto :goto_2bd

    .line 708
    :goto_2c3
    add-int/lit8 v6, v6, 0x1

    .line 709
    .line 710
    const/16 v29, 0x1

    .line 711
    .line 712
    goto/16 :goto_1ef

    .line 713
    .line 714
    :cond_2c9
    filled-new-array {v0, v1}, [[D

    .line 715
    .line 716
    .line 717
    move-result-object v0

    .line 718
    aget-object v1, v0, v24

    .line 719
    .line 720
    invoke-static {v1}, Lvs3;->q([D)D

    .line 721
    .line 722
    .line 723
    move-result-wide v5

    .line 724
    const/16 v29, 0x1

    .line 725
    .line 726
    aget-object v0, v0, v29

    .line 727
    .line 728
    move/from16 v2, v24

    .line 729
    .line 730
    :goto_2d9
    const/4 v10, 0x3

    .line 731
    if-ge v2, v10, :cond_390

    .line 732
    .line 733
    aget-wide v7, v1, v2

    .line 734
    .line 735
    aget-wide v11, v0, v2

    .line 736
    .line 737
    cmpl-double v9, v7, v11

    .line 738
    .line 739
    if-eqz v9, :cond_388

    .line 740
    .line 741
    cmpg-double v9, v7, v11

    .line 742
    .line 743
    const-wide/high16 v11, 0x3fe0000000000000L    # 0.5

    .line 744
    .line 745
    if-gez v9, :cond_301

    .line 746
    .line 747
    invoke-static {v7, v8}, Lvs3;->E(D)D

    .line 748
    .line 749
    .line 750
    move-result-wide v7

    .line 751
    sub-double/2addr v7, v11

    .line 752
    invoke-static {v7, v8}, Ljava/lang/Math;->floor(D)D

    .line 753
    .line 754
    .line 755
    move-result-wide v7

    .line 756
    double-to-int v7, v7

    .line 757
    aget-wide v8, v0, v2

    .line 758
    .line 759
    invoke-static {v8, v9}, Lvs3;->E(D)D

    .line 760
    .line 761
    .line 762
    move-result-wide v8

    .line 763
    sub-double/2addr v8, v11

    .line 764
    invoke-static {v8, v9}, Ljava/lang/Math;->ceil(D)D

    .line 765
    .line 766
    .line 767
    move-result-wide v8

    .line 768
    :goto_2ff
    double-to-int v8, v8

    .line 769
    goto :goto_317

    .line 770
    :cond_301
    invoke-static {v7, v8}, Lvs3;->E(D)D

    .line 771
    .line 772
    .line 773
    move-result-wide v7

    .line 774
    sub-double/2addr v7, v11

    .line 775
    invoke-static {v7, v8}, Ljava/lang/Math;->ceil(D)D

    .line 776
    .line 777
    .line 778
    move-result-wide v7

    .line 779
    double-to-int v7, v7

    .line 780
    aget-wide v8, v0, v2

    .line 781
    .line 782
    invoke-static {v8, v9}, Lvs3;->E(D)D

    .line 783
    .line 784
    .line 785
    move-result-wide v8

    .line 786
    sub-double/2addr v8, v11

    .line 787
    invoke-static {v8, v9}, Ljava/lang/Math;->floor(D)D

    .line 788
    .line 789
    .line 790
    move-result-wide v8

    .line 791
    goto :goto_2ff

    .line 792
    :goto_317
    move/from16 v9, v24

    .line 793
    .line 794
    const/16 v13, 0x8

    .line 795
    .line 796
    :goto_31b
    if-ge v9, v13, :cond_326

    .line 797
    .line 798
    sub-int v11, v8, v7

    .line 799
    .line 800
    invoke-static {v11}, Ljava/lang/Math;->abs(I)I

    .line 801
    .line 802
    .line 803
    move-result v11

    .line 804
    const/4 v12, 0x1

    .line 805
    if-gt v11, v12, :cond_328

    .line 806
    .line 807
    :cond_326
    move-wide v14, v3

    .line 808
    goto :goto_38b

    .line 809
    :cond_328
    add-int v11, v7, v8

    .line 810
    .line 811
    int-to-double v11, v11

    .line 812
    div-double v11, v11, v16

    .line 813
    .line 814
    invoke-static {v11, v12}, Ljava/lang/Math;->floor(D)D

    .line 815
    .line 816
    .line 817
    move-result-wide v11

    .line 818
    double-to-int v11, v11

    .line 819
    sget-object v12, Lvs3;->f:[D

    .line 820
    .line 821
    aget-wide v14, v12, v11

    .line 822
    .line 823
    aget-wide v18, v1, v2

    .line 824
    .line 825
    aget-wide v20, v0, v2

    .line 826
    .line 827
    sub-double v14, v14, v18

    .line 828
    .line 829
    sub-double v20, v20, v18

    .line 830
    .line 831
    div-double v14, v14, v20

    .line 832
    .line 833
    aget-wide v18, v1, v24

    .line 834
    .line 835
    aget-wide v20, v0, v24

    .line 836
    .line 837
    sub-double v20, v20, v18

    .line 838
    .line 839
    mul-double v20, v20, v14

    .line 840
    .line 841
    add-double v20, v20, v18

    .line 842
    .line 843
    const/16 v29, 0x1

    .line 844
    .line 845
    aget-wide v18, v1, v29

    .line 846
    .line 847
    aget-wide v22, v0, v29

    .line 848
    .line 849
    sub-double v22, v22, v18

    .line 850
    .line 851
    mul-double v22, v22, v14

    .line 852
    .line 853
    add-double v22, v22, v18

    .line 854
    .line 855
    aget-wide v18, v1, v28

    .line 856
    .line 857
    aget-wide v25, v0, v28

    .line 858
    .line 859
    sub-double v25, v25, v18

    .line 860
    .line 861
    mul-double v25, v25, v14

    .line 862
    .line 863
    add-double v25, v25, v18

    .line 864
    .line 865
    const/4 v10, 0x3

    .line 866
    new-array v12, v10, [D

    .line 867
    .line 868
    aput-wide v20, v12, v24

    .line 869
    .line 870
    aput-wide v22, v12, v29

    .line 871
    .line 872
    aput-wide v25, v12, v28

    .line 873
    .line 874
    invoke-static {v12}, Lvs3;->q([D)D

    .line 875
    .line 876
    .line 877
    move-result-wide v14

    .line 878
    move-wide/from16 p2, v3

    .line 879
    .line 880
    move-wide/from16 p0, v5

    .line 881
    .line 882
    move-wide/from16 p4, v14

    .line 883
    .line 884
    invoke-static/range {p0 .. p5}, Lvs3;->a(DDD)Z

    .line 885
    .line 886
    .line 887
    move-result v3

    .line 888
    move-wide/from16 v14, p2

    .line 889
    .line 890
    move-wide/from16 v18, p4

    .line 891
    .line 892
    if-eqz v3, :cond_380

    .line 893
    .line 894
    move v8, v11

    .line 895
    move-object v0, v12

    .line 896
    goto :goto_384

    .line 897
    :cond_380
    move v7, v11

    .line 898
    move-object v1, v12

    .line 899
    move-wide/from16 v5, v18

    .line 900
    .line 901
    :goto_384
    add-int/lit8 v9, v9, 0x1

    .line 902
    .line 903
    move-wide v3, v14

    .line 904
    goto :goto_31b

    .line 905
    :cond_388
    move-wide v14, v3

    .line 906
    const/16 v13, 0x8

    .line 907
    .line 908
    :goto_38b
    add-int/lit8 v2, v2, 0x1

    .line 909
    .line 910
    move-wide v3, v14

    .line 911
    goto/16 :goto_2d9

    .line 912
    .line 913
    :cond_390
    aget-wide v2, v1, v24

    .line 914
    .line 915
    aget-wide v4, v0, v24

    .line 916
    .line 917
    add-double/2addr v2, v4

    .line 918
    div-double v2, v2, v16

    .line 919
    .line 920
    const/16 v29, 0x1

    .line 921
    .line 922
    aget-wide v4, v1, v29

    .line 923
    .line 924
    aget-wide v6, v0, v29

    .line 925
    .line 926
    add-double/2addr v4, v6

    .line 927
    div-double v4, v4, v16

    .line 928
    .line 929
    aget-wide v6, v1, v28

    .line 930
    .line 931
    aget-wide v8, v0, v28

    .line 932
    .line 933
    add-double/2addr v6, v8

    .line 934
    div-double v6, v6, v16

    .line 935
    .line 936
    const/4 v10, 0x3

    .line 937
    new-array v0, v10, [D

    .line 938
    .line 939
    aput-wide v2, v0, v24

    .line 940
    .line 941
    aput-wide v4, v0, v29

    .line 942
    .line 943
    aput-wide v6, v0, v28

    .line 944
    .line 945
    aget-wide v1, v0, v24

    .line 946
    .line 947
    invoke-static {v1, v2}, Lls0;->i(D)I

    .line 948
    .line 949
    .line 950
    move-result v1

    .line 951
    aget-wide v2, v0, v29

    .line 952
    .line 953
    invoke-static {v2, v3}, Lls0;->i(D)I

    .line 954
    .line 955
    .line 956
    move-result v2

    .line 957
    aget-wide v3, v0, v28

    .line 958
    .line 959
    invoke-static {v3, v4}, Lls0;->i(D)I

    .line 960
    .line 961
    .line 962
    move-result v0

    .line 963
    invoke-static {v1, v2, v0}, Lls0;->b(III)I

    .line 964
    .line 965
    .line 966
    move-result v0

    .line 967
    goto :goto_3d3

    .line 968
    :cond_3c7
    :goto_3c7
    invoke-static/range {p4 .. p5}, Lls0;->v(D)D

    .line 969
    .line 970
    .line 971
    move-result-wide v0

    .line 972
    invoke-static {v0, v1}, Lls0;->i(D)I

    .line 973
    .line 974
    .line 975
    move-result v0

    .line 976
    invoke-static {v0, v0, v0}, Lls0;->b(III)I

    .line 977
    .line 978
    .line 979
    move-result v0

    .line 980
    :goto_3d3
    new-instance v1, Lux0;

    .line 981
    .line 982
    invoke-direct {v1, v0}, Lux0;-><init>(I)V

    .line 983
    .line 984
    .line 985
    return-object v1

    .line 986
    nop

    .line 987
    :array_3da
    .array-data 8
        -0x4010000000000000L    # -1.0
        -0x4010000000000000L    # -1.0
        -0x4010000000000000L    # -1.0
    .end array-data

    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    :array_3ea
    .array-data 8
        -0x4010000000000000L    # -1.0
        -0x4010000000000000L    # -1.0
        -0x4010000000000000L    # -1.0
    .end array-data

    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    :array_3fa
    .array-data 8
        -0x4010000000000000L    # -1.0
        -0x4010000000000000L    # -1.0
        -0x4010000000000000L    # -1.0
    .end array-data
.end method
