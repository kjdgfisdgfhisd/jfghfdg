###### Class defpackage.es3 (es3)
.class public final Les3;
.super Lov3;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field private static final zzc:Les3;

.field private static volatile zzd:Lvw3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lvw3;"
        }
    .end annotation
.end field


# instance fields
.field private zze:I

.field private zzf:I

.field private zzg:Law3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Law3;"
        }
    .end annotation
.end field

.field private zzh:Ljava/lang/String;

.field private zzi:Ljava/lang/String;

.field private zzj:Z

.field private zzk:D


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Les3;

    .line 2
    .line 3
    invoke-direct {v0}, Les3;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Les3;->zzc:Les3;

    .line 7
    .line 8
    const-class v1, Les3;

    .line 9
    .line 10
    invoke-static {v1, v0}, Lov3;->f(Ljava/lang/Class;Lov3;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Lov3;-><init>()V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lyw3;->e:Lyw3;

    .line 5
    .line 6
    iput-object v0, p0, Les3;->zzg:Law3;

    .line 7
    .line 8
    const-string v0, ""

    .line 9
    .line 10
    iput-object v0, p0, Les3;->zzh:Ljava/lang/String;

    .line 11
    .line 12
    iput-object v0, p0, Les3;->zzi:Ljava/lang/String;

    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final c(I)Ljava/lang/Object;
    .registers 11

    .line 1
    sget-object p0, Lhs3;->a:[I

    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    sub-int/2addr p1, v0

    .line 5
    aget p0, p0, p1

    .line 6
    .line 7
    const/4 p1, 0x0

    .line 8
    packed-switch p0, :pswitch_data_62

    .line 9
    .line 10
    .line 11
    invoke-static {}, Lvn0;->n()V

    .line 12
    .line 13
    .line 14
    :pswitch_d
    return-object p1

    .line 15
    :pswitch_e
    invoke-static {v0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    return-object p0

    .line 20
    :pswitch_13
    sget-object p0, Les3;->zzd:Lvw3;

    .line 21
    .line 22
    if-nez p0, :cond_2f

    .line 23
    .line 24
    const-class p1, Les3;

    .line 25
    .line 26
    monitor-enter p1

    .line 27
    :try_start_1a
    sget-object p0, Les3;->zzd:Lvw3;

    .line 28
    .line 29
    if-nez p0, :cond_2b

    .line 30
    .line 31
    new-instance p0, Lap3;

    .line 32
    .line 33
    const/16 v0, 0xc

    .line 34
    .line 35
    invoke-direct {p0, v0}, Lap3;-><init>(I)V

    .line 36
    .line 37
    .line 38
    sput-object p0, Les3;->zzd:Lvw3;

    .line 39
    .line 40
    goto :goto_2b

    .line 41
    :catchall_28
    move-exception v0

    .line 42
    move-object p0, v0

    .line 43
    goto :goto_2d

    .line 44
    :cond_2b
    :goto_2b
    monitor-exit p1

    .line 45
    return-object p0

    .line 46
    :goto_2d
    monitor-exit p1
    :try_end_2e
    .catchall {:try_start_1a .. :try_end_2e} :catchall_28

    .line 47
    throw p0

    .line 48
    :cond_2f
    return-object p0

    .line 49
    :pswitch_30
    sget-object p0, Les3;->zzc:Les3;

    .line 50
    .line 51
    return-object p0

    .line 52
    :pswitch_33
    const-string v0, "zze"

    .line 53
    .line 54
    const-string v1, "zzf"

    .line 55
    .line 56
    sget-object v2, Lfq3;->i:Lfq3;

    .line 57
    .line 58
    const-string v3, "zzg"

    .line 59
    .line 60
    const-class v4, Les3;

    .line 61
    .line 62
    const-string v5, "zzh"

    .line 63
    .line 64
    const-string v6, "zzi"

    .line 65
    .line 66
    const-string v7, "zzj"

    .line 67
    .line 68
    const-string v8, "zzk"

    .line 69
    .line 70
    filled-new-array/range {v0 .. v8}, [Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object p0

    .line 74
    const-string p1, "\u0004\u0006\u0000\u0001\u0001\u0006\u0006\u0000\u0001\u0000\u0001\u180c\u0000\u0002\u001b\u0003\u1008\u0001\u0004\u1008\u0002\u0005\u1007\u0003\u0006\u1000\u0004"

    .line 75
    .line 76
    sget-object v0, Les3;->zzc:Les3;

    .line 77
    .line 78
    new-instance v1, Lcx3;

    .line 79
    .line 80
    invoke-direct {v1, v0, p1, p0}, Lcx3;-><init>(Leu3;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 81
    .line 82
    .line 83
    return-object v1

    .line 84
    :pswitch_53
    new-instance p0, Laq3;

    .line 85
    .line 86
    sget-object p1, Les3;->zzc:Les3;

    .line 87
    .line 88
    invoke-direct {p0, p1}, Lmv3;-><init>(Lov3;)V

    .line 89
    .line 90
    .line 91
    return-object p0

    .line 92
    :pswitch_5b
    new-instance p0, Les3;

    .line 93
    .line 94
    invoke-direct {p0}, Les3;-><init>()V

    .line 95
    .line 96
    .line 97
    return-object p0

    .line 98
    nop

    .line 99
    :pswitch_data_62
    .packed-switch 0x1
        :pswitch_5b
        :pswitch_53
        :pswitch_33
        :pswitch_30
        :pswitch_13
        :pswitch_e
        :pswitch_d
    .end packed-switch
.end method

.method public final m()D
    .registers 3

    .line 1
    iget-wide v0, p0, Les3;->zzk:D

    .line 2
    .line 3
    return-wide v0
.end method

.method public final n()I
    .registers 1

    .line 1
    iget p0, p0, Les3;->zzf:I

    .line 2
    .line 3
    invoke-static {p0}, Lmg3;->c(I)I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    if-nez p0, :cond_9

    .line 8
    .line 9
    const/4 p0, 0x1

    .line 10
    :cond_9
    return p0
.end method

.method public final o()Ljava/lang/String;
    .registers 1

    .line 1
    iget-object p0, p0, Les3;->zzh:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final p()Ljava/lang/String;
    .registers 1

    .line 1
    iget-object p0, p0, Les3;->zzi:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final q()Ljava/util/List;
    .registers 1

    .line 1
    iget-object p0, p0, Les3;->zzg:Law3;

    .line 2
    .line 3
    return-object p0
.end method

.method public final r()Z
    .registers 1

    .line 1
    iget-boolean p0, p0, Les3;->zzj:Z

    .line 2
    .line 3
    return p0
.end method

.method public final s()Z
    .registers 1

    .line 1
    iget p0, p0, Les3;->zze:I

    .line 2
    .line 3
    and-int/lit8 p0, p0, 0x8

    .line 4
    .line 5
    if-eqz p0, :cond_8

    .line 6
    .line 7
    const/4 p0, 0x1

    .line 8
    return p0

    .line 9
    :cond_8
    const/4 p0, 0x0

    .line 10
    return p0
.end method

.method public final t()Z
    .registers 1

    .line 1
    iget p0, p0, Les3;->zze:I

    .line 2
    .line 3
    and-int/lit8 p0, p0, 0x10

    .line 4
    .line 5
    if-eqz p0, :cond_8

    .line 6
    .line 7
    const/4 p0, 0x1

    .line 8
    return p0

    .line 9
    :cond_8
    const/4 p0, 0x0

    .line 10
    return p0
.end method

.method public final u()Z
    .registers 1

    .line 1
    iget p0, p0, Les3;->zze:I

    .line 2
    .line 3
    and-int/lit8 p0, p0, 0x4

    .line 4
    .line 5
    if-eqz p0, :cond_8

    .line 6
    .line 7
    const/4 p0, 0x1

    .line 8
    return p0

    .line 9
    :cond_8
    const/4 p0, 0x0

    .line 10
    return p0
.end method
