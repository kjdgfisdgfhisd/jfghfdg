###### Class defpackage.j93 (j93)
.class public final Lj93;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Ld2;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lyx2;


# direct methods
.method public synthetic constructor <init>(Lyx2;I)V
    .registers 3

    .line 1
    iput p2, p0, Lj93;->a:I

    .line 2
    .line 3
    iput-object p1, p0, Lj93;->b:Lyx2;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a(Landroid/view/View;)Z
    .registers 4

    .line 1
    iget v0, p0, Lj93;->a:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    iget-object p0, p0, Lj93;->b:Lyx2;

    .line 5
    .line 6
    packed-switch v0, :pswitch_data_2e

    .line 7
    .line 8
    .line 9
    check-cast p1, Landroidx/viewpager2/widget/ViewPager2;

    .line 10
    .line 11
    invoke-virtual {p1}, Landroidx/viewpager2/widget/ViewPager2;->getCurrentItem()I

    .line 12
    .line 13
    .line 14
    move-result p1

    .line 15
    sub-int/2addr p1, v1

    .line 16
    iget-object p0, p0, Lyx2;->b:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast p0, Landroidx/viewpager2/widget/ViewPager2;

    .line 19
    .line 20
    iget-boolean v0, p0, Landroidx/viewpager2/widget/ViewPager2;->t:Z

    .line 21
    .line 22
    if-eqz v0, :cond_1a

    .line 23
    .line 24
    invoke-virtual {p0, p1, v1}, Landroidx/viewpager2/widget/ViewPager2;->b(IZ)V

    .line 25
    .line 26
    .line 27
    :cond_1a
    return v1

    .line 28
    :pswitch_1b
    check-cast p1, Landroidx/viewpager2/widget/ViewPager2;

    .line 29
    .line 30
    invoke-virtual {p1}, Landroidx/viewpager2/widget/ViewPager2;->getCurrentItem()I

    .line 31
    .line 32
    .line 33
    move-result p1

    .line 34
    add-int/2addr p1, v1

    .line 35
    iget-object p0, p0, Lyx2;->b:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast p0, Landroidx/viewpager2/widget/ViewPager2;

    .line 38
    .line 39
    iget-boolean v0, p0, Landroidx/viewpager2/widget/ViewPager2;->t:Z

    .line 40
    .line 41
    if-eqz v0, :cond_2d

    .line 42
    .line 43
    invoke-virtual {p0, p1, v1}, Landroidx/viewpager2/widget/ViewPager2;->b(IZ)V

    .line 44
    .line 45
    .line 46
    :cond_2d
    return v1

    .line 47
    :pswitch_data_2e
    .packed-switch 0x0
        :pswitch_1b
    .end packed-switch
.end method
