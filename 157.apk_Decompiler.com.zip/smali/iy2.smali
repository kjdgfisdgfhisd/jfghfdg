###### Class defpackage.iy2 (iy2)
.class public final Liy2;
.super Ljava/util/concurrent/CancellationException;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final transient a:Lq51;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljy2;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, Liy2;->a:Lq51;

    .line 5
    .line 6
    return-void
.end method
