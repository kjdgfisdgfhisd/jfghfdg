###### Class defpackage.ys0 (ys0)
.class public final Lys0;
.super Landroid/database/sqlite/SQLiteOpenHelper;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field public static final synthetic j:I


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Lf80;

.field public final c:Lo4;

.field public final d:Z

.field public e:Z

.field public final f:La52;

.field public g:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;Lf80;Lo4;Z)V
    .registers 12

    .line 1
    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget v4, p4, Lo4;->b:I

    .line 5
    .line 6
    new-instance v5, Lvs0;

    .line 7
    .line 8
    invoke-direct {v5, p4, p3}, Lvs0;-><init>(Lo4;Lf80;)V

    .line 9
    .line 10
    .line 11
    const/4 v3, 0x0

    .line 12
    move-object v0, p0

    .line 13
    move-object v1, p1

    .line 14
    move-object v2, p2

    .line 15
    invoke-direct/range {v0 .. v5}, Landroid/database/sqlite/SQLiteOpenHelper;-><init>(Landroid/content/Context;Ljava/lang/String;Landroid/database/sqlite/SQLiteDatabase$CursorFactory;ILandroid/database/DatabaseErrorHandler;)V

    .line 16
    .line 17
    .line 18
    iput-object v1, v0, Lys0;->a:Landroid/content/Context;

    .line 19
    .line 20
    iput-object p3, v0, Lys0;->b:Lf80;

    .line 21
    .line 22
    iput-object p4, v0, Lys0;->c:Lo4;

    .line 23
    .line 24
    iput-boolean p5, v0, Lys0;->d:Z

    .line 25
    .line 26
    new-instance p0, La52;

    .line 27
    .line 28
    if-nez v2, :cond_29

    .line 29
    .line 30
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    invoke-virtual {p1}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object p2

    .line 38
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 39
    .line 40
    .line 41
    goto :goto_2a

    .line 42
    :cond_29
    move-object p2, v2

    .line 43
    :goto_2a
    invoke-virtual {v1}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    .line 44
    .line 45
    .line 46
    move-result-object p1

    .line 47
    const/4 p3, 0x0

    .line 48
    invoke-direct {p0, p2, p1, p3}, La52;-><init>(Ljava/lang/String;Ljava/io/File;Z)V

    .line 49
    .line 50
    .line 51
    iput-object p0, v0, Lys0;->f:La52;

    .line 52
    .line 53
    return-void
.end method


# virtual methods
.method public final a(Z)Lus0;
    .registers 5

    .line 1
    iget-object v0, p0, Lys0;->f:La52;

    .line 2
    .line 3
    :try_start_2
    iget-boolean v1, p0, Lys0;->g:Z

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-nez v1, :cond_11

    .line 7
    .line 8
    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteOpenHelper;->getDatabaseName()Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    if-eqz v1, :cond_11

    .line 13
    .line 14
    const/4 v1, 0x1

    .line 15
    goto :goto_12

    .line 16
    :catchall_f
    move-exception p0

    .line 17
    goto :goto_32

    .line 18
    :cond_11
    move v1, v2

    .line 19
    :goto_12
    invoke-virtual {v0, v1}, La52;->a(Z)V

    .line 20
    .line 21
    .line 22
    iput-boolean v2, p0, Lys0;->e:Z

    .line 23
    .line 24
    invoke-virtual {p0, p1}, Lys0;->j(Z)Landroid/database/sqlite/SQLiteDatabase;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    iget-boolean v2, p0, Lys0;->e:Z

    .line 29
    .line 30
    if-eqz v2, :cond_2a

    .line 31
    .line 32
    invoke-virtual {p0}, Lys0;->close()V

    .line 33
    .line 34
    .line 35
    invoke-virtual {p0, p1}, Lys0;->a(Z)Lus0;

    .line 36
    .line 37
    .line 38
    move-result-object p0
    :try_end_26
    .catchall {:try_start_2 .. :try_end_26} :catchall_f

    .line 39
    invoke-virtual {v0}, La52;->b()V

    .line 40
    .line 41
    .line 42
    return-object p0

    .line 43
    :cond_2a
    :try_start_2a
    invoke-virtual {p0, v1}, Lys0;->f(Landroid/database/sqlite/SQLiteDatabase;)Lus0;

    .line 44
    .line 45
    .line 46
    move-result-object p0
    :try_end_2e
    .catchall {:try_start_2a .. :try_end_2e} :catchall_f

    .line 47
    invoke-virtual {v0}, La52;->b()V

    .line 48
    .line 49
    .line 50
    return-object p0

    .line 51
    :goto_32
    invoke-virtual {v0}, La52;->b()V

    .line 52
    .line 53
    .line 54
    throw p0
.end method

.method public final close()V
    .registers 4

    .line 1
    iget-object v0, p0, Lys0;->f:La52;

    .line 2
    .line 3
    :try_start_2
    iget-boolean v1, v0, La52;->a:Z

    .line 4
    .line 5
    invoke-virtual {v0, v1}, La52;->a(Z)V

    .line 6
    .line 7
    .line 8
    invoke-super {p0}, Landroid/database/sqlite/SQLiteOpenHelper;->close()V

    .line 9
    .line 10
    .line 11
    iget-object v1, p0, Lys0;->b:Lf80;

    .line 12
    .line 13
    const/4 v2, 0x0

    .line 14
    iput-object v2, v1, Lf80;->b:Ljava/lang/Object;

    .line 15
    .line 16
    const/4 v1, 0x0

    .line 17
    iput-boolean v1, p0, Lys0;->g:Z
    :try_end_12
    .catchall {:try_start_2 .. :try_end_12} :catchall_16

    .line 18
    .line 19
    invoke-virtual {v0}, La52;->b()V

    .line 20
    .line 21
    .line 22
    return-void

    .line 23
    :catchall_16
    move-exception p0

    .line 24
    invoke-virtual {v0}, La52;->b()V

    .line 25
    .line 26
    .line 27
    throw p0
.end method

.method public final f(Landroid/database/sqlite/SQLiteDatabase;)Lus0;
    .registers 4

    .line 1
    iget-object p0, p0, Lys0;->b:Lf80;

    .line 2
    .line 3
    iget-object v0, p0, Lf80;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lus0;

    .line 6
    .line 7
    if-eqz v0, :cond_12

    .line 8
    .line 9
    iget-object v1, v0, Lus0;->a:Landroid/database/sqlite/SQLiteDatabase;

    .line 10
    .line 11
    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    if-nez v1, :cond_11

    .line 16
    .line 17
    goto :goto_12

    .line 18
    :cond_11
    return-object v0

    .line 19
    :cond_12
    :goto_12
    new-instance v0, Lus0;

    .line 20
    .line 21
    invoke-direct {v0, p1}, Lus0;-><init>(Landroid/database/sqlite/SQLiteDatabase;)V

    .line 22
    .line 23
    .line 24
    iput-object v0, p0, Lf80;->b:Ljava/lang/Object;

    .line 25
    .line 26
    return-object v0
.end method

.method public final j(Z)Landroid/database/sqlite/SQLiteDatabase;
    .registers 7

    .line 1
    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteOpenHelper;->getDatabaseName()Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-boolean v1, p0, Lys0;->g:Z

    .line 6
    .line 7
    iget-object v2, p0, Lys0;->a:Landroid/content/Context;

    .line 8
    .line 9
    if-eqz v0, :cond_32

    .line 10
    .line 11
    if-nez v1, :cond_32

    .line 12
    .line 13
    invoke-virtual {v2, v0}, Landroid/content/Context;->getDatabasePath(Ljava/lang/String;)Ljava/io/File;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    invoke-virtual {v1}, Ljava/io/File;->getParentFile()Ljava/io/File;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    if-eqz v1, :cond_32

    .line 22
    .line 23
    invoke-virtual {v1}, Ljava/io/File;->mkdirs()Z

    .line 24
    .line 25
    .line 26
    invoke-virtual {v1}, Ljava/io/File;->isDirectory()Z

    .line 27
    .line 28
    .line 29
    move-result v3

    .line 30
    if-nez v3, :cond_32

    .line 31
    .line 32
    new-instance v3, Ljava/lang/StringBuilder;

    .line 33
    .line 34
    const-string v4, "Invalid database parent file, not a directory: "

    .line 35
    .line 36
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 40
    .line 41
    .line 42
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    const-string v3, "SupportSQLite"

    .line 47
    .line 48
    invoke-static {v3, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 49
    .line 50
    .line 51
    :cond_32
    if-eqz p1, :cond_3c

    .line 52
    .line 53
    :try_start_34
    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    .line 54
    .line 55
    .line 56
    move-result-object v1

    .line 57
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 58
    .line 59
    .line 60
    return-object v1

    .line 61
    :cond_3c
    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteOpenHelper;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    .line 62
    .line 63
    .line 64
    move-result-object v1

    .line 65
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_43
    .catchall {:try_start_34 .. :try_end_43} :catchall_44

    .line 66
    .line 67
    .line 68
    return-object v1

    .line 69
    :catchall_44
    const-wide/16 v3, 0x1f4

    .line 70
    .line 71
    :try_start_46
    invoke-static {v3, v4}, Ljava/lang/Thread;->sleep(J)V
    :try_end_49
    .catch Ljava/lang/InterruptedException; {:try_start_46 .. :try_end_49} :catch_49

    .line 72
    .line 73
    .line 74
    :catch_49
    if-eqz p1, :cond_55

    .line 75
    .line 76
    :try_start_4b
    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    .line 77
    .line 78
    .line 79
    move-result-object v1

    .line 80
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 81
    .line 82
    .line 83
    goto :goto_5c

    .line 84
    :catchall_53
    move-exception v1

    .line 85
    goto :goto_5d

    .line 86
    :cond_55
    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteOpenHelper;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    .line 87
    .line 88
    .line 89
    move-result-object v1

    .line 90
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_5c
    .catchall {:try_start_4b .. :try_end_5c} :catchall_53

    .line 91
    .line 92
    .line 93
    :goto_5c
    return-object v1

    .line 94
    :goto_5d
    instance-of v3, v1, Lws0;

    .line 95
    .line 96
    if-eqz v3, :cond_85

    .line 97
    .line 98
    check-cast v1, Lws0;

    .line 99
    .line 100
    iget-object v3, v1, Lws0;->a:Lxs0;

    .line 101
    .line 102
    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    .line 103
    .line 104
    .line 105
    move-result v3

    .line 106
    iget-object v1, v1, Lws0;->b:Ljava/lang/Throwable;

    .line 107
    .line 108
    if-eqz v3, :cond_84

    .line 109
    .line 110
    const/4 v4, 0x1

    .line 111
    if-eq v3, v4, :cond_84

    .line 112
    .line 113
    const/4 v4, 0x2

    .line 114
    if-eq v3, v4, :cond_84

    .line 115
    .line 116
    const/4 v4, 0x3

    .line 117
    if-eq v3, v4, :cond_84

    .line 118
    .line 119
    const/4 v4, 0x4

    .line 120
    if-ne v3, v4, :cond_7f

    .line 121
    .line 122
    instance-of v3, v1, Landroid/database/sqlite/SQLiteException;

    .line 123
    .line 124
    if-eqz v3, :cond_7e

    .line 125
    .line 126
    goto :goto_85

    .line 127
    :cond_7e
    throw v1

    .line 128
    :cond_7f
    invoke-static {}, Lm03;->a()V

    .line 129
    .line 130
    .line 131
    const/4 p0, 0x0

    .line 132
    return-object p0

    .line 133
    :cond_84
    throw v1

    .line 134
    :cond_85
    :goto_85
    instance-of v3, v1, Landroid/database/sqlite/SQLiteException;

    .line 135
    .line 136
    if-eqz v3, :cond_a9

    .line 137
    .line 138
    if-eqz v0, :cond_a9

    .line 139
    .line 140
    iget-boolean v3, p0, Lys0;->d:Z

    .line 141
    .line 142
    if-eqz v3, :cond_a9

    .line 143
    .line 144
    invoke-virtual {v2, v0}, Landroid/content/Context;->deleteDatabase(Ljava/lang/String;)Z

    .line 145
    .line 146
    .line 147
    if-eqz p1, :cond_9e

    .line 148
    .line 149
    :try_start_94
    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    .line 150
    .line 151
    .line 152
    move-result-object p0

    .line 153
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 154
    .line 155
    .line 156
    goto :goto_a5

    .line 157
    :catch_9c
    move-exception p0

    .line 158
    goto :goto_a6

    .line 159
    :cond_9e
    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteOpenHelper;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    .line 160
    .line 161
    .line 162
    move-result-object p0

    .line 163
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_a5
    .catch Lws0; {:try_start_94 .. :try_end_a5} :catch_9c

    .line 164
    .line 165
    .line 166
    :goto_a5
    return-object p0

    .line 167
    :goto_a6
    iget-object p0, p0, Lws0;->b:Ljava/lang/Throwable;

    .line 168
    .line 169
    throw p0

    .line 170
    :cond_a9
    throw v1
.end method

.method public final onConfigure(Landroid/database/sqlite/SQLiteDatabase;)V
    .registers 5

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-boolean v0, p0, Lys0;->e:Z

    .line 5
    .line 6
    iget-object v1, p0, Lys0;->c:Lo4;

    .line 7
    .line 8
    if-nez v0, :cond_15

    .line 9
    .line 10
    iget v0, v1, Lo4;->b:I

    .line 11
    .line 12
    invoke-virtual {p1}, Landroid/database/sqlite/SQLiteDatabase;->getVersion()I

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    if-eq v0, v2, :cond_15

    .line 17
    .line 18
    const/4 v0, 0x1

    .line 19
    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->setMaxSqlCacheSize(I)V

    .line 20
    .line 21
    .line 22
    :cond_15
    :try_start_15
    invoke-virtual {p0, p1}, Lys0;->f(Landroid/database/sqlite/SQLiteDatabase;)Lus0;

    .line 23
    .line 24
    .line 25
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_1b
    .catchall {:try_start_15 .. :try_end_1b} :catchall_1c

    .line 26
    .line 27
    .line 28
    return-void

    .line 29
    :catchall_1c
    move-exception p0

    .line 30
    new-instance p1, Lws0;

    .line 31
    .line 32
    sget-object v0, Lxs0;->a:Lxs0;

    .line 33
    .line 34
    invoke-direct {p1, v0, p0}, Lws0;-><init>(Lxs0;Ljava/lang/Throwable;)V

    .line 35
    .line 36
    .line 37
    throw p1
.end method

.method public final onCreate(Landroid/database/sqlite/SQLiteDatabase;)V
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    :try_start_3
    iget-object v0, p0, Lys0;->c:Lo4;

    .line 5
    .line 6
    invoke-virtual {p0, p1}, Lys0;->f(Landroid/database/sqlite/SQLiteDatabase;)Lus0;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    iget-object p1, v0, Lo4;->c:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast p1, Lyg2;

    .line 13
    .line 14
    new-instance v0, Lbv2;

    .line 15
    .line 16
    invoke-direct {v0, p0}, Lbv2;-><init>(Lus0;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {p1, v0}, Lyg2;->d(Ldi2;)V
    :try_end_15
    .catchall {:try_start_3 .. :try_end_15} :catchall_16

    .line 20
    .line 21
    .line 22
    return-void

    .line 23
    :catchall_16
    move-exception p0

    .line 24
    new-instance p1, Lws0;

    .line 25
    .line 26
    sget-object v0, Lxs0;->b:Lxs0;

    .line 27
    .line 28
    invoke-direct {p1, v0, p0}, Lws0;-><init>(Lxs0;Ljava/lang/Throwable;)V

    .line 29
    .line 30
    .line 31
    throw p1
.end method

.method public final onDowngrade(Landroid/database/sqlite/SQLiteDatabase;II)V
    .registers 5

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    iput-boolean v0, p0, Lys0;->e:Z

    .line 6
    .line 7
    :try_start_6
    iget-object v0, p0, Lys0;->c:Lo4;

    .line 8
    .line 9
    invoke-virtual {p0, p1}, Lys0;->f(Landroid/database/sqlite/SQLiteDatabase;)Lus0;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    invoke-virtual {v0, p0, p2, p3}, Lo4;->g(Lus0;II)V
    :try_end_f
    .catchall {:try_start_6 .. :try_end_f} :catchall_10

    .line 14
    .line 15
    .line 16
    return-void

    .line 17
    :catchall_10
    move-exception p0

    .line 18
    new-instance p1, Lws0;

    .line 19
    .line 20
    sget-object p2, Lxs0;->d:Lxs0;

    .line 21
    .line 22
    invoke-direct {p1, p2, p0}, Lws0;-><init>(Lxs0;Ljava/lang/Throwable;)V

    .line 23
    .line 24
    .line 25
    throw p1
.end method

.method public final onOpen(Landroid/database/sqlite/SQLiteDatabase;)V
    .registers 4

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-boolean v0, p0, Lys0;->e:Z

    .line 5
    .line 6
    if-nez v0, :cond_25

    .line 7
    .line 8
    :try_start_7
    iget-object v0, p0, Lys0;->c:Lo4;

    .line 9
    .line 10
    invoke-virtual {p0, p1}, Lys0;->f(Landroid/database/sqlite/SQLiteDatabase;)Lus0;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    iget-object v0, v0, Lo4;->c:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v0, Lyg2;

    .line 17
    .line 18
    new-instance v1, Lbv2;

    .line 19
    .line 20
    invoke-direct {v1, p1}, Lbv2;-><init>(Lus0;)V

    .line 21
    .line 22
    .line 23
    invoke-virtual {v0, v1}, Lyg2;->f(Ldi2;)V

    .line 24
    .line 25
    .line 26
    iput-object p1, v0, Lyg2;->g:Lus0;
    :try_end_1b
    .catchall {:try_start_7 .. :try_end_1b} :catchall_1c

    .line 27
    .line 28
    goto :goto_25

    .line 29
    :catchall_1c
    move-exception p0

    .line 30
    new-instance p1, Lws0;

    .line 31
    .line 32
    sget-object v0, Lxs0;->e:Lxs0;

    .line 33
    .line 34
    invoke-direct {p1, v0, p0}, Lws0;-><init>(Lxs0;Ljava/lang/Throwable;)V

    .line 35
    .line 36
    .line 37
    throw p1

    .line 38
    :cond_25
    :goto_25
    const/4 p1, 0x1

    .line 39
    iput-boolean p1, p0, Lys0;->g:Z

    .line 40
    .line 41
    return-void
.end method

.method public final onUpgrade(Landroid/database/sqlite/SQLiteDatabase;II)V
    .registers 5

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    iput-boolean v0, p0, Lys0;->e:Z

    .line 6
    .line 7
    :try_start_6
    iget-object v0, p0, Lys0;->c:Lo4;

    .line 8
    .line 9
    invoke-virtual {p0, p1}, Lys0;->f(Landroid/database/sqlite/SQLiteDatabase;)Lus0;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    invoke-virtual {v0, p0, p2, p3}, Lo4;->g(Lus0;II)V
    :try_end_f
    .catchall {:try_start_6 .. :try_end_f} :catchall_10

    .line 14
    .line 15
    .line 16
    return-void

    .line 17
    :catchall_10
    move-exception p0

    .line 18
    new-instance p1, Lws0;

    .line 19
    .line 20
    sget-object p2, Lxs0;->c:Lxs0;

    .line 21
    .line 22
    invoke-direct {p1, p2, p0}, Lws0;-><init>(Lxs0;Ljava/lang/Throwable;)V

    .line 23
    .line 24
    .line 25
    throw p1
.end method

###### Class defpackage.vs0 (vs0)
.class public final synthetic Lvs0;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Landroid/database/DatabaseErrorHandler;


# instance fields
.field public final synthetic a:Lo4;

.field public final synthetic b:Lf80;


# direct methods
.method public synthetic constructor <init>(Lo4;Lf80;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lvs0;->a:Lo4;

    .line 5
    .line 6
    iput-object p2, p0, Lvs0;->b:Lf80;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final onCorruption(Landroid/database/sqlite/SQLiteDatabase;)V
    .registers 5

    .line 1
    sget v0, Lys0;->j:I

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lvs0;->b:Lf80;

    .line 7
    .line 8
    iget-object v1, v0, Lf80;->b:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v1, Lus0;

    .line 11
    .line 12
    if-eqz v1, :cond_15

    .line 13
    .line 14
    iget-object v2, v1, Lus0;->a:Landroid/database/sqlite/SQLiteDatabase;

    .line 15
    .line 16
    invoke-virtual {v2, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    if-nez v2, :cond_1c

    .line 21
    .line 22
    :cond_15
    new-instance v1, Lus0;

    .line 23
    .line 24
    invoke-direct {v1, p1}, Lus0;-><init>(Landroid/database/sqlite/SQLiteDatabase;)V

    .line 25
    .line 26
    .line 27
    iput-object v1, v0, Lf80;->b:Ljava/lang/Object;

    .line 28
    .line 29
    :cond_1c
    iget-object p1, v1, Lus0;->a:Landroid/database/sqlite/SQLiteDatabase;

    .line 30
    .line 31
    iget-object p0, p0, Lvs0;->a:Lo4;

    .line 32
    .line 33
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 34
    .line 35
    .line 36
    new-instance p0, Ljava/lang/StringBuilder;

    .line 37
    .line 38
    const-string v0, "Corruption reported by sqlite on database: "

    .line 39
    .line 40
    invoke-direct {p0, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 44
    .line 45
    .line 46
    const-string v0, ".path"

    .line 47
    .line 48
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 49
    .line 50
    .line 51
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object p0

    .line 55
    const-string v0, "SupportSQLite"

    .line 56
    .line 57
    invoke-static {v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 58
    .line 59
    .line 60
    invoke-virtual {p1}, Landroid/database/sqlite/SQLiteDatabase;->isOpen()Z

    .line 61
    .line 62
    .line 63
    move-result p0

    .line 64
    if-nez p0, :cond_4b

    .line 65
    .line 66
    invoke-virtual {p1}, Landroid/database/sqlite/SQLiteDatabase;->getPath()Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object p0

    .line 70
    if-eqz p0, :cond_a8

    .line 71
    .line 72
    invoke-static {p0}, Lo4;->d(Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    return-void

    .line 76
    :cond_4b
    const/4 p0, 0x0

    .line 77
    :try_start_4c
    invoke-virtual {p1}, Landroid/database/sqlite/SQLiteDatabase;->getAttachedDbs()Ljava/util/List;

    .line 78
    .line 79
    .line 80
    move-result-object p0
    :try_end_50
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_4c .. :try_end_50} :catch_53
    .catchall {:try_start_4c .. :try_end_50} :catchall_51

    .line 81
    goto :goto_53

    .line 82
    :catchall_51
    move-exception v0

    .line 83
    goto :goto_57

    .line 84
    :catch_53
    :goto_53
    :try_start_53
    invoke-virtual {v1}, Lus0;->close()V
    :try_end_56
    .catch Ljava/io/IOException; {:try_start_53 .. :try_end_56} :catch_80
    .catchall {:try_start_53 .. :try_end_56} :catchall_51

    .line 85
    .line 86
    .line 87
    goto :goto_80

    .line 88
    :goto_57
    if-eqz p0, :cond_76

    .line 89
    .line 90
    check-cast p0, Ljava/lang/Iterable;

    .line 91
    .line 92
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 93
    .line 94
    .line 95
    move-result-object p0

    .line 96
    :goto_5f
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 97
    .line 98
    .line 99
    move-result p1

    .line 100
    if-eqz p1, :cond_7f

    .line 101
    .line 102
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 103
    .line 104
    .line 105
    move-result-object p1

    .line 106
    check-cast p1, Landroid/util/Pair;

    .line 107
    .line 108
    iget-object p1, p1, Landroid/util/Pair;->second:Ljava/lang/Object;

    .line 109
    .line 110
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 111
    .line 112
    .line 113
    check-cast p1, Ljava/lang/String;

    .line 114
    .line 115
    invoke-static {p1}, Lo4;->d(Ljava/lang/String;)V

    .line 116
    .line 117
    .line 118
    goto :goto_5f

    .line 119
    :cond_76
    invoke-virtual {p1}, Landroid/database/sqlite/SQLiteDatabase;->getPath()Ljava/lang/String;

    .line 120
    .line 121
    .line 122
    move-result-object p0

    .line 123
    if-eqz p0, :cond_7f

    .line 124
    .line 125
    invoke-static {p0}, Lo4;->d(Ljava/lang/String;)V

    .line 126
    .line 127
    .line 128
    :cond_7f
    throw v0

    .line 129
    :catch_80
    :goto_80
    if-eqz p0, :cond_9f

    .line 130
    .line 131
    check-cast p0, Ljava/lang/Iterable;

    .line 132
    .line 133
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 134
    .line 135
    .line 136
    move-result-object p0

    .line 137
    :goto_88
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 138
    .line 139
    .line 140
    move-result p1

    .line 141
    if-eqz p1, :cond_a8

    .line 142
    .line 143
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 144
    .line 145
    .line 146
    move-result-object p1

    .line 147
    check-cast p1, Landroid/util/Pair;

    .line 148
    .line 149
    iget-object p1, p1, Landroid/util/Pair;->second:Ljava/lang/Object;

    .line 150
    .line 151
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 152
    .line 153
    .line 154
    check-cast p1, Ljava/lang/String;

    .line 155
    .line 156
    invoke-static {p1}, Lo4;->d(Ljava/lang/String;)V

    .line 157
    .line 158
    .line 159
    goto :goto_88

    .line 160
    :cond_9f
    invoke-virtual {p1}, Landroid/database/sqlite/SQLiteDatabase;->getPath()Ljava/lang/String;

    .line 161
    .line 162
    .line 163
    move-result-object p0

    .line 164
    if-eqz p0, :cond_a8

    .line 165
    .line 166
    invoke-static {p0}, Lo4;->d(Ljava/lang/String;)V

    .line 167
    .line 168
    .line 169
    :cond_a8
    return-void
.end method
