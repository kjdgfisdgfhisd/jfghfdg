###### Class defpackage.jm2 (jm2)
.class public final Ljm2;
.super Lh0;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field public static final b:Ljm2;


# instance fields
.field public final a:Lko1;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Ljm2;

    .line 2
    .line 3
    sget-object v1, Lko1;->q:Lko1;

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljm2;-><init>(Lko1;)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Ljm2;->b:Ljm2;

    .line 9
    .line 10
    return-void
.end method

.method public constructor <init>()V
    .registers 2

    .line 1
    new-instance v0, Lko1;

    .line 2
    .line 3
    invoke-direct {v0}, Lko1;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/util/AbstractSet;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Ljm2;->a:Lko1;

    .line 10
    .line 11
    return-void
.end method

.method public constructor <init>(Lko1;)V
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    invoke-direct {p0}, Ljava/util/AbstractSet;-><init>()V

    .line 13
    iput-object p1, p0, Ljm2;->a:Lko1;

    return-void
.end method


# virtual methods
.method public final add(Ljava/lang/Object;)Z
    .registers 2

    .line 1
    iget-object p0, p0, Ljm2;->a:Lko1;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lko1;->a(Ljava/lang/Object;)I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    if-ltz p0, :cond_a

    .line 8
    .line 9
    const/4 p0, 0x1

    .line 10
    return p0

    .line 11
    :cond_a
    const/4 p0, 0x0

    .line 12
    return p0
.end method

.method public final addAll(Ljava/util/Collection;)Z
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Ljm2;->a:Lko1;

    .line 5
    .line 6
    invoke-virtual {v0}, Lko1;->d()V

    .line 7
    .line 8
    .line 9
    invoke-super {p0, p1}, Ljava/util/AbstractCollection;->addAll(Ljava/util/Collection;)Z

    .line 10
    .line 11
    .line 12
    move-result p0

    .line 13
    return p0
.end method

.method public final c()I
    .registers 1

    .line 1
    iget-object p0, p0, Ljm2;->a:Lko1;

    .line 2
    .line 3
    iget p0, p0, Lko1;->l:I

    .line 4
    .line 5
    return p0
.end method

.method public final clear()V
    .registers 1

    .line 1
    iget-object p0, p0, Ljm2;->a:Lko1;

    .line 2
    .line 3
    invoke-virtual {p0}, Lko1;->clear()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final contains(Ljava/lang/Object;)Z
    .registers 2

    .line 1
    iget-object p0, p0, Ljm2;->a:Lko1;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lko1;->containsKey(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final isEmpty()Z
    .registers 1

    .line 1
    iget-object p0, p0, Ljm2;->a:Lko1;

    .line 2
    .line 3
    invoke-virtual {p0}, Lko1;->isEmpty()Z

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final iterator()Ljava/util/Iterator;
    .registers 3

    .line 1
    new-instance v0, Lho1;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    iget-object p0, p0, Ljm2;->a:Lko1;

    .line 5
    .line 6
    invoke-direct {v0, p0, v1}, Lho1;-><init>(Lko1;I)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final remove(Ljava/lang/Object;)Z
    .registers 2

    .line 1
    iget-object p0, p0, Ljm2;->a:Lko1;

    .line 2
    .line 3
    invoke-virtual {p0}, Lko1;->d()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0, p1}, Lko1;->h(Ljava/lang/Object;)I

    .line 7
    .line 8
    .line 9
    move-result p1

    .line 10
    if-gez p1, :cond_d

    .line 11
    .line 12
    const/4 p0, 0x0

    .line 13
    return p0

    .line 14
    :cond_d
    invoke-virtual {p0, p1}, Lko1;->m(I)V

    .line 15
    .line 16
    .line 17
    const/4 p0, 0x1

    .line 18
    return p0
.end method

.method public final removeAll(Ljava/util/Collection;)Z
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Ljm2;->a:Lko1;

    .line 5
    .line 6
    invoke-virtual {v0}, Lko1;->d()V

    .line 7
    .line 8
    .line 9
    invoke-super {p0, p1}, Ljava/util/AbstractCollection;->removeAll(Ljava/util/Collection;)Z

    .line 10
    .line 11
    .line 12
    move-result p0

    .line 13
    return p0
.end method

.method public final retainAll(Ljava/util/Collection;)Z
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Ljm2;->a:Lko1;

    .line 5
    .line 6
    invoke-virtual {v0}, Lko1;->d()V

    .line 7
    .line 8
    .line 9
    invoke-super {p0, p1}, Ljava/util/AbstractCollection;->retainAll(Ljava/util/Collection;)Z

    .line 10
    .line 11
    .line 12
    move-result p0

    .line 13
    return p0
.end method
