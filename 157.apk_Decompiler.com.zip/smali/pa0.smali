###### Class defpackage.pa0 (pa0)
.class public final Lpa0;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lra0;


# static fields
.field public static final c:Lpa0;

.field public static final d:Lpa0;

.field public static final e:Lpa0;


# instance fields
.field public final a:Lta0;

.field public final b:Lrv2;


# direct methods
.method static constructor <clinit>()V
    .registers 6

    .line 1
    new-instance v0, Lta0;

    .line 2
    .line 3
    invoke-direct {v0}, Lta0;-><init>()V

    .line 4
    .line 5
    .line 6
    sget-object v1, Lxh0;->a:Lxh0;

    .line 7
    .line 8
    invoke-interface {v0, v1}, Lra0;->e(Ljava/util/Set;)V

    .line 9
    .line 10
    .line 11
    const/4 v2, 0x1

    .line 12
    iput-boolean v2, v0, Lta0;->a:Z

    .line 13
    .line 14
    new-instance v3, Lpa0;

    .line 15
    .line 16
    invoke-direct {v3, v0}, Lpa0;-><init>(Lta0;)V

    .line 17
    .line 18
    .line 19
    new-instance v0, Lta0;

    .line 20
    .line 21
    invoke-direct {v0}, Lta0;-><init>()V

    .line 22
    .line 23
    .line 24
    invoke-interface {v0}, Lra0;->h()V

    .line 25
    .line 26
    .line 27
    iput-boolean v2, v0, Lta0;->a:Z

    .line 28
    .line 29
    new-instance v3, Lpa0;

    .line 30
    .line 31
    invoke-direct {v3, v0}, Lpa0;-><init>(Lta0;)V

    .line 32
    .line 33
    .line 34
    new-instance v0, Lta0;

    .line 35
    .line 36
    invoke-direct {v0}, Lta0;-><init>()V

    .line 37
    .line 38
    .line 39
    invoke-interface {v0}, Lra0;->h()V

    .line 40
    .line 41
    .line 42
    invoke-interface {v0, v1}, Lra0;->e(Ljava/util/Set;)V

    .line 43
    .line 44
    .line 45
    iput-boolean v2, v0, Lta0;->a:Z

    .line 46
    .line 47
    new-instance v3, Lpa0;

    .line 48
    .line 49
    invoke-direct {v3, v0}, Lpa0;-><init>(Lta0;)V

    .line 50
    .line 51
    .line 52
    new-instance v0, Lta0;

    .line 53
    .line 54
    invoke-direct {v0}, Lta0;-><init>()V

    .line 55
    .line 56
    .line 57
    invoke-interface {v0}, Lra0;->h()V

    .line 58
    .line 59
    .line 60
    invoke-interface {v0, v1}, Lra0;->e(Ljava/util/Set;)V

    .line 61
    .line 62
    .line 63
    invoke-interface {v0}, Lra0;->m()V

    .line 64
    .line 65
    .line 66
    iput-boolean v2, v0, Lta0;->a:Z

    .line 67
    .line 68
    new-instance v3, Lpa0;

    .line 69
    .line 70
    invoke-direct {v3, v0}, Lpa0;-><init>(Lta0;)V

    .line 71
    .line 72
    .line 73
    new-instance v0, Lta0;

    .line 74
    .line 75
    invoke-direct {v0}, Lta0;-><init>()V

    .line 76
    .line 77
    .line 78
    invoke-interface {v0, v1}, Lra0;->e(Ljava/util/Set;)V

    .line 79
    .line 80
    .line 81
    sget-object v3, Lcu;->c:Lcu;

    .line 82
    .line 83
    invoke-interface {v0, v3}, Lra0;->f(Lcu;)V

    .line 84
    .line 85
    .line 86
    sget-object v4, Li12;->b:Li12;

    .line 87
    .line 88
    invoke-interface {v0, v4}, Lra0;->d(Li12;)V

    .line 89
    .line 90
    .line 91
    iput-boolean v2, v0, Lta0;->a:Z

    .line 92
    .line 93
    new-instance v5, Lpa0;

    .line 94
    .line 95
    invoke-direct {v5, v0}, Lpa0;-><init>(Lta0;)V

    .line 96
    .line 97
    .line 98
    new-instance v0, Lta0;

    .line 99
    .line 100
    invoke-direct {v0}, Lta0;-><init>()V

    .line 101
    .line 102
    .line 103
    invoke-interface {v0}, Lra0;->h()V

    .line 104
    .line 105
    .line 106
    invoke-interface {v0, v1}, Lra0;->e(Ljava/util/Set;)V

    .line 107
    .line 108
    .line 109
    invoke-interface {v0, v3}, Lra0;->f(Lcu;)V

    .line 110
    .line 111
    .line 112
    invoke-interface {v0}, Lra0;->k()V

    .line 113
    .line 114
    .line 115
    sget-object v1, Li12;->c:Li12;

    .line 116
    .line 117
    invoke-interface {v0, v1}, Lra0;->d(Li12;)V

    .line 118
    .line 119
    .line 120
    invoke-interface {v0}, Lra0;->a()V

    .line 121
    .line 122
    .line 123
    invoke-interface {v0}, Lra0;->c()V

    .line 124
    .line 125
    .line 126
    invoke-interface {v0}, Lra0;->m()V

    .line 127
    .line 128
    .line 129
    invoke-interface {v0}, Lra0;->g()V

    .line 130
    .line 131
    .line 132
    iput-boolean v2, v0, Lta0;->a:Z

    .line 133
    .line 134
    new-instance v1, Lpa0;

    .line 135
    .line 136
    invoke-direct {v1, v0}, Lpa0;-><init>(Lta0;)V

    .line 137
    .line 138
    .line 139
    new-instance v0, Lta0;

    .line 140
    .line 141
    invoke-direct {v0}, Lta0;-><init>()V

    .line 142
    .line 143
    .line 144
    sget-object v1, Lqa0;->b:Ljava/util/Set;

    .line 145
    .line 146
    invoke-interface {v0, v1}, Lra0;->e(Ljava/util/Set;)V

    .line 147
    .line 148
    .line 149
    iput-boolean v2, v0, Lta0;->a:Z

    .line 150
    .line 151
    new-instance v1, Lpa0;

    .line 152
    .line 153
    invoke-direct {v1, v0}, Lpa0;-><init>(Lta0;)V

    .line 154
    .line 155
    .line 156
    sput-object v1, Lpa0;->c:Lpa0;

    .line 157
    .line 158
    new-instance v0, Lta0;

    .line 159
    .line 160
    invoke-direct {v0}, Lta0;-><init>()V

    .line 161
    .line 162
    .line 163
    sget-object v1, Lqa0;->c:Ljava/util/Set;

    .line 164
    .line 165
    invoke-interface {v0, v1}, Lra0;->e(Ljava/util/Set;)V

    .line 166
    .line 167
    .line 168
    iput-boolean v2, v0, Lta0;->a:Z

    .line 169
    .line 170
    new-instance v1, Lpa0;

    .line 171
    .line 172
    invoke-direct {v1, v0}, Lpa0;-><init>(Lta0;)V

    .line 173
    .line 174
    .line 175
    new-instance v0, Lta0;

    .line 176
    .line 177
    invoke-direct {v0}, Lta0;-><init>()V

    .line 178
    .line 179
    .line 180
    invoke-interface {v0, v3}, Lra0;->f(Lcu;)V

    .line 181
    .line 182
    .line 183
    invoke-interface {v0, v4}, Lra0;->d(Li12;)V

    .line 184
    .line 185
    .line 186
    iput-boolean v2, v0, Lta0;->a:Z

    .line 187
    .line 188
    new-instance v1, Lpa0;

    .line 189
    .line 190
    invoke-direct {v1, v0}, Lpa0;-><init>(Lta0;)V

    .line 191
    .line 192
    .line 193
    sput-object v1, Lpa0;->d:Lpa0;

    .line 194
    .line 195
    new-instance v0, Lta0;

    .line 196
    .line 197
    invoke-direct {v0}, Lta0;-><init>()V

    .line 198
    .line 199
    .line 200
    invoke-interface {v0}, Lra0;->b()V

    .line 201
    .line 202
    .line 203
    sget-object v1, Lcu;->b:Lcu;

    .line 204
    .line 205
    invoke-interface {v0, v1}, Lra0;->f(Lcu;)V

    .line 206
    .line 207
    .line 208
    sget-object v1, Lqa0;->c:Ljava/util/Set;

    .line 209
    .line 210
    invoke-interface {v0, v1}, Lra0;->e(Ljava/util/Set;)V

    .line 211
    .line 212
    .line 213
    iput-boolean v2, v0, Lta0;->a:Z

    .line 214
    .line 215
    new-instance v1, Lpa0;

    .line 216
    .line 217
    invoke-direct {v1, v0}, Lpa0;-><init>(Lta0;)V

    .line 218
    .line 219
    .line 220
    sput-object v1, Lpa0;->e:Lpa0;

    .line 221
    .line 222
    new-instance v0, Lta0;

    .line 223
    .line 224
    invoke-direct {v0}, Lta0;-><init>()V

    .line 225
    .line 226
    .line 227
    invoke-interface {v0}, Lra0;->l()V

    .line 228
    .line 229
    .line 230
    sget-object v1, Lqa0;->c:Ljava/util/Set;

    .line 231
    .line 232
    invoke-interface {v0, v1}, Lra0;->e(Ljava/util/Set;)V

    .line 233
    .line 234
    .line 235
    iput-boolean v2, v0, Lta0;->a:Z

    .line 236
    .line 237
    new-instance v1, Lpa0;

    .line 238
    .line 239
    invoke-direct {v1, v0}, Lpa0;-><init>(Lta0;)V

    .line 240
    .line 241
    .line 242
    return-void
.end method

.method public constructor <init>(Lta0;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lpa0;->a:Lta0;

    .line 5
    .line 6
    new-instance p1, Lw0;

    .line 7
    .line 8
    const/4 v0, 0x6

    .line 9
    invoke-direct {p1, v0, p0}, Lw0;-><init>(ILjava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    new-instance v0, Lrv2;

    .line 13
    .line 14
    invoke-direct {v0, p1}, Lrv2;-><init>(Ldt0;)V

    .line 15
    .line 16
    .line 17
    iput-object v0, p0, Lpa0;->b:Lrv2;

    .line 18
    .line 19
    return-void
.end method

.method public static W(Ljava/lang/StringBuilder;)V
    .registers 3

    .line 1
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->length()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/16 v1, 0x20

    .line 6
    .line 7
    if-eqz v0, :cond_12

    .line 8
    .line 9
    add-int/lit8 v0, v0, -0x1

    .line 10
    .line 11
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->charAt(I)C

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eq v0, v1, :cond_11

    .line 16
    .line 17
    goto :goto_12

    .line 18
    :cond_11
    return-void

    .line 19
    :cond_12
    :goto_12
    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 20
    .line 21
    .line 22
    return-void
.end method

.method public static i0(Lgg1;)Z
    .registers 2

    .line 1
    invoke-static {p0}, Lq33;->z(Lgg1;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_33

    .line 6
    .line 7
    invoke-virtual {p0}, Lgg1;->s()Ljava/util/List;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    check-cast p0, Ljava/lang/Iterable;

    .line 12
    .line 13
    instance-of v0, p0, Ljava/util/Collection;

    .line 14
    .line 15
    if-eqz v0, :cond_1a

    .line 16
    .line 17
    move-object v0, p0

    .line 18
    check-cast v0, Ljava/util/Collection;

    .line 19
    .line 20
    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-eqz v0, :cond_1a

    .line 25
    .line 26
    goto :goto_31

    .line 27
    :cond_1a
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    :cond_1e
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    if-eqz v0, :cond_31

    .line 36
    .line 37
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    check-cast v0, Lq23;

    .line 42
    .line 43
    invoke-virtual {v0}, Lq23;->c()Z

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    if-eqz v0, :cond_1e

    .line 48
    .line 49
    goto :goto_33

    .line 50
    :cond_31
    :goto_31
    const/4 p0, 0x1

    .line 51
    return p0

    .line 52
    :cond_33
    :goto_33
    const/4 p0, 0x0

    .line 53
    return p0
.end method

.method public static u(Llr1;)Lot1;
    .registers 7

    .line 1
    instance-of v0, p0, Lxt1;

    .line 2
    .line 3
    sget-object v1, Lot1;->e:Lot1;

    .line 4
    .line 5
    sget-object v2, Ljt;->b:Ljt;

    .line 6
    .line 7
    sget-object v3, Lot1;->b:Lot1;

    .line 8
    .line 9
    if-eqz v0, :cond_14

    .line 10
    .line 11
    check-cast p0, Lxt1;

    .line 12
    .line 13
    invoke-virtual {p0}, Lxt1;->i()Ljt;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    if-ne p0, v2, :cond_13

    .line 18
    .line 19
    return-object v1

    .line 20
    :cond_13
    return-object v3

    .line 21
    :cond_14
    invoke-interface {p0}, Lm60;->p()Lm60;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    instance-of v4, v0, Lxt1;

    .line 26
    .line 27
    if-eqz v4, :cond_1f

    .line 28
    .line 29
    check-cast v0, Lxt1;

    .line 30
    .line 31
    goto :goto_20

    .line 32
    :cond_1f
    const/4 v0, 0x0

    .line 33
    :goto_20
    if-nez v0, :cond_23

    .line 34
    .line 35
    return-object v3

    .line 36
    :cond_23
    instance-of v4, p0, Lno;

    .line 37
    .line 38
    if-nez v4, :cond_28

    .line 39
    .line 40
    return-object v3

    .line 41
    :cond_28
    check-cast p0, Lno;

    .line 42
    .line 43
    invoke-interface {p0}, Lno;->r()Ljava/util/Collection;

    .line 44
    .line 45
    .line 46
    move-result-object v4

    .line 47
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 48
    .line 49
    .line 50
    invoke-interface {v4}, Ljava/util/Collection;->isEmpty()Z

    .line 51
    .line 52
    .line 53
    move-result v4

    .line 54
    sget-object v5, Lot1;->d:Lot1;

    .line 55
    .line 56
    if-nez v4, :cond_40

    .line 57
    .line 58
    invoke-virtual {v0}, Lxt1;->D()Lot1;

    .line 59
    .line 60
    .line 61
    move-result-object v4

    .line 62
    if-eq v4, v3, :cond_40

    .line 63
    .line 64
    return-object v5

    .line 65
    :cond_40
    invoke-virtual {v0}, Lxt1;->i()Ljt;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    if-ne v0, v2, :cond_5a

    .line 70
    .line 71
    invoke-interface {p0}, Llr1;->g()Lya0;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    sget-object v2, Lza0;->a:Lya0;

    .line 76
    .line 77
    invoke-static {v0, v2}, Ld31;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    if-nez v0, :cond_5a

    .line 82
    .line 83
    invoke-interface {p0}, Llr1;->D()Lot1;

    .line 84
    .line 85
    .line 86
    move-result-object p0

    .line 87
    if-ne p0, v1, :cond_59

    .line 88
    .line 89
    return-object v1

    .line 90
    :cond_59
    return-object v5

    .line 91
    :cond_5a
    return-object v3
.end method

.method public static synthetic y(Lpa0;Ljava/lang/StringBuilder;La6;)V
    .registers 4

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-virtual {p0, p1, p2, v0}, Lpa0;->x(Ljava/lang/StringBuilder;La6;Lg7;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public final A(Lsy;)Ljava/lang/String;
    .registers 9

    .line 1
    iget-object v0, p0, Lpa0;->a:Lta0;

    .line 2
    .line 3
    iget-object v0, v0, Lta0;->v:Lsa0;

    .line 4
    .line 5
    sget-object v1, Lta0;->Y:[Laf1;

    .line 6
    .line 7
    const/16 v2, 0x14

    .line 8
    .line 9
    aget-object v1, v1, v2

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    iget-object v0, v0, Lsa0;->a:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v0, Lft0;

    .line 20
    .line 21
    if-eqz v0, :cond_1d

    .line 22
    .line 23
    invoke-interface {v0, p1}, Lft0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    check-cast p0, Ljava/lang/String;

    .line 28
    .line 29
    return-object p0

    .line 30
    :cond_1d
    instance-of v0, p1, Ltb;

    .line 31
    .line 32
    if-eqz v0, :cond_55

    .line 33
    .line 34
    check-cast p1, Ltb;

    .line 35
    .line 36
    iget-object p1, p1, Lsy;->a:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast p1, Ljava/lang/Iterable;

    .line 39
    .line 40
    new-instance v0, Ljava/util/ArrayList;

    .line 41
    .line 42
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 43
    .line 44
    .line 45
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    :cond_30
    :goto_30
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 50
    .line 51
    .line 52
    move-result v1

    .line 53
    if-eqz v1, :cond_46

    .line 54
    .line 55
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v1

    .line 59
    check-cast v1, Lsy;

    .line 60
    .line 61
    invoke-virtual {p0, v1}, Lpa0;->A(Lsy;)Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object v1

    .line 65
    if-eqz v1, :cond_30

    .line 66
    .line 67
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 68
    .line 69
    .line 70
    goto :goto_30

    .line 71
    :cond_46
    const/4 v5, 0x0

    .line 72
    const/16 v6, 0x38

    .line 73
    .line 74
    const-string v1, ", "

    .line 75
    .line 76
    const-string v2, "{"

    .line 77
    .line 78
    const-string v3, "}"

    .line 79
    .line 80
    const/4 v4, 0x0

    .line 81
    invoke-static/range {v0 .. v6}, Lgv;->e0(Ljava/lang/Iterable;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILft0;I)Ljava/lang/String;

    .line 82
    .line 83
    .line 84
    move-result-object p0

    .line 85
    return-object p0

    .line 86
    :cond_55
    instance-of v0, p1, Lj7;

    .line 87
    .line 88
    const/4 v1, 0x0

    .line 89
    if-eqz v0, :cond_6b

    .line 90
    .line 91
    check-cast p1, Lj7;

    .line 92
    .line 93
    iget-object p1, p1, Lsy;->a:Ljava/lang/Object;

    .line 94
    .line 95
    check-cast p1, La7;

    .line 96
    .line 97
    invoke-virtual {p0, p1, v1}, Lpa0;->w(La7;Lg7;)Ljava/lang/String;

    .line 98
    .line 99
    .line 100
    move-result-object p0

    .line 101
    const-string p1, "@"

    .line 102
    .line 103
    invoke-static {p0, p1}, Lxt2;->Z(Ljava/lang/String;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 104
    .line 105
    .line 106
    move-result-object p0

    .line 107
    return-object p0

    .line 108
    :cond_6b
    instance-of p0, p1, Lid1;

    .line 109
    .line 110
    if-eqz p0, :cond_ba

    .line 111
    .line 112
    check-cast p1, Lid1;

    .line 113
    .line 114
    iget-object p0, p1, Lsy;->a:Ljava/lang/Object;

    .line 115
    .line 116
    check-cast p0, Lhd1;

    .line 117
    .line 118
    instance-of p1, p0, Lfd1;

    .line 119
    .line 120
    const-string v0, "::class"

    .line 121
    .line 122
    if-eqz p1, :cond_8f

    .line 123
    .line 124
    new-instance p1, Ljava/lang/StringBuilder;

    .line 125
    .line 126
    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    .line 127
    .line 128
    .line 129
    check-cast p0, Lfd1;

    .line 130
    .line 131
    iget-object p0, p0, Lfd1;->a:Lgg1;

    .line 132
    .line 133
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 134
    .line 135
    .line 136
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 137
    .line 138
    .line 139
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 140
    .line 141
    .line 142
    move-result-object p0

    .line 143
    return-object p0

    .line 144
    :cond_8f
    instance-of p1, p0, Lgd1;

    .line 145
    .line 146
    if-eqz p1, :cond_b6

    .line 147
    .line 148
    check-cast p0, Lgd1;

    .line 149
    .line 150
    iget-object p0, p0, Lgd1;->a:Lkt;

    .line 151
    .line 152
    iget-object p1, p0, Lkt;->a:Lft;

    .line 153
    .line 154
    invoke-virtual {p1}, Lft;->a()Lzq0;

    .line 155
    .line 156
    .line 157
    move-result-object p1

    .line 158
    invoke-virtual {p1}, Lzq0;->b()Ljava/lang/String;

    .line 159
    .line 160
    .line 161
    move-result-object p1

    .line 162
    iget p0, p0, Lkt;->b:I

    .line 163
    .line 164
    const/4 v1, 0x0

    .line 165
    :goto_a4
    if-ge v1, p0, :cond_b1

    .line 166
    .line 167
    const-string v2, "kotlin.Array<"

    .line 168
    .line 169
    const/16 v3, 0x3e

    .line 170
    .line 171
    invoke-static {v2, p1, v3}, Ls41;->q(Ljava/lang/String;Ljava/lang/String;C)Ljava/lang/String;

    .line 172
    .line 173
    .line 174
    move-result-object p1

    .line 175
    add-int/lit8 v1, v1, 0x1

    .line 176
    .line 177
    goto :goto_a4

    .line 178
    :cond_b1
    invoke-virtual {p1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 179
    .line 180
    .line 181
    move-result-object p0

    .line 182
    return-object p0

    .line 183
    :cond_b6
    invoke-static {}, Lm03;->a()V

    .line 184
    .line 185
    .line 186
    return-object v1

    .line 187
    :cond_ba
    invoke-virtual {p1}, Lsy;->toString()Ljava/lang/String;

    .line 188
    .line 189
    .line 190
    move-result-object p0

    .line 191
    return-object p0
.end method

.method public final B(Ljava/lang/StringBuilder;Ljava/util/List;)V
    .registers 8

    .line 1
    move-object v0, p2

    .line 2
    check-cast v0, Ljava/util/Collection;

    .line 3
    .line 4
    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-nez v0, :cond_4c

    .line 9
    .line 10
    const-string v0, "context("

    .line 11
    .line 12
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 13
    .line 14
    .line 15
    move-object v0, p2

    .line 16
    check-cast v0, Ljava/lang/Iterable;

    .line 17
    .line 18
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    const/4 v1, 0x0

    .line 23
    :goto_16
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 24
    .line 25
    .line 26
    move-result v2

    .line 27
    if-eqz v2, :cond_4c

    .line 28
    .line 29
    add-int/lit8 v2, v1, 0x1

    .line 30
    .line 31
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v3

    .line 35
    check-cast v3, Ltg1;

    .line 36
    .line 37
    sget-object v4, Lg7;->g:Lg7;

    .line 38
    .line 39
    invoke-virtual {p0, p1, v3, v4}, Lpa0;->x(Ljava/lang/StringBuilder;La6;Lg7;)V

    .line 40
    .line 41
    .line 42
    invoke-virtual {v3}, Ltg1;->getType()Lgg1;

    .line 43
    .line 44
    .line 45
    move-result-object v3

    .line 46
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 47
    .line 48
    .line 49
    invoke-virtual {p0, v3}, Lpa0;->F(Lgg1;)Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object v3

    .line 53
    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 54
    .line 55
    .line 56
    invoke-interface {p2}, Ljava/util/List;->size()I

    .line 57
    .line 58
    .line 59
    move-result v3

    .line 60
    add-int/lit8 v3, v3, -0x1

    .line 61
    .line 62
    if-ne v1, v3, :cond_45

    .line 63
    .line 64
    const-string v1, ") "

    .line 65
    .line 66
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 67
    .line 68
    .line 69
    goto :goto_4a

    .line 70
    :cond_45
    const-string v1, ", "

    .line 71
    .line 72
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 73
    .line 74
    .line 75
    :goto_4a
    move v1, v2

    .line 76
    goto :goto_16

    .line 77
    :cond_4c
    return-void
.end method

.method public final C(Ljava/lang/StringBuilder;Lko2;)V
    .registers 9

    .line 1
    invoke-static {p0, p1, p2}, Lpa0;->y(Lpa0;Ljava/lang/StringBuilder;La6;)V

    .line 2
    .line 3
    .line 4
    invoke-static {p2}, Lfw;->z(Lgg1;)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    const/4 v1, 0x0

    .line 9
    if-eqz v0, :cond_8b

    .line 10
    .line 11
    instance-of v0, p2, Lwj0;

    .line 12
    .line 13
    iget-object v2, p0, Lpa0;->a:Lta0;

    .line 14
    .line 15
    if-eqz v0, :cond_51

    .line 16
    .line 17
    move-object v3, p2

    .line 18
    check-cast v3, Lwj0;

    .line 19
    .line 20
    iget-object v3, v3, Lwj0;->d:Lyj0;

    .line 21
    .line 22
    iget-boolean v3, v3, Lyj0;->b:Z

    .line 23
    .line 24
    if-eqz v3, :cond_51

    .line 25
    .line 26
    iget-object v3, v2, Lta0;->V:Lsa0;

    .line 27
    .line 28
    sget-object v4, Lta0;->Y:[Laf1;

    .line 29
    .line 30
    const/16 v5, 0x2f

    .line 31
    .line 32
    aget-object v4, v4, v5

    .line 33
    .line 34
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 35
    .line 36
    .line 37
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 38
    .line 39
    .line 40
    iget-object v3, v3, Lsa0;->a:Ljava/lang/Object;

    .line 41
    .line 42
    check-cast v3, Ljava/lang/Boolean;

    .line 43
    .line 44
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 45
    .line 46
    .line 47
    move-result v3

    .line 48
    if-eqz v3, :cond_51

    .line 49
    .line 50
    sget-object v2, Lzj0;->a:Lzj0;

    .line 51
    .line 52
    if-eqz v0, :cond_3c

    .line 53
    .line 54
    move-object v0, p2

    .line 55
    check-cast v0, Lwj0;

    .line 56
    .line 57
    iget-object v0, v0, Lwj0;->d:Lyj0;

    .line 58
    .line 59
    iget-boolean v0, v0, Lyj0;->b:Z

    .line 60
    .line 61
    :cond_3c
    invoke-virtual {p2}, Lgg1;->y()Lp13;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 66
    .line 67
    .line 68
    check-cast v0, Lxj0;

    .line 69
    .line 70
    iget-object v0, v0, Lxj0;->b:[Ljava/lang/String;

    .line 71
    .line 72
    aget-object v0, v0, v1

    .line 73
    .line 74
    invoke-virtual {p0, v0}, Lpa0;->D(Ljava/lang/String;)Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object p0

    .line 78
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 79
    .line 80
    .line 81
    goto :goto_bb

    .line 82
    :cond_51
    if-eqz v0, :cond_74

    .line 83
    .line 84
    iget-object v0, v2, Lta0;->X:Lsa0;

    .line 85
    .line 86
    sget-object v1, Lta0;->Y:[Laf1;

    .line 87
    .line 88
    const/16 v2, 0x31

    .line 89
    .line 90
    aget-object v1, v1, v2

    .line 91
    .line 92
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 93
    .line 94
    .line 95
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 96
    .line 97
    .line 98
    iget-object v0, v0, Lsa0;->a:Ljava/lang/Object;

    .line 99
    .line 100
    check-cast v0, Ljava/lang/Boolean;

    .line 101
    .line 102
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 103
    .line 104
    .line 105
    move-result v0

    .line 106
    if-nez v0, :cond_74

    .line 107
    .line 108
    move-object v0, p2

    .line 109
    check-cast v0, Lwj0;

    .line 110
    .line 111
    iget-object v0, v0, Lwj0;->j:Ljava/lang/String;

    .line 112
    .line 113
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 114
    .line 115
    .line 116
    goto :goto_7f

    .line 117
    :cond_74
    invoke-virtual {p2}, Lgg1;->y()Lp13;

    .line 118
    .line 119
    .line 120
    move-result-object v0

    .line 121
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 122
    .line 123
    .line 124
    move-result-object v0

    .line 125
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 126
    .line 127
    .line 128
    :goto_7f
    invoke-virtual {p2}, Lgg1;->s()Ljava/util/List;

    .line 129
    .line 130
    .line 131
    move-result-object v0

    .line 132
    invoke-virtual {p0, v0}, Lpa0;->Y(Ljava/util/List;)Ljava/lang/String;

    .line 133
    .line 134
    .line 135
    move-result-object p0

    .line 136
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 137
    .line 138
    .line 139
    goto :goto_bb

    .line 140
    :cond_8b
    invoke-virtual {p2}, Lgg1;->y()Lp13;

    .line 141
    .line 142
    .line 143
    move-result-object v0

    .line 144
    invoke-virtual {p2}, Lgg1;->y()Lp13;

    .line 145
    .line 146
    .line 147
    move-result-object v2

    .line 148
    invoke-interface {v2}, Lp13;->c()Lau;

    .line 149
    .line 150
    .line 151
    move-result-object v2

    .line 152
    instance-of v3, v2, Lbu;

    .line 153
    .line 154
    if-eqz v3, :cond_9e

    .line 155
    .line 156
    check-cast v2, Lbu;

    .line 157
    .line 158
    goto :goto_9f

    .line 159
    :cond_9e
    const/4 v2, 0x0

    .line 160
    :goto_9f
    invoke-static {p2, v2, v1}, Ld31;->c(Lko2;Lbu;I)Lt51;

    .line 161
    .line 162
    .line 163
    move-result-object v1

    .line 164
    if-nez v1, :cond_b8

    .line 165
    .line 166
    invoke-virtual {p0, v0}, Lpa0;->Z(Lp13;)Ljava/lang/String;

    .line 167
    .line 168
    .line 169
    move-result-object v0

    .line 170
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 171
    .line 172
    .line 173
    invoke-virtual {p2}, Lgg1;->s()Ljava/util/List;

    .line 174
    .line 175
    .line 176
    move-result-object v0

    .line 177
    invoke-virtual {p0, v0}, Lpa0;->Y(Ljava/util/List;)Ljava/lang/String;

    .line 178
    .line 179
    .line 180
    move-result-object p0

    .line 181
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 182
    .line 183
    .line 184
    goto :goto_bb

    .line 185
    :cond_b8
    invoke-virtual {p0, p1, v1}, Lpa0;->T(Ljava/lang/StringBuilder;Lt51;)V

    .line 186
    .line 187
    .line 188
    :goto_bb
    invoke-virtual {p2}, Lgg1;->B()Z

    .line 189
    .line 190
    .line 191
    move-result p0

    .line 192
    if-eqz p0, :cond_c6

    .line 193
    .line 194
    const-string p0, "?"

    .line 195
    .line 196
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 197
    .line 198
    .line 199
    :cond_c6
    instance-of p0, p2, Lc90;

    .line 200
    .line 201
    if-eqz p0, :cond_cf

    .line 202
    .line 203
    const-string p0, " & Any"

    .line 204
    .line 205
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 206
    .line 207
    .line 208
    :cond_cf
    return-void
.end method

.method public final D(Ljava/lang/String;)Ljava/lang/String;
    .registers 3

    .line 1
    invoke-virtual {p0}, Lpa0;->r()Lme2;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 6
    .line 7
    .line 8
    move-result p0

    .line 9
    if-eqz p0, :cond_1b

    .line 10
    .line 11
    const/4 v0, 0x1

    .line 12
    if-ne p0, v0, :cond_16

    .line 13
    .line 14
    const-string p0, "<font color=red><b>"

    .line 15
    .line 16
    const-string v0, "</b></font>"

    .line 17
    .line 18
    invoke-static {p0, p1, v0}, Ln10;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :cond_16
    invoke-static {}, Lm03;->a()V

    .line 24
    .line 25
    .line 26
    const/4 p0, 0x0

    .line 27
    return-object p0

    .line 28
    :cond_1b
    return-object p1
.end method

.method public final E(Ljava/lang/String;Ljava/lang/String;Lxf1;)Ljava/lang/String;
    .registers 9

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    invoke-static {p1, p2}, Lb21;->A(Ljava/lang/String;Ljava/lang/String;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    const-string v1, "("

    .line 12
    .line 13
    if-eqz v0, :cond_24

    .line 14
    .line 15
    const/4 p0, 0x0

    .line 16
    const/4 p3, 0x2

    .line 17
    invoke-static {p3, p2, v1, p0}, Lfu2;->I(ILjava/lang/String;Ljava/lang/String;Z)Z

    .line 18
    .line 19
    .line 20
    move-result p0

    .line 21
    if-eqz p0, :cond_1d

    .line 22
    .line 23
    const-string p0, ")!"

    .line 24
    .line 25
    invoke-static {v1, p1, p0}, Ln10;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object p0

    .line 29
    return-object p0

    .line 30
    :cond_1d
    const-string p0, "!"

    .line 31
    .line 32
    invoke-virtual {p1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object p0

    .line 36
    return-object p0

    .line 37
    :cond_24
    invoke-virtual {p0}, Lpa0;->o()Lcu;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    sget-object v2, Lqr2;->C:Lzq0;

    .line 42
    .line 43
    invoke-virtual {p3, v2}, Lxf1;->i(Lzq0;)Lxt1;

    .line 44
    .line 45
    .line 46
    move-result-object v2

    .line 47
    invoke-virtual {v0, v2, p0}, Lcu;->b(Lau;Lpa0;)Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    const-string v2, "Collection"

    .line 52
    .line 53
    invoke-static {v0, v2}, Lxt2;->g0(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    const-string v2, "Mutable"

    .line 58
    .line 59
    invoke-virtual {v0, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object v2

    .line 63
    const-string v3, "(Mutable)"

    .line 64
    .line 65
    invoke-virtual {v0, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v3

    .line 69
    invoke-static {p1, v2, p2, v0, v3}, Lb21;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object v2

    .line 73
    if-eqz v2, :cond_4b

    .line 74
    .line 75
    return-object v2

    .line 76
    :cond_4b
    const-string v2, "MutableMap.MutableEntry"

    .line 77
    .line 78
    invoke-virtual {v0, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object v2

    .line 82
    const-string v3, "Map.Entry"

    .line 83
    .line 84
    invoke-virtual {v0, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object v3

    .line 88
    const-string v4, "(Mutable)Map.(Mutable)Entry"

    .line 89
    .line 90
    invoke-virtual {v0, v4}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    invoke-static {p1, v2, p2, v3, v0}, Lb21;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 95
    .line 96
    .line 97
    move-result-object v0

    .line 98
    if-eqz v0, :cond_64

    .line 99
    .line 100
    return-object v0

    .line 101
    :cond_64
    invoke-virtual {p0}, Lpa0;->o()Lcu;

    .line 102
    .line 103
    .line 104
    move-result-object v0

    .line 105
    const-string v2, "Array"

    .line 106
    .line 107
    invoke-virtual {p3, v2}, Lxf1;->j(Ljava/lang/String;)Lxt1;

    .line 108
    .line 109
    .line 110
    move-result-object p3

    .line 111
    invoke-virtual {v0, p3, p0}, Lcu;->b(Lau;Lpa0;)Ljava/lang/String;

    .line 112
    .line 113
    .line 114
    move-result-object p3

    .line 115
    invoke-static {p3, v2}, Lxt2;->g0(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 116
    .line 117
    .line 118
    move-result-object p3

    .line 119
    const-string v0, "Array<"

    .line 120
    .line 121
    invoke-virtual {p0, v0}, Lpa0;->n(Ljava/lang/String;)Ljava/lang/String;

    .line 122
    .line 123
    .line 124
    move-result-object v0

    .line 125
    invoke-virtual {p3, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 126
    .line 127
    .line 128
    move-result-object v0

    .line 129
    const-string v2, "Array<out "

    .line 130
    .line 131
    invoke-virtual {p0, v2}, Lpa0;->n(Ljava/lang/String;)Ljava/lang/String;

    .line 132
    .line 133
    .line 134
    move-result-object v2

    .line 135
    invoke-virtual {p3, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 136
    .line 137
    .line 138
    move-result-object v2

    .line 139
    const-string v3, "Array<(out) "

    .line 140
    .line 141
    invoke-virtual {p0, v3}, Lpa0;->n(Ljava/lang/String;)Ljava/lang/String;

    .line 142
    .line 143
    .line 144
    move-result-object p0

    .line 145
    invoke-virtual {p3, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 146
    .line 147
    .line 148
    move-result-object p0

    .line 149
    invoke-static {p1, v0, p2, v2, p0}, Lb21;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 150
    .line 151
    .line 152
    move-result-object p0

    .line 153
    if-eqz p0, :cond_9b

    .line 154
    .line 155
    return-object p0

    .line 156
    :cond_9b
    new-instance p0, Ljava/lang/StringBuilder;

    .line 157
    .line 158
    invoke-direct {p0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 159
    .line 160
    .line 161
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 162
    .line 163
    .line 164
    const-string p1, ".."

    .line 165
    .line 166
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 167
    .line 168
    .line 169
    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 170
    .line 171
    .line 172
    const/16 p1, 0x29

    .line 173
    .line 174
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 175
    .line 176
    .line 177
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 178
    .line 179
    .line 180
    move-result-object p0

    .line 181
    return-object p0
.end method

.method public final F(Lgg1;)Ljava/lang/String;
    .registers 3

    .line 1
    invoke-virtual {p0, p1}, Lpa0;->X(Lgg1;)Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-static {p1}, Lpa0;->i0(Lgg1;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_10

    .line 10
    .line 11
    invoke-static {p1}, La33;->e(Lgg1;)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_14

    .line 16
    .line 17
    :cond_10
    instance-of p1, p1, Lc90;

    .line 18
    .line 19
    if-eqz p1, :cond_1c

    .line 20
    .line 21
    :cond_14
    const-string p1, "("

    .line 22
    .line 23
    const/16 v0, 0x29

    .line 24
    .line 25
    invoke-static {p1, p0, v0}, Ls41;->q(Ljava/lang/String;Ljava/lang/String;C)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object p0

    .line 29
    :cond_1c
    return-object p0
.end method

.method public final G(Ld73;Ljava/lang/StringBuilder;)V
    .registers 6

    .line 1
    iget-object v0, p0, Lpa0;->a:Lta0;

    .line 2
    .line 3
    iget-object v0, v0, Lta0;->u:Lsa0;

    .line 4
    .line 5
    sget-object v1, Lta0;->Y:[Laf1;

    .line 6
    .line 7
    const/16 v2, 0x13

    .line 8
    .line 9
    aget-object v1, v1, v2

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    iget-object v0, v0, Lsa0;->a:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v0, Ljava/lang/Boolean;

    .line 20
    .line 21
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-eqz v0, :cond_32

    .line 26
    .line 27
    invoke-interface {p1}, Ld73;->l0()Lsy;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    if-eqz p1, :cond_32

    .line 32
    .line 33
    invoke-virtual {p0, p1}, Lpa0;->A(Lsy;)Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    if-eqz p1, :cond_32

    .line 38
    .line 39
    const-string v0, " = "

    .line 40
    .line 41
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 42
    .line 43
    .line 44
    invoke-virtual {p0, p1}, Lpa0;->n(Ljava/lang/String;)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object p0

    .line 48
    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 49
    .line 50
    .line 51
    :cond_32
    return-void
.end method

.method public final H(Ljava/lang/String;)Ljava/lang/String;
    .registers 4

    .line 1
    invoke-virtual {p0}, Lpa0;->r()Lme2;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_36

    .line 10
    .line 11
    const/4 v1, 0x1

    .line 12
    if-ne v0, v1, :cond_31

    .line 13
    .line 14
    iget-object p0, p0, Lpa0;->a:Lta0;

    .line 15
    .line 16
    iget-object p0, p0, Lta0;->W:Lsa0;

    .line 17
    .line 18
    sget-object v0, Lta0;->Y:[Laf1;

    .line 19
    .line 20
    const/16 v1, 0x30

    .line 21
    .line 22
    aget-object v0, v0, v1

    .line 23
    .line 24
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 25
    .line 26
    .line 27
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 28
    .line 29
    .line 30
    iget-object p0, p0, Lsa0;->a:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast p0, Ljava/lang/Boolean;

    .line 33
    .line 34
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 35
    .line 36
    .line 37
    move-result p0

    .line 38
    if-eqz p0, :cond_28

    .line 39
    .line 40
    goto :goto_36

    .line 41
    :cond_28
    const-string p0, "<b>"

    .line 42
    .line 43
    const-string v0, "</b>"

    .line 44
    .line 45
    invoke-static {p0, p1, v0}, Ln10;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object p0

    .line 49
    return-object p0

    .line 50
    :cond_31
    invoke-static {}, Lm03;->a()V

    .line 51
    .line 52
    .line 53
    const/4 p0, 0x0

    .line 54
    return-object p0

    .line 55
    :cond_36
    :goto_36
    return-object p1
.end method

.method public final I(Lno;Ljava/lang/StringBuilder;)V
    .registers 5

    .line 1
    invoke-virtual {p0}, Lpa0;->p()Ljava/util/Set;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    sget-object v1, Lqa0;->l:Lqa0;

    .line 6
    .line 7
    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-nez v0, :cond_d

    .line 12
    .line 13
    goto :goto_47

    .line 14
    :cond_d
    invoke-virtual {p0}, Lpa0;->t()Z

    .line 15
    .line 16
    .line 17
    move-result p0

    .line 18
    if-eqz p0, :cond_47

    .line 19
    .line 20
    invoke-interface {p1}, Lno;->j()I

    .line 21
    .line 22
    .line 23
    move-result p0

    .line 24
    const/4 v0, 0x1

    .line 25
    if-eq p0, v0, :cond_47

    .line 26
    .line 27
    const-string p0, "/*"

    .line 28
    .line 29
    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 30
    .line 31
    .line 32
    invoke-interface {p1}, Lno;->j()I

    .line 33
    .line 34
    .line 35
    move-result p0

    .line 36
    if-eq p0, v0, :cond_39

    .line 37
    .line 38
    const/4 p1, 0x2

    .line 39
    if-eq p0, p1, :cond_36

    .line 40
    .line 41
    const/4 p1, 0x3

    .line 42
    if-eq p0, p1, :cond_33

    .line 43
    .line 44
    const/4 p1, 0x4

    .line 45
    if-ne p0, p1, :cond_31

    .line 46
    .line 47
    const-string p0, "SYNTHESIZED"

    .line 48
    .line 49
    goto :goto_3b

    .line 50
    :cond_31
    const/4 p0, 0x0

    .line 51
    throw p0

    .line 52
    :cond_33
    const-string p0, "DELEGATION"

    .line 53
    .line 54
    goto :goto_3b

    .line 55
    :cond_36
    const-string p0, "FAKE_OVERRIDE"

    .line 56
    .line 57
    goto :goto_3b

    .line 58
    :cond_39
    const-string p0, "DECLARATION"

    .line 59
    .line 60
    :goto_3b
    invoke-static {p0}, Lvs3;->D(Ljava/lang/String;)Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object p0

    .line 64
    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 65
    .line 66
    .line 67
    const-string p0, "*/ "

    .line 68
    .line 69
    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 70
    .line 71
    .line 72
    :cond_47
    :goto_47
    return-void
.end method

.method public final J(Llr1;Ljava/lang/StringBuilder;)V
    .registers 7

    .line 1
    invoke-interface {p1}, Llr1;->z()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const-string v1, "external"

    .line 6
    .line 7
    invoke-virtual {p0, p2, v0, v1}, Lpa0;->M(Ljava/lang/StringBuilder;ZLjava/lang/String;)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0}, Lpa0;->p()Ljava/util/Set;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    sget-object v1, Lqa0;->o:Lqa0;

    .line 15
    .line 16
    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    const/4 v1, 0x0

    .line 21
    const/4 v2, 0x1

    .line 22
    if-eqz v0, :cond_1f

    .line 23
    .line 24
    invoke-interface {p1}, Llr1;->Y()Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_1f

    .line 29
    .line 30
    move v0, v2

    .line 31
    goto :goto_20

    .line 32
    :cond_1f
    move v0, v1

    .line 33
    :goto_20
    const-string v3, "expect"

    .line 34
    .line 35
    invoke-virtual {p0, p2, v0, v3}, Lpa0;->M(Ljava/lang/StringBuilder;ZLjava/lang/String;)V

    .line 36
    .line 37
    .line 38
    invoke-virtual {p0}, Lpa0;->p()Ljava/util/Set;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    sget-object v3, Lqa0;->p:Lqa0;

    .line 43
    .line 44
    invoke-interface {v0, v3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_38

    .line 49
    .line 50
    invoke-interface {p1}, Llr1;->o0()Z

    .line 51
    .line 52
    .line 53
    move-result p1

    .line 54
    if-eqz p1, :cond_38

    .line 55
    .line 56
    move v1, v2

    .line 57
    :cond_38
    const-string p1, "actual"

    .line 58
    .line 59
    invoke-virtual {p0, p2, v1, p1}, Lpa0;->M(Ljava/lang/StringBuilder;ZLjava/lang/String;)V

    .line 60
    .line 61
    .line 62
    return-void
.end method

.method public final K(Lot1;Ljava/lang/StringBuilder;Lot1;)V
    .registers 7

    .line 1
    iget-object v0, p0, Lpa0;->a:Lta0;

    .line 2
    .line 3
    iget-object v0, v0, Lta0;->p:Lsa0;

    .line 4
    .line 5
    sget-object v1, Lta0;->Y:[Laf1;

    .line 6
    .line 7
    const/16 v2, 0xe

    .line 8
    .line 9
    aget-object v1, v1, v2

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    iget-object v0, v0, Lsa0;->a:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v0, Ljava/lang/Boolean;

    .line 20
    .line 21
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-nez v0, :cond_1d

    .line 26
    .line 27
    if-ne p1, p3, :cond_1d

    .line 28
    .line 29
    return-void

    .line 30
    :cond_1d
    invoke-virtual {p0}, Lpa0;->p()Ljava/util/Set;

    .line 31
    .line 32
    .line 33
    move-result-object p3

    .line 34
    sget-object v0, Lqa0;->e:Lqa0;

    .line 35
    .line 36
    invoke-interface {p3, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 37
    .line 38
    .line 39
    move-result p3

    .line 40
    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object p1

    .line 44
    invoke-static {p1}, Lvs3;->D(Ljava/lang/String;)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    invoke-virtual {p0, p2, p3, p1}, Lpa0;->M(Ljava/lang/StringBuilder;ZLjava/lang/String;)V

    .line 49
    .line 50
    .line 51
    return-void
.end method

.method public final L(Lno;Ljava/lang/StringBuilder;)V
    .registers 6

    .line 1
    invoke-static {p1}, Lva0;->s(Lm60;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_e

    .line 6
    .line 7
    invoke-interface {p1}, Llr1;->D()Lot1;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    sget-object v1, Lot1;->b:Lot1;

    .line 12
    .line 13
    if-eq v0, v1, :cond_38

    .line 14
    .line 15
    :cond_e
    iget-object v0, p0, Lpa0;->a:Lta0;

    .line 16
    .line 17
    iget-object v0, v0, Lta0;->B:Lsa0;

    .line 18
    .line 19
    sget-object v1, Lta0;->Y:[Laf1;

    .line 20
    .line 21
    const/16 v2, 0x1a

    .line 22
    .line 23
    aget-object v1, v1, v2

    .line 24
    .line 25
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 26
    .line 27
    .line 28
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 29
    .line 30
    .line 31
    iget-object v0, v0, Lsa0;->a:Ljava/lang/Object;

    .line 32
    .line 33
    check-cast v0, Lp02;

    .line 34
    .line 35
    sget-object v1, Lp02;->a:Lp02;

    .line 36
    .line 37
    if-ne v0, v1, :cond_39

    .line 38
    .line 39
    invoke-interface {p1}, Llr1;->D()Lot1;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    sget-object v1, Lot1;->d:Lot1;

    .line 44
    .line 45
    if-ne v0, v1, :cond_39

    .line 46
    .line 47
    invoke-interface {p1}, Lno;->r()Ljava/util/Collection;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    if-nez v0, :cond_39

    .line 56
    .line 57
    :cond_38
    return-void

    .line 58
    :cond_39
    invoke-interface {p1}, Llr1;->D()Lot1;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 63
    .line 64
    .line 65
    invoke-static {p1}, Lpa0;->u(Llr1;)Lot1;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    invoke-virtual {p0, v0, p2, p1}, Lpa0;->K(Lot1;Ljava/lang/StringBuilder;Lot1;)V

    .line 70
    .line 71
    .line 72
    return-void
.end method

.method public final M(Ljava/lang/StringBuilder;ZLjava/lang/String;)V
    .registers 4

    .line 1
    if-eqz p2, :cond_e

    .line 2
    .line 3
    invoke-virtual {p0, p3}, Lpa0;->H(Ljava/lang/String;)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 8
    .line 9
    .line 10
    const-string p0, " "

    .line 11
    .line 12
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 13
    .line 14
    .line 15
    :cond_e
    return-void
.end method

.method public final N(Ldv1;Z)Ljava/lang/String;
    .registers 6

    .line 1
    invoke-static {p1}, Lb21;->u(Ldv1;)Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    invoke-virtual {p0, p1}, Lpa0;->n(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    iget-object v0, p0, Lpa0;->a:Lta0;

    .line 10
    .line 11
    iget-object v0, v0, Lta0;->W:Lsa0;

    .line 12
    .line 13
    sget-object v1, Lta0;->Y:[Laf1;

    .line 14
    .line 15
    const/16 v2, 0x30

    .line 16
    .line 17
    aget-object v1, v1, v2

    .line 18
    .line 19
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    .line 24
    .line 25
    iget-object v0, v0, Lsa0;->a:Ljava/lang/Object;

    .line 26
    .line 27
    check-cast v0, Ljava/lang/Boolean;

    .line 28
    .line 29
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-eqz v0, :cond_35

    .line 34
    .line 35
    invoke-virtual {p0}, Lpa0;->r()Lme2;

    .line 36
    .line 37
    .line 38
    move-result-object p0

    .line 39
    sget-object v0, Lme2;->b:Lke2;

    .line 40
    .line 41
    if-ne p0, v0, :cond_35

    .line 42
    .line 43
    if-eqz p2, :cond_35

    .line 44
    .line 45
    const-string p0, "<b>"

    .line 46
    .line 47
    const-string p2, "</b>"

    .line 48
    .line 49
    invoke-static {p0, p1, p2}, Ln10;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object p0

    .line 53
    return-object p0

    .line 54
    :cond_35
    return-object p1
.end method

.method public final O(Lm60;Ljava/lang/StringBuilder;Z)V
    .registers 4

    .line 1
    invoke-interface {p1}, Lm60;->getName()Ldv1;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0, p1, p3}, Lpa0;->N(Ldv1;Z)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public final P(Ljava/lang/StringBuilder;Lgg1;)V
    .registers 12

    .line 1
    invoke-virtual {p2}, Lgg1;->h0()Lv53;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    instance-of v1, v0, Lc;

    .line 6
    .line 7
    if-eqz v1, :cond_b

    .line 8
    .line 9
    check-cast v0, Lc;

    .line 10
    .line 11
    goto :goto_c

    .line 12
    :cond_b
    const/4 v0, 0x0

    .line 13
    :goto_c
    if-eqz v0, :cond_aa

    .line 14
    .line 15
    iget-object p2, v0, Lc;->c:Lko2;

    .line 16
    .line 17
    iget-object v0, v0, Lc;->b:Lko2;

    .line 18
    .line 19
    iget-object v1, p0, Lpa0;->a:Lta0;

    .line 20
    .line 21
    iget-object v2, v1, Lta0;->R:Lsa0;

    .line 22
    .line 23
    sget-object v3, Lta0;->Y:[Laf1;

    .line 24
    .line 25
    const/16 v4, 0x2a

    .line 26
    .line 27
    aget-object v4, v3, v4

    .line 28
    .line 29
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 30
    .line 31
    .line 32
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 33
    .line 34
    .line 35
    iget-object v2, v2, Lsa0;->a:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast v2, Ljava/lang/Boolean;

    .line 38
    .line 39
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 40
    .line 41
    .line 42
    move-result v2

    .line 43
    sget-object v4, Lme2;->b:Lke2;

    .line 44
    .line 45
    const-string v5, "</i></font>"

    .line 46
    .line 47
    const-string v6, " */"

    .line 48
    .line 49
    const-string v7, " /* "

    .line 50
    .line 51
    const-string v8, "<font color=\"808080\"><i>"

    .line 52
    .line 53
    if-eqz v2, :cond_70

    .line 54
    .line 55
    invoke-virtual {p0, p1, v0}, Lpa0;->Q(Ljava/lang/StringBuilder;Lgg1;)V

    .line 56
    .line 57
    .line 58
    iget-object v0, v1, Lta0;->S:Lsa0;

    .line 59
    .line 60
    const/16 v1, 0x2b

    .line 61
    .line 62
    aget-object v1, v3, v1

    .line 63
    .line 64
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 65
    .line 66
    .line 67
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 68
    .line 69
    .line 70
    iget-object v0, v0, Lsa0;->a:Ljava/lang/Object;

    .line 71
    .line 72
    check-cast v0, Ljava/lang/Boolean;

    .line 73
    .line 74
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    if-eqz v0, :cond_a9

    .line 79
    .line 80
    invoke-virtual {p0}, Lpa0;->r()Lme2;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    if-ne v0, v4, :cond_58

    .line 85
    .line 86
    invoke-virtual {p1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 87
    .line 88
    .line 89
    :cond_58
    invoke-virtual {p1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 90
    .line 91
    .line 92
    const-string v0, "from: "

    .line 93
    .line 94
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 95
    .line 96
    .line 97
    invoke-virtual {p0, p1, p2}, Lpa0;->Q(Ljava/lang/StringBuilder;Lgg1;)V

    .line 98
    .line 99
    .line 100
    invoke-virtual {p1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 101
    .line 102
    .line 103
    invoke-virtual {p0}, Lpa0;->r()Lme2;

    .line 104
    .line 105
    .line 106
    move-result-object p0

    .line 107
    if-ne p0, v4, :cond_a9

    .line 108
    .line 109
    invoke-virtual {p1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 110
    .line 111
    .line 112
    return-void

    .line 113
    :cond_70
    invoke-virtual {p0, p1, p2}, Lpa0;->Q(Ljava/lang/StringBuilder;Lgg1;)V

    .line 114
    .line 115
    .line 116
    iget-object p2, v1, Lta0;->Q:Lsa0;

    .line 117
    .line 118
    const/16 v1, 0x29

    .line 119
    .line 120
    aget-object v1, v3, v1

    .line 121
    .line 122
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 123
    .line 124
    .line 125
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 126
    .line 127
    .line 128
    iget-object p2, p2, Lsa0;->a:Ljava/lang/Object;

    .line 129
    .line 130
    check-cast p2, Ljava/lang/Boolean;

    .line 131
    .line 132
    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 133
    .line 134
    .line 135
    move-result p2

    .line 136
    if-eqz p2, :cond_a9

    .line 137
    .line 138
    invoke-virtual {p0}, Lpa0;->r()Lme2;

    .line 139
    .line 140
    .line 141
    move-result-object p2

    .line 142
    if-ne p2, v4, :cond_92

    .line 143
    .line 144
    invoke-virtual {p1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 145
    .line 146
    .line 147
    :cond_92
    invoke-virtual {p1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 148
    .line 149
    .line 150
    const-string p2, "= "

    .line 151
    .line 152
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 153
    .line 154
    .line 155
    invoke-virtual {p0, p1, v0}, Lpa0;->Q(Ljava/lang/StringBuilder;Lgg1;)V

    .line 156
    .line 157
    .line 158
    invoke-virtual {p1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 159
    .line 160
    .line 161
    invoke-virtual {p0}, Lpa0;->r()Lme2;

    .line 162
    .line 163
    .line 164
    move-result-object p0

    .line 165
    if-ne p0, v4, :cond_a9

    .line 166
    .line 167
    invoke-virtual {p1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 168
    .line 169
    .line 170
    :cond_a9
    return-void

    .line 171
    :cond_aa
    invoke-virtual {p0, p1, p2}, Lpa0;->Q(Ljava/lang/StringBuilder;Lgg1;)V

    .line 172
    .line 173
    .line 174
    return-void
.end method

.method public final Q(Ljava/lang/StringBuilder;Lgg1;)V
    .registers 27

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    iget-object v3, v0, Lpa0;->a:Lta0;

    .line 8
    .line 9
    instance-of v4, v2, Lii1;

    .line 10
    .line 11
    if-eqz v4, :cond_2a

    .line 12
    .line 13
    invoke-virtual {v3}, Lta0;->o()Z

    .line 14
    .line 15
    .line 16
    move-result v4

    .line 17
    if-eqz v4, :cond_2a

    .line 18
    .line 19
    move-object v4, v2

    .line 20
    check-cast v4, Lii1;

    .line 21
    .line 22
    iget-object v4, v4, Lii1;->d:Lzl1;

    .line 23
    .line 24
    iget-object v5, v4, Lyl1;->c:Ljava/lang/Object;

    .line 25
    .line 26
    sget-object v6, Lbm1;->a:Lbm1;

    .line 27
    .line 28
    if-eq v5, v6, :cond_24

    .line 29
    .line 30
    iget-object v4, v4, Lyl1;->c:Ljava/lang/Object;

    .line 31
    .line 32
    sget-object v5, Lbm1;->b:Lbm1;

    .line 33
    .line 34
    if-eq v4, v5, :cond_24

    .line 35
    .line 36
    goto :goto_2a

    .line 37
    :cond_24
    const-string v0, "<Not computed yet>"

    .line 38
    .line 39
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 40
    .line 41
    .line 42
    return-void

    .line 43
    :cond_2a
    :goto_2a
    invoke-virtual {v2}, Lgg1;->h0()Lv53;

    .line 44
    .line 45
    .line 46
    move-result-object v2

    .line 47
    instance-of v4, v2, Lwo0;

    .line 48
    .line 49
    if-eqz v4, :cond_3c

    .line 50
    .line 51
    check-cast v2, Lwo0;

    .line 52
    .line 53
    invoke-virtual {v2, v0, v0}, Lwo0;->y0(Lpa0;Lpa0;)Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 58
    .line 59
    .line 60
    return-void

    .line 61
    :cond_3c
    instance-of v4, v2, Lko2;

    .line 62
    .line 63
    if-eqz v4, :cond_2b6

    .line 64
    .line 65
    check-cast v2, Lko2;

    .line 66
    .line 67
    sget-object v4, La33;->b:Lwj0;

    .line 68
    .line 69
    invoke-virtual {v2, v4}, Lgg1;->equals(Ljava/lang/Object;)Z

    .line 70
    .line 71
    .line 72
    move-result v4

    .line 73
    const-string v5, "???"

    .line 74
    .line 75
    if-nez v4, :cond_2b2

    .line 76
    .line 77
    invoke-virtual {v2}, Lgg1;->y()Lp13;

    .line 78
    .line 79
    .line 80
    move-result-object v4

    .line 81
    sget-object v6, La33;->a:Lwj0;

    .line 82
    .line 83
    iget-object v6, v6, Lwj0;->b:Lp13;

    .line 84
    .line 85
    if-ne v4, v6, :cond_58

    .line 86
    .line 87
    goto/16 :goto_2b2

    .line 88
    .line 89
    :cond_58
    invoke-virtual {v2}, Lgg1;->y()Lp13;

    .line 90
    .line 91
    .line 92
    move-result-object v4

    .line 93
    instance-of v6, v4, Lxj0;

    .line 94
    .line 95
    const/4 v7, 0x0

    .line 96
    if-eqz v6, :cond_9a

    .line 97
    .line 98
    check-cast v4, Lxj0;

    .line 99
    .line 100
    iget-object v4, v4, Lxj0;->a:Lyj0;

    .line 101
    .line 102
    sget-object v6, Lyj0;->m:Lyj0;

    .line 103
    .line 104
    if-ne v4, v6, :cond_9a

    .line 105
    .line 106
    iget-object v3, v3, Lta0;->t:Lsa0;

    .line 107
    .line 108
    sget-object v4, Lta0;->Y:[Laf1;

    .line 109
    .line 110
    const/16 v6, 0x12

    .line 111
    .line 112
    aget-object v4, v4, v6

    .line 113
    .line 114
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 115
    .line 116
    .line 117
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 118
    .line 119
    .line 120
    iget-object v3, v3, Lsa0;->a:Ljava/lang/Object;

    .line 121
    .line 122
    check-cast v3, Ljava/lang/Boolean;

    .line 123
    .line 124
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 125
    .line 126
    .line 127
    move-result v3

    .line 128
    if-eqz v3, :cond_96

    .line 129
    .line 130
    invoke-virtual {v2}, Lgg1;->y()Lp13;

    .line 131
    .line 132
    .line 133
    move-result-object v2

    .line 134
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 135
    .line 136
    .line 137
    check-cast v2, Lxj0;

    .line 138
    .line 139
    iget-object v2, v2, Lxj0;->b:[Ljava/lang/String;

    .line 140
    .line 141
    aget-object v2, v2, v7

    .line 142
    .line 143
    invoke-virtual {v0, v2}, Lpa0;->D(Ljava/lang/String;)Ljava/lang/String;

    .line 144
    .line 145
    .line 146
    move-result-object v0

    .line 147
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 148
    .line 149
    .line 150
    return-void

    .line 151
    :cond_96
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 152
    .line 153
    .line 154
    return-void

    .line 155
    :cond_9a
    invoke-static {v2}, Lfw;->z(Lgg1;)Z

    .line 156
    .line 157
    .line 158
    move-result v4

    .line 159
    if-eqz v4, :cond_a4

    .line 160
    .line 161
    invoke-virtual {v0, v1, v2}, Lpa0;->C(Ljava/lang/StringBuilder;Lko2;)V

    .line 162
    .line 163
    .line 164
    return-void

    .line 165
    :cond_a4
    invoke-static {v2}, Lpa0;->i0(Lgg1;)Z

    .line 166
    .line 167
    .line 168
    move-result v4

    .line 169
    if-eqz v4, :cond_2ae

    .line 170
    .line 171
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->length()I

    .line 172
    .line 173
    .line 174
    move-result v4

    .line 175
    iget-object v6, v0, Lpa0;->b:Lrv2;

    .line 176
    .line 177
    invoke-virtual {v6}, Lrv2;->getValue()Ljava/lang/Object;

    .line 178
    .line 179
    .line 180
    move-result-object v6

    .line 181
    check-cast v6, Lpa0;

    .line 182
    .line 183
    invoke-static {v6, v1, v2}, Lpa0;->y(Lpa0;Ljava/lang/StringBuilder;La6;)V

    .line 184
    .line 185
    .line 186
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->length()I

    .line 187
    .line 188
    .line 189
    move-result v6

    .line 190
    const/4 v8, 0x1

    .line 191
    if-eq v6, v4, :cond_c2

    .line 192
    .line 193
    move v6, v8

    .line 194
    goto :goto_c3

    .line 195
    :cond_c2
    move v6, v7

    .line 196
    :goto_c3
    invoke-static {v2}, Lq33;->q(Lgg1;)Lgg1;

    .line 197
    .line 198
    .line 199
    move-result-object v9

    .line 200
    invoke-static {v2}, Lq33;->m(Lgg1;)Ljava/util/List;

    .line 201
    .line 202
    .line 203
    move-result-object v10

    .line 204
    invoke-virtual {v2}, Lgg1;->y()Lp13;

    .line 205
    .line 206
    .line 207
    move-result-object v11

    .line 208
    invoke-interface {v11}, Lp13;->c()Lau;

    .line 209
    .line 210
    .line 211
    move-result-object v11

    .line 212
    if-eqz v11, :cond_da

    .line 213
    .line 214
    invoke-static {v11}, Lq33;->n(Lau;)Ltu0;

    .line 215
    .line 216
    .line 217
    move-result-object v11

    .line 218
    goto :goto_db

    .line 219
    :cond_da
    const/4 v11, 0x0

    .line 220
    :goto_db
    sget-object v13, Lsu0;->c:Lsu0;

    .line 221
    .line 222
    invoke-static {v11, v13}, Ld31;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 223
    .line 224
    .line 225
    move-result v11

    .line 226
    invoke-virtual {v2}, Lgg1;->B()Z

    .line 227
    .line 228
    .line 229
    move-result v13

    .line 230
    if-nez v13, :cond_ee

    .line 231
    .line 232
    if-eqz v6, :cond_ec

    .line 233
    .line 234
    if-eqz v9, :cond_ec

    .line 235
    .line 236
    goto :goto_ee

    .line 237
    :cond_ec
    move v14, v7

    .line 238
    goto :goto_ef

    .line 239
    :cond_ee
    :goto_ee
    move v14, v8

    .line 240
    :goto_ef
    const-string v15, "("

    .line 241
    .line 242
    if-eqz v14, :cond_131

    .line 243
    .line 244
    if-eqz v11, :cond_fb

    .line 245
    .line 246
    const/16 v6, 0x28

    .line 247
    .line 248
    invoke-virtual {v1, v4, v6}, Ljava/lang/StringBuilder;->insert(IC)Ljava/lang/StringBuilder;

    .line 249
    .line 250
    .line 251
    goto :goto_131

    .line 252
    :cond_fb
    if-eqz v6, :cond_12e

    .line 253
    .line 254
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->length()I

    .line 255
    .line 256
    .line 257
    move-result v4

    .line 258
    if-eqz v4, :cond_128

    .line 259
    .line 260
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->length()I

    .line 261
    .line 262
    .line 263
    move-result v4

    .line 264
    sub-int/2addr v4, v8

    .line 265
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->charAt(I)C

    .line 266
    .line 267
    .line 268
    move-result v4

    .line 269
    invoke-static {v4}, Lg70;->m(C)Z

    .line 270
    .line 271
    .line 272
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->length()I

    .line 273
    .line 274
    .line 275
    move-result v4

    .line 276
    add-int/lit8 v4, v4, -0x2

    .line 277
    .line 278
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->charAt(I)C

    .line 279
    .line 280
    .line 281
    move-result v4

    .line 282
    const/16 v6, 0x29

    .line 283
    .line 284
    if-eq v4, v6, :cond_12e

    .line 285
    .line 286
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->length()I

    .line 287
    .line 288
    .line 289
    move-result v4

    .line 290
    sub-int/2addr v4, v8

    .line 291
    const-string v6, "()"

    .line 292
    .line 293
    invoke-virtual {v1, v4, v6}, Ljava/lang/StringBuilder;->insert(ILjava/lang/String;)Ljava/lang/StringBuilder;

    .line 294
    .line 295
    .line 296
    goto :goto_12e

    .line 297
    :cond_128
    const-string v0, "Char sequence is empty."

    .line 298
    .line 299
    invoke-static {v0}, Lm03;->j(Ljava/lang/String;)V

    .line 300
    .line 301
    .line 302
    return-void

    .line 303
    :cond_12e
    :goto_12e
    invoke-virtual {v1, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 304
    .line 305
    .line 306
    :cond_131
    :goto_131
    move-object v4, v10

    .line 307
    check-cast v4, Ljava/util/Collection;

    .line 308
    .line 309
    invoke-interface {v4}, Ljava/util/Collection;->isEmpty()Z

    .line 310
    .line 311
    .line 312
    move-result v4

    .line 313
    const-string v6, ") "

    .line 314
    .line 315
    const-string v12, ", "

    .line 316
    .line 317
    if-nez v4, :cond_172

    .line 318
    .line 319
    const-string v4, "context("

    .line 320
    .line 321
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 322
    .line 323
    .line 324
    invoke-interface {v10}, Ljava/util/List;->size()I

    .line 325
    .line 326
    .line 327
    move-result v4

    .line 328
    sub-int/2addr v4, v8

    .line 329
    invoke-interface {v10, v7, v4}, Ljava/util/List;->subList(II)Ljava/util/List;

    .line 330
    .line 331
    .line 332
    move-result-object v4

    .line 333
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 334
    .line 335
    .line 336
    move-result-object v4

    .line 337
    :goto_150
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 338
    .line 339
    .line 340
    move-result v16

    .line 341
    if-eqz v16, :cond_166

    .line 342
    .line 343
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 344
    .line 345
    .line 346
    move-result-object v16

    .line 347
    move-object/from16 v7, v16

    .line 348
    .line 349
    check-cast v7, Lgg1;

    .line 350
    .line 351
    invoke-virtual {v0, v1, v7}, Lpa0;->P(Ljava/lang/StringBuilder;Lgg1;)V

    .line 352
    .line 353
    .line 354
    invoke-virtual {v1, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 355
    .line 356
    .line 357
    const/4 v7, 0x0

    .line 358
    goto :goto_150

    .line 359
    :cond_166
    invoke-static {v10}, Lgv;->g0(Ljava/util/List;)Ljava/lang/Object;

    .line 360
    .line 361
    .line 362
    move-result-object v4

    .line 363
    check-cast v4, Lgg1;

    .line 364
    .line 365
    invoke-virtual {v0, v1, v4}, Lpa0;->P(Ljava/lang/StringBuilder;Lgg1;)V

    .line 366
    .line 367
    .line 368
    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 369
    .line 370
    .line 371
    :cond_172
    const-string v4, "suspend"

    .line 372
    .line 373
    invoke-virtual {v0, v1, v11, v4}, Lpa0;->M(Ljava/lang/StringBuilder;ZLjava/lang/String;)V

    .line 374
    .line 375
    .line 376
    const-string v4, ")"

    .line 377
    .line 378
    if-eqz v9, :cond_1c4

    .line 379
    .line 380
    invoke-static {v9}, Lpa0;->i0(Lgg1;)Z

    .line 381
    .line 382
    .line 383
    move-result v7

    .line 384
    if-eqz v7, :cond_187

    .line 385
    .line 386
    invoke-virtual {v9}, Lgg1;->B()Z

    .line 387
    .line 388
    .line 389
    move-result v7

    .line 390
    if-eqz v7, :cond_1b1

    .line 391
    .line 392
    :cond_187
    invoke-virtual {v9}, Lgg1;->y()Lp13;

    .line 393
    .line 394
    .line 395
    move-result-object v7

    .line 396
    invoke-interface {v7}, Lp13;->c()Lau;

    .line 397
    .line 398
    .line 399
    move-result-object v7

    .line 400
    if-eqz v7, :cond_196

    .line 401
    .line 402
    invoke-static {v7}, Lq33;->n(Lau;)Ltu0;

    .line 403
    .line 404
    .line 405
    move-result-object v7

    .line 406
    goto :goto_197

    .line 407
    :cond_196
    const/4 v7, 0x0

    .line 408
    :goto_197
    sget-object v10, Lsu0;->c:Lsu0;

    .line 409
    .line 410
    invoke-static {v7, v10}, Ld31;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 411
    .line 412
    .line 413
    move-result v7

    .line 414
    if-nez v7, :cond_1b1

    .line 415
    .line 416
    invoke-virtual {v9}, Lgg1;->getAnnotations()Ll7;

    .line 417
    .line 418
    .line 419
    move-result-object v7

    .line 420
    invoke-interface {v7}, Ll7;->isEmpty()Z

    .line 421
    .line 422
    .line 423
    move-result v7

    .line 424
    if-nez v7, :cond_1aa

    .line 425
    .line 426
    goto :goto_1b1

    .line 427
    :cond_1aa
    instance-of v7, v9, Lc90;

    .line 428
    .line 429
    if-eqz v7, :cond_1af

    .line 430
    .line 431
    goto :goto_1b1

    .line 432
    :cond_1af
    const/4 v7, 0x0

    .line 433
    goto :goto_1b2

    .line 434
    :cond_1b1
    :goto_1b1
    move v7, v8

    .line 435
    :goto_1b2
    if-eqz v7, :cond_1b7

    .line 436
    .line 437
    invoke-virtual {v1, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 438
    .line 439
    .line 440
    :cond_1b7
    invoke-virtual {v0, v1, v9}, Lpa0;->P(Ljava/lang/StringBuilder;Lgg1;)V

    .line 441
    .line 442
    .line 443
    if-eqz v7, :cond_1bf

    .line 444
    .line 445
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 446
    .line 447
    .line 448
    :cond_1bf
    const-string v7, "."

    .line 449
    .line 450
    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 451
    .line 452
    .line 453
    :cond_1c4
    invoke-virtual {v1, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 454
    .line 455
    .line 456
    invoke-static {v2}, Lq33;->z(Lgg1;)Z

    .line 457
    .line 458
    .line 459
    move-result v7

    .line 460
    if-eqz v7, :cond_1e8

    .line 461
    .line 462
    invoke-virtual {v2}, Lgg1;->getAnnotations()Ll7;

    .line 463
    .line 464
    .line 465
    move-result-object v7

    .line 466
    sget-object v9, Lqr2;->p:Lzq0;

    .line 467
    .line 468
    invoke-interface {v7, v9}, Ll7;->p(Lzq0;)La7;

    .line 469
    .line 470
    .line 471
    move-result-object v7

    .line 472
    if-eqz v7, :cond_1e8

    .line 473
    .line 474
    invoke-virtual {v2}, Lgg1;->s()Ljava/util/List;

    .line 475
    .line 476
    .line 477
    move-result-object v7

    .line 478
    invoke-interface {v7}, Ljava/util/List;->size()I

    .line 479
    .line 480
    .line 481
    move-result v7

    .line 482
    if-gt v7, v8, :cond_1e8

    .line 483
    .line 484
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 485
    .line 486
    .line 487
    goto/16 :goto_266

    .line 488
    .line 489
    :cond_1e8
    invoke-static {v2}, Lq33;->t(Lgg1;)Ljava/util/List;

    .line 490
    .line 491
    .line 492
    move-result-object v5

    .line 493
    check-cast v5, Ljava/lang/Iterable;

    .line 494
    .line 495
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 496
    .line 497
    .line 498
    move-result-object v5

    .line 499
    const/4 v7, 0x0

    .line 500
    :goto_1f3
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 501
    .line 502
    .line 503
    move-result v9

    .line 504
    if-eqz v9, :cond_266

    .line 505
    .line 506
    add-int/lit8 v9, v7, 0x1

    .line 507
    .line 508
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 509
    .line 510
    .line 511
    move-result-object v10

    .line 512
    check-cast v10, Lq23;

    .line 513
    .line 514
    if-lez v7, :cond_206

    .line 515
    .line 516
    invoke-virtual {v1, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 517
    .line 518
    .line 519
    :cond_206
    iget-object v7, v3, Lta0;->U:Lsa0;

    .line 520
    .line 521
    sget-object v11, Lta0;->Y:[Laf1;

    .line 522
    .line 523
    const/16 v15, 0x2d

    .line 524
    .line 525
    aget-object v11, v11, v15

    .line 526
    .line 527
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 528
    .line 529
    .line 530
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 531
    .line 532
    .line 533
    iget-object v7, v7, Lsa0;->a:Ljava/lang/Object;

    .line 534
    .line 535
    check-cast v7, Ljava/lang/Boolean;

    .line 536
    .line 537
    invoke-virtual {v7}, Ljava/lang/Boolean;->booleanValue()Z

    .line 538
    .line 539
    .line 540
    move-result v7

    .line 541
    if-eqz v7, :cond_22a

    .line 542
    .line 543
    invoke-virtual {v10}, Lq23;->b()Lgg1;

    .line 544
    .line 545
    .line 546
    move-result-object v7

    .line 547
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 548
    .line 549
    .line 550
    invoke-static {v7}, Lq33;->k(Lgg1;)Ldv1;

    .line 551
    .line 552
    .line 553
    move-result-object v7

    .line 554
    goto :goto_22b

    .line 555
    :cond_22a
    const/4 v7, 0x0

    .line 556
    :goto_22b
    if-eqz v7, :cond_23a

    .line 557
    .line 558
    const/4 v11, 0x0

    .line 559
    invoke-virtual {v0, v7, v11}, Lpa0;->N(Ldv1;Z)Ljava/lang/String;

    .line 560
    .line 561
    .line 562
    move-result-object v7

    .line 563
    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 564
    .line 565
    .line 566
    const-string v7, ": "

    .line 567
    .line 568
    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 569
    .line 570
    .line 571
    :cond_23a
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 572
    .line 573
    .line 574
    new-instance v18, Ljava/lang/StringBuilder;

    .line 575
    .line 576
    invoke-direct/range {v18 .. v18}, Ljava/lang/StringBuilder;-><init>()V

    .line 577
    .line 578
    .line 579
    invoke-static {v10}, Lia1;->u(Ljava/lang/Object;)Ljava/util/List;

    .line 580
    .line 581
    .line 582
    move-result-object v7

    .line 583
    move-object/from16 v17, v7

    .line 584
    .line 585
    check-cast v17, Ljava/lang/Iterable;

    .line 586
    .line 587
    new-instance v7, Loa0;

    .line 588
    .line 589
    const/4 v11, 0x0

    .line 590
    invoke-direct {v7, v0, v11}, Loa0;-><init>(Lpa0;I)V

    .line 591
    .line 592
    .line 593
    const/16 v23, 0x3c

    .line 594
    .line 595
    const-string v19, ", "

    .line 596
    .line 597
    const/16 v20, 0x0

    .line 598
    .line 599
    const/16 v21, 0x0

    .line 600
    .line 601
    move-object/from16 v22, v7

    .line 602
    .line 603
    invoke-static/range {v17 .. v23}, Lgv;->d0(Ljava/lang/Iterable;Ljava/lang/Appendable;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lft0;I)V

    .line 604
    .line 605
    .line 606
    invoke-virtual/range {v18 .. v18}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 607
    .line 608
    .line 609
    move-result-object v7

    .line 610
    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 611
    .line 612
    .line 613
    move v7, v9

    .line 614
    goto :goto_1f3

    .line 615
    :cond_266
    :goto_266
    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 616
    .line 617
    .line 618
    invoke-virtual {v0}, Lpa0;->r()Lme2;

    .line 619
    .line 620
    .line 621
    move-result-object v3

    .line 622
    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    .line 623
    .line 624
    .line 625
    move-result v3

    .line 626
    if-eqz v3, :cond_27c

    .line 627
    .line 628
    if-ne v3, v8, :cond_278

    .line 629
    .line 630
    const-string v3, "&rarr;"

    .line 631
    .line 632
    goto :goto_282

    .line 633
    :cond_278
    invoke-static {}, Lm03;->a()V

    .line 634
    .line 635
    .line 636
    return-void

    .line 637
    :cond_27c
    const-string v3, "->"

    .line 638
    .line 639
    invoke-virtual {v0, v3}, Lpa0;->n(Ljava/lang/String;)Ljava/lang/String;

    .line 640
    .line 641
    .line 642
    move-result-object v3

    .line 643
    :goto_282
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 644
    .line 645
    .line 646
    const-string v3, " "

    .line 647
    .line 648
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 649
    .line 650
    .line 651
    invoke-static {v2}, Lq33;->z(Lgg1;)Z

    .line 652
    .line 653
    .line 654
    invoke-virtual {v2}, Lgg1;->s()Ljava/util/List;

    .line 655
    .line 656
    .line 657
    move-result-object v2

    .line 658
    invoke-static {v2}, Lgv;->g0(Ljava/util/List;)Ljava/lang/Object;

    .line 659
    .line 660
    .line 661
    move-result-object v2

    .line 662
    check-cast v2, Lq23;

    .line 663
    .line 664
    invoke-virtual {v2}, Lq23;->b()Lgg1;

    .line 665
    .line 666
    .line 667
    move-result-object v2

    .line 668
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 669
    .line 670
    .line 671
    invoke-virtual {v0, v1, v2}, Lpa0;->P(Ljava/lang/StringBuilder;Lgg1;)V

    .line 672
    .line 673
    .line 674
    if-eqz v14, :cond_2a6

    .line 675
    .line 676
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 677
    .line 678
    .line 679
    :cond_2a6
    if-eqz v13, :cond_2ad

    .line 680
    .line 681
    const-string v0, "?"

    .line 682
    .line 683
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 684
    .line 685
    .line 686
    :cond_2ad
    return-void

    .line 687
    :cond_2ae
    invoke-virtual {v0, v1, v2}, Lpa0;->C(Ljava/lang/StringBuilder;Lko2;)V

    .line 688
    .line 689
    .line 690
    return-void

    .line 691
    :cond_2b2
    :goto_2b2
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 692
    .line 693
    .line 694
    return-void

    .line 695
    :cond_2b6
    invoke-static {}, Lm03;->a()V

    .line 696
    .line 697
    .line 698
    return-void
.end method

.method public final R(Lno;Ljava/lang/StringBuilder;)V
    .registers 6

    .line 1
    invoke-virtual {p0}, Lpa0;->p()Ljava/util/Set;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    sget-object v1, Lqa0;->f:Lqa0;

    .line 6
    .line 7
    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-nez v0, :cond_d

    .line 12
    .line 13
    goto :goto_50

    .line 14
    :cond_d
    invoke-interface {p1}, Lno;->r()Ljava/util/Collection;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    if-nez v0, :cond_50

    .line 23
    .line 24
    iget-object v0, p0, Lpa0;->a:Lta0;

    .line 25
    .line 26
    iget-object v0, v0, Lta0;->B:Lsa0;

    .line 27
    .line 28
    sget-object v1, Lta0;->Y:[Laf1;

    .line 29
    .line 30
    const/16 v2, 0x1a

    .line 31
    .line 32
    aget-object v1, v1, v2

    .line 33
    .line 34
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 35
    .line 36
    .line 37
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 38
    .line 39
    .line 40
    iget-object v0, v0, Lsa0;->a:Ljava/lang/Object;

    .line 41
    .line 42
    check-cast v0, Lp02;

    .line 43
    .line 44
    sget-object v1, Lp02;->b:Lp02;

    .line 45
    .line 46
    if-eq v0, v1, :cond_50

    .line 47
    .line 48
    const/4 v0, 0x1

    .line 49
    const-string v1, "override"

    .line 50
    .line 51
    invoke-virtual {p0, p2, v0, v1}, Lpa0;->M(Ljava/lang/StringBuilder;ZLjava/lang/String;)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {p0}, Lpa0;->t()Z

    .line 55
    .line 56
    .line 57
    move-result p0

    .line 58
    if-eqz p0, :cond_50

    .line 59
    .line 60
    const-string p0, "/*"

    .line 61
    .line 62
    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 63
    .line 64
    .line 65
    invoke-interface {p1}, Lno;->r()Ljava/util/Collection;

    .line 66
    .line 67
    .line 68
    move-result-object p0

    .line 69
    invoke-interface {p0}, Ljava/util/Collection;->size()I

    .line 70
    .line 71
    .line 72
    move-result p0

    .line 73
    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 74
    .line 75
    .line 76
    const-string p0, "*/ "

    .line 77
    .line 78
    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 79
    .line 80
    .line 81
    :cond_50
    :goto_50
    return-void
.end method

.method public final S(Lzq0;Ljava/lang/String;Ljava/lang/StringBuilder;)V
    .registers 4

    .line 1
    invoke-virtual {p0, p2}, Lpa0;->H(Ljava/lang/String;)Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object p2

    .line 5
    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 6
    .line 7
    .line 8
    invoke-virtual {p1}, Lzq0;->i()Lar0;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    .line 14
    .line 15
    invoke-virtual {p1}, Lar0;->e()Ljava/util/List;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    invoke-static {p1}, Lb21;->v(Ljava/util/List;)Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    invoke-virtual {p0, p1}, Lpa0;->n(Ljava/lang/String;)Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 28
    .line 29
    .line 30
    move-result p1

    .line 31
    if-lez p1, :cond_28

    .line 32
    .line 33
    const-string p1, " "

    .line 34
    .line 35
    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 36
    .line 37
    .line 38
    invoke-virtual {p3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 39
    .line 40
    .line 41
    :cond_28
    return-void
.end method

.method public final T(Ljava/lang/StringBuilder;Lt51;)V
    .registers 5

    .line 1
    iget-object v0, p2, Lt51;->d:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lt51;

    .line 4
    .line 5
    iget-object v1, p2, Lt51;->b:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Lbu;

    .line 8
    .line 9
    if-eqz v0, :cond_22

    .line 10
    .line 11
    invoke-virtual {p0, p1, v0}, Lpa0;->T(Ljava/lang/StringBuilder;Lt51;)V

    .line 12
    .line 13
    .line 14
    const/16 v0, 0x2e

    .line 15
    .line 16
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 17
    .line 18
    .line 19
    invoke-interface {v1}, Lm60;->getName()Ldv1;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 24
    .line 25
    .line 26
    const/4 v1, 0x0

    .line 27
    invoke-virtual {p0, v0, v1}, Lpa0;->N(Ldv1;Z)Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 32
    .line 33
    .line 34
    goto :goto_30

    .line 35
    :cond_22
    invoke-interface {v1}, Lau;->C()Lp13;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 40
    .line 41
    .line 42
    invoke-virtual {p0, v0}, Lpa0;->Z(Lp13;)Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 47
    .line 48
    .line 49
    :goto_30
    iget-object p2, p2, Lt51;->c:Ljava/lang/Object;

    .line 50
    .line 51
    check-cast p2, Ljava/util/List;

    .line 52
    .line 53
    invoke-virtual {p0, p2}, Lpa0;->Y(Ljava/util/List;)Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object p0

    .line 57
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 58
    .line 59
    .line 60
    return-void
.end method

.method public final U(Ll52;Ljava/lang/StringBuilder;)V
    .registers 9

    .line 1
    invoke-virtual {p0}, Lpa0;->q()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x1

    .line 6
    if-nez v0, :cond_106

    .line 7
    .line 8
    iget-object v0, p0, Lpa0;->a:Lta0;

    .line 9
    .line 10
    iget-object v2, v0, Lta0;->g:Lsa0;

    .line 11
    .line 12
    sget-object v3, Lta0;->Y:[Laf1;

    .line 13
    .line 14
    const/4 v4, 0x5

    .line 15
    aget-object v4, v3, v4

    .line 16
    .line 17
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    .line 19
    .line 20
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 21
    .line 22
    .line 23
    iget-object v2, v2, Lsa0;->a:Ljava/lang/Object;

    .line 24
    .line 25
    check-cast v2, Ljava/lang/Boolean;

    .line 26
    .line 27
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 28
    .line 29
    .line 30
    move-result v2

    .line 31
    const/4 v4, 0x0

    .line 32
    if-nez v2, :cond_db

    .line 33
    .line 34
    invoke-interface {p1}, Llo;->U()Ljava/util/List;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 39
    .line 40
    .line 41
    invoke-virtual {p0, p2, v2}, Lpa0;->B(Ljava/lang/StringBuilder;Ljava/util/List;)V

    .line 42
    .line 43
    .line 44
    invoke-virtual {p0}, Lpa0;->p()Ljava/util/Set;

    .line 45
    .line 46
    .line 47
    move-result-object v2

    .line 48
    sget-object v5, Lqa0;->g:Lqa0;

    .line 49
    .line 50
    invoke-interface {v2, v5}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 51
    .line 52
    .line 53
    move-result v2

    .line 54
    if-nez v2, :cond_38

    .line 55
    .line 56
    goto :goto_91

    .line 57
    :cond_38
    const/4 v2, 0x0

    .line 58
    invoke-virtual {p0, p2, p1, v2}, Lpa0;->x(Ljava/lang/StringBuilder;La6;Lg7;)V

    .line 59
    .line 60
    .line 61
    invoke-interface {p1}, Ll52;->S()Lom0;

    .line 62
    .line 63
    .line 64
    move-result-object v2

    .line 65
    if-eqz v2, :cond_47

    .line 66
    .line 67
    sget-object v5, Lg7;->b:Lg7;

    .line 68
    .line 69
    invoke-virtual {p0, p2, v2, v5}, Lpa0;->x(Ljava/lang/StringBuilder;La6;Lg7;)V

    .line 70
    .line 71
    .line 72
    :cond_47
    invoke-interface {p1}, Ll52;->L()Lom0;

    .line 73
    .line 74
    .line 75
    move-result-object v2

    .line 76
    if-eqz v2, :cond_52

    .line 77
    .line 78
    sget-object v5, Lg7;->m:Lg7;

    .line 79
    .line 80
    invoke-virtual {p0, p2, v2, v5}, Lpa0;->x(Ljava/lang/StringBuilder;La6;Lg7;)V

    .line 81
    .line 82
    .line 83
    :cond_52
    iget-object v0, v0, Lta0;->H:Lsa0;

    .line 84
    .line 85
    const/16 v2, 0x20

    .line 86
    .line 87
    aget-object v2, v3, v2

    .line 88
    .line 89
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 90
    .line 91
    .line 92
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 93
    .line 94
    .line 95
    iget-object v0, v0, Lsa0;->a:Ljava/lang/Object;

    .line 96
    .line 97
    check-cast v0, Lj52;

    .line 98
    .line 99
    sget-object v2, Lj52;->b:Lj52;

    .line 100
    .line 101
    if-ne v0, v2, :cond_91

    .line 102
    .line 103
    invoke-interface {p1}, Ll52;->c()Lo52;

    .line 104
    .line 105
    .line 106
    move-result-object v0

    .line 107
    if-eqz v0, :cond_71

    .line 108
    .line 109
    sget-object v2, Lg7;->e:Lg7;

    .line 110
    .line 111
    invoke-virtual {p0, p2, v0, v2}, Lpa0;->x(Ljava/lang/StringBuilder;La6;Lg7;)V

    .line 112
    .line 113
    .line 114
    :cond_71
    invoke-interface {p1}, Ll52;->f()Lb62;

    .line 115
    .line 116
    .line 117
    move-result-object v0

    .line 118
    if-eqz v0, :cond_91

    .line 119
    .line 120
    sget-object v2, Lg7;->f:Lg7;

    .line 121
    .line 122
    invoke-virtual {p0, p2, v0, v2}, Lpa0;->x(Ljava/lang/StringBuilder;La6;Lg7;)V

    .line 123
    .line 124
    .line 125
    invoke-virtual {v0}, Lb62;->r0()Ljava/util/List;

    .line 126
    .line 127
    .line 128
    move-result-object v0

    .line 129
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 130
    .line 131
    .line 132
    invoke-static {v0}, Lgv;->p0(Ljava/util/List;)Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    move-result-object v0

    .line 136
    check-cast v0, Lc73;

    .line 137
    .line 138
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 139
    .line 140
    .line 141
    sget-object v2, Lg7;->l:Lg7;

    .line 142
    .line 143
    invoke-virtual {p0, p2, v0, v2}, Lpa0;->x(Ljava/lang/StringBuilder;La6;Lg7;)V

    .line 144
    .line 145
    .line 146
    :cond_91
    :goto_91
    invoke-interface {p1}, Llr1;->g()Lya0;

    .line 147
    .line 148
    .line 149
    move-result-object v0

    .line 150
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 151
    .line 152
    .line 153
    invoke-virtual {p0, v0, p2}, Lpa0;->g0(Lya0;Ljava/lang/StringBuilder;)Z

    .line 154
    .line 155
    .line 156
    invoke-virtual {p0}, Lpa0;->p()Ljava/util/Set;

    .line 157
    .line 158
    .line 159
    move-result-object v0

    .line 160
    sget-object v2, Lqa0;->q:Lqa0;

    .line 161
    .line 162
    invoke-interface {v0, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 163
    .line 164
    .line 165
    move-result v0

    .line 166
    if-eqz v0, :cond_af

    .line 167
    .line 168
    invoke-interface {p1}, Ld73;->F()Z

    .line 169
    .line 170
    .line 171
    move-result v0

    .line 172
    if-eqz v0, :cond_af

    .line 173
    .line 174
    move v0, v1

    .line 175
    goto :goto_b0

    .line 176
    :cond_af
    move v0, v4

    .line 177
    :goto_b0
    const-string v2, "const"

    .line 178
    .line 179
    invoke-virtual {p0, p2, v0, v2}, Lpa0;->M(Ljava/lang/StringBuilder;ZLjava/lang/String;)V

    .line 180
    .line 181
    .line 182
    invoke-virtual {p0, p1, p2}, Lpa0;->J(Llr1;Ljava/lang/StringBuilder;)V

    .line 183
    .line 184
    .line 185
    invoke-virtual {p0, p1, p2}, Lpa0;->L(Lno;Ljava/lang/StringBuilder;)V

    .line 186
    .line 187
    .line 188
    invoke-virtual {p0, p1, p2}, Lpa0;->R(Lno;Ljava/lang/StringBuilder;)V

    .line 189
    .line 190
    .line 191
    invoke-virtual {p0}, Lpa0;->p()Ljava/util/Set;

    .line 192
    .line 193
    .line 194
    move-result-object v0

    .line 195
    sget-object v2, Lqa0;->r:Lqa0;

    .line 196
    .line 197
    invoke-interface {v0, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 198
    .line 199
    .line 200
    move-result v0

    .line 201
    if-eqz v0, :cond_d2

    .line 202
    .line 203
    invoke-interface {p1}, Ld73;->V()Z

    .line 204
    .line 205
    .line 206
    move-result v0

    .line 207
    if-eqz v0, :cond_d2

    .line 208
    .line 209
    move v0, v1

    .line 210
    goto :goto_d3

    .line 211
    :cond_d2
    move v0, v4

    .line 212
    :goto_d3
    const-string v2, "lateinit"

    .line 213
    .line 214
    invoke-virtual {p0, p2, v0, v2}, Lpa0;->M(Ljava/lang/StringBuilder;ZLjava/lang/String;)V

    .line 215
    .line 216
    .line 217
    invoke-virtual {p0, p1, p2}, Lpa0;->I(Lno;Ljava/lang/StringBuilder;)V

    .line 218
    .line 219
    .line 220
    :cond_db
    invoke-virtual {p0, p1, p2, v4}, Lpa0;->d0(Ld73;Ljava/lang/StringBuilder;Z)V

    .line 221
    .line 222
    .line 223
    invoke-interface {p1}, Llo;->getTypeParameters()Ljava/util/List;

    .line 224
    .line 225
    .line 226
    move-result-object v0

    .line 227
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 228
    .line 229
    .line 230
    invoke-virtual {p0, v0, p2, v1}, Lpa0;->c0(Ljava/util/List;Ljava/lang/StringBuilder;Z)V

    .line 231
    .line 232
    .line 233
    invoke-interface {p1}, Llo;->K()Ltg1;

    .line 234
    .line 235
    .line 236
    move-result-object v0

    .line 237
    if-eqz v0, :cond_106

    .line 238
    .line 239
    sget-object v2, Lg7;->g:Lg7;

    .line 240
    .line 241
    invoke-virtual {p0, p2, v0, v2}, Lpa0;->x(Ljava/lang/StringBuilder;La6;Lg7;)V

    .line 242
    .line 243
    .line 244
    invoke-virtual {v0}, Ltg1;->getType()Lgg1;

    .line 245
    .line 246
    .line 247
    move-result-object v0

    .line 248
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 249
    .line 250
    .line 251
    invoke-virtual {p0, v0}, Lpa0;->F(Lgg1;)Ljava/lang/String;

    .line 252
    .line 253
    .line 254
    move-result-object v0

    .line 255
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 256
    .line 257
    .line 258
    const-string v0, "."

    .line 259
    .line 260
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 261
    .line 262
    .line 263
    :cond_106
    invoke-virtual {p0, p1, p2, v1}, Lpa0;->O(Lm60;Ljava/lang/StringBuilder;Z)V

    .line 264
    .line 265
    .line 266
    const-string v0, ": "

    .line 267
    .line 268
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 269
    .line 270
    .line 271
    invoke-interface {p1}, Lv63;->getType()Lgg1;

    .line 272
    .line 273
    .line 274
    move-result-object v0

    .line 275
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 276
    .line 277
    .line 278
    invoke-virtual {p0, v0}, Lpa0;->X(Lgg1;)Ljava/lang/String;

    .line 279
    .line 280
    .line 281
    move-result-object v0

    .line 282
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 283
    .line 284
    .line 285
    invoke-virtual {p0, p1, p2}, Lpa0;->V(Llo;Ljava/lang/StringBuilder;)V

    .line 286
    .line 287
    .line 288
    invoke-virtual {p0, p1, p2}, Lpa0;->G(Ld73;Ljava/lang/StringBuilder;)V

    .line 289
    .line 290
    .line 291
    invoke-interface {p1}, Llo;->getTypeParameters()Ljava/util/List;

    .line 292
    .line 293
    .line 294
    move-result-object p1

    .line 295
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 296
    .line 297
    .line 298
    invoke-virtual {p0, p2, p1}, Lpa0;->h0(Ljava/lang/StringBuilder;Ljava/util/List;)V

    .line 299
    .line 300
    .line 301
    return-void
.end method

.method public final V(Llo;Ljava/lang/StringBuilder;)V
    .registers 6

    .line 1
    iget-object v0, p0, Lpa0;->a:Lta0;

    .line 2
    .line 3
    iget-object v0, v0, Lta0;->F:Lsa0;

    .line 4
    .line 5
    sget-object v1, Lta0;->Y:[Laf1;

    .line 6
    .line 7
    const/16 v2, 0x1e

    .line 8
    .line 9
    aget-object v1, v1, v2

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    iget-object v0, v0, Lsa0;->a:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v0, Ljava/lang/Boolean;

    .line 20
    .line 21
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-nez v0, :cond_1b

    .line 26
    .line 27
    goto :goto_34

    .line 28
    :cond_1b
    invoke-interface {p1}, Llo;->K()Ltg1;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    if-eqz p1, :cond_34

    .line 33
    .line 34
    const-string v0, " on "

    .line 35
    .line 36
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 37
    .line 38
    .line 39
    invoke-virtual {p1}, Ltg1;->getType()Lgg1;

    .line 40
    .line 41
    .line 42
    move-result-object p1

    .line 43
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 44
    .line 45
    .line 46
    invoke-virtual {p0, p1}, Lpa0;->X(Lgg1;)Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object p0

    .line 50
    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 51
    .line 52
    .line 53
    :cond_34
    :goto_34
    return-void
.end method

.method public final X(Lgg1;)Ljava/lang/String;
    .registers 6

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/lang/StringBuilder;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 7
    .line 8
    .line 9
    iget-object v1, p0, Lpa0;->a:Lta0;

    .line 10
    .line 11
    iget-object v1, v1, Lta0;->y:Lsa0;

    .line 12
    .line 13
    sget-object v2, Lta0;->Y:[Laf1;

    .line 14
    .line 15
    const/16 v3, 0x17

    .line 16
    .line 17
    aget-object v2, v2, v3

    .line 18
    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    .line 24
    .line 25
    iget-object v1, v1, Lsa0;->a:Ljava/lang/Object;

    .line 26
    .line 27
    check-cast v1, Lft0;

    .line 28
    .line 29
    invoke-interface {v1, p1}, Lft0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    check-cast p1, Lgg1;

    .line 34
    .line 35
    invoke-virtual {p0, v0, p1}, Lpa0;->P(Ljava/lang/StringBuilder;Lgg1;)V

    .line 36
    .line 37
    .line 38
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object p0

    .line 42
    return-object p0
.end method

.method public final Y(Ljava/util/List;)Ljava/lang/String;
    .registers 9

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_c

    .line 9
    .line 10
    const-string p0, ""

    .line 11
    .line 12
    return-object p0

    .line 13
    :cond_c
    new-instance v1, Ljava/lang/StringBuilder;

    .line 14
    .line 15
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 16
    .line 17
    .line 18
    const-string v0, "<"

    .line 19
    .line 20
    invoke-virtual {p0, v0}, Lpa0;->n(Ljava/lang/String;)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 25
    .line 26
    .line 27
    move-object v0, p1

    .line 28
    check-cast v0, Ljava/lang/Iterable;

    .line 29
    .line 30
    new-instance v5, Loa0;

    .line 31
    .line 32
    const/4 p1, 0x0

    .line 33
    invoke-direct {v5, p0, p1}, Loa0;-><init>(Lpa0;I)V

    .line 34
    .line 35
    .line 36
    const/16 v6, 0x3c

    .line 37
    .line 38
    const-string v2, ", "

    .line 39
    .line 40
    const/4 v3, 0x0

    .line 41
    const/4 v4, 0x0

    .line 42
    invoke-static/range {v0 .. v6}, Lgv;->d0(Ljava/lang/Iterable;Ljava/lang/Appendable;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lft0;I)V

    .line 43
    .line 44
    .line 45
    const-string p1, ">"

    .line 46
    .line 47
    invoke-virtual {p0, p1}, Lpa0;->n(Ljava/lang/String;)Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object p0

    .line 51
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 52
    .line 53
    .line 54
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object p0

    .line 58
    return-object p0
.end method

.method public final Z(Lp13;)Ljava/lang/String;
    .registers 4

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-interface {p1}, Lp13;->c()Lau;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    instance-of v1, v0, Ll23;

    .line 9
    .line 10
    if-nez v1, :cond_33

    .line 11
    .line 12
    instance-of v1, v0, Lxt1;

    .line 13
    .line 14
    if-nez v1, :cond_33

    .line 15
    .line 16
    instance-of v1, v0, Lcc0;

    .line 17
    .line 18
    if-eqz v1, :cond_14

    .line 19
    .line 20
    goto :goto_33

    .line 21
    :cond_14
    if-nez v0, :cond_28

    .line 22
    .line 23
    instance-of p0, p1, Lc31;

    .line 24
    .line 25
    if-eqz p0, :cond_23

    .line 26
    .line 27
    check-cast p1, Lc31;

    .line 28
    .line 29
    sget-object p0, Lz6;->p:Lz6;

    .line 30
    .line 31
    invoke-virtual {p1, p0}, Lc31;->g(Lft0;)Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object p0

    .line 35
    return-object p0

    .line 36
    :cond_23
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object p0

    .line 40
    return-object p0

    .line 41
    :cond_28
    const-string p0, "Unexpected classifier: "

    .line 42
    .line 43
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 44
    .line 45
    .line 46
    move-result-object p1

    .line 47
    invoke-static {p1, p0}, Lt12;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    const/4 p0, 0x0

    .line 51
    return-object p0

    .line 52
    :cond_33
    :goto_33
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 53
    .line 54
    .line 55
    invoke-static {v0}, Lzj0;->f(Lm60;)Z

    .line 56
    .line 57
    .line 58
    move-result p1

    .line 59
    if-eqz p1, :cond_45

    .line 60
    .line 61
    invoke-interface {v0}, Lau;->C()Lp13;

    .line 62
    .line 63
    .line 64
    move-result-object p0

    .line 65
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object p0

    .line 69
    return-object p0

    .line 70
    :cond_45
    invoke-virtual {p0}, Lpa0;->o()Lcu;

    .line 71
    .line 72
    .line 73
    move-result-object p1

    .line 74
    invoke-virtual {p1, v0, p0}, Lcu;->b(Lau;Lpa0;)Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object p0

    .line 78
    return-object p0
.end method

.method public final a()V
    .registers 1

    .line 1
    iget-object p0, p0, Lpa0;->a:Lta0;

    .line 2
    .line 3
    invoke-virtual {p0}, Lta0;->a()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final a0(Ll23;Ljava/lang/StringBuilder;Z)V
    .registers 11

    .line 1
    if-eqz p3, :cond_b

    .line 2
    .line 3
    const-string v0, "<"

    .line 4
    .line 5
    invoke-virtual {p0, v0}, Lpa0;->n(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 10
    .line 11
    .line 12
    :cond_b
    invoke-virtual {p0}, Lpa0;->t()Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_22

    .line 17
    .line 18
    const-string v0, "/*"

    .line 19
    .line 20
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    invoke-interface {p1}, Ll23;->getIndex()I

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    const-string v0, "*/ "

    .line 31
    .line 32
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 33
    .line 34
    .line 35
    :cond_22
    invoke-interface {p1}, Ll23;->O()Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    const-string v1, "reified"

    .line 40
    .line 41
    invoke-virtual {p0, p2, v0, v1}, Lpa0;->M(Ljava/lang/StringBuilder;ZLjava/lang/String;)V

    .line 42
    .line 43
    .line 44
    invoke-interface {p1}, Ll23;->b0()Lf73;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    iget-object v0, v0, Lf73;->a:Ljava/lang/String;

    .line 49
    .line 50
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 51
    .line 52
    .line 53
    move-result v1

    .line 54
    const/4 v2, 0x0

    .line 55
    const/4 v3, 0x1

    .line 56
    if-lez v1, :cond_3b

    .line 57
    .line 58
    move v1, v3

    .line 59
    goto :goto_3c

    .line 60
    :cond_3b
    move v1, v2

    .line 61
    :goto_3c
    invoke-virtual {p0, p2, v1, v0}, Lpa0;->M(Ljava/lang/StringBuilder;ZLjava/lang/String;)V

    .line 62
    .line 63
    .line 64
    const/4 v0, 0x0

    .line 65
    invoke-virtual {p0, p2, p1, v0}, Lpa0;->x(Ljava/lang/StringBuilder;La6;Lg7;)V

    .line 66
    .line 67
    .line 68
    invoke-virtual {p0, p1, p2, p3}, Lpa0;->O(Lm60;Ljava/lang/StringBuilder;Z)V

    .line 69
    .line 70
    .line 71
    invoke-interface {p1}, Ll23;->getUpperBounds()Ljava/util/List;

    .line 72
    .line 73
    .line 74
    move-result-object v1

    .line 75
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 76
    .line 77
    .line 78
    move-result v1

    .line 79
    const/16 v4, 0x8e

    .line 80
    .line 81
    const-string v5, " : "

    .line 82
    .line 83
    if-le v1, v3, :cond_56

    .line 84
    .line 85
    if-eqz p3, :cond_58

    .line 86
    .line 87
    :cond_56
    if-ne v1, v3, :cond_84

    .line 88
    .line 89
    :cond_58
    invoke-interface {p1}, Ll23;->getUpperBounds()Ljava/util/List;

    .line 90
    .line 91
    .line 92
    move-result-object p1

    .line 93
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 94
    .line 95
    .line 96
    move-result-object p1

    .line 97
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    move-result-object p1

    .line 101
    check-cast p1, Lgg1;

    .line 102
    .line 103
    if-eqz p1, :cond_80

    .line 104
    .line 105
    invoke-static {p1}, Lxf1;->x(Lgg1;)Z

    .line 106
    .line 107
    .line 108
    move-result v0

    .line 109
    if-eqz v0, :cond_75

    .line 110
    .line 111
    invoke-virtual {p1}, Lgg1;->B()Z

    .line 112
    .line 113
    .line 114
    move-result v0

    .line 115
    if-eqz v0, :cond_75

    .line 116
    .line 117
    goto :goto_c1

    .line 118
    :cond_75
    invoke-virtual {p2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 119
    .line 120
    .line 121
    invoke-virtual {p0, p1}, Lpa0;->X(Lgg1;)Ljava/lang/String;

    .line 122
    .line 123
    .line 124
    move-result-object p1

    .line 125
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 126
    .line 127
    .line 128
    goto :goto_c1

    .line 129
    :cond_80
    invoke-static {v4}, Lxf1;->a(I)V

    .line 130
    .line 131
    .line 132
    throw v0

    .line 133
    :cond_84
    if-eqz p3, :cond_c1

    .line 134
    .line 135
    invoke-interface {p1}, Ll23;->getUpperBounds()Ljava/util/List;

    .line 136
    .line 137
    .line 138
    move-result-object p1

    .line 139
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 140
    .line 141
    .line 142
    move-result-object p1

    .line 143
    :goto_8e
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 144
    .line 145
    .line 146
    move-result v1

    .line 147
    if-eqz v1, :cond_c1

    .line 148
    .line 149
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 150
    .line 151
    .line 152
    move-result-object v1

    .line 153
    check-cast v1, Lgg1;

    .line 154
    .line 155
    if-eqz v1, :cond_bd

    .line 156
    .line 157
    invoke-static {v1}, Lxf1;->x(Lgg1;)Z

    .line 158
    .line 159
    .line 160
    move-result v6

    .line 161
    if-eqz v6, :cond_a9

    .line 162
    .line 163
    invoke-virtual {v1}, Lgg1;->B()Z

    .line 164
    .line 165
    .line 166
    move-result v6

    .line 167
    if-eqz v6, :cond_a9

    .line 168
    .line 169
    goto :goto_8e

    .line 170
    :cond_a9
    if-eqz v3, :cond_af

    .line 171
    .line 172
    invoke-virtual {p2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 173
    .line 174
    .line 175
    goto :goto_b4

    .line 176
    :cond_af
    const-string v3, " & "

    .line 177
    .line 178
    invoke-virtual {p2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 179
    .line 180
    .line 181
    :goto_b4
    invoke-virtual {p0, v1}, Lpa0;->X(Lgg1;)Ljava/lang/String;

    .line 182
    .line 183
    .line 184
    move-result-object v1

    .line 185
    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 186
    .line 187
    .line 188
    move v3, v2

    .line 189
    goto :goto_8e

    .line 190
    :cond_bd
    invoke-static {v4}, Lxf1;->a(I)V

    .line 191
    .line 192
    .line 193
    throw v0

    .line 194
    :cond_c1
    :goto_c1
    if-eqz p3, :cond_cc

    .line 195
    .line 196
    const-string p1, ">"

    .line 197
    .line 198
    invoke-virtual {p0, p1}, Lpa0;->n(Ljava/lang/String;)Ljava/lang/String;

    .line 199
    .line 200
    .line 201
    move-result-object p0

    .line 202
    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 203
    .line 204
    .line 205
    :cond_cc
    return-void
.end method

.method public final b()V
    .registers 1

    .line 1
    iget-object p0, p0, Lpa0;->a:Lta0;

    .line 2
    .line 3
    invoke-virtual {p0}, Lta0;->b()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final b0(Ljava/lang/StringBuilder;Ljava/util/List;)V
    .registers 5

    .line 1
    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 2
    .line 3
    .line 4
    move-result-object p2

    .line 5
    :cond_4
    :goto_4
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_20

    .line 10
    .line 11
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    check-cast v0, Ll23;

    .line 16
    .line 17
    const/4 v1, 0x0

    .line 18
    invoke-virtual {p0, v0, p1, v1}, Lpa0;->a0(Ll23;Ljava/lang/StringBuilder;Z)V

    .line 19
    .line 20
    .line 21
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-eqz v0, :cond_4

    .line 26
    .line 27
    const-string v0, ", "

    .line 28
    .line 29
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 30
    .line 31
    .line 32
    goto :goto_4

    .line 33
    :cond_20
    return-void
.end method

.method public final c()V
    .registers 1

    .line 1
    iget-object p0, p0, Lpa0;->a:Lta0;

    .line 2
    .line 3
    invoke-virtual {p0}, Lta0;->c()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final c0(Ljava/util/List;Ljava/lang/StringBuilder;Z)V
    .registers 7

    .line 1
    iget-object v0, p0, Lpa0;->a:Lta0;

    .line 2
    .line 3
    iget-object v0, v0, Lta0;->w:Lsa0;

    .line 4
    .line 5
    sget-object v1, Lta0;->Y:[Laf1;

    .line 6
    .line 7
    const/16 v2, 0x15

    .line 8
    .line 9
    aget-object v1, v1, v2

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    iget-object v0, v0, Lsa0;->a:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v0, Ljava/lang/Boolean;

    .line 20
    .line 21
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-eqz v0, :cond_1b

    .line 26
    .line 27
    goto :goto_40

    .line 28
    :cond_1b
    move-object v0, p1

    .line 29
    check-cast v0, Ljava/util/Collection;

    .line 30
    .line 31
    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    if-nez v0, :cond_40

    .line 36
    .line 37
    const-string v0, "<"

    .line 38
    .line 39
    invoke-virtual {p0, v0}, Lpa0;->n(Ljava/lang/String;)Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 44
    .line 45
    .line 46
    invoke-virtual {p0, p2, p1}, Lpa0;->b0(Ljava/lang/StringBuilder;Ljava/util/List;)V

    .line 47
    .line 48
    .line 49
    const-string p1, ">"

    .line 50
    .line 51
    invoke-virtual {p0, p1}, Lpa0;->n(Ljava/lang/String;)Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object p0

    .line 55
    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 56
    .line 57
    .line 58
    if-eqz p3, :cond_40

    .line 59
    .line 60
    const-string p0, " "

    .line 61
    .line 62
    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 63
    .line 64
    .line 65
    :cond_40
    :goto_40
    return-void
.end method

.method public final d(Li12;)V
    .registers 2

    .line 1
    iget-object p0, p0, Lpa0;->a:Lta0;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lta0;->d(Li12;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final d0(Ld73;Ljava/lang/StringBuilder;Z)V
    .registers 4

    .line 1
    if-nez p3, :cond_8

    .line 2
    .line 3
    instance-of p3, p1, Lc73;

    .line 4
    .line 5
    if-nez p3, :cond_7

    .line 6
    .line 7
    goto :goto_8

    .line 8
    :cond_7
    return-void

    .line 9
    :cond_8
    :goto_8
    invoke-interface {p1}, Ld73;->G()Z

    .line 10
    .line 11
    .line 12
    move-result p1

    .line 13
    if-eqz p1, :cond_11

    .line 14
    .line 15
    const-string p1, "var"

    .line 16
    .line 17
    goto :goto_13

    .line 18
    :cond_11
    const-string p1, "val"

    .line 19
    .line 20
    :goto_13
    invoke-virtual {p0, p1}, Lpa0;->H(Ljava/lang/String;)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 25
    .line 26
    .line 27
    const-string p0, " "

    .line 28
    .line 29
    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 30
    .line 31
    .line 32
    return-void
.end method

.method public final e(Ljava/util/Set;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lpa0;->a:Lta0;

    .line 5
    .line 6
    invoke-virtual {p0, p1}, Lta0;->e(Ljava/util/Set;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final e0(Lc73;ZLjava/lang/StringBuilder;Z)V
    .registers 13

    .line 1
    if-eqz p4, :cond_10

    .line 2
    .line 3
    const-string v0, "value-parameter"

    .line 4
    .line 5
    invoke-virtual {p0, v0}, Lpa0;->H(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 10
    .line 11
    .line 12
    const-string v0, " "

    .line 13
    .line 14
    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 15
    .line 16
    .line 17
    :cond_10
    invoke-virtual {p0}, Lpa0;->t()Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-eqz v0, :cond_25

    .line 22
    .line 23
    const-string v0, "/*"

    .line 24
    .line 25
    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    iget v0, p1, Lc73;->j:I

    .line 29
    .line 30
    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 31
    .line 32
    .line 33
    const-string v0, "*/ "

    .line 34
    .line 35
    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 36
    .line 37
    .line 38
    :cond_25
    const/4 v0, 0x0

    .line 39
    invoke-virtual {p0, p3, p1, v0}, Lpa0;->x(Ljava/lang/StringBuilder;La6;Lg7;)V

    .line 40
    .line 41
    .line 42
    iget-boolean v1, p1, Lc73;->m:Z

    .line 43
    .line 44
    const-string v2, "crossinline"

    .line 45
    .line 46
    invoke-virtual {p0, p3, v1, v2}, Lpa0;->M(Ljava/lang/StringBuilder;ZLjava/lang/String;)V

    .line 47
    .line 48
    .line 49
    iget-boolean v1, p1, Lc73;->n:Z

    .line 50
    .line 51
    const-string v2, "noinline"

    .line 52
    .line 53
    invoke-virtual {p0, p3, v1, v2}, Lpa0;->M(Ljava/lang/StringBuilder;ZLjava/lang/String;)V

    .line 54
    .line 55
    .line 56
    iget-object v1, p0, Lpa0;->a:Lta0;

    .line 57
    .line 58
    iget-object v2, v1, Lta0;->r:Lsa0;

    .line 59
    .line 60
    sget-object v3, Lta0;->Y:[Laf1;

    .line 61
    .line 62
    const/16 v4, 0x10

    .line 63
    .line 64
    aget-object v4, v3, v4

    .line 65
    .line 66
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 67
    .line 68
    .line 69
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 70
    .line 71
    .line 72
    iget-object v2, v2, Lsa0;->a:Ljava/lang/Object;

    .line 73
    .line 74
    check-cast v2, Ljava/lang/Boolean;

    .line 75
    .line 76
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 77
    .line 78
    .line 79
    move-result v2

    .line 80
    const/4 v4, 0x0

    .line 81
    const/4 v5, 0x1

    .line 82
    if-eqz v2, :cond_66

    .line 83
    .line 84
    invoke-virtual {p1}, Lc73;->M0()Llo;

    .line 85
    .line 86
    .line 87
    move-result-object v2

    .line 88
    instance-of v6, v2, Lvs;

    .line 89
    .line 90
    if-eqz v6, :cond_5e

    .line 91
    .line 92
    move-object v0, v2

    .line 93
    check-cast v0, Lvs;

    .line 94
    .line 95
    :cond_5e
    if-eqz v0, :cond_66

    .line 96
    .line 97
    iget-boolean v0, v0, Lvs;->I:Z

    .line 98
    .line 99
    if-ne v0, v5, :cond_66

    .line 100
    .line 101
    move v0, v5

    .line 102
    goto :goto_67

    .line 103
    :cond_66
    move v0, v4

    .line 104
    :goto_67
    if-eqz v0, :cond_82

    .line 105
    .line 106
    iget-object v2, v1, Lta0;->s:Lsa0;

    .line 107
    .line 108
    const/16 v6, 0x11

    .line 109
    .line 110
    aget-object v6, v3, v6

    .line 111
    .line 112
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 113
    .line 114
    .line 115
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 116
    .line 117
    .line 118
    iget-object v2, v2, Lsa0;->a:Ljava/lang/Object;

    .line 119
    .line 120
    check-cast v2, Ljava/lang/Boolean;

    .line 121
    .line 122
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 123
    .line 124
    .line 125
    move-result v2

    .line 126
    const-string v6, "actual"

    .line 127
    .line 128
    invoke-virtual {p0, p3, v2, v6}, Lpa0;->M(Ljava/lang/StringBuilder;ZLjava/lang/String;)V

    .line 129
    .line 130
    .line 131
    :cond_82
    invoke-virtual {p1}, Le73;->getType()Lgg1;

    .line 132
    .line 133
    .line 134
    move-result-object v2

    .line 135
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 136
    .line 137
    .line 138
    iget-object v6, p1, Lc73;->o:Lgg1;

    .line 139
    .line 140
    if-nez v6, :cond_8f

    .line 141
    .line 142
    move-object v7, v2

    .line 143
    goto :goto_90

    .line 144
    :cond_8f
    move-object v7, v6

    .line 145
    :goto_90
    if-eqz v6, :cond_93

    .line 146
    .line 147
    move v4, v5

    .line 148
    :cond_93
    const-string v5, "vararg"

    .line 149
    .line 150
    invoke-virtual {p0, p3, v4, v5}, Lpa0;->M(Ljava/lang/StringBuilder;ZLjava/lang/String;)V

    .line 151
    .line 152
    .line 153
    if-nez v0, :cond_a2

    .line 154
    .line 155
    if-eqz p4, :cond_a5

    .line 156
    .line 157
    invoke-virtual {p0}, Lpa0;->q()Z

    .line 158
    .line 159
    .line 160
    move-result v4

    .line 161
    if-nez v4, :cond_a5

    .line 162
    .line 163
    :cond_a2
    invoke-virtual {p0, p1, p3, v0}, Lpa0;->d0(Ld73;Ljava/lang/StringBuilder;Z)V

    .line 164
    .line 165
    .line 166
    :cond_a5
    if-eqz p2, :cond_af

    .line 167
    .line 168
    invoke-virtual {p0, p1, p3, p4}, Lpa0;->O(Lm60;Ljava/lang/StringBuilder;Z)V

    .line 169
    .line 170
    .line 171
    const-string p2, ": "

    .line 172
    .line 173
    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 174
    .line 175
    .line 176
    :cond_af
    invoke-virtual {p0, v7}, Lpa0;->X(Lgg1;)Ljava/lang/String;

    .line 177
    .line 178
    .line 179
    move-result-object p2

    .line 180
    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 181
    .line 182
    .line 183
    invoke-virtual {p0, p1, p3}, Lpa0;->G(Ld73;Ljava/lang/StringBuilder;)V

    .line 184
    .line 185
    .line 186
    invoke-virtual {p0}, Lpa0;->t()Z

    .line 187
    .line 188
    .line 189
    move-result p2

    .line 190
    if-eqz p2, :cond_d2

    .line 191
    .line 192
    if-eqz v6, :cond_d2

    .line 193
    .line 194
    const-string p2, " /*"

    .line 195
    .line 196
    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 197
    .line 198
    .line 199
    invoke-virtual {p0, v2}, Lpa0;->X(Lgg1;)Ljava/lang/String;

    .line 200
    .line 201
    .line 202
    move-result-object p0

    .line 203
    invoke-virtual {p3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 204
    .line 205
    .line 206
    const-string p0, "*/"

    .line 207
    .line 208
    invoke-virtual {p3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 209
    .line 210
    .line 211
    :cond_d2
    iget-object p0, v1, Lta0;->z:Lsa0;

    .line 212
    .line 213
    const/16 p2, 0x18

    .line 214
    .line 215
    aget-object p4, v3, p2

    .line 216
    .line 217
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 218
    .line 219
    .line 220
    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 221
    .line 222
    .line 223
    iget-object p0, p0, Lsa0;->a:Ljava/lang/Object;

    .line 224
    .line 225
    check-cast p0, Lft0;

    .line 226
    .line 227
    if-eqz p0, :cond_11d

    .line 228
    .line 229
    invoke-virtual {v1}, Lta0;->o()Z

    .line 230
    .line 231
    .line 232
    move-result p0

    .line 233
    if-eqz p0, :cond_ef

    .line 234
    .line 235
    invoke-virtual {p1}, Lc73;->L0()Z

    .line 236
    .line 237
    .line 238
    move-result p0

    .line 239
    goto :goto_f3

    .line 240
    :cond_ef
    invoke-static {p1}, Lxa0;->a(Lc73;)Z

    .line 241
    .line 242
    .line 243
    move-result p0

    .line 244
    :goto_f3
    if-eqz p0, :cond_11d

    .line 245
    .line 246
    new-instance p0, Ljava/lang/StringBuilder;

    .line 247
    .line 248
    const-string p4, " = "

    .line 249
    .line 250
    invoke-direct {p0, p4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 251
    .line 252
    .line 253
    iget-object p4, v1, Lta0;->z:Lsa0;

    .line 254
    .line 255
    aget-object p2, v3, p2

    .line 256
    .line 257
    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 258
    .line 259
    .line 260
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 261
    .line 262
    .line 263
    iget-object p2, p4, Lsa0;->a:Ljava/lang/Object;

    .line 264
    .line 265
    check-cast p2, Lft0;

    .line 266
    .line 267
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 268
    .line 269
    .line 270
    invoke-interface {p2, p1}, Lft0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 271
    .line 272
    .line 273
    move-result-object p1

    .line 274
    check-cast p1, Ljava/lang/String;

    .line 275
    .line 276
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 277
    .line 278
    .line 279
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 280
    .line 281
    .line 282
    move-result-object p0

    .line 283
    invoke-virtual {p3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 284
    .line 285
    .line 286
    :cond_11d
    return-void
.end method

.method public final f(Lcu;)V
    .registers 2

    .line 1
    iget-object p0, p0, Lpa0;->a:Lta0;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lta0;->f(Lcu;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final f0(Ljava/util/Collection;ZLjava/lang/StringBuilder;)V
    .registers 11

    .line 1
    iget-object v0, p0, Lpa0;->a:Lta0;

    .line 2
    .line 3
    iget-object v0, v0, Lta0;->E:Lsa0;

    .line 4
    .line 5
    sget-object v1, Lta0;->Y:[Laf1;

    .line 6
    .line 7
    const/16 v2, 0x1d

    .line 8
    .line 9
    aget-object v1, v1, v2

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    iget-object v0, v0, Lsa0;->a:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v0, Li12;

    .line 20
    .line 21
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    const/4 v1, 0x0

    .line 26
    const/4 v2, 0x1

    .line 27
    if-eqz v0, :cond_29

    .line 28
    .line 29
    if-eq v0, v2, :cond_27

    .line 30
    .line 31
    const/4 p2, 0x2

    .line 32
    if-ne v0, p2, :cond_23

    .line 33
    .line 34
    :cond_21
    move p2, v1

    .line 35
    goto :goto_2a

    .line 36
    :cond_23
    invoke-static {}, Lm03;->a()V

    .line 37
    .line 38
    .line 39
    return-void

    .line 40
    :cond_27
    if-nez p2, :cond_21

    .line 41
    .line 42
    :cond_29
    move p2, v2

    .line 43
    :goto_2a
    invoke-interface {p1}, Ljava/util/Collection;->size()I

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    invoke-virtual {p0}, Lpa0;->s()Lna0;

    .line 48
    .line 49
    .line 50
    move-result-object v3

    .line 51
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 52
    .line 53
    .line 54
    const-string v3, "("

    .line 55
    .line 56
    invoke-virtual {p3, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 57
    .line 58
    .line 59
    check-cast p1, Ljava/lang/Iterable;

    .line 60
    .line 61
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    move v3, v1

    .line 66
    :goto_41
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 67
    .line 68
    .line 69
    move-result v4

    .line 70
    if-eqz v4, :cond_6e

    .line 71
    .line 72
    add-int/lit8 v4, v3, 0x1

    .line 73
    .line 74
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    move-result-object v5

    .line 78
    check-cast v5, Lc73;

    .line 79
    .line 80
    invoke-virtual {p0}, Lpa0;->s()Lna0;

    .line 81
    .line 82
    .line 83
    move-result-object v6

    .line 84
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 85
    .line 86
    .line 87
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 88
    .line 89
    .line 90
    invoke-virtual {p0, v5, p2, p3, v1}, Lpa0;->e0(Lc73;ZLjava/lang/StringBuilder;Z)V

    .line 91
    .line 92
    .line 93
    invoke-virtual {p0}, Lpa0;->s()Lna0;

    .line 94
    .line 95
    .line 96
    move-result-object v5

    .line 97
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 98
    .line 99
    .line 100
    add-int/lit8 v5, v0, -0x1

    .line 101
    .line 102
    if-eq v3, v5, :cond_6c

    .line 103
    .line 104
    const-string v3, ", "

    .line 105
    .line 106
    invoke-virtual {p3, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 107
    .line 108
    .line 109
    :cond_6c
    move v3, v4

    .line 110
    goto :goto_41

    .line 111
    :cond_6e
    invoke-virtual {p0}, Lpa0;->s()Lna0;

    .line 112
    .line 113
    .line 114
    move-result-object p0

    .line 115
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 116
    .line 117
    .line 118
    const-string p0, ")"

    .line 119
    .line 120
    invoke-virtual {p3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 121
    .line 122
    .line 123
    return-void
.end method

.method public final g()V
    .registers 1

    .line 1
    iget-object p0, p0, Lpa0;->a:Lta0;

    .line 2
    .line 3
    invoke-virtual {p0}, Lta0;->g()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final g0(Lya0;Ljava/lang/StringBuilder;)Z
    .registers 7

    .line 1
    invoke-virtual {p0}, Lpa0;->p()Ljava/util/Set;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    sget-object v1, Lqa0;->d:Lqa0;

    .line 6
    .line 7
    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-nez v0, :cond_d

    .line 12
    .line 13
    goto :goto_4f

    .line 14
    :cond_d
    iget-object v0, p0, Lpa0;->a:Lta0;

    .line 15
    .line 16
    iget-object v1, v0, Lta0;->n:Lsa0;

    .line 17
    .line 18
    sget-object v2, Lta0;->Y:[Laf1;

    .line 19
    .line 20
    const/16 v3, 0xc

    .line 21
    .line 22
    aget-object v3, v2, v3

    .line 23
    .line 24
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 25
    .line 26
    .line 27
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 28
    .line 29
    .line 30
    iget-object v1, v1, Lsa0;->a:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast v1, Ljava/lang/Boolean;

    .line 33
    .line 34
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 35
    .line 36
    .line 37
    move-result v1

    .line 38
    if-eqz v1, :cond_31

    .line 39
    .line 40
    iget-object p1, p1, Lya0;->a:Lua3;

    .line 41
    .line 42
    invoke-virtual {p1}, Lua3;->c()Lua3;

    .line 43
    .line 44
    .line 45
    move-result-object p1

    .line 46
    invoke-static {p1}, Lza0;->g(Lua3;)Lya0;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    :cond_31
    iget-object v0, v0, Lta0;->o:Lsa0;

    .line 51
    .line 52
    const/16 v1, 0xd

    .line 53
    .line 54
    aget-object v1, v2, v1

    .line 55
    .line 56
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 57
    .line 58
    .line 59
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 60
    .line 61
    .line 62
    iget-object v0, v0, Lsa0;->a:Ljava/lang/Object;

    .line 63
    .line 64
    check-cast v0, Ljava/lang/Boolean;

    .line 65
    .line 66
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    if-nez v0, :cond_51

    .line 71
    .line 72
    sget-object v0, Lza0;->j:Lya0;

    .line 73
    .line 74
    invoke-static {p1, v0}, Ld31;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    if-eqz v0, :cond_51

    .line 79
    .line 80
    :goto_4f
    const/4 p0, 0x0

    .line 81
    return p0

    .line 82
    :cond_51
    iget-object p1, p1, Lya0;->a:Lua3;

    .line 83
    .line 84
    invoke-virtual {p1}, Lua3;->b()Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object p1

    .line 88
    invoke-virtual {p0, p1}, Lpa0;->H(Ljava/lang/String;)Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    move-result-object p0

    .line 92
    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 93
    .line 94
    .line 95
    const-string p0, " "

    .line 96
    .line 97
    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 98
    .line 99
    .line 100
    const/4 p0, 0x1

    .line 101
    return p0
.end method

.method public final h()V
    .registers 1

    .line 1
    iget-object p0, p0, Lpa0;->a:Lta0;

    .line 2
    .line 3
    invoke-virtual {p0}, Lta0;->h()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final h0(Ljava/lang/StringBuilder;Ljava/util/List;)V
    .registers 11

    .line 1
    iget-object v0, p0, Lpa0;->a:Lta0;

    .line 2
    .line 3
    iget-object v0, v0, Lta0;->w:Lsa0;

    .line 4
    .line 5
    sget-object v1, Lta0;->Y:[Laf1;

    .line 6
    .line 7
    const/16 v2, 0x15

    .line 8
    .line 9
    aget-object v1, v1, v2

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    iget-object v0, v0, Lsa0;->a:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v0, Ljava/lang/Boolean;

    .line 20
    .line 21
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-eqz v0, :cond_1c

    .line 26
    .line 27
    goto/16 :goto_9a

    .line 28
    .line 29
    :cond_1c
    new-instance v1, Ljava/util/ArrayList;

    .line 30
    .line 31
    const/4 v0, 0x0

    .line 32
    invoke-direct {v1, v0}, Ljava/util/ArrayList;-><init>(I)V

    .line 33
    .line 34
    .line 35
    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 36
    .line 37
    .line 38
    move-result-object p2

    .line 39
    :cond_26
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 40
    .line 41
    .line 42
    move-result v2

    .line 43
    if-eqz v2, :cond_78

    .line 44
    .line 45
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v2

    .line 49
    check-cast v2, Ll23;

    .line 50
    .line 51
    invoke-interface {v2}, Ll23;->getUpperBounds()Ljava/util/List;

    .line 52
    .line 53
    .line 54
    move-result-object v3

    .line 55
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 56
    .line 57
    .line 58
    check-cast v3, Ljava/lang/Iterable;

    .line 59
    .line 60
    invoke-static {v3}, Lgv;->U(Ljava/lang/Iterable;)Ljava/util/List;

    .line 61
    .line 62
    .line 63
    move-result-object v3

    .line 64
    check-cast v3, Ljava/lang/Iterable;

    .line 65
    .line 66
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 67
    .line 68
    .line 69
    move-result-object v3

    .line 70
    :goto_45
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 71
    .line 72
    .line 73
    move-result v4

    .line 74
    if-eqz v4, :cond_26

    .line 75
    .line 76
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object v4

    .line 80
    check-cast v4, Lgg1;

    .line 81
    .line 82
    new-instance v5, Ljava/lang/StringBuilder;

    .line 83
    .line 84
    invoke-interface {v2}, Lm60;->getName()Ldv1;

    .line 85
    .line 86
    .line 87
    move-result-object v6

    .line 88
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 89
    .line 90
    .line 91
    invoke-virtual {p0, v6, v0}, Lpa0;->N(Ldv1;Z)Ljava/lang/String;

    .line 92
    .line 93
    .line 94
    move-result-object v6

    .line 95
    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 96
    .line 97
    .line 98
    const-string v6, " : "

    .line 99
    .line 100
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 101
    .line 102
    .line 103
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 104
    .line 105
    .line 106
    invoke-virtual {p0, v4}, Lpa0;->X(Lgg1;)Ljava/lang/String;

    .line 107
    .line 108
    .line 109
    move-result-object v4

    .line 110
    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 111
    .line 112
    .line 113
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 114
    .line 115
    .line 116
    move-result-object v4

    .line 117
    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 118
    .line 119
    .line 120
    goto :goto_45

    .line 121
    :cond_78
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 122
    .line 123
    .line 124
    move-result p2

    .line 125
    if-nez p2, :cond_9a

    .line 126
    .line 127
    const-string p2, " "

    .line 128
    .line 129
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 130
    .line 131
    .line 132
    const-string v0, "where"

    .line 133
    .line 134
    invoke-virtual {p0, v0}, Lpa0;->H(Ljava/lang/String;)Ljava/lang/String;

    .line 135
    .line 136
    .line 137
    move-result-object p0

    .line 138
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 139
    .line 140
    .line 141
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 142
    .line 143
    .line 144
    const/4 v6, 0x0

    .line 145
    const/16 v7, 0x7c

    .line 146
    .line 147
    const-string v3, ", "

    .line 148
    .line 149
    const/4 v4, 0x0

    .line 150
    const/4 v5, 0x0

    .line 151
    move-object v2, p1

    .line 152
    invoke-static/range {v1 .. v7}, Lgv;->d0(Ljava/lang/Iterable;Ljava/lang/Appendable;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lft0;I)V

    .line 153
    .line 154
    .line 155
    :cond_9a
    :goto_9a
    return-void
.end method

.method public final i()Ljava/util/Set;
    .registers 1

    .line 1
    iget-object p0, p0, Lpa0;->a:Lta0;

    .line 2
    .line 3
    invoke-virtual {p0}, Lta0;->i()Ljava/util/Set;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final j(Ljava/util/LinkedHashSet;)V
    .registers 2

    .line 1
    iget-object p0, p0, Lpa0;->a:Lta0;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lta0;->j(Ljava/util/LinkedHashSet;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final k()V
    .registers 1

    .line 1
    iget-object p0, p0, Lpa0;->a:Lta0;

    .line 2
    .line 3
    invoke-virtual {p0}, Lta0;->k()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final l()V
    .registers 1

    .line 1
    iget-object p0, p0, Lpa0;->a:Lta0;

    .line 2
    .line 3
    invoke-virtual {p0}, Lta0;->l()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final m()V
    .registers 1

    .line 1
    iget-object p0, p0, Lpa0;->a:Lta0;

    .line 2
    .line 3
    invoke-virtual {p0}, Lta0;->m()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final n(Ljava/lang/String;)Ljava/lang/String;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lpa0;->r()Lme2;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0, p1}, Lme2;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public final o()Lcu;
    .registers 3

    .line 1
    iget-object p0, p0, Lpa0;->a:Lta0;

    .line 2
    .line 3
    iget-object p0, p0, Lta0;->b:Lsa0;

    .line 4
    .line 5
    sget-object v0, Lta0;->Y:[Laf1;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    aget-object v0, v0, v1

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    iget-object p0, p0, Lsa0;->a:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast p0, Lcu;

    .line 16
    .line 17
    return-object p0
.end method

.method public final p()Ljava/util/Set;
    .registers 3

    .line 1
    iget-object p0, p0, Lpa0;->a:Lta0;

    .line 2
    .line 3
    iget-object p0, p0, Lta0;->e:Lsa0;

    .line 4
    .line 5
    sget-object v0, Lta0;->Y:[Laf1;

    .line 6
    .line 7
    const/4 v1, 0x3

    .line 8
    aget-object v0, v0, v1

    .line 9
    .line 10
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    iget-object p0, p0, Lsa0;->a:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast p0, Ljava/util/Set;

    .line 19
    .line 20
    return-object p0
.end method

.method public final q()Z
    .registers 3

    .line 1
    iget-object p0, p0, Lpa0;->a:Lta0;

    .line 2
    .line 3
    iget-object p0, p0, Lta0;->f:Lsa0;

    .line 4
    .line 5
    sget-object v0, Lta0;->Y:[Laf1;

    .line 6
    .line 7
    const/4 v1, 0x4

    .line 8
    aget-object v0, v0, v1

    .line 9
    .line 10
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    iget-object p0, p0, Lsa0;->a:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast p0, Ljava/lang/Boolean;

    .line 19
    .line 20
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 21
    .line 22
    .line 23
    move-result p0

    .line 24
    return p0
.end method

.method public final r()Lme2;
    .registers 3

    .line 1
    iget-object p0, p0, Lpa0;->a:Lta0;

    .line 2
    .line 3
    iget-object p0, p0, Lta0;->D:Lsa0;

    .line 4
    .line 5
    sget-object v0, Lta0;->Y:[Laf1;

    .line 6
    .line 7
    const/16 v1, 0x1c

    .line 8
    .line 9
    aget-object v0, v0, v1

    .line 10
    .line 11
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    iget-object p0, p0, Lsa0;->a:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast p0, Lme2;

    .line 20
    .line 21
    return-object p0
.end method

.method public final s()Lna0;
    .registers 3

    .line 1
    iget-object p0, p0, Lpa0;->a:Lta0;

    .line 2
    .line 3
    iget-object p0, p0, Lta0;->C:Lsa0;

    .line 4
    .line 5
    sget-object v0, Lta0;->Y:[Laf1;

    .line 6
    .line 7
    const/16 v1, 0x1b

    .line 8
    .line 9
    aget-object v0, v0, v1

    .line 10
    .line 11
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    iget-object p0, p0, Lsa0;->a:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast p0, Lna0;

    .line 20
    .line 21
    return-object p0
.end method

.method public final t()Z
    .registers 3

    .line 1
    iget-object p0, p0, Lpa0;->a:Lta0;

    .line 2
    .line 3
    iget-object p0, p0, Lta0;->j:Lsa0;

    .line 4
    .line 5
    sget-object v0, Lta0;->Y:[Laf1;

    .line 6
    .line 7
    const/16 v1, 0x8

    .line 8
    .line 9
    aget-object v0, v0, v1

    .line 10
    .line 11
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    iget-object p0, p0, Lsa0;->a:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast p0, Ljava/lang/Boolean;

    .line 20
    .line 21
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 22
    .line 23
    .line 24
    move-result p0

    .line 25
    return p0
.end method

.method public final v(Lm60;)Ljava/lang/String;
    .registers 9

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 4
    .line 5
    .line 6
    new-instance v1, Lf80;

    .line 7
    .line 8
    const/4 v2, 0x3

    .line 9
    invoke-direct {v1, v2, p0}, Lf80;-><init>(ILjava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    invoke-interface {p1, v1, v0}, Lm60;->n0(Lq60;Ljava/lang/Object;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    iget-object v1, p0, Lpa0;->a:Lta0;

    .line 16
    .line 17
    iget-object v2, v1, Lta0;->c:Lsa0;

    .line 18
    .line 19
    sget-object v3, Lta0;->Y:[Laf1;

    .line 20
    .line 21
    const/4 v4, 0x1

    .line 22
    aget-object v5, v3, v4

    .line 23
    .line 24
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 25
    .line 26
    .line 27
    iget-object v2, v2, Lsa0;->a:Ljava/lang/Object;

    .line 28
    .line 29
    check-cast v2, Ljava/lang/Boolean;

    .line 30
    .line 31
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 32
    .line 33
    .line 34
    move-result v2

    .line 35
    if-eqz v2, :cond_9c

    .line 36
    .line 37
    instance-of v2, p1, Lu02;

    .line 38
    .line 39
    if-nez v2, :cond_9c

    .line 40
    .line 41
    instance-of v2, p1, Lyh1;

    .line 42
    .line 43
    if-eqz v2, :cond_2d

    .line 44
    .line 45
    goto :goto_9c

    .line 46
    :cond_2d
    invoke-interface {p1}, Lm60;->p()Lm60;

    .line 47
    .line 48
    .line 49
    move-result-object v2

    .line 50
    if-eqz v2, :cond_9c

    .line 51
    .line 52
    instance-of v5, v2, Lzt1;

    .line 53
    .line 54
    if-nez v5, :cond_9c

    .line 55
    .line 56
    const-string v5, " "

    .line 57
    .line 58
    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 59
    .line 60
    .line 61
    invoke-virtual {p0}, Lpa0;->r()Lme2;

    .line 62
    .line 63
    .line 64
    move-result-object v6

    .line 65
    invoke-virtual {v6}, Ljava/lang/Enum;->ordinal()I

    .line 66
    .line 67
    .line 68
    move-result v6

    .line 69
    if-eqz v6, :cond_50

    .line 70
    .line 71
    if-ne v6, v4, :cond_4b

    .line 72
    .line 73
    const-string v4, "<i>defined in</i>"

    .line 74
    .line 75
    goto :goto_52

    .line 76
    :cond_4b
    invoke-static {}, Lm03;->a()V

    .line 77
    .line 78
    .line 79
    const/4 p0, 0x0

    .line 80
    return-object p0

    .line 81
    :cond_50
    const-string v4, "defined in"

    .line 82
    .line 83
    :goto_52
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 84
    .line 85
    .line 86
    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 87
    .line 88
    .line 89
    invoke-static {v2}, Lva0;->g(Lm60;)Lar0;

    .line 90
    .line 91
    .line 92
    move-result-object v4

    .line 93
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 94
    .line 95
    .line 96
    iget-object v5, v4, Lar0;->a:Ljava/lang/String;

    .line 97
    .line 98
    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    .line 99
    .line 100
    .line 101
    move-result v5

    .line 102
    if-eqz v5, :cond_6a

    .line 103
    .line 104
    const-string p0, "root package"

    .line 105
    .line 106
    goto :goto_76

    .line 107
    :cond_6a
    invoke-virtual {v4}, Lar0;->e()Ljava/util/List;

    .line 108
    .line 109
    .line 110
    move-result-object v4

    .line 111
    invoke-static {v4}, Lb21;->v(Ljava/util/List;)Ljava/lang/String;

    .line 112
    .line 113
    .line 114
    move-result-object v4

    .line 115
    invoke-virtual {p0, v4}, Lpa0;->n(Ljava/lang/String;)Ljava/lang/String;

    .line 116
    .line 117
    .line 118
    move-result-object p0

    .line 119
    :goto_76
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 120
    .line 121
    .line 122
    iget-object p0, v1, Lta0;->d:Lsa0;

    .line 123
    .line 124
    const/4 v1, 0x2

    .line 125
    aget-object v1, v3, v1

    .line 126
    .line 127
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 128
    .line 129
    .line 130
    iget-object p0, p0, Lsa0;->a:Ljava/lang/Object;

    .line 131
    .line 132
    check-cast p0, Ljava/lang/Boolean;

    .line 133
    .line 134
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 135
    .line 136
    .line 137
    move-result p0

    .line 138
    if-eqz p0, :cond_9c

    .line 139
    .line 140
    instance-of p0, v2, Lu02;

    .line 141
    .line 142
    if-eqz p0, :cond_9c

    .line 143
    .line 144
    instance-of p0, p1, Lo60;

    .line 145
    .line 146
    if-eqz p0, :cond_9c

    .line 147
    .line 148
    check-cast p1, Lo60;

    .line 149
    .line 150
    invoke-interface {p1}, Lo60;->d()Loq2;

    .line 151
    .line 152
    .line 153
    move-result-object p0

    .line 154
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 155
    .line 156
    .line 157
    :cond_9c
    :goto_9c
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 158
    .line 159
    .line 160
    move-result-object p0

    .line 161
    return-object p0
.end method

.method public final w(La7;Lg7;)Ljava/lang/String;
    .registers 12

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    new-instance v1, Ljava/lang/StringBuilder;

    .line 5
    .line 6
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 7
    .line 8
    .line 9
    const/16 v0, 0x40

    .line 10
    .line 11
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 12
    .line 13
    .line 14
    if-eqz p2, :cond_25

    .line 15
    .line 16
    new-instance v0, Ljava/lang/StringBuilder;

    .line 17
    .line 18
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 19
    .line 20
    .line 21
    iget-object p2, p2, Lg7;->a:Ljava/lang/String;

    .line 22
    .line 23
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 24
    .line 25
    .line 26
    const/16 p2, 0x3a

    .line 27
    .line 28
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 29
    .line 30
    .line 31
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object p2

    .line 35
    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 36
    .line 37
    .line 38
    :cond_25
    invoke-interface {p1}, La7;->getType()Lgg1;

    .line 39
    .line 40
    .line 41
    move-result-object p2

    .line 42
    invoke-virtual {p0, p2}, Lpa0;->X(Lgg1;)Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 47
    .line 48
    .line 49
    iget-object v0, p0, Lpa0;->a:Lta0;

    .line 50
    .line 51
    invoke-virtual {v0}, Lta0;->n()Lp6;

    .line 52
    .line 53
    .line 54
    move-result-object v2

    .line 55
    iget-boolean v2, v2, Lp6;->a:Z

    .line 56
    .line 57
    if-eqz v2, :cond_184

    .line 58
    .line 59
    invoke-interface {p1}, La7;->f()Ljava/util/Map;

    .line 60
    .line 61
    .line 62
    move-result-object v2

    .line 63
    iget-object v3, v0, Lta0;->I:Lsa0;

    .line 64
    .line 65
    sget-object v4, Lta0;->Y:[Laf1;

    .line 66
    .line 67
    const/16 v5, 0x21

    .line 68
    .line 69
    aget-object v4, v4, v5

    .line 70
    .line 71
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 72
    .line 73
    .line 74
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 75
    .line 76
    .line 77
    iget-object v3, v3, Lsa0;->a:Ljava/lang/Object;

    .line 78
    .line 79
    check-cast v3, Ljava/lang/Boolean;

    .line 80
    .line 81
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 82
    .line 83
    .line 84
    move-result v3

    .line 85
    const/4 v4, 0x0

    .line 86
    if-eqz v3, :cond_5c

    .line 87
    .line 88
    invoke-static {p1}, Lxa0;->d(La7;)Lxt1;

    .line 89
    .line 90
    .line 91
    move-result-object p1

    .line 92
    goto :goto_5d

    .line 93
    :cond_5c
    move-object p1, v4

    .line 94
    :goto_5d
    const/16 v3, 0xa

    .line 95
    .line 96
    if-eqz p1, :cond_b1

    .line 97
    .line 98
    invoke-virtual {p1}, Lxt1;->w0()Lvs;

    .line 99
    .line 100
    .line 101
    move-result-object p1

    .line 102
    if-eqz p1, :cond_b1

    .line 103
    .line 104
    invoke-virtual {p1}, Llu0;->r0()Ljava/util/List;

    .line 105
    .line 106
    .line 107
    move-result-object p1

    .line 108
    if-eqz p1, :cond_b1

    .line 109
    .line 110
    check-cast p1, Ljava/lang/Iterable;

    .line 111
    .line 112
    new-instance v4, Ljava/util/ArrayList;

    .line 113
    .line 114
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 115
    .line 116
    .line 117
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 118
    .line 119
    .line 120
    move-result-object p1

    .line 121
    :cond_78
    :goto_78
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 122
    .line 123
    .line 124
    move-result v5

    .line 125
    if-eqz v5, :cond_8f

    .line 126
    .line 127
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 128
    .line 129
    .line 130
    move-result-object v5

    .line 131
    move-object v6, v5

    .line 132
    check-cast v6, Lc73;

    .line 133
    .line 134
    invoke-virtual {v6}, Lc73;->L0()Z

    .line 135
    .line 136
    .line 137
    move-result v6

    .line 138
    if-eqz v6, :cond_78

    .line 139
    .line 140
    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 141
    .line 142
    .line 143
    goto :goto_78

    .line 144
    :cond_8f
    new-instance p1, Ljava/util/ArrayList;

    .line 145
    .line 146
    invoke-static {v4, v3}, Liv;->M(Ljava/lang/Iterable;I)I

    .line 147
    .line 148
    .line 149
    move-result v5

    .line 150
    invoke-direct {p1, v5}, Ljava/util/ArrayList;-><init>(I)V

    .line 151
    .line 152
    .line 153
    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 154
    .line 155
    .line 156
    move-result-object v4

    .line 157
    :goto_9c
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 158
    .line 159
    .line 160
    move-result v5

    .line 161
    if-eqz v5, :cond_b0

    .line 162
    .line 163
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 164
    .line 165
    .line 166
    move-result-object v5

    .line 167
    check-cast v5, Lc73;

    .line 168
    .line 169
    invoke-virtual {v5}, Ln60;->getName()Ldv1;

    .line 170
    .line 171
    .line 172
    move-result-object v5

    .line 173
    invoke-virtual {p1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 174
    .line 175
    .line 176
    goto :goto_9c

    .line 177
    :cond_b0
    move-object v4, p1

    .line 178
    :cond_b1
    if-nez v4, :cond_b5

    .line 179
    .line 180
    sget-object v4, Lth0;->a:Lth0;

    .line 181
    .line 182
    :cond_b5
    move-object p1, v4

    .line 183
    check-cast p1, Ljava/lang/Iterable;

    .line 184
    .line 185
    new-instance v5, Ljava/util/ArrayList;

    .line 186
    .line 187
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 188
    .line 189
    .line 190
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 191
    .line 192
    .line 193
    move-result-object p1

    .line 194
    :cond_c1
    :goto_c1
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 195
    .line 196
    .line 197
    move-result v6

    .line 198
    if-eqz v6, :cond_d8

    .line 199
    .line 200
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 201
    .line 202
    .line 203
    move-result-object v6

    .line 204
    move-object v7, v6

    .line 205
    check-cast v7, Ldv1;

    .line 206
    .line 207
    invoke-interface {v2, v7}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 208
    .line 209
    .line 210
    move-result v7

    .line 211
    if-nez v7, :cond_c1

    .line 212
    .line 213
    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 214
    .line 215
    .line 216
    goto :goto_c1

    .line 217
    :cond_d8
    new-instance p1, Ljava/util/ArrayList;

    .line 218
    .line 219
    invoke-static {v5, v3}, Liv;->M(Ljava/lang/Iterable;I)I

    .line 220
    .line 221
    .line 222
    move-result v6

    .line 223
    invoke-direct {p1, v6}, Ljava/util/ArrayList;-><init>(I)V

    .line 224
    .line 225
    .line 226
    invoke-virtual {v5}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 227
    .line 228
    .line 229
    move-result-object v5

    .line 230
    :goto_e5
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 231
    .line 232
    .line 233
    move-result v6

    .line 234
    if-eqz v6, :cond_10a

    .line 235
    .line 236
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 237
    .line 238
    .line 239
    move-result-object v6

    .line 240
    check-cast v6, Ldv1;

    .line 241
    .line 242
    new-instance v7, Ljava/lang/StringBuilder;

    .line 243
    .line 244
    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    .line 245
    .line 246
    .line 247
    invoke-virtual {v6}, Ldv1;->b()Ljava/lang/String;

    .line 248
    .line 249
    .line 250
    move-result-object v6

    .line 251
    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 252
    .line 253
    .line 254
    const-string v6, " = ..."

    .line 255
    .line 256
    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 257
    .line 258
    .line 259
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 260
    .line 261
    .line 262
    move-result-object v6

    .line 263
    invoke-virtual {p1, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 264
    .line 265
    .line 266
    goto :goto_e5

    .line 267
    :cond_10a
    invoke-interface {v2}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 268
    .line 269
    .line 270
    move-result-object v2

    .line 271
    new-instance v5, Ljava/util/ArrayList;

    .line 272
    .line 273
    invoke-static {v2, v3}, Liv;->M(Ljava/lang/Iterable;I)I

    .line 274
    .line 275
    .line 276
    move-result v3

    .line 277
    invoke-direct {v5, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 278
    .line 279
    .line 280
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 281
    .line 282
    .line 283
    move-result-object v2

    .line 284
    :goto_11b
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 285
    .line 286
    .line 287
    move-result v3

    .line 288
    if-eqz v3, :cond_15c

    .line 289
    .line 290
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 291
    .line 292
    .line 293
    move-result-object v3

    .line 294
    check-cast v3, Ljava/util/Map$Entry;

    .line 295
    .line 296
    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 297
    .line 298
    .line 299
    move-result-object v6

    .line 300
    check-cast v6, Ldv1;

    .line 301
    .line 302
    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 303
    .line 304
    .line 305
    move-result-object v3

    .line 306
    check-cast v3, Lsy;

    .line 307
    .line 308
    new-instance v7, Ljava/lang/StringBuilder;

    .line 309
    .line 310
    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    .line 311
    .line 312
    .line 313
    invoke-virtual {v6}, Ldv1;->b()Ljava/lang/String;

    .line 314
    .line 315
    .line 316
    move-result-object v8

    .line 317
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 318
    .line 319
    .line 320
    const-string v8, " = "

    .line 321
    .line 322
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 323
    .line 324
    .line 325
    invoke-interface {v4, v6}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 326
    .line 327
    .line 328
    move-result v6

    .line 329
    if-nez v6, :cond_14f

    .line 330
    .line 331
    invoke-virtual {p0, v3}, Lpa0;->A(Lsy;)Ljava/lang/String;

    .line 332
    .line 333
    .line 334
    move-result-object v3

    .line 335
    goto :goto_151

    .line 336
    :cond_14f
    const-string v3, "..."

    .line 337
    .line 338
    :goto_151
    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 339
    .line 340
    .line 341
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 342
    .line 343
    .line 344
    move-result-object v3

    .line 345
    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 346
    .line 347
    .line 348
    goto :goto_11b

    .line 349
    :cond_15c
    invoke-static {p1, v5}, Lgv;->k0(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 350
    .line 351
    .line 352
    move-result-object p1

    .line 353
    invoke-static {p1}, Lgv;->t0(Ljava/lang/Iterable;)Ljava/util/List;

    .line 354
    .line 355
    .line 356
    move-result-object p1

    .line 357
    invoke-virtual {v0}, Lta0;->n()Lp6;

    .line 358
    .line 359
    .line 360
    move-result-object v0

    .line 361
    iget-boolean v0, v0, Lp6;->b:Z

    .line 362
    .line 363
    if-nez v0, :cond_175

    .line 364
    .line 365
    move-object v0, p1

    .line 366
    check-cast v0, Ljava/util/Collection;

    .line 367
    .line 368
    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    .line 369
    .line 370
    .line 371
    move-result v0

    .line 372
    if-nez v0, :cond_184

    .line 373
    .line 374
    :cond_175
    move-object v0, p1

    .line 375
    check-cast v0, Ljava/lang/Iterable;

    .line 376
    .line 377
    const/4 v5, 0x0

    .line 378
    const/16 v6, 0x70

    .line 379
    .line 380
    const-string v2, ", "

    .line 381
    .line 382
    const-string v3, "("

    .line 383
    .line 384
    const-string v4, ")"

    .line 385
    .line 386
    invoke-static/range {v0 .. v6}, Lgv;->d0(Ljava/lang/Iterable;Ljava/lang/Appendable;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lft0;I)V

    .line 387
    .line 388
    .line 389
    :cond_184
    invoke-virtual {p0}, Lpa0;->t()Z

    .line 390
    .line 391
    .line 392
    move-result p0

    .line 393
    if-eqz p0, :cond_1a1

    .line 394
    .line 395
    invoke-static {p2}, Lfw;->z(Lgg1;)Z

    .line 396
    .line 397
    .line 398
    move-result p0

    .line 399
    if-nez p0, :cond_19c

    .line 400
    .line 401
    invoke-virtual {p2}, Lgg1;->y()Lp13;

    .line 402
    .line 403
    .line 404
    move-result-object p0

    .line 405
    invoke-interface {p0}, Lp13;->c()Lau;

    .line 406
    .line 407
    .line 408
    move-result-object p0

    .line 409
    instance-of p0, p0, Lyw1;

    .line 410
    .line 411
    if-eqz p0, :cond_1a1

    .line 412
    .line 413
    :cond_19c
    const-string p0, " /* annotation class not found */"

    .line 414
    .line 415
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 416
    .line 417
    .line 418
    :cond_1a1
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 419
    .line 420
    .line 421
    move-result-object p0

    .line 422
    return-object p0
.end method

.method public final x(Ljava/lang/StringBuilder;La6;Lg7;)V
    .registers 10

    .line 1
    invoke-virtual {p0}, Lpa0;->p()Ljava/util/Set;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    sget-object v1, Lqa0;->g:Lqa0;

    .line 6
    .line 7
    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-nez v0, :cond_e

    .line 12
    .line 13
    goto/16 :goto_a0

    .line 14
    .line 15
    :cond_e
    instance-of v0, p2, Lgg1;

    .line 16
    .line 17
    iget-object v1, p0, Lpa0;->a:Lta0;

    .line 18
    .line 19
    if-eqz v0, :cond_19

    .line 20
    .line 21
    invoke-virtual {v1}, Lta0;->i()Ljava/util/Set;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    goto :goto_2b

    .line 26
    :cond_19
    iget-object v0, v1, Lta0;->K:Lsa0;

    .line 27
    .line 28
    sget-object v2, Lta0;->Y:[Laf1;

    .line 29
    .line 30
    const/16 v3, 0x23

    .line 31
    .line 32
    aget-object v2, v2, v3

    .line 33
    .line 34
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 35
    .line 36
    .line 37
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 38
    .line 39
    .line 40
    iget-object v0, v0, Lsa0;->a:Ljava/lang/Object;

    .line 41
    .line 42
    check-cast v0, Ljava/util/Set;

    .line 43
    .line 44
    :goto_2b
    iget-object v2, v1, Lta0;->M:Lsa0;

    .line 45
    .line 46
    sget-object v3, Lta0;->Y:[Laf1;

    .line 47
    .line 48
    const/16 v4, 0x25

    .line 49
    .line 50
    aget-object v3, v3, v4

    .line 51
    .line 52
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 53
    .line 54
    .line 55
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 56
    .line 57
    .line 58
    iget-object v2, v2, Lsa0;->a:Ljava/lang/Object;

    .line 59
    .line 60
    check-cast v2, Lft0;

    .line 61
    .line 62
    invoke-interface {p2}, La6;->getAnnotations()Ll7;

    .line 63
    .line 64
    .line 65
    move-result-object p2

    .line 66
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 67
    .line 68
    .line 69
    move-result-object p2

    .line 70
    :cond_45
    :goto_45
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 71
    .line 72
    .line 73
    move-result v3

    .line 74
    if-eqz v3, :cond_a0

    .line 75
    .line 76
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object v3

    .line 80
    check-cast v3, La7;

    .line 81
    .line 82
    invoke-interface {v3}, La7;->e()Lzq0;

    .line 83
    .line 84
    .line 85
    move-result-object v4

    .line 86
    invoke-static {v0, v4}, Lgv;->T(Ljava/lang/Iterable;Ljava/lang/Object;)Z

    .line 87
    .line 88
    .line 89
    move-result v4

    .line 90
    if-nez v4, :cond_45

    .line 91
    .line 92
    invoke-interface {v3}, La7;->e()Lzq0;

    .line 93
    .line 94
    .line 95
    move-result-object v4

    .line 96
    sget-object v5, Lqr2;->r:Lzq0;

    .line 97
    .line 98
    invoke-static {v4, v5}, Ld31;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 99
    .line 100
    .line 101
    move-result v4

    .line 102
    if-nez v4, :cond_45

    .line 103
    .line 104
    if-eqz v2, :cond_75

    .line 105
    .line 106
    invoke-interface {v2, v3}, Lft0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    move-result-object v4

    .line 110
    check-cast v4, Ljava/lang/Boolean;

    .line 111
    .line 112
    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    .line 113
    .line 114
    .line 115
    move-result v4

    .line 116
    if-eqz v4, :cond_45

    .line 117
    .line 118
    :cond_75
    invoke-virtual {p0, v3, p3}, Lpa0;->w(La7;Lg7;)Ljava/lang/String;

    .line 119
    .line 120
    .line 121
    move-result-object v3

    .line 122
    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 123
    .line 124
    .line 125
    iget-object v3, v1, Lta0;->J:Lsa0;

    .line 126
    .line 127
    sget-object v4, Lta0;->Y:[Laf1;

    .line 128
    .line 129
    const/16 v5, 0x22

    .line 130
    .line 131
    aget-object v4, v4, v5

    .line 132
    .line 133
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 134
    .line 135
    .line 136
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 137
    .line 138
    .line 139
    iget-object v3, v3, Lsa0;->a:Ljava/lang/Object;

    .line 140
    .line 141
    check-cast v3, Ljava/lang/Boolean;

    .line 142
    .line 143
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 144
    .line 145
    .line 146
    move-result v3

    .line 147
    if-eqz v3, :cond_9a

    .line 148
    .line 149
    const/16 v3, 0xa

    .line 150
    .line 151
    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 152
    .line 153
    .line 154
    goto :goto_45

    .line 155
    :cond_9a
    const-string v3, " "

    .line 156
    .line 157
    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 158
    .line 159
    .line 160
    goto :goto_45

    .line 161
    :cond_a0
    :goto_a0
    return-void
.end method

.method public final z(Lbu;Ljava/lang/StringBuilder;)V
    .registers 6

    .line 1
    invoke-interface {p1}, Lbu;->s0()Ljava/util/List;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    invoke-interface {p1}, Lau;->C()Lp13;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    invoke-interface {v1}, Lp13;->e()Ljava/util/List;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    invoke-virtual {p0}, Lpa0;->t()Z

    .line 20
    .line 21
    .line 22
    move-result v2

    .line 23
    if-eqz v2, :cond_41

    .line 24
    .line 25
    invoke-interface {p1}, Lbu;->Z()Z

    .line 26
    .line 27
    .line 28
    move-result p1

    .line 29
    if-eqz p1, :cond_41

    .line 30
    .line 31
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 32
    .line 33
    .line 34
    move-result p1

    .line 35
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 36
    .line 37
    .line 38
    move-result v2

    .line 39
    if-le p1, v2, :cond_41

    .line 40
    .line 41
    const-string p1, " /*captured type parameters: "

    .line 42
    .line 43
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 44
    .line 45
    .line 46
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 47
    .line 48
    .line 49
    move-result p1

    .line 50
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    invoke-interface {v1, p1, v0}, Ljava/util/List;->subList(II)Ljava/util/List;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    invoke-virtual {p0, p2, p1}, Lpa0;->b0(Ljava/lang/StringBuilder;Ljava/util/List;)V

    .line 59
    .line 60
    .line 61
    const-string p0, "*/"

    .line 62
    .line 63
    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 64
    .line 65
    .line 66
    :cond_41
    return-void
.end method
