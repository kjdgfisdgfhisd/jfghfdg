###### Class defpackage.si2 (si2)
.class public final Lsi2;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Ljava/lang/Iterable;


# instance fields
.field public a:Lpi2;

.field public b:Lpi2;

.field public final c:Ljava/util/WeakHashMap;

.field public d:I


# direct methods
.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/util/WeakHashMap;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Lsi2;->c:Ljava/util/WeakHashMap;

    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    iput v0, p0, Lsi2;->d:I

    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final b(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 1
    iget-object v0, p0, Lsi2;->a:Lpi2;

    .line 2
    .line 3
    :goto_2
    if-eqz v0, :cond_10

    .line 4
    .line 5
    iget-object v1, v0, Lpi2;->a:Ljava/lang/Object;

    .line 6
    .line 7
    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-eqz v1, :cond_d

    .line 12
    .line 13
    goto :goto_10

    .line 14
    :cond_d
    iget-object v0, v0, Lpi2;->c:Lpi2;

    .line 15
    .line 16
    goto :goto_2

    .line 17
    :cond_10
    :goto_10
    if-eqz v0, :cond_15

    .line 18
    .line 19
    iget-object p0, v0, Lpi2;->b:Ljava/lang/Object;

    .line 20
    .line 21
    return-object p0

    .line 22
    :cond_15
    new-instance v0, Lpi2;

    .line 23
    .line 24
    invoke-direct {v0, p1, p2}, Lpi2;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    iget p1, p0, Lsi2;->d:I

    .line 28
    .line 29
    add-int/lit8 p1, p1, 0x1

    .line 30
    .line 31
    iput p1, p0, Lsi2;->d:I

    .line 32
    .line 33
    iget-object p1, p0, Lsi2;->b:Lpi2;

    .line 34
    .line 35
    if-nez p1, :cond_29

    .line 36
    .line 37
    iput-object v0, p0, Lsi2;->a:Lpi2;

    .line 38
    .line 39
    iput-object v0, p0, Lsi2;->b:Lpi2;

    .line 40
    .line 41
    goto :goto_2f

    .line 42
    :cond_29
    iput-object v0, p1, Lpi2;->c:Lpi2;

    .line 43
    .line 44
    iput-object p1, v0, Lpi2;->d:Lpi2;

    .line 45
    .line 46
    iput-object v0, p0, Lsi2;->b:Lpi2;

    .line 47
    .line 48
    :goto_2f
    const/4 p0, 0x0

    .line 49
    return-object p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 7

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p1, p0, :cond_4

    .line 3
    .line 4
    return v0

    .line 5
    :cond_4
    instance-of v1, p1, Lsi2;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_a

    .line 9
    .line 10
    return v2

    .line 11
    :cond_a
    check-cast p1, Lsi2;

    .line 12
    .line 13
    iget v1, p0, Lsi2;->d:I

    .line 14
    .line 15
    iget v3, p1, Lsi2;->d:I

    .line 16
    .line 17
    if-eq v1, v3, :cond_13

    .line 18
    .line 19
    return v2

    .line 20
    :cond_13
    invoke-virtual {p0}, Lsi2;->iterator()Ljava/util/Iterator;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    invoke-virtual {p1}, Lsi2;->iterator()Ljava/util/Iterator;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    :cond_1b
    move-object v1, p0

    .line 29
    check-cast v1, Loi2;

    .line 30
    .line 31
    invoke-virtual {v1}, Loi2;->hasNext()Z

    .line 32
    .line 33
    .line 34
    move-result v3

    .line 35
    if-eqz v3, :cond_44

    .line 36
    .line 37
    move-object v3, p1

    .line 38
    check-cast v3, Loi2;

    .line 39
    .line 40
    invoke-virtual {v3}, Loi2;->hasNext()Z

    .line 41
    .line 42
    .line 43
    move-result v4

    .line 44
    if-eqz v4, :cond_44

    .line 45
    .line 46
    invoke-virtual {v1}, Loi2;->next()Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v1

    .line 50
    check-cast v1, Ljava/util/Map$Entry;

    .line 51
    .line 52
    invoke-virtual {v3}, Loi2;->next()Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v3

    .line 56
    if-nez v1, :cond_3b

    .line 57
    .line 58
    if-nez v3, :cond_43

    .line 59
    .line 60
    :cond_3b
    if-eqz v1, :cond_1b

    .line 61
    .line 62
    invoke-interface {v1, v3}, Ljava/util/Map$Entry;->equals(Ljava/lang/Object;)Z

    .line 63
    .line 64
    .line 65
    move-result v1

    .line 66
    if-nez v1, :cond_1b

    .line 67
    .line 68
    :cond_43
    return v2

    .line 69
    :cond_44
    invoke-virtual {v1}, Loi2;->hasNext()Z

    .line 70
    .line 71
    .line 72
    move-result p0

    .line 73
    if-nez p0, :cond_53

    .line 74
    .line 75
    check-cast p1, Loi2;

    .line 76
    .line 77
    invoke-virtual {p1}, Loi2;->hasNext()Z

    .line 78
    .line 79
    .line 80
    move-result p0

    .line 81
    if-nez p0, :cond_53

    .line 82
    .line 83
    return v0

    .line 84
    :cond_53
    return v2
.end method

.method public final hashCode()I
    .registers 4

    .line 1
    invoke-virtual {p0}, Lsi2;->iterator()Ljava/util/Iterator;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    const/4 v0, 0x0

    .line 6
    :goto_5
    move-object v1, p0

    .line 7
    check-cast v1, Loi2;

    .line 8
    .line 9
    invoke-virtual {v1}, Loi2;->hasNext()Z

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    if-eqz v2, :cond_1a

    .line 14
    .line 15
    invoke-virtual {v1}, Loi2;->next()Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    check-cast v1, Ljava/util/Map$Entry;

    .line 20
    .line 21
    invoke-interface {v1}, Ljava/util/Map$Entry;->hashCode()I

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    add-int/2addr v0, v1

    .line 26
    goto :goto_5

    .line 27
    :cond_1a
    return v0
.end method

.method public final iterator()Ljava/util/Iterator;
    .registers 4

    .line 1
    new-instance v0, Loi2;

    .line 2
    .line 3
    iget-object v1, p0, Lsi2;->a:Lpi2;

    .line 4
    .line 5
    iget-object v2, p0, Lsi2;->b:Lpi2;

    .line 6
    .line 7
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object v2, v0, Loi2;->a:Lpi2;

    .line 11
    .line 12
    iput-object v1, v0, Loi2;->b:Lpi2;

    .line 13
    .line 14
    iget-object p0, p0, Lsi2;->c:Ljava/util/WeakHashMap;

    .line 15
    .line 16
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 17
    .line 18
    invoke-virtual {p0, v0, v1}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    return-object v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "["

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0}, Lsi2;->iterator()Ljava/util/Iterator;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    :cond_b
    :goto_b
    move-object v1, p0

    .line 13
    check-cast v1, Loi2;

    .line 14
    .line 15
    invoke-virtual {v1}, Loi2;->hasNext()Z

    .line 16
    .line 17
    .line 18
    move-result v2

    .line 19
    if-eqz v2, :cond_2d

    .line 20
    .line 21
    invoke-virtual {v1}, Loi2;->next()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    check-cast v2, Ljava/util/Map$Entry;

    .line 26
    .line 27
    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 32
    .line 33
    .line 34
    invoke-virtual {v1}, Loi2;->hasNext()Z

    .line 35
    .line 36
    .line 37
    move-result v1

    .line 38
    if-eqz v1, :cond_b

    .line 39
    .line 40
    const-string v1, ", "

    .line 41
    .line 42
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 43
    .line 44
    .line 45
    goto :goto_b

    .line 46
    :cond_2d
    const-string p0, "]"

    .line 47
    .line 48
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 49
    .line 50
    .line 51
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object p0

    .line 55
    return-object p0
.end method
