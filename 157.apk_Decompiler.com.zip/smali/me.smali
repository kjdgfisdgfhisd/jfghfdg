###### Class defpackage.me (me)
.class public final Lme;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lhy1;


# static fields
.field public static final a:Lme;

.field public static final b:Lnm0;

.field public static final c:Lnm0;

.field public static final d:Lnm0;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Lme;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lme;->a:Lme;

    .line 7
    .line 8
    const-string v0, "eventType"

    .line 9
    .line 10
    invoke-static {v0}, Lnm0;->a(Ljava/lang/String;)Lnm0;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    sput-object v0, Lme;->b:Lnm0;

    .line 15
    .line 16
    const-string v0, "sessionData"

    .line 17
    .line 18
    invoke-static {v0}, Lnm0;->a(Ljava/lang/String;)Lnm0;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    sput-object v0, Lme;->c:Lnm0;

    .line 23
    .line 24
    const-string v0, "applicationInfo"

    .line 25
    .line 26
    invoke-static {v0}, Lnm0;->a(Ljava/lang/String;)Lnm0;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    sput-object v0, Lme;->d:Lnm0;

    .line 31
    .line 32
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    .line 1
    check-cast p1, Lql2;

    .line 2
    .line 3
    check-cast p2, Liy1;

    .line 4
    .line 5
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    sget-object p0, Llk0;->b:Llk0;

    .line 9
    .line 10
    sget-object v0, Lme;->b:Lnm0;

    .line 11
    .line 12
    invoke-interface {p2, v0, p0}, Liy1;->a(Lnm0;Ljava/lang/Object;)Liy1;

    .line 13
    .line 14
    .line 15
    sget-object p0, Lme;->c:Lnm0;

    .line 16
    .line 17
    iget-object v0, p1, Lql2;->a:Lyl2;

    .line 18
    .line 19
    invoke-interface {p2, p0, v0}, Liy1;->a(Lnm0;Ljava/lang/Object;)Liy1;

    .line 20
    .line 21
    .line 22
    sget-object p0, Lme;->d:Lnm0;

    .line 23
    .line 24
    iget-object p1, p1, Lql2;->b:Lsa;

    .line 25
    .line 26
    invoke-interface {p2, p0, p1}, Liy1;->a(Lnm0;Ljava/lang/Object;)Liy1;

    .line 27
    .line 28
    .line 29
    return-void
.end method
