###### Class defpackage.qo0 (qo0)
.class public interface abstract Lqo0;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"
