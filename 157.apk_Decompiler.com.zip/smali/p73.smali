###### Class defpackage.p73 (p73)
.class public final Lp73;
.super Lg73;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field public static final m:Landroid/graphics/PorterDuff$Mode;


# instance fields
.field public b:Ln73;

.field public c:Landroid/graphics/PorterDuffColorFilter;

.field public d:Landroid/graphics/ColorFilter;

.field public e:Z

.field public f:Z

.field public final g:[F

.field public final j:Landroid/graphics/Matrix;

.field public final l:Landroid/graphics/Rect;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    sget-object v0, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    .line 2
    .line 3
    sput-object v0, Lp73;->m:Landroid/graphics/PorterDuff$Mode;

    .line 4
    .line 5
    return-void
.end method

.method public constructor <init>()V
    .registers 3

    .line 1
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    iput-boolean v0, p0, Lp73;->f:Z

    .line 6
    .line 7
    const/16 v0, 0x9

    .line 8
    .line 9
    new-array v0, v0, [F

    .line 10
    .line 11
    iput-object v0, p0, Lp73;->g:[F

    .line 12
    .line 13
    new-instance v0, Landroid/graphics/Matrix;

    .line 14
    .line 15
    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    .line 16
    .line 17
    .line 18
    iput-object v0, p0, Lp73;->j:Landroid/graphics/Matrix;

    .line 19
    .line 20
    new-instance v0, Landroid/graphics/Rect;

    .line 21
    .line 22
    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    .line 23
    .line 24
    .line 25
    iput-object v0, p0, Lp73;->l:Landroid/graphics/Rect;

    .line 26
    .line 27
    new-instance v0, Ln73;

    .line 28
    .line 29
    invoke-direct {v0}, Landroid/graphics/drawable/Drawable$ConstantState;-><init>()V

    .line 30
    .line 31
    .line 32
    const/4 v1, 0x0

    .line 33
    iput-object v1, v0, Ln73;->c:Landroid/content/res/ColorStateList;

    .line 34
    .line 35
    sget-object v1, Lp73;->m:Landroid/graphics/PorterDuff$Mode;

    .line 36
    .line 37
    iput-object v1, v0, Ln73;->d:Landroid/graphics/PorterDuff$Mode;

    .line 38
    .line 39
    new-instance v1, Lm73;

    .line 40
    .line 41
    invoke-direct {v1}, Lm73;-><init>()V

    .line 42
    .line 43
    .line 44
    iput-object v1, v0, Ln73;->b:Lm73;

    .line 45
    .line 46
    iput-object v0, p0, Lp73;->b:Ln73;

    .line 47
    .line 48
    return-void
.end method

.method public constructor <init>(Ln73;)V
    .registers 3

    .line 49
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    const/4 v0, 0x1

    .line 50
    iput-boolean v0, p0, Lp73;->f:Z

    const/16 v0, 0x9

    .line 51
    new-array v0, v0, [F

    iput-object v0, p0, Lp73;->g:[F

    .line 52
    new-instance v0, Landroid/graphics/Matrix;

    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    iput-object v0, p0, Lp73;->j:Landroid/graphics/Matrix;

    .line 53
    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    iput-object v0, p0, Lp73;->l:Landroid/graphics/Rect;

    .line 54
    iput-object p1, p0, Lp73;->b:Ln73;

    .line 55
    iget-object v0, p1, Ln73;->c:Landroid/content/res/ColorStateList;

    iget-object p1, p1, Ln73;->d:Landroid/graphics/PorterDuff$Mode;

    invoke-virtual {p0, v0, p1}, Lp73;->a(Landroid/content/res/ColorStateList;Landroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;

    move-result-object p1

    iput-object p1, p0, Lp73;->c:Landroid/graphics/PorterDuffColorFilter;

    return-void
.end method


# virtual methods
.method public final a(Landroid/content/res/ColorStateList;Landroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;
    .registers 4

    .line 1
    if-eqz p1, :cond_14

    .line 2
    .line 3
    if-nez p2, :cond_5

    .line 4
    .line 5
    goto :goto_14

    .line 6
    :cond_5
    invoke-virtual {p0}, Lg73;->getState()[I

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    const/4 v0, 0x0

    .line 11
    invoke-virtual {p1, p0, v0}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    .line 12
    .line 13
    .line 14
    move-result p0

    .line 15
    new-instance p1, Landroid/graphics/PorterDuffColorFilter;

    .line 16
    .line 17
    invoke-direct {p1, p0, p2}, Landroid/graphics/PorterDuffColorFilter;-><init>(ILandroid/graphics/PorterDuff$Mode;)V

    .line 18
    .line 19
    .line 20
    return-object p1

    .line 21
    :cond_14
    :goto_14
    const/4 p0, 0x0

    .line 22
    return-object p0
.end method

.method public final canApplyTheme()Z
    .registers 1

    .line 1
    iget-object p0, p0, Lg73;->a:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    if-eqz p0, :cond_7

    .line 4
    .line 5
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->canApplyTheme()Z

    .line 6
    .line 7
    .line 8
    :cond_7
    const/4 p0, 0x0

    .line 9
    return p0
.end method

.method public final draw(Landroid/graphics/Canvas;)V
    .registers 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    iget-object v2, v0, Lg73;->a:Landroid/graphics/drawable/Drawable;

    .line 6
    .line 7
    if-eqz v2, :cond_c

    .line 8
    .line 9
    invoke-virtual {v2, v1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    .line 10
    .line 11
    .line 12
    return-void

    .line 13
    :cond_c
    iget-object v2, v0, Lp73;->l:Landroid/graphics/Rect;

    .line 14
    .line 15
    invoke-virtual {v0, v2}, Landroid/graphics/drawable/Drawable;->copyBounds(Landroid/graphics/Rect;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {v2}, Landroid/graphics/Rect;->width()I

    .line 19
    .line 20
    .line 21
    move-result v3

    .line 22
    if-lez v3, :cond_16c

    .line 23
    .line 24
    invoke-virtual {v2}, Landroid/graphics/Rect;->height()I

    .line 25
    .line 26
    .line 27
    move-result v3

    .line 28
    if-gtz v3, :cond_1f

    .line 29
    .line 30
    goto/16 :goto_16c

    .line 31
    .line 32
    :cond_1f
    iget-object v3, v0, Lp73;->d:Landroid/graphics/ColorFilter;

    .line 33
    .line 34
    if-nez v3, :cond_25

    .line 35
    .line 36
    iget-object v3, v0, Lp73;->c:Landroid/graphics/PorterDuffColorFilter;

    .line 37
    .line 38
    :cond_25
    iget-object v4, v0, Lp73;->j:Landroid/graphics/Matrix;

    .line 39
    .line 40
    invoke-virtual {v1, v4}, Landroid/graphics/Canvas;->getMatrix(Landroid/graphics/Matrix;)V

    .line 41
    .line 42
    .line 43
    iget-object v5, v0, Lp73;->g:[F

    .line 44
    .line 45
    invoke-virtual {v4, v5}, Landroid/graphics/Matrix;->getValues([F)V

    .line 46
    .line 47
    .line 48
    const/4 v4, 0x0

    .line 49
    aget v6, v5, v4

    .line 50
    .line 51
    invoke-static {v6}, Ljava/lang/Math;->abs(F)F

    .line 52
    .line 53
    .line 54
    move-result v6

    .line 55
    const/4 v7, 0x4

    .line 56
    aget v7, v5, v7

    .line 57
    .line 58
    invoke-static {v7}, Ljava/lang/Math;->abs(F)F

    .line 59
    .line 60
    .line 61
    move-result v7

    .line 62
    const/4 v8, 0x1

    .line 63
    aget v9, v5, v8

    .line 64
    .line 65
    invoke-static {v9}, Ljava/lang/Math;->abs(F)F

    .line 66
    .line 67
    .line 68
    move-result v9

    .line 69
    const/4 v10, 0x3

    .line 70
    aget v5, v5, v10

    .line 71
    .line 72
    invoke-static {v5}, Ljava/lang/Math;->abs(F)F

    .line 73
    .line 74
    .line 75
    move-result v5

    .line 76
    const/4 v10, 0x0

    .line 77
    cmpl-float v9, v9, v10

    .line 78
    .line 79
    const/high16 v11, 0x3f800000    # 1.0f

    .line 80
    .line 81
    if-nez v9, :cond_56

    .line 82
    .line 83
    cmpl-float v5, v5, v10

    .line 84
    .line 85
    if-eqz v5, :cond_58

    .line 86
    .line 87
    :cond_56
    move v6, v11

    .line 88
    move v7, v6

    .line 89
    :cond_58
    invoke-virtual {v2}, Landroid/graphics/Rect;->width()I

    .line 90
    .line 91
    .line 92
    move-result v5

    .line 93
    int-to-float v5, v5

    .line 94
    mul-float/2addr v5, v6

    .line 95
    float-to-int v5, v5

    .line 96
    invoke-virtual {v2}, Landroid/graphics/Rect;->height()I

    .line 97
    .line 98
    .line 99
    move-result v6

    .line 100
    int-to-float v6, v6

    .line 101
    mul-float/2addr v6, v7

    .line 102
    float-to-int v6, v6

    .line 103
    const/16 v7, 0x800

    .line 104
    .line 105
    invoke-static {v7, v5}, Ljava/lang/Math;->min(II)I

    .line 106
    .line 107
    .line 108
    move-result v5

    .line 109
    invoke-static {v7, v6}, Ljava/lang/Math;->min(II)I

    .line 110
    .line 111
    .line 112
    move-result v6

    .line 113
    if-lez v5, :cond_16c

    .line 114
    .line 115
    if-gtz v6, :cond_76

    .line 116
    .line 117
    goto/16 :goto_16c

    .line 118
    .line 119
    :cond_76
    invoke-virtual {v1}, Landroid/graphics/Canvas;->save()I

    .line 120
    .line 121
    .line 122
    move-result v7

    .line 123
    iget v9, v2, Landroid/graphics/Rect;->left:I

    .line 124
    .line 125
    int-to-float v9, v9

    .line 126
    iget v12, v2, Landroid/graphics/Rect;->top:I

    .line 127
    .line 128
    int-to-float v12, v12

    .line 129
    invoke-virtual {v1, v9, v12}, Landroid/graphics/Canvas;->translate(FF)V

    .line 130
    .line 131
    .line 132
    invoke-virtual {v0}, Lp73;->isAutoMirrored()Z

    .line 133
    .line 134
    .line 135
    move-result v9

    .line 136
    if-eqz v9, :cond_9c

    .line 137
    .line 138
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getLayoutDirection()I

    .line 139
    .line 140
    .line 141
    move-result v9

    .line 142
    if-ne v9, v8, :cond_9c

    .line 143
    .line 144
    invoke-virtual {v2}, Landroid/graphics/Rect;->width()I

    .line 145
    .line 146
    .line 147
    move-result v9

    .line 148
    int-to-float v9, v9

    .line 149
    invoke-virtual {v1, v9, v10}, Landroid/graphics/Canvas;->translate(FF)V

    .line 150
    .line 151
    .line 152
    const/high16 v9, -0x40800000    # -1.0f

    .line 153
    .line 154
    invoke-virtual {v1, v9, v11}, Landroid/graphics/Canvas;->scale(FF)V

    .line 155
    .line 156
    .line 157
    :cond_9c
    invoke-virtual {v2, v4, v4}, Landroid/graphics/Rect;->offsetTo(II)V

    .line 158
    .line 159
    .line 160
    iget-object v9, v0, Lp73;->b:Ln73;

    .line 161
    .line 162
    iget-object v10, v9, Ln73;->f:Landroid/graphics/Bitmap;

    .line 163
    .line 164
    if-eqz v10, :cond_b4

    .line 165
    .line 166
    invoke-virtual {v10}, Landroid/graphics/Bitmap;->getWidth()I

    .line 167
    .line 168
    .line 169
    move-result v10

    .line 170
    if-ne v5, v10, :cond_b4

    .line 171
    .line 172
    iget-object v10, v9, Ln73;->f:Landroid/graphics/Bitmap;

    .line 173
    .line 174
    invoke-virtual {v10}, Landroid/graphics/Bitmap;->getHeight()I

    .line 175
    .line 176
    .line 177
    move-result v10

    .line 178
    if-ne v6, v10, :cond_b4

    .line 179
    .line 180
    goto :goto_be

    .line 181
    :cond_b4
    sget-object v10, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    .line 182
    .line 183
    invoke-static {v5, v6, v10}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    .line 184
    .line 185
    .line 186
    move-result-object v10

    .line 187
    iput-object v10, v9, Ln73;->f:Landroid/graphics/Bitmap;

    .line 188
    .line 189
    iput-boolean v8, v9, Ln73;->k:Z

    .line 190
    .line 191
    :goto_be
    iget-boolean v9, v0, Lp73;->f:Z

    .line 192
    .line 193
    iget-object v10, v0, Lp73;->b:Ln73;

    .line 194
    .line 195
    if-nez v9, :cond_de

    .line 196
    .line 197
    iget-object v9, v10, Ln73;->f:Landroid/graphics/Bitmap;

    .line 198
    .line 199
    invoke-virtual {v9, v4}, Landroid/graphics/Bitmap;->eraseColor(I)V

    .line 200
    .line 201
    .line 202
    new-instance v15, Landroid/graphics/Canvas;

    .line 203
    .line 204
    iget-object v4, v10, Ln73;->f:Landroid/graphics/Bitmap;

    .line 205
    .line 206
    invoke-direct {v15, v4}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 207
    .line 208
    .line 209
    iget-object v12, v10, Ln73;->b:Lm73;

    .line 210
    .line 211
    iget-object v13, v12, Lm73;->g:Lj73;

    .line 212
    .line 213
    sget-object v14, Lm73;->p:Landroid/graphics/Matrix;

    .line 214
    .line 215
    move/from16 v16, v5

    .line 216
    .line 217
    move/from16 v17, v6

    .line 218
    .line 219
    invoke-virtual/range {v12 .. v17}, Lm73;->a(Lj73;Landroid/graphics/Matrix;Landroid/graphics/Canvas;II)V

    .line 220
    .line 221
    .line 222
    goto :goto_132

    .line 223
    :cond_de
    move/from16 v16, v5

    .line 224
    .line 225
    move/from16 v17, v6

    .line 226
    .line 227
    iget-boolean v5, v10, Ln73;->k:Z

    .line 228
    .line 229
    if-nez v5, :cond_103

    .line 230
    .line 231
    iget-object v5, v10, Ln73;->g:Landroid/content/res/ColorStateList;

    .line 232
    .line 233
    iget-object v6, v10, Ln73;->c:Landroid/content/res/ColorStateList;

    .line 234
    .line 235
    if-ne v5, v6, :cond_103

    .line 236
    .line 237
    iget-object v5, v10, Ln73;->h:Landroid/graphics/PorterDuff$Mode;

    .line 238
    .line 239
    iget-object v6, v10, Ln73;->d:Landroid/graphics/PorterDuff$Mode;

    .line 240
    .line 241
    if-ne v5, v6, :cond_103

    .line 242
    .line 243
    iget-boolean v5, v10, Ln73;->j:Z

    .line 244
    .line 245
    iget-boolean v6, v10, Ln73;->e:Z

    .line 246
    .line 247
    if-ne v5, v6, :cond_103

    .line 248
    .line 249
    iget v5, v10, Ln73;->i:I

    .line 250
    .line 251
    iget-object v6, v10, Ln73;->b:Lm73;

    .line 252
    .line 253
    invoke-virtual {v6}, Lm73;->getRootAlpha()I

    .line 254
    .line 255
    .line 256
    move-result v6

    .line 257
    if-ne v5, v6, :cond_103

    .line 258
    .line 259
    goto :goto_132

    .line 260
    :cond_103
    iget-object v5, v0, Lp73;->b:Ln73;

    .line 261
    .line 262
    iget-object v6, v5, Ln73;->f:Landroid/graphics/Bitmap;

    .line 263
    .line 264
    invoke-virtual {v6, v4}, Landroid/graphics/Bitmap;->eraseColor(I)V

    .line 265
    .line 266
    .line 267
    new-instance v15, Landroid/graphics/Canvas;

    .line 268
    .line 269
    iget-object v6, v5, Ln73;->f:Landroid/graphics/Bitmap;

    .line 270
    .line 271
    invoke-direct {v15, v6}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 272
    .line 273
    .line 274
    iget-object v12, v5, Ln73;->b:Lm73;

    .line 275
    .line 276
    iget-object v13, v12, Lm73;->g:Lj73;

    .line 277
    .line 278
    sget-object v14, Lm73;->p:Landroid/graphics/Matrix;

    .line 279
    .line 280
    invoke-virtual/range {v12 .. v17}, Lm73;->a(Lj73;Landroid/graphics/Matrix;Landroid/graphics/Canvas;II)V

    .line 281
    .line 282
    .line 283
    iget-object v5, v0, Lp73;->b:Ln73;

    .line 284
    .line 285
    iget-object v6, v5, Ln73;->c:Landroid/content/res/ColorStateList;

    .line 286
    .line 287
    iput-object v6, v5, Ln73;->g:Landroid/content/res/ColorStateList;

    .line 288
    .line 289
    iget-object v6, v5, Ln73;->d:Landroid/graphics/PorterDuff$Mode;

    .line 290
    .line 291
    iput-object v6, v5, Ln73;->h:Landroid/graphics/PorterDuff$Mode;

    .line 292
    .line 293
    iget-object v6, v5, Ln73;->b:Lm73;

    .line 294
    .line 295
    invoke-virtual {v6}, Lm73;->getRootAlpha()I

    .line 296
    .line 297
    .line 298
    move-result v6

    .line 299
    iput v6, v5, Ln73;->i:I

    .line 300
    .line 301
    iget-boolean v6, v5, Ln73;->e:Z

    .line 302
    .line 303
    iput-boolean v6, v5, Ln73;->j:Z

    .line 304
    .line 305
    iput-boolean v4, v5, Ln73;->k:Z

    .line 306
    .line 307
    :goto_132
    iget-object v0, v0, Lp73;->b:Ln73;

    .line 308
    .line 309
    iget-object v4, v0, Ln73;->b:Lm73;

    .line 310
    .line 311
    invoke-virtual {v4}, Lm73;->getRootAlpha()I

    .line 312
    .line 313
    .line 314
    move-result v4

    .line 315
    const/16 v5, 0xff

    .line 316
    .line 317
    const/4 v6, 0x0

    .line 318
    if-ge v4, v5, :cond_140

    .line 319
    .line 320
    goto :goto_144

    .line 321
    :cond_140
    if-nez v3, :cond_144

    .line 322
    .line 323
    move-object v3, v6

    .line 324
    goto :goto_164

    .line 325
    :cond_144
    :goto_144
    iget-object v4, v0, Ln73;->l:Landroid/graphics/Paint;

    .line 326
    .line 327
    if-nez v4, :cond_152

    .line 328
    .line 329
    new-instance v4, Landroid/graphics/Paint;

    .line 330
    .line 331
    invoke-direct {v4}, Landroid/graphics/Paint;-><init>()V

    .line 332
    .line 333
    .line 334
    iput-object v4, v0, Ln73;->l:Landroid/graphics/Paint;

    .line 335
    .line 336
    invoke-virtual {v4, v8}, Landroid/graphics/Paint;->setFilterBitmap(Z)V

    .line 337
    .line 338
    .line 339
    :cond_152
    iget-object v4, v0, Ln73;->l:Landroid/graphics/Paint;

    .line 340
    .line 341
    iget-object v5, v0, Ln73;->b:Lm73;

    .line 342
    .line 343
    invoke-virtual {v5}, Lm73;->getRootAlpha()I

    .line 344
    .line 345
    .line 346
    move-result v5

    .line 347
    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 348
    .line 349
    .line 350
    iget-object v4, v0, Ln73;->l:Landroid/graphics/Paint;

    .line 351
    .line 352
    invoke-virtual {v4, v3}, Landroid/graphics/Paint;->setColorFilter(Landroid/graphics/ColorFilter;)Landroid/graphics/ColorFilter;

    .line 353
    .line 354
    .line 355
    iget-object v3, v0, Ln73;->l:Landroid/graphics/Paint;

    .line 356
    .line 357
    :goto_164
    iget-object v0, v0, Ln73;->f:Landroid/graphics/Bitmap;

    .line 358
    .line 359
    invoke-virtual {v1, v0, v6, v2, v3}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/Rect;Landroid/graphics/Paint;)V

    .line 360
    .line 361
    .line 362
    invoke-virtual {v1, v7}, Landroid/graphics/Canvas;->restoreToCount(I)V

    .line 363
    .line 364
    .line 365
    :cond_16c
    :goto_16c
    return-void
.end method

.method public final getAlpha()I
    .registers 2

    .line 1
    iget-object v0, p0, Lg73;->a:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    if-eqz v0, :cond_9

    .line 4
    .line 5
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getAlpha()I

    .line 6
    .line 7
    .line 8
    move-result p0

    .line 9
    return p0

    .line 10
    :cond_9
    iget-object p0, p0, Lp73;->b:Ln73;

    .line 11
    .line 12
    iget-object p0, p0, Ln73;->b:Lm73;

    .line 13
    .line 14
    invoke-virtual {p0}, Lm73;->getRootAlpha()I

    .line 15
    .line 16
    .line 17
    move-result p0

    .line 18
    return p0
.end method

.method public final getChangingConfigurations()I
    .registers 2

    .line 1
    iget-object v0, p0, Lg73;->a:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    if-eqz v0, :cond_9

    .line 4
    .line 5
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getChangingConfigurations()I

    .line 6
    .line 7
    .line 8
    move-result p0

    .line 9
    return p0

    .line 10
    :cond_9
    invoke-super {p0}, Landroid/graphics/drawable/Drawable;->getChangingConfigurations()I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    iget-object p0, p0, Lp73;->b:Ln73;

    .line 15
    .line 16
    invoke-virtual {p0}, Ln73;->getChangingConfigurations()I

    .line 17
    .line 18
    .line 19
    move-result p0

    .line 20
    or-int/2addr p0, v0

    .line 21
    return p0
.end method

.method public final getColorFilter()Landroid/graphics/ColorFilter;
    .registers 2

    .line 1
    iget-object v0, p0, Lg73;->a:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    if-eqz v0, :cond_9

    .line 4
    .line 5
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getColorFilter()Landroid/graphics/ColorFilter;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0

    .line 10
    :cond_9
    iget-object p0, p0, Lp73;->d:Landroid/graphics/ColorFilter;

    .line 11
    .line 12
    return-object p0
.end method

.method public final getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;
    .registers 3

    .line 1
    iget-object v0, p0, Lg73;->a:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    if-eqz v0, :cond_10

    .line 4
    .line 5
    new-instance v0, Lo73;

    .line 6
    .line 7
    iget-object p0, p0, Lg73;->a:Landroid/graphics/drawable/Drawable;

    .line 8
    .line 9
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    invoke-direct {v0, p0}, Lo73;-><init>(Landroid/graphics/drawable/Drawable$ConstantState;)V

    .line 14
    .line 15
    .line 16
    return-object v0

    .line 17
    :cond_10
    iget-object v0, p0, Lp73;->b:Ln73;

    .line 18
    .line 19
    invoke-virtual {p0}, Lp73;->getChangingConfigurations()I

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    iput v1, v0, Ln73;->a:I

    .line 24
    .line 25
    iget-object p0, p0, Lp73;->b:Ln73;

    .line 26
    .line 27
    return-object p0
.end method

.method public final getIntrinsicHeight()I
    .registers 2

    .line 1
    iget-object v0, p0, Lg73;->a:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    if-eqz v0, :cond_9

    .line 4
    .line 5
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    .line 6
    .line 7
    .line 8
    move-result p0

    .line 9
    return p0

    .line 10
    :cond_9
    iget-object p0, p0, Lp73;->b:Ln73;

    .line 11
    .line 12
    iget-object p0, p0, Ln73;->b:Lm73;

    .line 13
    .line 14
    iget p0, p0, Lm73;->i:F

    .line 15
    .line 16
    float-to-int p0, p0

    .line 17
    return p0
.end method

.method public final getIntrinsicWidth()I
    .registers 2

    .line 1
    iget-object v0, p0, Lg73;->a:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    if-eqz v0, :cond_9

    .line 4
    .line 5
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    .line 6
    .line 7
    .line 8
    move-result p0

    .line 9
    return p0

    .line 10
    :cond_9
    iget-object p0, p0, Lp73;->b:Ln73;

    .line 11
    .line 12
    iget-object p0, p0, Ln73;->b:Lm73;

    .line 13
    .line 14
    iget p0, p0, Lm73;->h:F

    .line 15
    .line 16
    float-to-int p0, p0

    .line 17
    return p0
.end method

.method public final getOpacity()I
    .registers 1

    .line 1
    iget-object p0, p0, Lg73;->a:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    if-eqz p0, :cond_9

    .line 4
    .line 5
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getOpacity()I

    .line 6
    .line 7
    .line 8
    move-result p0

    .line 9
    return p0

    .line 10
    :cond_9
    const/4 p0, -0x3

    .line 11
    return p0
.end method

.method public final inflate(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;)V
    .registers 5

    .line 1173
    iget-object v0, p0, Lg73;->a:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_8

    .line 1174
    invoke-virtual {v0, p1, p2, p3}, Landroid/graphics/drawable/Drawable;->inflate(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;)V

    return-void

    :cond_8
    const/4 v0, 0x0

    .line 1175
    invoke-virtual {p0, p1, p2, p3, v0}, Lp73;->inflate(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V

    return-void
.end method

.method public final inflate(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V
    .registers 33

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v2, p1

    .line 4
    .line 5
    move-object/from16 v3, p2

    .line 6
    .line 7
    move-object/from16 v4, p3

    .line 8
    .line 9
    move-object/from16 v5, p4

    .line 10
    .line 11
    iget-object v0, v1, Lg73;->a:Landroid/graphics/drawable/Drawable;

    .line 12
    .line 13
    if-eqz v0, :cond_12

    .line 14
    .line 15
    invoke-virtual {v0, v2, v3, v4, v5}, Landroid/graphics/drawable/Drawable;->inflate(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V

    .line 16
    .line 17
    .line 18
    return-void

    .line 19
    :cond_12
    iget-object v6, v1, Lp73;->b:Ln73;

    .line 20
    .line 21
    new-instance v0, Lm73;

    .line 22
    .line 23
    invoke-direct {v0}, Lm73;-><init>()V

    .line 24
    .line 25
    .line 26
    iput-object v0, v6, Ln73;->b:Lm73;

    .line 27
    .line 28
    sget-object v0, Lc10;->a:[I

    .line 29
    .line 30
    invoke-static {v2, v5, v4, v0}, Lq33;->C(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    .line 31
    .line 32
    .line 33
    move-result-object v7

    .line 34
    iget-object v8, v1, Lp73;->b:Ln73;

    .line 35
    .line 36
    iget-object v9, v8, Ln73;->b:Lm73;

    .line 37
    .line 38
    const-string v0, "tintMode"

    .line 39
    .line 40
    invoke-static {v3, v0}, Lq33;->u(Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;)Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    const/4 v10, -0x1

    .line 45
    const/4 v11, 0x6

    .line 46
    if-nez v0, :cond_31

    .line 47
    .line 48
    move v0, v10

    .line 49
    goto :goto_35

    .line 50
    :cond_31
    invoke-virtual {v7, v11, v10}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    :goto_35
    sget-object v12, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    .line 55
    .line 56
    const/16 v13, 0x9

    .line 57
    .line 58
    const/4 v14, 0x3

    .line 59
    const/4 v15, 0x5

    .line 60
    if-eq v0, v14, :cond_51

    .line 61
    .line 62
    if-eq v0, v15, :cond_53

    .line 63
    .line 64
    if-eq v0, v13, :cond_4e

    .line 65
    .line 66
    packed-switch v0, :pswitch_data_494

    .line 67
    .line 68
    .line 69
    goto :goto_53

    .line 70
    :pswitch_45
    sget-object v12, Landroid/graphics/PorterDuff$Mode;->ADD:Landroid/graphics/PorterDuff$Mode;

    .line 71
    .line 72
    goto :goto_53

    .line 73
    :pswitch_48
    sget-object v12, Landroid/graphics/PorterDuff$Mode;->SCREEN:Landroid/graphics/PorterDuff$Mode;

    .line 74
    .line 75
    goto :goto_53

    .line 76
    :pswitch_4b
    sget-object v12, Landroid/graphics/PorterDuff$Mode;->MULTIPLY:Landroid/graphics/PorterDuff$Mode;

    .line 77
    .line 78
    goto :goto_53

    .line 79
    :cond_4e
    sget-object v12, Landroid/graphics/PorterDuff$Mode;->SRC_ATOP:Landroid/graphics/PorterDuff$Mode;

    .line 80
    .line 81
    goto :goto_53

    .line 82
    :cond_51
    sget-object v12, Landroid/graphics/PorterDuff$Mode;->SRC_OVER:Landroid/graphics/PorterDuff$Mode;

    .line 83
    .line 84
    :cond_53
    :goto_53
    iput-object v12, v8, Ln73;->d:Landroid/graphics/PorterDuff$Mode;

    .line 85
    .line 86
    const-string v0, "tint"

    .line 87
    .line 88
    const-string v12, "http://schemas.android.com/apk/res/android"

    .line 89
    .line 90
    invoke-interface {v3, v12, v0}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    const/16 v16, 0x0

    .line 95
    .line 96
    const/4 v11, 0x2

    .line 97
    const/4 v13, 0x0

    .line 98
    const/4 v10, 0x1

    .line 99
    if-eqz v0, :cond_7e

    .line 100
    .line 101
    new-instance v0, Landroid/util/TypedValue;

    .line 102
    .line 103
    invoke-direct {v0}, Landroid/util/TypedValue;-><init>()V

    .line 104
    .line 105
    .line 106
    invoke-virtual {v7, v10, v0}, Landroid/content/res/TypedArray;->getValue(ILandroid/util/TypedValue;)Z

    .line 107
    .line 108
    .line 109
    iget v14, v0, Landroid/util/TypedValue;->type:I

    .line 110
    .line 111
    if-eq v14, v11, :cond_9d

    .line 112
    .line 113
    const/16 v11, 0x1c

    .line 114
    .line 115
    if-lt v14, v11, :cond_81

    .line 116
    .line 117
    const/16 v11, 0x1f

    .line 118
    .line 119
    if-gt v14, v11, :cond_81

    .line 120
    .line 121
    iget v0, v0, Landroid/util/TypedValue;->data:I

    .line 122
    .line 123
    invoke-static {v0}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    .line 124
    .line 125
    .line 126
    move-result-object v16

    .line 127
    :cond_7e
    :goto_7e
    move-object/from16 v0, v16

    .line 128
    .line 129
    goto :goto_a3

    .line 130
    :cond_81
    invoke-virtual {v7}, Landroid/content/res/TypedArray;->getResources()Landroid/content/res/Resources;

    .line 131
    .line 132
    .line 133
    move-result-object v0

    .line 134
    invoke-virtual {v7, v10, v13}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 135
    .line 136
    .line 137
    move-result v11

    .line 138
    sget-object v14, Lwv;->a:Ljava/lang/ThreadLocal;

    .line 139
    .line 140
    :try_start_8b
    invoke-virtual {v0, v11}, Landroid/content/res/Resources;->getXml(I)Landroid/content/res/XmlResourceParser;

    .line 141
    .line 142
    .line 143
    move-result-object v11

    .line 144
    invoke-static {v0, v11, v5}, Lwv;->a(Landroid/content/res/Resources;Landroid/content/res/XmlResourceParser;Landroid/content/res/Resources$Theme;)Landroid/content/res/ColorStateList;

    .line 145
    .line 146
    .line 147
    move-result-object v16
    :try_end_93
    .catch Ljava/lang/Exception; {:try_start_8b .. :try_end_93} :catch_94

    .line 148
    goto :goto_7e

    .line 149
    :catch_94
    move-exception v0

    .line 150
    const-string v11, "CSLCompat"

    .line 151
    .line 152
    const-string v14, "Failed to inflate ColorStateList."

    .line 153
    .line 154
    invoke-static {v11, v14, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 155
    .line 156
    .line 157
    goto :goto_7e

    .line 158
    :cond_9d
    const-string v1, "Failed to resolve attribute at index 1: "

    .line 159
    .line 160
    invoke-static {v0, v1}, Lm03;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 161
    .line 162
    .line 163
    return-void

    .line 164
    :goto_a3
    if-eqz v0, :cond_a7

    .line 165
    .line 166
    iput-object v0, v8, Ln73;->c:Landroid/content/res/ColorStateList;

    .line 167
    .line 168
    :cond_a7
    iget-boolean v0, v8, Ln73;->e:Z

    .line 169
    .line 170
    const-string v11, "autoMirrored"

    .line 171
    .line 172
    invoke-interface {v3, v12, v11}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 173
    .line 174
    .line 175
    move-result-object v11

    .line 176
    if-eqz v11, :cond_b5

    .line 177
    .line 178
    invoke-virtual {v7, v15, v0}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 179
    .line 180
    .line 181
    move-result v0

    .line 182
    :cond_b5
    iput-boolean v0, v8, Ln73;->e:Z

    .line 183
    .line 184
    iget v0, v9, Lm73;->j:F

    .line 185
    .line 186
    const-string v8, "viewportWidth"

    .line 187
    .line 188
    invoke-interface {v3, v12, v8}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 189
    .line 190
    .line 191
    move-result-object v8

    .line 192
    const/4 v11, 0x7

    .line 193
    if-eqz v8, :cond_c6

    .line 194
    .line 195
    invoke-virtual {v7, v11, v0}, Landroid/content/res/TypedArray;->getFloat(IF)F

    .line 196
    .line 197
    .line 198
    move-result v0

    .line 199
    :cond_c6
    iput v0, v9, Lm73;->j:F

    .line 200
    .line 201
    iget v0, v9, Lm73;->k:F

    .line 202
    .line 203
    const-string v8, "viewportHeight"

    .line 204
    .line 205
    invoke-interface {v3, v12, v8}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 206
    .line 207
    .line 208
    move-result-object v8

    .line 209
    const/16 v14, 0x8

    .line 210
    .line 211
    if-eqz v8, :cond_d8

    .line 212
    .line 213
    invoke-virtual {v7, v14, v0}, Landroid/content/res/TypedArray;->getFloat(IF)F

    .line 214
    .line 215
    .line 216
    move-result v0

    .line 217
    :cond_d8
    iput v0, v9, Lm73;->k:F

    .line 218
    .line 219
    iget v8, v9, Lm73;->j:F

    .line 220
    .line 221
    const/4 v15, 0x0

    .line 222
    cmpg-float v8, v8, v15

    .line 223
    .line 224
    if-lez v8, :cond_478

    .line 225
    .line 226
    cmpg-float v0, v0, v15

    .line 227
    .line 228
    if-lez v0, :cond_45d

    .line 229
    .line 230
    iget v0, v9, Lm73;->h:F

    .line 231
    .line 232
    const/4 v8, 0x3

    .line 233
    invoke-virtual {v7, v8, v0}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 234
    .line 235
    .line 236
    move-result v0

    .line 237
    iput v0, v9, Lm73;->h:F

    .line 238
    .line 239
    iget v0, v9, Lm73;->i:F

    .line 240
    .line 241
    const/4 v8, 0x2

    .line 242
    invoke-virtual {v7, v8, v0}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 243
    .line 244
    .line 245
    move-result v0

    .line 246
    iput v0, v9, Lm73;->i:F

    .line 247
    .line 248
    iget v8, v9, Lm73;->h:F

    .line 249
    .line 250
    cmpg-float v8, v8, v15

    .line 251
    .line 252
    if-lez v8, :cond_442

    .line 253
    .line 254
    cmpg-float v0, v0, v15

    .line 255
    .line 256
    if-lez v0, :cond_427

    .line 257
    .line 258
    invoke-virtual {v9}, Lm73;->getAlpha()F

    .line 259
    .line 260
    .line 261
    move-result v0

    .line 262
    const-string v8, "alpha"

    .line 263
    .line 264
    invoke-interface {v3, v12, v8}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 265
    .line 266
    .line 267
    move-result-object v8

    .line 268
    const/4 v11, 0x4

    .line 269
    if-eqz v8, :cond_112

    .line 270
    .line 271
    invoke-virtual {v7, v11, v0}, Landroid/content/res/TypedArray;->getFloat(IF)F

    .line 272
    .line 273
    .line 274
    move-result v0

    .line 275
    :cond_112
    invoke-virtual {v9, v0}, Lm73;->setAlpha(F)V

    .line 276
    .line 277
    .line 278
    invoke-virtual {v7, v13}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    .line 279
    .line 280
    .line 281
    move-result-object v0

    .line 282
    if-eqz v0, :cond_122

    .line 283
    .line 284
    iput-object v0, v9, Lm73;->m:Ljava/lang/String;

    .line 285
    .line 286
    iget-object v8, v9, Lm73;->o:Llb;

    .line 287
    .line 288
    invoke-virtual {v8, v0, v9}, Lco2;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 289
    .line 290
    .line 291
    :cond_122
    invoke-virtual {v7}, Landroid/content/res/TypedArray;->recycle()V

    .line 292
    .line 293
    .line 294
    invoke-virtual {v1}, Lp73;->getChangingConfigurations()I

    .line 295
    .line 296
    .line 297
    move-result v0

    .line 298
    iput v0, v6, Ln73;->a:I

    .line 299
    .line 300
    iput-boolean v10, v6, Ln73;->k:Z

    .line 301
    .line 302
    iget-object v0, v1, Lp73;->b:Ln73;

    .line 303
    .line 304
    iget-object v7, v0, Ln73;->b:Lm73;

    .line 305
    .line 306
    new-instance v8, Ljava/util/ArrayDeque;

    .line 307
    .line 308
    invoke-direct {v8}, Ljava/util/ArrayDeque;-><init>()V

    .line 309
    .line 310
    .line 311
    iget-object v9, v7, Lm73;->g:Lj73;

    .line 312
    .line 313
    iget-object v7, v7, Lm73;->o:Llb;

    .line 314
    .line 315
    invoke-virtual {v8, v9}, Ljava/util/ArrayDeque;->push(Ljava/lang/Object;)V

    .line 316
    .line 317
    .line 318
    invoke-interface {v3}, Lorg/xmlpull/v1/XmlPullParser;->getEventType()I

    .line 319
    .line 320
    .line 321
    move-result v9

    .line 322
    invoke-interface {v3}, Lorg/xmlpull/v1/XmlPullParser;->getDepth()I

    .line 323
    .line 324
    .line 325
    move-result v21

    .line 326
    add-int/lit8 v11, v21, 0x1

    .line 327
    .line 328
    move/from16 v21, v10

    .line 329
    .line 330
    :goto_149
    if-eq v9, v10, :cond_412

    .line 331
    .line 332
    invoke-interface {v3}, Lorg/xmlpull/v1/XmlPullParser;->getDepth()I

    .line 333
    .line 334
    .line 335
    move-result v14

    .line 336
    if-ge v14, v11, :cond_154

    .line 337
    .line 338
    const/4 v14, 0x3

    .line 339
    if-eq v9, v14, :cond_412

    .line 340
    .line 341
    :cond_154
    const-string v14, "group"

    .line 342
    .line 343
    const/4 v10, 0x2

    .line 344
    if-ne v9, v10, :cond_3e4

    .line 345
    .line 346
    invoke-interface {v3}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    .line 347
    .line 348
    .line 349
    move-result-object v9

    .line 350
    invoke-virtual {v8}, Ljava/util/ArrayDeque;->peek()Ljava/lang/Object;

    .line 351
    .line 352
    .line 353
    move-result-object v10

    .line 354
    check-cast v10, Lj73;

    .line 355
    .line 356
    const-string v13, "path"

    .line 357
    .line 358
    invoke-virtual {v13, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 359
    .line 360
    .line 361
    move-result v13

    .line 362
    const-string v15, "fillType"

    .line 363
    .line 364
    move/from16 v25, v11

    .line 365
    .line 366
    const-string v11, "pathData"

    .line 367
    .line 368
    if-eqz v13, :cond_2d0

    .line 369
    .line 370
    new-instance v9, Li73;

    .line 371
    .line 372
    invoke-direct {v9}, Ll73;-><init>()V

    .line 373
    .line 374
    .line 375
    const/4 v13, 0x0

    .line 376
    iput v13, v9, Li73;->e:F

    .line 377
    .line 378
    const/high16 v14, 0x3f800000    # 1.0f

    .line 379
    .line 380
    iput v14, v9, Li73;->g:F

    .line 381
    .line 382
    iput v14, v9, Li73;->h:F

    .line 383
    .line 384
    iput v13, v9, Li73;->i:F

    .line 385
    .line 386
    iput v14, v9, Li73;->j:F

    .line 387
    .line 388
    iput v13, v9, Li73;->k:F

    .line 389
    .line 390
    sget-object v14, Landroid/graphics/Paint$Cap;->BUTT:Landroid/graphics/Paint$Cap;

    .line 391
    .line 392
    iput-object v14, v9, Li73;->l:Landroid/graphics/Paint$Cap;

    .line 393
    .line 394
    sget-object v13, Landroid/graphics/Paint$Join;->MITER:Landroid/graphics/Paint$Join;

    .line 395
    .line 396
    iput-object v13, v9, Li73;->m:Landroid/graphics/Paint$Join;

    .line 397
    .line 398
    move-object/from16 v21, v13

    .line 399
    .line 400
    const/high16 v13, 0x40800000    # 4.0f

    .line 401
    .line 402
    iput v13, v9, Li73;->n:F

    .line 403
    .line 404
    sget-object v13, Lc10;->c:[I

    .line 405
    .line 406
    invoke-static {v2, v5, v4, v13}, Lq33;->C(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    .line 407
    .line 408
    .line 409
    move-result-object v13

    .line 410
    invoke-interface {v3, v12, v11}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 411
    .line 412
    .line 413
    move-result-object v11

    .line 414
    if-eqz v11, :cond_2ab

    .line 415
    .line 416
    move-object/from16 v26, v14

    .line 417
    .line 418
    const/4 v11, 0x0

    .line 419
    invoke-virtual {v13, v11}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    .line 420
    .line 421
    .line 422
    move-result-object v14

    .line 423
    if-eqz v14, :cond_1aa

    .line 424
    .line 425
    iput-object v14, v9, Ll73;->b:Ljava/lang/String;

    .line 426
    .line 427
    :cond_1aa
    const/4 v11, 0x2

    .line 428
    invoke-virtual {v13, v11}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    .line 429
    .line 430
    .line 431
    move-result-object v14

    .line 432
    if-eqz v14, :cond_1b7

    .line 433
    .line 434
    invoke-static {v14}, Lkw0;->g(Ljava/lang/String;)[Ln12;

    .line 435
    .line 436
    .line 437
    move-result-object v11

    .line 438
    iput-object v11, v9, Ll73;->a:[Ln12;

    .line 439
    .line 440
    :cond_1b7
    const-string v11, "fillColor"

    .line 441
    .line 442
    const/4 v14, 0x1

    .line 443
    invoke-static {v13, v3, v5, v11, v14}, Lq33;->p(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Landroid/content/res/Resources$Theme;Ljava/lang/String;I)Le9;

    .line 444
    .line 445
    .line 446
    move-result-object v11

    .line 447
    iput-object v11, v9, Li73;->f:Le9;

    .line 448
    .line 449
    iget v11, v9, Li73;->h:F

    .line 450
    .line 451
    const-string v14, "fillAlpha"

    .line 452
    .line 453
    invoke-interface {v3, v12, v14}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 454
    .line 455
    .line 456
    move-result-object v14

    .line 457
    if-eqz v14, :cond_1d0

    .line 458
    .line 459
    const/16 v14, 0xc

    .line 460
    .line 461
    invoke-virtual {v13, v14, v11}, Landroid/content/res/TypedArray;->getFloat(IF)F

    .line 462
    .line 463
    .line 464
    move-result v11

    .line 465
    :cond_1d0
    iput v11, v9, Li73;->h:F

    .line 466
    .line 467
    const-string v11, "strokeLineCap"

    .line 468
    .line 469
    invoke-interface {v3, v12, v11}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 470
    .line 471
    .line 472
    move-result-object v11

    .line 473
    if-eqz v11, :cond_1e4

    .line 474
    .line 475
    const/16 v11, 0x8

    .line 476
    .line 477
    const/4 v14, -0x1

    .line 478
    invoke-virtual {v13, v11, v14}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 479
    .line 480
    .line 481
    move-result v23

    .line 482
    move/from16 v14, v23

    .line 483
    .line 484
    goto :goto_1e5

    .line 485
    :cond_1e4
    const/4 v14, -0x1

    .line 486
    :goto_1e5
    iget-object v11, v9, Li73;->l:Landroid/graphics/Paint$Cap;

    .line 487
    .line 488
    if-eqz v14, :cond_1fa

    .line 489
    .line 490
    move-object/from16 v27, v11

    .line 491
    .line 492
    const/4 v11, 0x1

    .line 493
    if-eq v14, v11, :cond_1f7

    .line 494
    .line 495
    const/4 v11, 0x2

    .line 496
    if-eq v14, v11, :cond_1f4

    .line 497
    .line 498
    move-object/from16 v14, v27

    .line 499
    .line 500
    goto :goto_1fc

    .line 501
    :cond_1f4
    sget-object v14, Landroid/graphics/Paint$Cap;->SQUARE:Landroid/graphics/Paint$Cap;

    .line 502
    .line 503
    goto :goto_1fc

    .line 504
    :cond_1f7
    sget-object v14, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    .line 505
    .line 506
    goto :goto_1fc

    .line 507
    :cond_1fa
    move-object/from16 v14, v26

    .line 508
    .line 509
    :goto_1fc
    iput-object v14, v9, Li73;->l:Landroid/graphics/Paint$Cap;

    .line 510
    .line 511
    const-string v11, "strokeLineJoin"

    .line 512
    .line 513
    invoke-interface {v3, v12, v11}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 514
    .line 515
    .line 516
    move-result-object v11

    .line 517
    if-eqz v11, :cond_210

    .line 518
    .line 519
    const/4 v11, -0x1

    .line 520
    const/16 v14, 0x9

    .line 521
    .line 522
    invoke-virtual {v13, v14, v11}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 523
    .line 524
    .line 525
    move-result v18

    .line 526
    move/from16 v11, v18

    .line 527
    .line 528
    goto :goto_211

    .line 529
    :cond_210
    const/4 v11, -0x1

    .line 530
    :goto_211
    iget-object v14, v9, Li73;->m:Landroid/graphics/Paint$Join;

    .line 531
    .line 532
    if-eqz v11, :cond_226

    .line 533
    .line 534
    move-object/from16 v26, v14

    .line 535
    .line 536
    const/4 v14, 0x1

    .line 537
    if-eq v11, v14, :cond_223

    .line 538
    .line 539
    const/4 v14, 0x2

    .line 540
    if-eq v11, v14, :cond_220

    .line 541
    .line 542
    move-object/from16 v11, v26

    .line 543
    .line 544
    goto :goto_228

    .line 545
    :cond_220
    sget-object v11, Landroid/graphics/Paint$Join;->BEVEL:Landroid/graphics/Paint$Join;

    .line 546
    .line 547
    goto :goto_228

    .line 548
    :cond_223
    sget-object v11, Landroid/graphics/Paint$Join;->ROUND:Landroid/graphics/Paint$Join;

    .line 549
    .line 550
    goto :goto_228

    .line 551
    :cond_226
    move-object/from16 v11, v21

    .line 552
    .line 553
    :goto_228
    iput-object v11, v9, Li73;->m:Landroid/graphics/Paint$Join;

    .line 554
    .line 555
    iget v11, v9, Li73;->n:F

    .line 556
    .line 557
    const-string v14, "strokeMiterLimit"

    .line 558
    .line 559
    invoke-interface {v3, v12, v14}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 560
    .line 561
    .line 562
    move-result-object v14

    .line 563
    if-eqz v14, :cond_23a

    .line 564
    .line 565
    const/16 v14, 0xa

    .line 566
    .line 567
    invoke-virtual {v13, v14, v11}, Landroid/content/res/TypedArray;->getFloat(IF)F

    .line 568
    .line 569
    .line 570
    move-result v11

    .line 571
    :cond_23a
    iput v11, v9, Li73;->n:F

    .line 572
    .line 573
    const-string v11, "strokeColor"

    .line 574
    .line 575
    const/4 v14, 0x3

    .line 576
    invoke-static {v13, v3, v5, v11, v14}, Lq33;->p(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Landroid/content/res/Resources$Theme;Ljava/lang/String;I)Le9;

    .line 577
    .line 578
    .line 579
    move-result-object v11

    .line 580
    iput-object v11, v9, Li73;->d:Le9;

    .line 581
    .line 582
    iget v11, v9, Li73;->g:F

    .line 583
    .line 584
    const-string v14, "strokeAlpha"

    .line 585
    .line 586
    invoke-interface {v3, v12, v14}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 587
    .line 588
    .line 589
    move-result-object v14

    .line 590
    if-eqz v14, :cond_255

    .line 591
    .line 592
    const/16 v14, 0xb

    .line 593
    .line 594
    invoke-virtual {v13, v14, v11}, Landroid/content/res/TypedArray;->getFloat(IF)F

    .line 595
    .line 596
    .line 597
    move-result v11

    .line 598
    :cond_255
    iput v11, v9, Li73;->g:F

    .line 599
    .line 600
    iget v11, v9, Li73;->e:F

    .line 601
    .line 602
    const-string v14, "strokeWidth"

    .line 603
    .line 604
    invoke-interface {v3, v12, v14}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 605
    .line 606
    .line 607
    move-result-object v14

    .line 608
    if-eqz v14, :cond_266

    .line 609
    .line 610
    const/4 v14, 0x4

    .line 611
    invoke-virtual {v13, v14, v11}, Landroid/content/res/TypedArray;->getFloat(IF)F

    .line 612
    .line 613
    .line 614
    move-result v11

    .line 615
    :cond_266
    iput v11, v9, Li73;->e:F

    .line 616
    .line 617
    iget v11, v9, Li73;->j:F

    .line 618
    .line 619
    const-string v14, "trimPathEnd"

    .line 620
    .line 621
    invoke-interface {v3, v12, v14}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 622
    .line 623
    .line 624
    move-result-object v14

    .line 625
    if-eqz v14, :cond_277

    .line 626
    .line 627
    const/4 v14, 0x6

    .line 628
    invoke-virtual {v13, v14, v11}, Landroid/content/res/TypedArray;->getFloat(IF)F

    .line 629
    .line 630
    .line 631
    move-result v11

    .line 632
    :cond_277
    iput v11, v9, Li73;->j:F

    .line 633
    .line 634
    iget v11, v9, Li73;->k:F

    .line 635
    .line 636
    const-string v14, "trimPathOffset"

    .line 637
    .line 638
    invoke-interface {v3, v12, v14}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 639
    .line 640
    .line 641
    move-result-object v14

    .line 642
    if-eqz v14, :cond_288

    .line 643
    .line 644
    const/4 v14, 0x7

    .line 645
    invoke-virtual {v13, v14, v11}, Landroid/content/res/TypedArray;->getFloat(IF)F

    .line 646
    .line 647
    .line 648
    move-result v11

    .line 649
    :cond_288
    iput v11, v9, Li73;->k:F

    .line 650
    .line 651
    iget v11, v9, Li73;->i:F

    .line 652
    .line 653
    const-string v14, "trimPathStart"

    .line 654
    .line 655
    invoke-interface {v3, v12, v14}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 656
    .line 657
    .line 658
    move-result-object v14

    .line 659
    if-eqz v14, :cond_299

    .line 660
    .line 661
    const/4 v14, 0x5

    .line 662
    invoke-virtual {v13, v14, v11}, Landroid/content/res/TypedArray;->getFloat(IF)F

    .line 663
    .line 664
    .line 665
    move-result v11

    .line 666
    :cond_299
    iput v11, v9, Li73;->i:F

    .line 667
    .line 668
    iget v11, v9, Ll73;->c:I

    .line 669
    .line 670
    invoke-interface {v3, v12, v15}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 671
    .line 672
    .line 673
    move-result-object v14

    .line 674
    if-eqz v14, :cond_2a9

    .line 675
    .line 676
    const/16 v14, 0xd

    .line 677
    .line 678
    invoke-virtual {v13, v14, v11}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 679
    .line 680
    .line 681
    move-result v11

    .line 682
    :cond_2a9
    iput v11, v9, Ll73;->c:I

    .line 683
    .line 684
    :cond_2ab
    invoke-virtual {v13}, Landroid/content/res/TypedArray;->recycle()V

    .line 685
    .line 686
    .line 687
    iget-object v10, v10, Lj73;->b:Ljava/util/ArrayList;

    .line 688
    .line 689
    invoke-virtual {v10, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 690
    .line 691
    .line 692
    invoke-virtual {v9}, Ll73;->getPathName()Ljava/lang/String;

    .line 693
    .line 694
    .line 695
    move-result-object v10

    .line 696
    if-eqz v10, :cond_2c0

    .line 697
    .line 698
    invoke-virtual {v9}, Ll73;->getPathName()Ljava/lang/String;

    .line 699
    .line 700
    .line 701
    move-result-object v10

    .line 702
    invoke-virtual {v7, v10, v9}, Lco2;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 703
    .line 704
    .line 705
    :cond_2c0
    iget v9, v0, Ln73;->a:I

    .line 706
    .line 707
    iput v9, v0, Ln73;->a:I

    .line 708
    .line 709
    const/4 v13, 0x0

    .line 710
    const/4 v15, 0x2

    .line 711
    const/16 v18, 0x9

    .line 712
    .line 713
    const/16 v19, -0x1

    .line 714
    .line 715
    const/16 v21, 0x0

    .line 716
    .line 717
    const/16 v23, 0x8

    .line 718
    .line 719
    goto/16 :goto_3da

    .line 720
    .line 721
    :cond_2d0
    const/16 v18, 0x9

    .line 722
    .line 723
    const/16 v19, -0x1

    .line 724
    .line 725
    const/16 v23, 0x8

    .line 726
    .line 727
    const-string v13, "clip-path"

    .line 728
    .line 729
    invoke-virtual {v13, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 730
    .line 731
    .line 732
    move-result v13

    .line 733
    if-eqz v13, :cond_332

    .line 734
    .line 735
    new-instance v9, Lh73;

    .line 736
    .line 737
    invoke-direct {v9}, Ll73;-><init>()V

    .line 738
    .line 739
    .line 740
    invoke-interface {v3, v12, v11}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 741
    .line 742
    .line 743
    move-result-object v11

    .line 744
    if-eqz v11, :cond_318

    .line 745
    .line 746
    sget-object v11, Lc10;->d:[I

    .line 747
    .line 748
    invoke-static {v2, v5, v4, v11}, Lq33;->C(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    .line 749
    .line 750
    .line 751
    move-result-object v11

    .line 752
    const/4 v13, 0x0

    .line 753
    invoke-virtual {v11, v13}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    .line 754
    .line 755
    .line 756
    move-result-object v14

    .line 757
    if-eqz v14, :cond_2f8

    .line 758
    .line 759
    iput-object v14, v9, Ll73;->b:Ljava/lang/String;

    .line 760
    .line 761
    :cond_2f8
    const/4 v14, 0x1

    .line 762
    invoke-virtual {v11, v14}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    .line 763
    .line 764
    .line 765
    move-result-object v13

    .line 766
    if-eqz v13, :cond_305

    .line 767
    .line 768
    invoke-static {v13}, Lkw0;->g(Ljava/lang/String;)[Ln12;

    .line 769
    .line 770
    .line 771
    move-result-object v13

    .line 772
    iput-object v13, v9, Ll73;->a:[Ln12;

    .line 773
    .line 774
    :cond_305
    invoke-static {v3, v15}, Lq33;->u(Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;)Z

    .line 775
    .line 776
    .line 777
    move-result v13

    .line 778
    if-nez v13, :cond_30d

    .line 779
    .line 780
    const/4 v15, 0x0

    .line 781
    goto :goto_313

    .line 782
    :cond_30d
    const/4 v13, 0x0

    .line 783
    const/4 v14, 0x2

    .line 784
    invoke-virtual {v11, v14, v13}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 785
    .line 786
    .line 787
    move-result v15

    .line 788
    :goto_313
    iput v15, v9, Ll73;->c:I

    .line 789
    .line 790
    invoke-virtual {v11}, Landroid/content/res/TypedArray;->recycle()V

    .line 791
    .line 792
    .line 793
    :cond_318
    iget-object v10, v10, Lj73;->b:Ljava/util/ArrayList;

    .line 794
    .line 795
    invoke-virtual {v10, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 796
    .line 797
    .line 798
    invoke-virtual {v9}, Ll73;->getPathName()Ljava/lang/String;

    .line 799
    .line 800
    .line 801
    move-result-object v10

    .line 802
    if-eqz v10, :cond_32a

    .line 803
    .line 804
    invoke-virtual {v9}, Ll73;->getPathName()Ljava/lang/String;

    .line 805
    .line 806
    .line 807
    move-result-object v10

    .line 808
    invoke-virtual {v7, v10, v9}, Lco2;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 809
    .line 810
    .line 811
    :cond_32a
    iget v9, v0, Ln73;->a:I

    .line 812
    .line 813
    iput v9, v0, Ln73;->a:I

    .line 814
    .line 815
    :cond_32e
    const/4 v13, 0x0

    .line 816
    const/4 v15, 0x2

    .line 817
    goto/16 :goto_3da

    .line 818
    .line 819
    :cond_332
    invoke-virtual {v14, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 820
    .line 821
    .line 822
    move-result v9

    .line 823
    if-eqz v9, :cond_32e

    .line 824
    .line 825
    new-instance v9, Lj73;

    .line 826
    .line 827
    invoke-direct {v9}, Lj73;-><init>()V

    .line 828
    .line 829
    .line 830
    sget-object v11, Lc10;->b:[I

    .line 831
    .line 832
    invoke-static {v2, v5, v4, v11}, Lq33;->C(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    .line 833
    .line 834
    .line 835
    move-result-object v11

    .line 836
    iget v13, v9, Lj73;->c:F

    .line 837
    .line 838
    const-string v14, "rotation"

    .line 839
    .line 840
    invoke-interface {v3, v12, v14}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 841
    .line 842
    .line 843
    move-result-object v14

    .line 844
    if-eqz v14, :cond_353

    .line 845
    .line 846
    const/4 v15, 0x5

    .line 847
    invoke-virtual {v11, v15, v13}, Landroid/content/res/TypedArray;->getFloat(IF)F

    .line 848
    .line 849
    .line 850
    move-result v13

    .line 851
    goto :goto_354

    .line 852
    :cond_353
    const/4 v15, 0x5

    .line 853
    :goto_354
    iput v13, v9, Lj73;->c:F

    .line 854
    .line 855
    iget v13, v9, Lj73;->d:F

    .line 856
    .line 857
    const/4 v14, 0x1

    .line 858
    invoke-virtual {v11, v14, v13}, Landroid/content/res/TypedArray;->getFloat(IF)F

    .line 859
    .line 860
    .line 861
    move-result v13

    .line 862
    iput v13, v9, Lj73;->d:F

    .line 863
    .line 864
    iget v13, v9, Lj73;->e:F

    .line 865
    .line 866
    const/4 v15, 0x2

    .line 867
    invoke-virtual {v11, v15, v13}, Landroid/content/res/TypedArray;->getFloat(IF)F

    .line 868
    .line 869
    .line 870
    move-result v13

    .line 871
    iput v13, v9, Lj73;->e:F

    .line 872
    .line 873
    iget v13, v9, Lj73;->f:F

    .line 874
    .line 875
    const-string v14, "scaleX"

    .line 876
    .line 877
    invoke-interface {v3, v12, v14}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 878
    .line 879
    .line 880
    move-result-object v14

    .line 881
    if-eqz v14, :cond_377

    .line 882
    .line 883
    const/4 v14, 0x3

    .line 884
    invoke-virtual {v11, v14, v13}, Landroid/content/res/TypedArray;->getFloat(IF)F

    .line 885
    .line 886
    .line 887
    move-result v13

    .line 888
    :cond_377
    iput v13, v9, Lj73;->f:F

    .line 889
    .line 890
    iget v13, v9, Lj73;->g:F

    .line 891
    .line 892
    const-string v14, "scaleY"

    .line 893
    .line 894
    invoke-interface {v3, v12, v14}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 895
    .line 896
    .line 897
    move-result-object v14

    .line 898
    if-eqz v14, :cond_389

    .line 899
    .line 900
    const/4 v14, 0x4

    .line 901
    invoke-virtual {v11, v14, v13}, Landroid/content/res/TypedArray;->getFloat(IF)F

    .line 902
    .line 903
    .line 904
    move-result v13

    .line 905
    goto :goto_38a

    .line 906
    :cond_389
    const/4 v14, 0x4

    .line 907
    :goto_38a
    iput v13, v9, Lj73;->g:F

    .line 908
    .line 909
    iget v13, v9, Lj73;->h:F

    .line 910
    .line 911
    const-string v14, "translateX"

    .line 912
    .line 913
    invoke-interface {v3, v12, v14}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 914
    .line 915
    .line 916
    move-result-object v14

    .line 917
    if-eqz v14, :cond_39c

    .line 918
    .line 919
    const/4 v14, 0x6

    .line 920
    invoke-virtual {v11, v14, v13}, Landroid/content/res/TypedArray;->getFloat(IF)F

    .line 921
    .line 922
    .line 923
    move-result v13

    .line 924
    goto :goto_39d

    .line 925
    :cond_39c
    const/4 v14, 0x6

    .line 926
    :goto_39d
    iput v13, v9, Lj73;->h:F

    .line 927
    .line 928
    iget v13, v9, Lj73;->i:F

    .line 929
    .line 930
    const-string v14, "translateY"

    .line 931
    .line 932
    invoke-interface {v3, v12, v14}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 933
    .line 934
    .line 935
    move-result-object v14

    .line 936
    if-eqz v14, :cond_3af

    .line 937
    .line 938
    const/4 v14, 0x7

    .line 939
    invoke-virtual {v11, v14, v13}, Landroid/content/res/TypedArray;->getFloat(IF)F

    .line 940
    .line 941
    .line 942
    move-result v13

    .line 943
    goto :goto_3b0

    .line 944
    :cond_3af
    const/4 v14, 0x7

    .line 945
    :goto_3b0
    iput v13, v9, Lj73;->i:F

    .line 946
    .line 947
    const/4 v13, 0x0

    .line 948
    invoke-virtual {v11, v13}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    .line 949
    .line 950
    .line 951
    move-result-object v14

    .line 952
    if-eqz v14, :cond_3bb

    .line 953
    .line 954
    iput-object v14, v9, Lj73;->k:Ljava/lang/String;

    .line 955
    .line 956
    :cond_3bb
    invoke-virtual {v9}, Lj73;->c()V

    .line 957
    .line 958
    .line 959
    invoke-virtual {v11}, Landroid/content/res/TypedArray;->recycle()V

    .line 960
    .line 961
    .line 962
    iget-object v10, v10, Lj73;->b:Ljava/util/ArrayList;

    .line 963
    .line 964
    invoke-virtual {v10, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 965
    .line 966
    .line 967
    invoke-virtual {v8, v9}, Ljava/util/ArrayDeque;->push(Ljava/lang/Object;)V

    .line 968
    .line 969
    .line 970
    invoke-virtual {v9}, Lj73;->getGroupName()Ljava/lang/String;

    .line 971
    .line 972
    .line 973
    move-result-object v10

    .line 974
    if-eqz v10, :cond_3d6

    .line 975
    .line 976
    invoke-virtual {v9}, Lj73;->getGroupName()Ljava/lang/String;

    .line 977
    .line 978
    .line 979
    move-result-object v10

    .line 980
    invoke-virtual {v7, v10, v9}, Lco2;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 981
    .line 982
    .line 983
    :cond_3d6
    iget v9, v0, Ln73;->a:I

    .line 984
    .line 985
    iput v9, v0, Ln73;->a:I

    .line 986
    .line 987
    :goto_3da
    const/4 v10, 0x3

    .line 988
    const/16 v17, 0x6

    .line 989
    .line 990
    const/16 v20, 0x7

    .line 991
    .line 992
    const/16 v22, 0x4

    .line 993
    .line 994
    const/16 v24, 0x1

    .line 995
    .line 996
    goto :goto_405

    .line 997
    :cond_3e4
    move v15, v10

    .line 998
    move/from16 v25, v11

    .line 999
    .line 1000
    const/4 v10, 0x3

    .line 1001
    const/16 v17, 0x6

    .line 1002
    .line 1003
    const/16 v18, 0x9

    .line 1004
    .line 1005
    const/16 v19, -0x1

    .line 1006
    .line 1007
    const/16 v20, 0x7

    .line 1008
    .line 1009
    const/16 v22, 0x4

    .line 1010
    .line 1011
    const/16 v23, 0x8

    .line 1012
    .line 1013
    const/16 v24, 0x1

    .line 1014
    .line 1015
    if-ne v9, v10, :cond_405

    .line 1016
    .line 1017
    invoke-interface {v3}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    .line 1018
    .line 1019
    .line 1020
    move-result-object v9

    .line 1021
    invoke-virtual {v14, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1022
    .line 1023
    .line 1024
    move-result v9

    .line 1025
    if-eqz v9, :cond_405

    .line 1026
    .line 1027
    invoke-virtual {v8}, Ljava/util/ArrayDeque;->pop()Ljava/lang/Object;

    .line 1028
    .line 1029
    .line 1030
    :cond_405
    :goto_405
    invoke-interface {v3}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    .line 1031
    .line 1032
    .line 1033
    move-result v9

    .line 1034
    move/from16 v14, v23

    .line 1035
    .line 1036
    move/from16 v10, v24

    .line 1037
    .line 1038
    move/from16 v11, v25

    .line 1039
    .line 1040
    const/4 v15, 0x0

    .line 1041
    goto/16 :goto_149

    .line 1042
    .line 1043
    :cond_412
    if-nez v21, :cond_41f

    .line 1044
    .line 1045
    iget-object v0, v6, Ln73;->c:Landroid/content/res/ColorStateList;

    .line 1046
    .line 1047
    iget-object v2, v6, Ln73;->d:Landroid/graphics/PorterDuff$Mode;

    .line 1048
    .line 1049
    invoke-virtual {v1, v0, v2}, Lp73;->a(Landroid/content/res/ColorStateList;Landroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;

    .line 1050
    .line 1051
    .line 1052
    move-result-object v0

    .line 1053
    iput-object v0, v1, Lp73;->c:Landroid/graphics/PorterDuffColorFilter;

    .line 1054
    .line 1055
    return-void

    .line 1056
    :cond_41f
    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    .line 1057
    .line 1058
    const-string v1, "no path defined"

    .line 1059
    .line 1060
    invoke-direct {v0, v1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    .line 1061
    .line 1062
    .line 1063
    throw v0

    .line 1064
    :cond_427
    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    .line 1065
    .line 1066
    invoke-virtual {v7}, Landroid/content/res/TypedArray;->getPositionDescription()Ljava/lang/String;

    .line 1067
    .line 1068
    .line 1069
    move-result-object v1

    .line 1070
    new-instance v2, Ljava/lang/StringBuilder;

    .line 1071
    .line 1072
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 1073
    .line 1074
    .line 1075
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1076
    .line 1077
    .line 1078
    const-string v1, "<vector> tag requires height > 0"

    .line 1079
    .line 1080
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1081
    .line 1082
    .line 1083
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1084
    .line 1085
    .line 1086
    move-result-object v1

    .line 1087
    invoke-direct {v0, v1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    .line 1088
    .line 1089
    .line 1090
    throw v0

    .line 1091
    :cond_442
    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    .line 1092
    .line 1093
    invoke-virtual {v7}, Landroid/content/res/TypedArray;->getPositionDescription()Ljava/lang/String;

    .line 1094
    .line 1095
    .line 1096
    move-result-object v1

    .line 1097
    new-instance v2, Ljava/lang/StringBuilder;

    .line 1098
    .line 1099
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 1100
    .line 1101
    .line 1102
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1103
    .line 1104
    .line 1105
    const-string v1, "<vector> tag requires width > 0"

    .line 1106
    .line 1107
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1108
    .line 1109
    .line 1110
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1111
    .line 1112
    .line 1113
    move-result-object v1

    .line 1114
    invoke-direct {v0, v1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    .line 1115
    .line 1116
    .line 1117
    throw v0

    .line 1118
    :cond_45d
    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    .line 1119
    .line 1120
    invoke-virtual {v7}, Landroid/content/res/TypedArray;->getPositionDescription()Ljava/lang/String;

    .line 1121
    .line 1122
    .line 1123
    move-result-object v1

    .line 1124
    new-instance v2, Ljava/lang/StringBuilder;

    .line 1125
    .line 1126
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 1127
    .line 1128
    .line 1129
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1130
    .line 1131
    .line 1132
    const-string v1, "<vector> tag requires viewportHeight > 0"

    .line 1133
    .line 1134
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1135
    .line 1136
    .line 1137
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1138
    .line 1139
    .line 1140
    move-result-object v1

    .line 1141
    invoke-direct {v0, v1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    .line 1142
    .line 1143
    .line 1144
    throw v0

    .line 1145
    :cond_478
    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    .line 1146
    .line 1147
    invoke-virtual {v7}, Landroid/content/res/TypedArray;->getPositionDescription()Ljava/lang/String;

    .line 1148
    .line 1149
    .line 1150
    move-result-object v1

    .line 1151
    new-instance v2, Ljava/lang/StringBuilder;

    .line 1152
    .line 1153
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 1154
    .line 1155
    .line 1156
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1157
    .line 1158
    .line 1159
    const-string v1, "<vector> tag requires viewportWidth > 0"

    .line 1160
    .line 1161
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1162
    .line 1163
    .line 1164
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1165
    .line 1166
    .line 1167
    move-result-object v1

    .line 1168
    invoke-direct {v0, v1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    .line 1169
    .line 1170
    .line 1171
    throw v0

    .line 1172
    nop

    .line 1173
    :pswitch_data_494
    .packed-switch 0xe
        :pswitch_4b
        :pswitch_48
        :pswitch_45
    .end packed-switch
.end method

.method public final invalidateSelf()V
    .registers 2

    .line 1
    iget-object v0, p0, Lg73;->a:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    if-eqz v0, :cond_8

    .line 4
    .line 5
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 6
    .line 7
    .line 8
    return-void

    .line 9
    :cond_8
    invoke-super {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public final isAutoMirrored()Z
    .registers 2

    .line 1
    iget-object v0, p0, Lg73;->a:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    if-eqz v0, :cond_9

    .line 4
    .line 5
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->isAutoMirrored()Z

    .line 6
    .line 7
    .line 8
    move-result p0

    .line 9
    return p0

    .line 10
    :cond_9
    iget-object p0, p0, Lp73;->b:Ln73;

    .line 11
    .line 12
    iget-boolean p0, p0, Ln73;->e:Z

    .line 13
    .line 14
    return p0
.end method

.method public final isStateful()Z
    .registers 3

    .line 1
    iget-object v0, p0, Lg73;->a:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    if-eqz v0, :cond_9

    .line 4
    .line 5
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->isStateful()Z

    .line 6
    .line 7
    .line 8
    move-result p0

    .line 9
    return p0

    .line 10
    :cond_9
    invoke-super {p0}, Landroid/graphics/drawable/Drawable;->isStateful()Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-nez v0, :cond_3a

    .line 15
    .line 16
    iget-object v0, p0, Lp73;->b:Ln73;

    .line 17
    .line 18
    if-eqz v0, :cond_38

    .line 19
    .line 20
    iget-object v0, v0, Ln73;->b:Lm73;

    .line 21
    .line 22
    iget-object v1, v0, Lm73;->n:Ljava/lang/Boolean;

    .line 23
    .line 24
    if-nez v1, :cond_25

    .line 25
    .line 26
    iget-object v1, v0, Lm73;->g:Lj73;

    .line 27
    .line 28
    invoke-virtual {v1}, Lj73;->a()Z

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    iput-object v1, v0, Lm73;->n:Ljava/lang/Boolean;

    .line 37
    .line 38
    :cond_25
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    if-nez v0, :cond_3a

    .line 43
    .line 44
    iget-object p0, p0, Lp73;->b:Ln73;

    .line 45
    .line 46
    iget-object p0, p0, Ln73;->c:Landroid/content/res/ColorStateList;

    .line 47
    .line 48
    if-eqz p0, :cond_38

    .line 49
    .line 50
    invoke-virtual {p0}, Landroid/content/res/ColorStateList;->isStateful()Z

    .line 51
    .line 52
    .line 53
    move-result p0

    .line 54
    if-eqz p0, :cond_38

    .line 55
    .line 56
    goto :goto_3a

    .line 57
    :cond_38
    const/4 p0, 0x0

    .line 58
    return p0

    .line 59
    :cond_3a
    :goto_3a
    const/4 p0, 0x1

    .line 60
    return p0
.end method

.method public final mutate()Landroid/graphics/drawable/Drawable;
    .registers 6

    .line 1
    iget-object v0, p0, Lg73;->a:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    if-eqz v0, :cond_8

    .line 4
    .line 5
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    .line 6
    .line 7
    .line 8
    return-object p0

    .line 9
    :cond_8
    iget-boolean v0, p0, Lp73;->e:Z

    .line 10
    .line 11
    if-nez v0, :cond_64

    .line 12
    .line 13
    invoke-super {p0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    if-ne v0, p0, :cond_64

    .line 18
    .line 19
    new-instance v0, Ln73;

    .line 20
    .line 21
    iget-object v1, p0, Lp73;->b:Ln73;

    .line 22
    .line 23
    invoke-direct {v0}, Landroid/graphics/drawable/Drawable$ConstantState;-><init>()V

    .line 24
    .line 25
    .line 26
    const/4 v2, 0x0

    .line 27
    iput-object v2, v0, Ln73;->c:Landroid/content/res/ColorStateList;

    .line 28
    .line 29
    sget-object v2, Lp73;->m:Landroid/graphics/PorterDuff$Mode;

    .line 30
    .line 31
    iput-object v2, v0, Ln73;->d:Landroid/graphics/PorterDuff$Mode;

    .line 32
    .line 33
    if-eqz v1, :cond_5f

    .line 34
    .line 35
    iget v2, v1, Ln73;->a:I

    .line 36
    .line 37
    iput v2, v0, Ln73;->a:I

    .line 38
    .line 39
    new-instance v2, Lm73;

    .line 40
    .line 41
    iget-object v3, v1, Ln73;->b:Lm73;

    .line 42
    .line 43
    invoke-direct {v2, v3}, Lm73;-><init>(Lm73;)V

    .line 44
    .line 45
    .line 46
    iput-object v2, v0, Ln73;->b:Lm73;

    .line 47
    .line 48
    iget-object v3, v1, Ln73;->b:Lm73;

    .line 49
    .line 50
    iget-object v3, v3, Lm73;->e:Landroid/graphics/Paint;

    .line 51
    .line 52
    if-eqz v3, :cond_40

    .line 53
    .line 54
    new-instance v3, Landroid/graphics/Paint;

    .line 55
    .line 56
    iget-object v4, v1, Ln73;->b:Lm73;

    .line 57
    .line 58
    iget-object v4, v4, Lm73;->e:Landroid/graphics/Paint;

    .line 59
    .line 60
    invoke-direct {v3, v4}, Landroid/graphics/Paint;-><init>(Landroid/graphics/Paint;)V

    .line 61
    .line 62
    .line 63
    iput-object v3, v2, Lm73;->e:Landroid/graphics/Paint;

    .line 64
    .line 65
    :cond_40
    iget-object v2, v1, Ln73;->b:Lm73;

    .line 66
    .line 67
    iget-object v2, v2, Lm73;->d:Landroid/graphics/Paint;

    .line 68
    .line 69
    if-eqz v2, :cond_53

    .line 70
    .line 71
    iget-object v2, v0, Ln73;->b:Lm73;

    .line 72
    .line 73
    new-instance v3, Landroid/graphics/Paint;

    .line 74
    .line 75
    iget-object v4, v1, Ln73;->b:Lm73;

    .line 76
    .line 77
    iget-object v4, v4, Lm73;->d:Landroid/graphics/Paint;

    .line 78
    .line 79
    invoke-direct {v3, v4}, Landroid/graphics/Paint;-><init>(Landroid/graphics/Paint;)V

    .line 80
    .line 81
    .line 82
    iput-object v3, v2, Lm73;->d:Landroid/graphics/Paint;

    .line 83
    .line 84
    :cond_53
    iget-object v2, v1, Ln73;->c:Landroid/content/res/ColorStateList;

    .line 85
    .line 86
    iput-object v2, v0, Ln73;->c:Landroid/content/res/ColorStateList;

    .line 87
    .line 88
    iget-object v2, v1, Ln73;->d:Landroid/graphics/PorterDuff$Mode;

    .line 89
    .line 90
    iput-object v2, v0, Ln73;->d:Landroid/graphics/PorterDuff$Mode;

    .line 91
    .line 92
    iget-boolean v1, v1, Ln73;->e:Z

    .line 93
    .line 94
    iput-boolean v1, v0, Ln73;->e:Z

    .line 95
    .line 96
    :cond_5f
    iput-object v0, p0, Lp73;->b:Ln73;

    .line 97
    .line 98
    const/4 v0, 0x1

    .line 99
    iput-boolean v0, p0, Lp73;->e:Z

    .line 100
    .line 101
    :cond_64
    return-object p0
.end method

.method public final onBoundsChange(Landroid/graphics/Rect;)V
    .registers 2

    .line 1
    iget-object p0, p0, Lg73;->a:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    if-eqz p0, :cond_7

    .line 4
    .line 5
    invoke-virtual {p0, p1}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    .line 6
    .line 7
    .line 8
    :cond_7
    return-void
.end method

.method public final onStateChange([I)Z
    .registers 7

    .line 1
    iget-object v0, p0, Lg73;->a:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    if-eqz v0, :cond_9

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    .line 6
    .line 7
    .line 8
    move-result p0

    .line 9
    return p0

    .line 10
    :cond_9
    iget-object v0, p0, Lp73;->b:Ln73;

    .line 11
    .line 12
    iget-object v1, v0, Ln73;->c:Landroid/content/res/ColorStateList;

    .line 13
    .line 14
    const/4 v2, 0x1

    .line 15
    if-eqz v1, :cond_1f

    .line 16
    .line 17
    iget-object v3, v0, Ln73;->d:Landroid/graphics/PorterDuff$Mode;

    .line 18
    .line 19
    if-eqz v3, :cond_1f

    .line 20
    .line 21
    invoke-virtual {p0, v1, v3}, Lp73;->a(Landroid/content/res/ColorStateList;Landroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    iput-object v1, p0, Lp73;->c:Landroid/graphics/PorterDuffColorFilter;

    .line 26
    .line 27
    invoke-virtual {p0}, Lp73;->invalidateSelf()V

    .line 28
    .line 29
    .line 30
    move v1, v2

    .line 31
    goto :goto_20

    .line 32
    :cond_1f
    const/4 v1, 0x0

    .line 33
    :goto_20
    iget-object v3, v0, Ln73;->b:Lm73;

    .line 34
    .line 35
    iget-object v4, v3, Lm73;->n:Ljava/lang/Boolean;

    .line 36
    .line 37
    if-nez v4, :cond_32

    .line 38
    .line 39
    iget-object v4, v3, Lm73;->g:Lj73;

    .line 40
    .line 41
    invoke-virtual {v4}, Lj73;->a()Z

    .line 42
    .line 43
    .line 44
    move-result v4

    .line 45
    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 46
    .line 47
    .line 48
    move-result-object v4

    .line 49
    iput-object v4, v3, Lm73;->n:Ljava/lang/Boolean;

    .line 50
    .line 51
    :cond_32
    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    .line 52
    .line 53
    .line 54
    move-result v3

    .line 55
    if-eqz v3, :cond_4b

    .line 56
    .line 57
    iget-object v3, v0, Ln73;->b:Lm73;

    .line 58
    .line 59
    iget-object v3, v3, Lm73;->g:Lj73;

    .line 60
    .line 61
    invoke-virtual {v3, p1}, Lj73;->b([I)Z

    .line 62
    .line 63
    .line 64
    move-result p1

    .line 65
    iget-boolean v3, v0, Ln73;->k:Z

    .line 66
    .line 67
    or-int/2addr v3, p1

    .line 68
    iput-boolean v3, v0, Ln73;->k:Z

    .line 69
    .line 70
    if-eqz p1, :cond_4b

    .line 71
    .line 72
    invoke-virtual {p0}, Lp73;->invalidateSelf()V

    .line 73
    .line 74
    .line 75
    return v2

    .line 76
    :cond_4b
    return v1
.end method

.method public final scheduleSelf(Ljava/lang/Runnable;J)V
    .registers 5

    .line 1
    iget-object v0, p0, Lg73;->a:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    if-eqz v0, :cond_8

    .line 4
    .line 5
    invoke-virtual {v0, p1, p2, p3}, Landroid/graphics/drawable/Drawable;->scheduleSelf(Ljava/lang/Runnable;J)V

    .line 6
    .line 7
    .line 8
    return-void

    .line 9
    :cond_8
    invoke-super {p0, p1, p2, p3}, Landroid/graphics/drawable/Drawable;->scheduleSelf(Ljava/lang/Runnable;J)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public final setAlpha(I)V
    .registers 3

    .line 1
    iget-object v0, p0, Lg73;->a:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    if-eqz v0, :cond_8

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    .line 6
    .line 7
    .line 8
    return-void

    .line 9
    :cond_8
    iget-object v0, p0, Lp73;->b:Ln73;

    .line 10
    .line 11
    iget-object v0, v0, Ln73;->b:Lm73;

    .line 12
    .line 13
    invoke-virtual {v0}, Lm73;->getRootAlpha()I

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eq v0, p1, :cond_1c

    .line 18
    .line 19
    iget-object v0, p0, Lp73;->b:Ln73;

    .line 20
    .line 21
    iget-object v0, v0, Ln73;->b:Lm73;

    .line 22
    .line 23
    invoke-virtual {v0, p1}, Lm73;->setRootAlpha(I)V

    .line 24
    .line 25
    .line 26
    invoke-virtual {p0}, Lp73;->invalidateSelf()V

    .line 27
    .line 28
    .line 29
    :cond_1c
    return-void
.end method

.method public final setAutoMirrored(Z)V
    .registers 3

    .line 1
    iget-object v0, p0, Lg73;->a:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    if-eqz v0, :cond_8

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setAutoMirrored(Z)V

    .line 6
    .line 7
    .line 8
    return-void

    .line 9
    :cond_8
    iget-object p0, p0, Lp73;->b:Ln73;

    .line 10
    .line 11
    iput-boolean p1, p0, Ln73;->e:Z

    .line 12
    .line 13
    return-void
.end method

.method public final setColorFilter(Landroid/graphics/ColorFilter;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lg73;->a:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    if-eqz v0, :cond_8

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setColorFilter(Landroid/graphics/ColorFilter;)V

    .line 6
    .line 7
    .line 8
    return-void

    .line 9
    :cond_8
    iput-object p1, p0, Lp73;->d:Landroid/graphics/ColorFilter;

    .line 10
    .line 11
    invoke-virtual {p0}, Lp73;->invalidateSelf()V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public final setTint(I)V
    .registers 3

    .line 1
    iget-object v0, p0, Lg73;->a:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    if-eqz v0, :cond_8

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setTint(I)V

    .line 6
    .line 7
    .line 8
    return-void

    .line 9
    :cond_8
    invoke-static {p1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    invoke-virtual {p0, p1}, Lp73;->setTintList(Landroid/content/res/ColorStateList;)V

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public final setTintList(Landroid/content/res/ColorStateList;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lg73;->a:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    if-eqz v0, :cond_8

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setTintList(Landroid/content/res/ColorStateList;)V

    .line 6
    .line 7
    .line 8
    return-void

    .line 9
    :cond_8
    iget-object v0, p0, Lp73;->b:Ln73;

    .line 10
    .line 11
    iget-object v1, v0, Ln73;->c:Landroid/content/res/ColorStateList;

    .line 12
    .line 13
    if-eq v1, p1, :cond_1b

    .line 14
    .line 15
    iput-object p1, v0, Ln73;->c:Landroid/content/res/ColorStateList;

    .line 16
    .line 17
    iget-object v0, v0, Ln73;->d:Landroid/graphics/PorterDuff$Mode;

    .line 18
    .line 19
    invoke-virtual {p0, p1, v0}, Lp73;->a(Landroid/content/res/ColorStateList;Landroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    iput-object p1, p0, Lp73;->c:Landroid/graphics/PorterDuffColorFilter;

    .line 24
    .line 25
    invoke-virtual {p0}, Lp73;->invalidateSelf()V

    .line 26
    .line 27
    .line 28
    :cond_1b
    return-void
.end method

.method public final setTintMode(Landroid/graphics/PorterDuff$Mode;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lg73;->a:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    if-eqz v0, :cond_8

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setTintMode(Landroid/graphics/PorterDuff$Mode;)V

    .line 6
    .line 7
    .line 8
    return-void

    .line 9
    :cond_8
    iget-object v0, p0, Lp73;->b:Ln73;

    .line 10
    .line 11
    iget-object v1, v0, Ln73;->d:Landroid/graphics/PorterDuff$Mode;

    .line 12
    .line 13
    if-eq v1, p1, :cond_1b

    .line 14
    .line 15
    iput-object p1, v0, Ln73;->d:Landroid/graphics/PorterDuff$Mode;

    .line 16
    .line 17
    iget-object v0, v0, Ln73;->c:Landroid/content/res/ColorStateList;

    .line 18
    .line 19
    invoke-virtual {p0, v0, p1}, Lp73;->a(Landroid/content/res/ColorStateList;Landroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    iput-object p1, p0, Lp73;->c:Landroid/graphics/PorterDuffColorFilter;

    .line 24
    .line 25
    invoke-virtual {p0}, Lp73;->invalidateSelf()V

    .line 26
    .line 27
    .line 28
    :cond_1b
    return-void
.end method

.method public final setVisible(ZZ)Z
    .registers 4

    .line 1
    iget-object v0, p0, Lg73;->a:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    if-eqz v0, :cond_9

    .line 4
    .line 5
    invoke-virtual {v0, p1, p2}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    .line 6
    .line 7
    .line 8
    move-result p0

    .line 9
    return p0

    .line 10
    :cond_9
    invoke-super {p0, p1, p2}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    .line 11
    .line 12
    .line 13
    move-result p0

    .line 14
    return p0
.end method

.method public final unscheduleSelf(Ljava/lang/Runnable;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lg73;->a:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    if-eqz v0, :cond_8

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->unscheduleSelf(Ljava/lang/Runnable;)V

    .line 6
    .line 7
    .line 8
    return-void

    .line 9
    :cond_8
    invoke-super {p0, p1}, Landroid/graphics/drawable/Drawable;->unscheduleSelf(Ljava/lang/Runnable;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method
