###### Class defpackage.h2 (h2)
.class public final Lh2;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 1
    iput p1, p0, Lh2;->a:I

    .line 2
    .line 3
    iput-object p2, p0, Lh2;->b:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 5

    .line 1
    iget v0, p0, Lh2;->a:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    iget-object p0, p0, Lh2;->b:Ljava/lang/Object;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_c4

    .line 8
    .line 9
    .line 10
    check-cast p0, Landroidx/appcompat/widget/Toolbar;

    .line 11
    .line 12
    iget-object p0, p0, Landroidx/appcompat/widget/Toolbar;->P:Luy2;

    .line 13
    .line 14
    if-nez p0, :cond_10

    .line 15
    .line 16
    goto :goto_12

    .line 17
    :cond_10
    iget-object v1, p0, Luy2;->b:Lks1;

    .line 18
    .line 19
    :goto_12
    if-eqz v1, :cond_17

    .line 20
    .line 21
    invoke-virtual {v1}, Lks1;->collapseActionView()Z

    .line 22
    .line 23
    .line 24
    :cond_17
    return-void

    .line 25
    :pswitch_18
    check-cast p0, Leq1;

    .line 26
    .line 27
    iget p1, p0, Leq1;->j:I

    .line 28
    .line 29
    const/4 v0, 0x2

    .line 30
    if-ne p1, v0, :cond_23

    .line 31
    .line 32
    invoke-virtual {p0, v2}, Leq1;->q(I)V

    .line 33
    .line 34
    .line 35
    goto :goto_28

    .line 36
    :cond_23
    if-ne p1, v2, :cond_28

    .line 37
    .line 38
    invoke-virtual {p0, v0}, Leq1;->q(I)V

    .line 39
    .line 40
    .line 41
    :cond_28
    :goto_28
    invoke-virtual {p0}, Landroidx/fragment/app/m;->getView()Landroid/view/View;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    invoke-virtual {p0, p1}, Leq1;->r(Landroid/view/View;)V

    .line 46
    .line 47
    .line 48
    return-void

    .line 49
    :pswitch_30
    check-cast p0, Lcom/mazenrashed/dotsindicator/DotsIndicator;

    .line 50
    .line 51
    invoke-virtual {p0}, Lcom/mazenrashed/dotsindicator/DotsIndicator;->getOnSelectListener()Lft0;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    const-string v1, "null cannot be cast to non-null type kotlin.Int"

    .line 56
    .line 57
    if-eqz v0, :cond_52

    .line 58
    .line 59
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 60
    .line 61
    .line 62
    invoke-virtual {p1}, Landroid/view/View;->getTag()Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object v2

    .line 66
    if-eqz v2, :cond_4c

    .line 67
    .line 68
    check-cast v2, Ljava/lang/Integer;

    .line 69
    .line 70
    invoke-interface {v0, v2}, Lft0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    check-cast v0, Lw43;

    .line 75
    .line 76
    goto :goto_52

    .line 77
    :cond_4c
    new-instance p0, Ll13;

    .line 78
    .line 79
    invoke-direct {p0, v1}, Ljava/lang/ClassCastException;-><init>(Ljava/lang/String;)V

    .line 80
    .line 81
    .line 82
    throw p0

    .line 83
    :cond_52
    :goto_52
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 84
    .line 85
    .line 86
    invoke-virtual {p1}, Landroid/view/View;->getTag()Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object p1

    .line 90
    if-eqz p1, :cond_65

    .line 91
    .line 92
    check-cast p1, Ljava/lang/Integer;

    .line 93
    .line 94
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 95
    .line 96
    .line 97
    move-result p1

    .line 98
    invoke-virtual {p0, p1}, Lcom/mazenrashed/dotsindicator/DotsIndicator;->setDotSelection(I)V

    .line 99
    .line 100
    .line 101
    return-void

    .line 102
    :cond_65
    new-instance p0, Ll13;

    .line 103
    .line 104
    invoke-direct {p0, v1}, Ljava/lang/ClassCastException;-><init>(Ljava/lang/String;)V

    .line 105
    .line 106
    .line 107
    throw p0

    .line 108
    :pswitch_6b
    check-cast p0, Lll;

    .line 109
    .line 110
    iget-boolean p1, p0, Lll;->m:Z

    .line 111
    .line 112
    if-eqz p1, :cond_9d

    .line 113
    .line 114
    invoke-virtual {p0}, Landroid/app/Dialog;->isShowing()Z

    .line 115
    .line 116
    .line 117
    move-result p1

    .line 118
    if-eqz p1, :cond_9d

    .line 119
    .line 120
    iget-boolean p1, p0, Lll;->o:Z

    .line 121
    .line 122
    if-nez p1, :cond_96

    .line 123
    .line 124
    invoke-virtual {p0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    .line 125
    .line 126
    .line 127
    move-result-object p1

    .line 128
    const v0, 0x101035b

    .line 129
    .line 130
    .line 131
    filled-new-array {v0}, [I

    .line 132
    .line 133
    .line 134
    move-result-object v0

    .line 135
    invoke-virtual {p1, v0}, Landroid/content/Context;->obtainStyledAttributes([I)Landroid/content/res/TypedArray;

    .line 136
    .line 137
    .line 138
    move-result-object p1

    .line 139
    const/4 v0, 0x0

    .line 140
    invoke-virtual {p1, v0, v2}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 141
    .line 142
    .line 143
    move-result v0

    .line 144
    iput-boolean v0, p0, Lll;->n:Z

    .line 145
    .line 146
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    .line 147
    .line 148
    .line 149
    iput-boolean v2, p0, Lll;->o:Z

    .line 150
    .line 151
    :cond_96
    iget-boolean p1, p0, Lll;->n:Z

    .line 152
    .line 153
    if-eqz p1, :cond_9d

    .line 154
    .line 155
    invoke-virtual {p0}, Lll;->cancel()V

    .line 156
    .line 157
    .line 158
    :cond_9d
    return-void

    .line 159
    :pswitch_9e
    check-cast p0, Ln4;

    .line 160
    .line 161
    iget-object v0, p0, Ln4;->i:Landroid/widget/Button;

    .line 162
    .line 163
    if-ne p1, v0, :cond_ac

    .line 164
    .line 165
    iget-object p1, p0, Ln4;->k:Landroid/os/Message;

    .line 166
    .line 167
    if-eqz p1, :cond_ac

    .line 168
    .line 169
    invoke-static {p1}, Landroid/os/Message;->obtain(Landroid/os/Message;)Landroid/os/Message;

    .line 170
    .line 171
    .line 172
    move-result-object v1

    .line 173
    :cond_ac
    if-eqz v1, :cond_b1

    .line 174
    .line 175
    invoke-virtual {v1}, Landroid/os/Message;->sendToTarget()V

    .line 176
    .line 177
    .line 178
    :cond_b1
    iget-object p1, p0, Ln4;->A:Ll4;

    .line 179
    .line 180
    iget-object p0, p0, Ln4;->b:Lp4;

    .line 181
    .line 182
    invoke-virtual {p1, v2, p0}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    .line 183
    .line 184
    .line 185
    move-result-object p0

    .line 186
    invoke-virtual {p0}, Landroid/os/Message;->sendToTarget()V

    .line 187
    .line 188
    .line 189
    return-void

    .line 190
    :pswitch_bd
    check-cast p0, Lz2;

    .line 191
    .line 192
    invoke-virtual {p0}, Lz2;->a()V

    .line 193
    .line 194
    .line 195
    return-void

    .line 196
    nop

    .line 197
    :pswitch_data_c4
    .packed-switch 0x0
        :pswitch_bd
        :pswitch_9e
        :pswitch_6b
        :pswitch_30
        :pswitch_18
    .end packed-switch
.end method
