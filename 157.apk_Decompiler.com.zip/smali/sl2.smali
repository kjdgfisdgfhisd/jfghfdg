###### Class defpackage.sl2 (sl2)
.class public interface abstract Lsl2;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"
