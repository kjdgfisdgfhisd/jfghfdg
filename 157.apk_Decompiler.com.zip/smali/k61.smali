###### Class defpackage.k61 (k61)
.class public final Lk61;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lif1;


# static fields
.field public static final a:Lk61;

.field public static final b:Lj61;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Lk61;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lk61;->a:Lk61;

    .line 7
    .line 8
    sget-object v0, Lj61;->b:Lj61;

    .line 9
    .line 10
    sput-object v0, Lk61;->b:Lj61;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final deserialize(Lz60;)Ljava/lang/Object;
    .registers 4

    .line 1
    invoke-static {p1}, Lmw1;->a(Lz60;)Lx61;

    .line 2
    .line 3
    .line 4
    new-instance p0, Li61;

    .line 5
    .line 6
    sget-object v0, Lg71;->a:Lg71;

    .line 7
    .line 8
    new-instance v1, Leb;

    .line 9
    .line 10
    invoke-direct {v1, v0}, Leb;-><init>(Lif1;)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {v1, p1}, Ls;->e(Lz60;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    check-cast p1, Ljava/util/List;

    .line 18
    .line 19
    invoke-direct {p0, p1}, Li61;-><init>(Ljava/util/List;)V

    .line 20
    .line 21
    .line 22
    return-object p0
.end method

.method public final getDescriptor()Lwk2;
    .registers 1

    .line 1
    sget-object p0, Lk61;->b:Lj61;

    .line 2
    .line 3
    return-object p0
.end method

.method public final serialize(Lbi0;Ljava/lang/Object;)V
    .registers 8

    .line 1
    check-cast p2, Li61;

    .line 2
    .line 3
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-static {p1}, Lmw1;->b(Lbi0;)V

    .line 7
    .line 8
    .line 9
    sget-object p0, Lg71;->a:Lg71;

    .line 10
    .line 11
    new-instance v0, Ldb;

    .line 12
    .line 13
    invoke-interface {p0}, Lif1;->getDescriptor()Lwk2;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    .line 19
    .line 20
    invoke-direct {v0, v1}, Lmk1;-><init>(Lwk2;)V

    .line 21
    .line 22
    .line 23
    invoke-interface {p2}, Ljava/util/Collection;->size()I

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    invoke-interface {p1, v0}, Lbi0;->b(Lwk2;)Lox;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    invoke-interface {p2}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 32
    .line 33
    .line 34
    move-result-object p2

    .line 35
    const/4 v2, 0x0

    .line 36
    :goto_23
    if-ge v2, v1, :cond_32

    .line 37
    .line 38
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v3

    .line 42
    move-object v4, p1

    .line 43
    check-cast v4, Lnt2;

    .line 44
    .line 45
    invoke-virtual {v4, v0, v2, p0, v3}, Lnt2;->w(Lwk2;ILif1;Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    add-int/lit8 v2, v2, 0x1

    .line 49
    .line 50
    goto :goto_23

    .line 51
    :cond_32
    invoke-interface {p1, v0}, Lox;->a(Lwk2;)V

    .line 52
    .line 53
    .line 54
    return-void
.end method
