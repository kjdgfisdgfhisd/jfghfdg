###### Class defpackage.dx3 (dx3)
.class public final Ldx3;
.super Lom3;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final synthetic e:I

.field public final synthetic f:Lbx3;


# direct methods
.method public synthetic constructor <init>(Lbx3;Lvu3;I)V
    .registers 4

    .line 1
    iput p3, p0, Ldx3;->e:I

    .line 2
    .line 3
    iput-object p1, p0, Ldx3;->f:Lbx3;

    .line 4
    .line 5
    invoke-direct {p0, p2}, Lom3;-><init>(Lvu3;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final c()V
    .registers 3

    .line 1
    iget v0, p0, Ldx3;->e:I

    .line 2
    .line 3
    iget-object p0, p0, Ldx3;->f:Lbx3;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_2c

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    iget-object p0, p0, Lqs3;->n:Lts3;

    .line 13
    .line 14
    const-string v0, "Tasks have been queued for a long time"

    .line 15
    .line 16
    invoke-virtual {p0, v0}, Lts3;->c(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    return-void

    .line 20
    :pswitch_13
    invoke-virtual {p0}, Lgp3;->H0()V

    .line 21
    .line 22
    .line 23
    invoke-virtual {p0}, Lbx3;->V0()Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-eqz v0, :cond_2a

    .line 28
    .line 29
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    iget-object v0, v0, Lqs3;->s:Lts3;

    .line 34
    .line 35
    const-string v1, "Inactivity, disconnecting from the service"

    .line 36
    .line 37
    invoke-virtual {v0, v1}, Lts3;->c(Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    invoke-virtual {p0}, Lbx3;->U0()V

    .line 41
    .line 42
    .line 43
    :cond_2a
    return-void

    .line 44
    nop

    .line 45
    :pswitch_data_2c
    .packed-switch 0x0
        :pswitch_13
    .end packed-switch
.end method
