###### Class defpackage.jx0 (jx0)
.class public final Ljx0;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final a:Ljava/lang/Object;

.field public b:Ljava/util/ArrayList;

.field public c:Ljx0;

.field public d:Ljx0;


# direct methods
.method public constructor <init>(Le22;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p0, p0, Ljx0;->d:Ljx0;

    .line 5
    .line 6
    iput-object p0, p0, Ljx0;->c:Ljx0;

    .line 7
    .line 8
    iput-object p1, p0, Ljx0;->a:Ljava/lang/Object;

    .line 9
    .line 10
    return-void
.end method
