###### Class defpackage.cz3 (cz3)
.class public final Lcz3;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lru2;


# static fields
.field public static final b:Lcz3;


# instance fields
.field public final a:Luu2;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Lcz3;

    .line 2
    .line 3
    invoke-direct {v0}, Lcz3;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcz3;->b:Lcz3;

    .line 7
    .line 8
    return-void
.end method

.method public constructor <init>()V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lgz3;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    new-instance v1, Luu2;

    .line 10
    .line 11
    invoke-direct {v1, v0}, Luu2;-><init>(Ljava/lang/Object;)V

    .line 12
    .line 13
    .line 14
    iput-object v1, p0, Lcz3;->a:Luu2;

    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 1

    .line 1
    iget-object p0, p0, Lcz3;->a:Luu2;

    .line 2
    .line 3
    iget-object p0, p0, Luu2;->a:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast p0, Lgz3;

    .line 6
    .line 7
    return-object p0
.end method
