###### Class defpackage.qy2 (qy2)
.class public final Lqy2;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final a:D

.field public final b:D


# direct methods
.method public constructor <init>(DD)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/util/HashMap;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-wide p1, p0, Lqy2;->a:D

    .line 10
    .line 11
    iput-wide p3, p0, Lqy2;->b:D

    .line 12
    .line 13
    return-void
.end method

.method public static a(DD)Lqy2;
    .registers 22

    .line 1
    move-wide/from16 v0, p0

    .line 2
    .line 3
    move-wide/from16 v2, p2

    .line 4
    .line 5
    new-instance v4, Lpy2;

    .line 6
    .line 7
    invoke-direct {v4, v0, v1, v2, v3}, Lpy2;-><init>(DD)V

    .line 8
    .line 9
    .line 10
    const/4 v5, 0x0

    .line 11
    const/16 v6, 0x64

    .line 12
    .line 13
    move v7, v5

    .line 14
    :goto_d
    if-ge v7, v6, :cond_58

    .line 15
    .line 16
    add-int v8, v7, v6

    .line 17
    .line 18
    div-int/lit8 v8, v8, 0x2

    .line 19
    .line 20
    invoke-virtual {v4, v8}, Lpy2;->a(I)D

    .line 21
    .line 22
    .line 23
    move-result-wide v9

    .line 24
    add-int/lit8 v11, v8, 0x1

    .line 25
    .line 26
    invoke-virtual {v4, v11}, Lpy2;->a(I)D

    .line 27
    .line 28
    .line 29
    move-result-wide v12

    .line 30
    cmpg-double v9, v9, v12

    .line 31
    .line 32
    if-gez v9, :cond_23

    .line 33
    .line 34
    const/4 v9, 0x1

    .line 35
    goto :goto_24

    .line 36
    :cond_23
    move v9, v5

    .line 37
    :goto_24
    invoke-virtual {v4, v8}, Lpy2;->a(I)D

    .line 38
    .line 39
    .line 40
    move-result-wide v12

    .line 41
    iget-wide v14, v4, Lpy2;->b:D

    .line 42
    .line 43
    const-wide v16, 0x3f847ae147ae147bL    # 0.01

    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    sub-double v14, v14, v16

    .line 49
    .line 50
    cmpl-double v10, v12, v14

    .line 51
    .line 52
    if-ltz v10, :cond_52

    .line 53
    .line 54
    add-int/lit8 v9, v7, -0x32

    .line 55
    .line 56
    invoke-static {v9}, Ljava/lang/Math;->abs(I)I

    .line 57
    .line 58
    .line 59
    move-result v9

    .line 60
    add-int/lit8 v10, v6, -0x32

    .line 61
    .line 62
    invoke-static {v10}, Ljava/lang/Math;->abs(I)I

    .line 63
    .line 64
    .line 65
    move-result v10

    .line 66
    if-ge v9, v10, :cond_44

    .line 67
    .line 68
    goto :goto_56

    .line 69
    :cond_44
    if-ne v7, v8, :cond_50

    .line 70
    .line 71
    iget-wide v13, v4, Lpy2;->b:D

    .line 72
    .line 73
    int-to-double v5, v7

    .line 74
    iget-wide v11, v4, Lpy2;->a:D

    .line 75
    .line 76
    move-wide v15, v5

    .line 77
    invoke-static/range {v11 .. v16}, Lux0;->a(DDD)Lux0;

    .line 78
    .line 79
    .line 80
    goto :goto_60

    .line 81
    :cond_50
    move v7, v8

    .line 82
    goto :goto_d

    .line 83
    :cond_52
    if-eqz v9, :cond_56

    .line 84
    .line 85
    move v7, v11

    .line 86
    goto :goto_d

    .line 87
    :cond_56
    :goto_56
    move v6, v8

    .line 88
    goto :goto_d

    .line 89
    :cond_58
    iget-wide v10, v4, Lpy2;->b:D

    .line 90
    .line 91
    int-to-double v12, v7

    .line 92
    iget-wide v8, v4, Lpy2;->a:D

    .line 93
    .line 94
    invoke-static/range {v8 .. v13}, Lux0;->a(DDD)Lux0;

    .line 95
    .line 96
    .line 97
    :goto_60
    new-instance v4, Lqy2;

    .line 98
    .line 99
    invoke-direct {v4, v0, v1, v2, v3}, Lqy2;-><init>(DD)V

    .line 100
    .line 101
    .line 102
    return-object v4
.end method
