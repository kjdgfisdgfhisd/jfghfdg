###### Class defpackage.zs2 (zs2)
.class public final Lzs2;
.super Lbt2;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public transient c:Lkv3;


# direct methods
.method public constructor <init>()V
    .registers 3

    .line 1
    const-class v0, Ljava/lang/String;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {p0, v1, v0}, Lbt2;-><init>(ILjava/lang/Class;)V

    .line 5
    .line 6
    .line 7
    sget-object v0, Lx52;->c:Lx52;

    .line 8
    .line 9
    iput-object v0, p0, Lzs2;->c:Lkv3;

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Lt71;Lfl2;)V
    .registers 8

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v1, p0, Lzs2;->c:Lkv3;

    .line 6
    .line 7
    invoke-virtual {v1, v0}, Lkv3;->u(Ljava/lang/Class;)Lt91;

    .line 8
    .line 9
    .line 10
    move-result-object v2

    .line 11
    if-nez v2, :cond_31

    .line 12
    .line 13
    const-class v2, Ljava/lang/Object;

    .line 14
    .line 15
    if-ne v0, v2, :cond_1e

    .line 16
    .line 17
    new-instance v2, Lys2;

    .line 18
    .line 19
    const/16 v3, 0x8

    .line 20
    .line 21
    invoke-direct {v2, v3, v0}, Lys2;-><init>(ILjava/lang/Class;)V

    .line 22
    .line 23
    .line 24
    invoke-virtual {v1, v0, v2}, Lkv3;->q(Ljava/lang/Class;Lt91;)Lkv3;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    iput-object v0, p0, Lzs2;->c:Lkv3;

    .line 29
    .line 30
    goto :goto_31

    .line 31
    :cond_1e
    iget-object v2, p3, Lfl2;->a:Lbl2;

    .line 32
    .line 33
    invoke-virtual {v2, v0}, Lvo1;->c(Ljava/lang/Class;)Lh13;

    .line 34
    .line 35
    .line 36
    move-result-object v2

    .line 37
    const/4 v3, 0x0

    .line 38
    invoke-virtual {p3, v2, v3}, Lfl2;->j(Lh13;Lwj;)Lt91;

    .line 39
    .line 40
    .line 41
    move-result-object v2

    .line 42
    invoke-virtual {v1, v0, v2}, Lkv3;->q(Ljava/lang/Class;Lt91;)Lkv3;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    if-eq v1, v0, :cond_31

    .line 47
    .line 48
    iput-object v0, p0, Lzs2;->c:Lkv3;

    .line 49
    .line 50
    :cond_31
    :goto_31
    invoke-virtual {v2, p1, p2, p3}, Lt91;->e(Ljava/lang/Object;Lt71;Lfl2;)V

    .line 51
    .line 52
    .line 53
    return-void
.end method
