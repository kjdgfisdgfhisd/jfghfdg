###### Class defpackage.w00 (w00)
.class public interface abstract Lw00;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# virtual methods
.method public abstract getContext()Lr10;
.end method

.method public abstract resumeWith(Ljava/lang/Object;)V
.end method
