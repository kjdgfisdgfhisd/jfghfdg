###### Class defpackage.bk (bk)
.class public final Lbk;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field public static final i:[Lyj;


# instance fields
.field public final a:Ljava/lang/Object;

.field public b:Ljava/lang/Object;

.field public c:Ljava/lang/Object;

.field public d:Ljava/lang/Object;

.field public e:Ljava/lang/Object;

.field public f:Ljava/lang/Object;

.field public g:Ljava/lang/Object;

.field public h:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    const/4 v0, 0x0

    .line 2
    new-array v0, v0, [Lyj;

    .line 3
    .line 4
    sput-object v0, Lbk;->i:[Lyj;

    .line 5
    .line 6
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lrm2;Lxa1;Lrt1;Lgo1;Lk80;Lc6;)V
    .registers 11

    .line 56
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 57
    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    iput-object v0, p0, Lbk;->g:Ljava/lang/Object;

    .line 58
    new-instance v1, Ljava/util/concurrent/atomic/AtomicReference;

    new-instance v2, Lpw2;

    invoke-direct {v2}, Lpw2;-><init>()V

    invoke-direct {v1, v2}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    iput-object v1, p0, Lbk;->h:Ljava/lang/Object;

    .line 59
    iput-object p1, p0, Lbk;->a:Ljava/lang/Object;

    .line 60
    iput-object p2, p0, Lbk;->b:Ljava/lang/Object;

    .line 61
    iput-object p4, p0, Lbk;->c:Ljava/lang/Object;

    .line 62
    iput-object p5, p0, Lbk;->d:Ljava/lang/Object;

    .line 63
    iput-object p6, p0, Lbk;->e:Ljava/lang/Object;

    .line 64
    iput-object p7, p0, Lbk;->f:Ljava/lang/Object;

    .line 65
    invoke-static {p3}, Lwn0;->i(Lxa1;)Lmm2;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lux;Lvd3;Lc52;Landroidx/work/impl/WorkDatabase;Lje3;Ljava/util/ArrayList;)V
    .registers 8

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 11
    .line 12
    .line 13
    iput-object p2, p0, Lbk;->a:Ljava/lang/Object;

    .line 14
    .line 15
    iput-object p3, p0, Lbk;->b:Ljava/lang/Object;

    .line 16
    .line 17
    iput-object p4, p0, Lbk;->c:Ljava/lang/Object;

    .line 18
    .line 19
    iput-object p5, p0, Lbk;->d:Ljava/lang/Object;

    .line 20
    .line 21
    iput-object p6, p0, Lbk;->e:Ljava/lang/Object;

    .line 22
    .line 23
    iput-object p7, p0, Lbk;->f:Ljava/lang/Object;

    .line 24
    .line 25
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 30
    .line 31
    .line 32
    iput-object p1, p0, Lbk;->g:Ljava/lang/Object;

    .line 33
    .line 34
    new-instance p1, Lt51;

    .line 35
    .line 36
    const/16 p2, 0xf

    .line 37
    .line 38
    invoke-direct {p1, p2}, Lt51;-><init>(I)V

    .line 39
    .line 40
    .line 41
    iput-object p1, p0, Lbk;->h:Ljava/lang/Object;

    .line 42
    .line 43
    return-void
.end method

.method public constructor <init>(Lij;)V
    .registers 3

    .line 44
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 45
    sget-object v0, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    iput-object v0, p0, Lbk;->c:Ljava/lang/Object;

    .line 46
    iput-object p1, p0, Lbk;->a:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljt3;)V
    .registers 9

    .line 47
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 48
    iput-object p1, p0, Lbk;->a:Ljava/lang/Object;

    .line 49
    iput-object p2, p0, Lbk;->b:Ljava/lang/Object;

    .line 50
    iput-object p3, p0, Lbk;->c:Ljava/lang/Object;

    .line 51
    iput-object p4, p0, Lbk;->d:Ljava/lang/Object;

    .line 52
    iput-object p5, p0, Lbk;->e:Ljava/lang/Object;

    .line 53
    iput-object p6, p0, Lbk;->f:Ljava/lang/Object;

    .line 54
    iput-object p7, p0, Lbk;->g:Ljava/lang/Object;

    .line 55
    iput-object p8, p0, Lbk;->h:Ljava/lang/Object;

    return-void
.end method

.method public static d(Ljava/lang/String;Lorg/json/JSONObject;)V
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    const-string p1, "FirebaseCrashlytics"

    .line 18
    .line 19
    const/4 v0, 0x3

    .line 20
    invoke-static {p1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-eqz v0, :cond_1d

    .line 25
    .line 26
    const/4 v0, 0x0

    .line 27
    invoke-static {p1, p0, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 28
    .line 29
    .line 30
    :cond_1d
    return-void
.end method


# virtual methods
.method public a()Lzj;
    .registers 7

    .line 1
    iget-object v0, p0, Lbk;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lh6;

    .line 4
    .line 5
    if-eqz v0, :cond_29

    .line 6
    .line 7
    iget-object v0, p0, Lbk;->b:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v0, Lbl2;

    .line 10
    .line 11
    sget-object v1, Lxo1;->q:Lxo1;

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Lvo1;->f(Lxo1;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_29

    .line 18
    .line 19
    iget-object v0, p0, Lbk;->g:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast v0, Lh6;

    .line 22
    .line 23
    iget-object v1, p0, Lbk;->b:Ljava/lang/Object;

    .line 24
    .line 25
    check-cast v1, Lbl2;

    .line 26
    .line 27
    sget-object v2, Lxo1;->r:Lxo1;

    .line 28
    .line 29
    invoke-virtual {v1, v2}, Lvo1;->f(Lxo1;)Z

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    invoke-virtual {v0}, Lh6;->A()Ljava/lang/reflect/Member;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    if-eqz v0, :cond_29

    .line 38
    .line 39
    invoke-static {v0, v1}, Lut;->d(Ljava/lang/reflect/Member;Z)V

    .line 40
    .line 41
    .line 42
    :cond_29
    iget-object v0, p0, Lbk;->e:Ljava/lang/Object;

    .line 43
    .line 44
    check-cast v0, Lyx2;

    .line 45
    .line 46
    if-eqz v0, :cond_46

    .line 47
    .line 48
    iget-object v1, p0, Lbk;->b:Ljava/lang/Object;

    .line 49
    .line 50
    check-cast v1, Lbl2;

    .line 51
    .line 52
    iget-object v0, v0, Lyx2;->d:Ljava/lang/Object;

    .line 53
    .line 54
    check-cast v0, Lh6;

    .line 55
    .line 56
    sget-object v2, Lxo1;->r:Lxo1;

    .line 57
    .line 58
    invoke-virtual {v1, v2}, Lvo1;->f(Lxo1;)Z

    .line 59
    .line 60
    .line 61
    move-result v1

    .line 62
    invoke-virtual {v0}, Lh6;->A()Ljava/lang/reflect/Member;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    if-eqz v0, :cond_46

    .line 67
    .line 68
    invoke-static {v0, v1}, Lut;->d(Ljava/lang/reflect/Member;Z)V

    .line 69
    .line 70
    .line 71
    :cond_46
    iget-object v0, p0, Lbk;->c:Ljava/lang/Object;

    .line 72
    .line 73
    check-cast v0, Ljava/util/List;

    .line 74
    .line 75
    if-eqz v0, :cond_8d

    .line 76
    .line 77
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    if-eqz v0, :cond_53

    .line 82
    .line 83
    goto :goto_8d

    .line 84
    :cond_53
    iget-object v0, p0, Lbk;->c:Ljava/lang/Object;

    .line 85
    .line 86
    check-cast v0, Ljava/util/List;

    .line 87
    .line 88
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 89
    .line 90
    .line 91
    move-result v1

    .line 92
    new-array v1, v1, [Lyj;

    .line 93
    .line 94
    invoke-interface {v0, v1}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    move-result-object v0

    .line 98
    check-cast v0, [Lyj;

    .line 99
    .line 100
    iget-object v1, p0, Lbk;->b:Ljava/lang/Object;

    .line 101
    .line 102
    check-cast v1, Lbl2;

    .line 103
    .line 104
    sget-object v2, Lxo1;->q:Lxo1;

    .line 105
    .line 106
    invoke-virtual {v1, v2}, Lvo1;->f(Lxo1;)Z

    .line 107
    .line 108
    .line 109
    move-result v1

    .line 110
    if-eqz v1, :cond_9d

    .line 111
    .line 112
    array-length v1, v0

    .line 113
    const/4 v2, 0x0

    .line 114
    :goto_71
    if-ge v2, v1, :cond_9d

    .line 115
    .line 116
    aget-object v3, v0, v2

    .line 117
    .line 118
    iget-object v4, p0, Lbk;->b:Ljava/lang/Object;

    .line 119
    .line 120
    check-cast v4, Lbl2;

    .line 121
    .line 122
    iget-object v3, v3, Lyj;->g:Lh6;

    .line 123
    .line 124
    sget-object v5, Lxo1;->r:Lxo1;

    .line 125
    .line 126
    invoke-virtual {v4, v5}, Lvo1;->f(Lxo1;)Z

    .line 127
    .line 128
    .line 129
    move-result v4

    .line 130
    invoke-virtual {v3}, Lh6;->A()Ljava/lang/reflect/Member;

    .line 131
    .line 132
    .line 133
    move-result-object v3

    .line 134
    if-eqz v3, :cond_8a

    .line 135
    .line 136
    invoke-static {v3, v4}, Lut;->d(Ljava/lang/reflect/Member;Z)V

    .line 137
    .line 138
    .line 139
    :cond_8a
    add-int/lit8 v2, v2, 0x1

    .line 140
    .line 141
    goto :goto_71

    .line 142
    :cond_8d
    :goto_8d
    iget-object v0, p0, Lbk;->e:Ljava/lang/Object;

    .line 143
    .line 144
    check-cast v0, Lyx2;

    .line 145
    .line 146
    if-nez v0, :cond_9b

    .line 147
    .line 148
    iget-object v0, p0, Lbk;->h:Ljava/lang/Object;

    .line 149
    .line 150
    check-cast v0, Lmy1;

    .line 151
    .line 152
    if-nez v0, :cond_9b

    .line 153
    .line 154
    const/4 p0, 0x0

    .line 155
    return-object p0

    .line 156
    :cond_9b
    sget-object v0, Lbk;->i:[Lyj;

    .line 157
    .line 158
    :cond_9d
    iget-object v1, p0, Lbk;->d:Ljava/lang/Object;

    .line 159
    .line 160
    check-cast v1, [Lyj;

    .line 161
    .line 162
    if-eqz v1, :cond_d4

    .line 163
    .line 164
    array-length v1, v1

    .line 165
    iget-object v2, p0, Lbk;->c:Ljava/lang/Object;

    .line 166
    .line 167
    check-cast v2, Ljava/util/List;

    .line 168
    .line 169
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 170
    .line 171
    .line 172
    move-result v2

    .line 173
    if-ne v1, v2, :cond_af

    .line 174
    .line 175
    goto :goto_d4

    .line 176
    :cond_af
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 177
    .line 178
    iget-object v1, p0, Lbk;->c:Ljava/lang/Object;

    .line 179
    .line 180
    check-cast v1, Ljava/util/List;

    .line 181
    .line 182
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 183
    .line 184
    .line 185
    move-result v1

    .line 186
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 187
    .line 188
    .line 189
    move-result-object v1

    .line 190
    iget-object p0, p0, Lbk;->d:Ljava/lang/Object;

    .line 191
    .line 192
    check-cast p0, [Lyj;

    .line 193
    .line 194
    array-length p0, p0

    .line 195
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 196
    .line 197
    .line 198
    move-result-object p0

    .line 199
    filled-new-array {v1, p0}, [Ljava/lang/Object;

    .line 200
    .line 201
    .line 202
    move-result-object p0

    .line 203
    const-string v1, "Mismatch between `properties` size (%d), `filteredProperties` (%s): should have as many (or `null` for latter)"

    .line 204
    .line 205
    invoke-static {v1, p0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 206
    .line 207
    .line 208
    move-result-object p0

    .line 209
    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 210
    .line 211
    .line 212
    throw v0

    .line 213
    :cond_d4
    :goto_d4
    new-instance v1, Lzj;

    .line 214
    .line 215
    iget-object v2, p0, Lbk;->a:Ljava/lang/Object;

    .line 216
    .line 217
    check-cast v2, Lij;

    .line 218
    .line 219
    iget-object v2, v2, Lij;->b:Ljava/io/Serializable;

    .line 220
    .line 221
    check-cast v2, Lh13;

    .line 222
    .line 223
    iget-object v3, p0, Lbk;->d:Ljava/lang/Object;

    .line 224
    .line 225
    check-cast v3, [Lyj;

    .line 226
    .line 227
    invoke-direct {v1, v2, p0, v0, v3}, Lak;-><init>(Lh13;Lbk;[Lyj;[Lyj;)V

    .line 228
    .line 229
    .line 230
    return-object v1
.end method

.method public b(I)Lmm2;
    .registers 9

    .line 1
    const-string v0, "FirebaseCrashlytics"

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    const/4 v2, 0x0

    .line 5
    :try_start_4
    invoke-static {v1, p1}, Ln10;->b(II)Z

    .line 6
    .line 7
    .line 8
    move-result v3

    .line 9
    if-nez v3, :cond_5c

    .line 10
    .line 11
    iget-object v3, p0, Lbk;->d:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v3, Lgo1;

    .line 14
    .line 15
    invoke-virtual {v3}, Lgo1;->P()Lorg/json/JSONObject;

    .line 16
    .line 17
    .line 18
    move-result-object v3

    .line 19
    const/4 v4, 0x3

    .line 20
    if-eqz v3, :cond_51

    .line 21
    .line 22
    iget-object p0, p0, Lbk;->c:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast p0, Lrt1;

    .line 25
    .line 26
    invoke-virtual {p0, v3}, Lrt1;->p(Lorg/json/JSONObject;)Lmm2;

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    const-string v5, "Loaded cached settings: "

    .line 31
    .line 32
    invoke-static {v5, v3}, Lbk;->d(Ljava/lang/String;Lorg/json/JSONObject;)V

    .line 33
    .line 34
    .line 35
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 36
    .line 37
    .line 38
    move-result-wide v5

    .line 39
    invoke-static {v4, p1}, Ln10;->b(II)Z

    .line 40
    .line 41
    .line 42
    move-result p1

    .line 43
    if-nez p1, :cond_40

    .line 44
    .line 45
    iget-wide v3, p0, Lmm2;->c:J

    .line 46
    .line 47
    cmp-long p1, v3, v5

    .line 48
    .line 49
    if-gez p1, :cond_40

    .line 50
    .line 51
    const-string p0, "Cached settings have expired."

    .line 52
    .line 53
    invoke-static {v0, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 54
    .line 55
    .line 56
    move-result p1

    .line 57
    if-eqz p1, :cond_5c

    .line 58
    .line 59
    invoke-static {v0, p0, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_3d
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_3d} :catch_3e

    .line 60
    .line 61
    .line 62
    return-object v2

    .line 63
    :catch_3e
    move-exception p0

    .line 64
    goto :goto_5d

    .line 65
    :cond_40
    :try_start_40
    const-string p1, "Returning cached settings."

    .line 66
    .line 67
    invoke-static {v0, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 68
    .line 69
    .line 70
    move-result v1

    .line 71
    if-eqz v1, :cond_4b

    .line 72
    .line 73
    invoke-static {v0, p1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_4b
    .catch Ljava/lang/Exception; {:try_start_40 .. :try_end_4b} :catch_4f

    .line 74
    .line 75
    .line 76
    :cond_4b
    return-object p0

    .line 77
    :goto_4c
    move-object v2, p0

    .line 78
    move-object p0, p1

    .line 79
    goto :goto_5d

    .line 80
    :catch_4f
    move-exception p1

    .line 81
    goto :goto_4c

    .line 82
    :cond_51
    :try_start_51
    const-string p0, "No cached settings data found."

    .line 83
    .line 84
    invoke-static {v0, v4}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 85
    .line 86
    .line 87
    move-result p1

    .line 88
    if-eqz p1, :cond_5c

    .line 89
    .line 90
    invoke-static {v0, p0, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_5c
    .catch Ljava/lang/Exception; {:try_start_51 .. :try_end_5c} :catch_3e

    .line 91
    .line 92
    .line 93
    :cond_5c
    return-object v2

    .line 94
    :goto_5d
    const-string p1, "Failed to get cached settings"

    .line 95
    .line 96
    invoke-static {v0, p1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 97
    .line 98
    .line 99
    return-object v2
.end method

.method public c()Lmm2;
    .registers 1

    .line 1
    iget-object p0, p0, Lbk;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Ljava/util/concurrent/atomic/AtomicReference;

    .line 4
    .line 5
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    check-cast p0, Lmm2;

    .line 10
    .line 11
    return-object p0
.end method
