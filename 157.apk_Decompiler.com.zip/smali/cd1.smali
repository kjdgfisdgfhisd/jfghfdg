###### Class defpackage.cd1 (cd1)
.class public final Lcd1;
.super Lgw0;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# virtual methods
.method public final h()Ljava/util/List;
    .registers 1

    .line 1
    sget-object p0, Lth0;->a:Lth0;

    .line 2
    .line 3
    return-object p0
.end method
