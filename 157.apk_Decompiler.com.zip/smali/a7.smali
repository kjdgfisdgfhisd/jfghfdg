###### Class defpackage.a7 (a7)
.class public interface abstract La7;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# virtual methods
.method public abstract d()Loq2;
.end method

.method public abstract e()Lzq0;
.end method

.method public abstract f()Ljava/util/Map;
.end method

.method public abstract getType()Lgg1;
.end method
