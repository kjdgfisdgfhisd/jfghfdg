###### Class defpackage.pj2 (pj2)
.class public interface abstract Lpj2;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# virtual methods
.method public abstract a(Lkv0;)I
.end method

.method public abstract b(Lkv0;Lkv0;)V
.end method

.method public abstract c(Ljava/lang/Object;Lls;Lql0;)V
.end method

.method public abstract d(Ljava/lang/Object;)V
.end method

.method public abstract e(Ljava/lang/Object;)Z
.end method

.method public abstract f(Lf0;)I
.end method

.method public abstract g(Ljava/lang/Object;Lgo1;)V
.end method

.method public abstract h(Lkv0;Lkv0;)Z
.end method

.method public abstract i()Ljava/lang/Object;
.end method
