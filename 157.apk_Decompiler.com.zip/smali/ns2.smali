###### Class defpackage.ns2 (ns2)
.class public final Lns2;
.super Lqb;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    sget-object v0, Ly13;->c:Ly13;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    sget-object v0, Ljava/lang/Double;->TYPE:Ljava/lang/Class;

    .line 7
    .line 8
    invoke-static {v0}, Ly13;->i(Ljava/lang/Class;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final c(Lfl2;Ljava/lang/Object;)Z
    .registers 3

    .line 1
    check-cast p2, [D

    .line 2
    .line 3
    array-length p0, p2

    .line 4
    if-nez p0, :cond_7

    .line 5
    .line 6
    const/4 p0, 0x1

    .line 7
    return p0

    .line 8
    :cond_7
    const/4 p0, 0x0

    .line 9
    return p0
.end method

.method public final e(Ljava/lang/Object;Lt71;Lfl2;)V
    .registers 7

    .line 1
    check-cast p1, [D

    .line 2
    .line 3
    array-length v0, p1

    .line 4
    const/4 v1, 0x1

    .line 5
    const/4 v2, 0x0

    .line 6
    if-ne v0, v1, :cond_19

    .line 7
    .line 8
    invoke-virtual {p0, p3}, Lqb;->o(Lfl2;)Z

    .line 9
    .line 10
    .line 11
    move-result p0

    .line 12
    if-eqz p0, :cond_19

    .line 13
    .line 14
    array-length p0, p1

    .line 15
    :goto_e
    if-ge v2, p0, :cond_18

    .line 16
    .line 17
    aget-wide v0, p1, v2

    .line 18
    .line 19
    invoke-virtual {p2, v0, v1}, Lt71;->F(D)V

    .line 20
    .line 21
    .line 22
    add-int/lit8 v2, v2, 0x1

    .line 23
    .line 24
    goto :goto_e

    .line 25
    :cond_18
    return-void

    .line 26
    :cond_19
    array-length p0, p1

    .line 27
    array-length p3, p1

    .line 28
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 29
    .line 30
    .line 31
    invoke-static {p3, p0}, Lt71;->f(II)V

    .line 32
    .line 33
    .line 34
    invoke-virtual {p2, p1}, Lt71;->O(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    :goto_24
    if-ge v2, p0, :cond_2e

    .line 38
    .line 39
    aget-wide v0, p1, v2

    .line 40
    .line 41
    invoke-virtual {p2, v0, v1}, Lt71;->F(D)V

    .line 42
    .line 43
    .line 44
    add-int/lit8 v2, v2, 0x1

    .line 45
    .line 46
    goto :goto_24

    .line 47
    :cond_2e
    invoke-virtual {p2}, Lt71;->r()V

    .line 48
    .line 49
    .line 50
    return-void
.end method

.method public final n(Ls23;)Lh00;
    .registers 2

    .line 1
    return-object p0
.end method

.method public final p(Lwj;Ljava/lang/Boolean;)Lt91;
    .registers 4

    .line 1
    new-instance v0, Lns2;

    .line 2
    .line 3
    invoke-direct {v0, p0, p1, p2}, Lqb;-><init>(Lqb;Lwj;Ljava/lang/Boolean;)V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method

.method public final q(Ljava/lang/Object;Lt71;Lfl2;)V
    .registers 6

    .line 1
    check-cast p1, [D

    .line 2
    .line 3
    array-length p0, p1

    .line 4
    const/4 p3, 0x0

    .line 5
    :goto_4
    if-ge p3, p0, :cond_e

    .line 6
    .line 7
    aget-wide v0, p1, p3

    .line 8
    .line 9
    invoke-virtual {p2, v0, v1}, Lt71;->F(D)V

    .line 10
    .line 11
    .line 12
    add-int/lit8 p3, p3, 0x1

    .line 13
    .line 14
    goto :goto_4

    .line 15
    :cond_e
    return-void
.end method
