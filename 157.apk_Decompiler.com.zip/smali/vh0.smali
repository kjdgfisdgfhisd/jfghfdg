###### Class defpackage.vh0 (vh0)
.class public final Lvh0;
.super Lv02;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final synthetic l:I


# direct methods
.method public constructor <init>(Lzt1;Lzq0;I)V
    .registers 4

    .line 1
    iput p3, p0, Lvh0;->l:I

    .line 2
    .line 3
    packed-switch p3, :pswitch_data_14

    .line 4
    .line 5
    .line 6
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    invoke-direct {p0, p1, p2}, Lv02;-><init>(Lzt1;Lzq0;)V

    .line 13
    .line 14
    .line 15
    return-void

    .line 16
    :pswitch_f
    invoke-direct {p0, p1, p2}, Lv02;-><init>(Lzt1;Lzq0;)V

    .line 17
    .line 18
    .line 19
    return-void

    .line 20
    nop

    .line 21
    :pswitch_data_14
    .packed-switch 0x1
        :pswitch_f
    .end packed-switch
.end method


# virtual methods
.method public final p0()Lvr1;
    .registers 2

    .line 1
    iget p0, p0, Lvh0;->l:I

    .line 2
    .line 3
    sget-object v0, Lur1;->b:Lur1;

    .line 4
    .line 5
    return-object v0
.end method
