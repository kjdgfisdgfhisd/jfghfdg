###### Class defpackage.x40 (x40)
.class public final Lx40;
.super Ll60;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final synthetic e:I

.field public final synthetic f:Ljava/lang/Object;

.field public final synthetic g:Ljava/io/Serializable;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/io/Serializable;I)V
    .registers 4

    .line 12
    iput p3, p0, Lx40;->e:I

    iput-object p1, p0, Lx40;->f:Ljava/lang/Object;

    iput-object p2, p0, Lx40;->g:Ljava/io/Serializable;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Ljc2;Lft0;)V
    .registers 4

    .line 1
    const/4 v0, 0x1

    .line 2
    iput v0, p0, Lx40;->e:I

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lx40;->g:Ljava/io/Serializable;

    .line 8
    .line 9
    iput-object p2, p0, Lx40;->f:Ljava/lang/Object;

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public b(Ljava/lang/Object;)V
    .registers 4

    .line 1
    iget v0, p0, Lx40;->e:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_26

    .line 4
    .line 5
    .line 6
    return-void

    .line 7
    :pswitch_6
    check-cast p1, Lno;

    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    iget-object v0, p0, Lx40;->g:Ljava/io/Serializable;

    .line 13
    .line 14
    check-cast v0, Ljc2;

    .line 15
    .line 16
    iget-object v1, v0, Ljc2;->a:Ljava/lang/Object;

    .line 17
    .line 18
    if-nez v1, :cond_25

    .line 19
    .line 20
    iget-object p0, p0, Lx40;->f:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast p0, Lft0;

    .line 23
    .line 24
    invoke-interface {p0, p1}, Lft0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object p0

    .line 28
    check-cast p0, Ljava/lang/Boolean;

    .line 29
    .line 30
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 31
    .line 32
    .line 33
    move-result p0

    .line 34
    if-eqz p0, :cond_25

    .line 35
    .line 36
    iput-object p1, v0, Ljc2;->a:Ljava/lang/Object;

    .line 37
    .line 38
    :cond_25
    return-void

    .line 39
    :pswitch_data_26
    .packed-switch 0x1
        :pswitch_6
    .end packed-switch
.end method

.method public final c(Ljava/lang/Object;)Z
    .registers 6

    .line 1
    iget v0, p0, Lx40;->e:I

    .line 2
    .line 3
    iget-object v1, p0, Lx40;->f:Ljava/lang/Object;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v3, 0x1

    .line 7
    iget-object p0, p0, Lx40;->g:Ljava/io/Serializable;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_a0

    .line 10
    .line 11
    .line 12
    check-cast p1, Lxt1;

    .line 13
    .line 14
    check-cast p0, Ljc2;

    .line 15
    .line 16
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    check-cast v1, Ljava/lang/String;

    .line 20
    .line 21
    sget-object v0, Lb51;->a:Ljava/lang/String;

    .line 22
    .line 23
    invoke-static {p1}, Lxa0;->g(Lm60;)Lzq0;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    invoke-virtual {v0}, Lzq0;->i()Lar0;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 32
    .line 33
    .line 34
    invoke-static {v0}, Lb51;->g(Lar0;)Lft;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    if-eqz v0, :cond_2c

    .line 39
    .line 40
    invoke-static {v0}, Lib1;->e(Lft;)Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object p1

    .line 44
    goto :goto_32

    .line 45
    :cond_2c
    sget-object v0, Lih2;->n:Lih2;

    .line 46
    .line 47
    invoke-static {p1, v0}, Lkw0;->d(Lxt1;Lih2;)Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object p1

    .line 51
    :goto_32
    new-instance v0, Ljava/lang/StringBuilder;

    .line 52
    .line 53
    invoke-direct {v0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    const/16 p1, 0x2e

    .line 57
    .line 58
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 59
    .line 60
    .line 61
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 62
    .line 63
    .line 64
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object p1

    .line 68
    sget-object v0, Lhb1;->b:Ljava/util/LinkedHashSet;

    .line 69
    .line 70
    invoke-interface {v0, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    if-eqz v0, :cond_50

    .line 75
    .line 76
    sget-object p1, Ldb1;->a:Ldb1;

    .line 77
    .line 78
    iput-object p1, p0, Ljc2;->a:Ljava/lang/Object;

    .line 79
    .line 80
    goto :goto_76

    .line 81
    :cond_50
    sget-object v0, Lhb1;->d:Ljava/util/LinkedHashSet;

    .line 82
    .line 83
    invoke-interface {v0, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 84
    .line 85
    .line 86
    move-result v0

    .line 87
    if-eqz v0, :cond_5d

    .line 88
    .line 89
    sget-object p1, Ldb1;->b:Ldb1;

    .line 90
    .line 91
    iput-object p1, p0, Ljc2;->a:Ljava/lang/Object;

    .line 92
    .line 93
    goto :goto_76

    .line 94
    :cond_5d
    sget-object v0, Lhb1;->c:Ljava/util/LinkedHashSet;

    .line 95
    .line 96
    invoke-interface {v0, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 97
    .line 98
    .line 99
    move-result v0

    .line 100
    if-eqz v0, :cond_6a

    .line 101
    .line 102
    sget-object p1, Ldb1;->c:Ldb1;

    .line 103
    .line 104
    iput-object p1, p0, Ljc2;->a:Ljava/lang/Object;

    .line 105
    .line 106
    goto :goto_76

    .line 107
    :cond_6a
    sget-object v0, Lhb1;->a:Ljava/util/LinkedHashSet;

    .line 108
    .line 109
    invoke-interface {v0, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 110
    .line 111
    .line 112
    move-result p1

    .line 113
    if-eqz p1, :cond_76

    .line 114
    .line 115
    sget-object p1, Ldb1;->e:Ldb1;

    .line 116
    .line 117
    iput-object p1, p0, Ljc2;->a:Ljava/lang/Object;

    .line 118
    .line 119
    :cond_76
    :goto_76
    iget-object p0, p0, Ljc2;->a:Ljava/lang/Object;

    .line 120
    .line 121
    if-nez p0, :cond_7b

    .line 122
    .line 123
    move v2, v3

    .line 124
    :cond_7b
    return v2

    .line 125
    :pswitch_7c
    check-cast p1, Lno;

    .line 126
    .line 127
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 128
    .line 129
    .line 130
    check-cast p0, Ljc2;

    .line 131
    .line 132
    iget-object p0, p0, Ljc2;->a:Ljava/lang/Object;

    .line 133
    .line 134
    if-nez p0, :cond_88

    .line 135
    .line 136
    move v2, v3

    .line 137
    :cond_88
    return v2

    .line 138
    :pswitch_89
    check-cast p0, [Z

    .line 139
    .line 140
    check-cast v1, Lft0;

    .line 141
    .line 142
    invoke-interface {v1, p1}, Lft0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 143
    .line 144
    .line 145
    move-result-object p1

    .line 146
    check-cast p1, Ljava/lang/Boolean;

    .line 147
    .line 148
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 149
    .line 150
    .line 151
    move-result p1

    .line 152
    if-eqz p1, :cond_9b

    .line 153
    .line 154
    aput-boolean v3, p0, v2

    .line 155
    .line 156
    :cond_9b
    aget-boolean p0, p0, v2

    .line 157
    .line 158
    xor-int/2addr p0, v3

    .line 159
    return p0

    .line 160
    nop

    .line 161
    :pswitch_data_a0
    .packed-switch 0x0
        :pswitch_89
        :pswitch_7c
    .end packed-switch
.end method

.method public final v()Ljava/lang/Object;
    .registers 2

    .line 1
    iget v0, p0, Lx40;->e:I

    .line 2
    .line 3
    iget-object p0, p0, Lx40;->g:Ljava/io/Serializable;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_24

    .line 6
    .line 7
    .line 8
    check-cast p0, Ljc2;

    .line 9
    .line 10
    iget-object p0, p0, Ljc2;->a:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast p0, Ldb1;

    .line 13
    .line 14
    if-nez p0, :cond_11

    .line 15
    .line 16
    sget-object p0, Ldb1;->d:Ldb1;

    .line 17
    .line 18
    :cond_11
    return-object p0

    .line 19
    :pswitch_12
    check-cast p0, Ljc2;

    .line 20
    .line 21
    iget-object p0, p0, Ljc2;->a:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast p0, Lno;

    .line 24
    .line 25
    return-object p0

    .line 26
    :pswitch_19
    check-cast p0, [Z

    .line 27
    .line 28
    const/4 v0, 0x0

    .line 29
    aget-boolean p0, p0, v0

    .line 30
    .line 31
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 32
    .line 33
    .line 34
    move-result-object p0

    .line 35
    return-object p0

    .line 36
    nop

    .line 37
    :pswitch_data_24
    .packed-switch 0x0
        :pswitch_19
        :pswitch_12
    .end packed-switch
.end method
