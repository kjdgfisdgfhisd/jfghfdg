###### Class defpackage.c22 (c22)
.class public final Lc22;
.super Ly00;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public j:Ld22;

.field public synthetic l:Ljava/lang/Object;

.field public final synthetic m:Ld22;

.field public n:I


# direct methods
.method public constructor <init>(Ld22;Ly00;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lc22;->m:Ld22;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Ly00;-><init>(Lw00;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    iput-object p1, p0, Lc22;->l:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lc22;->n:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lc22;->n:I

    .line 9
    .line 10
    iget-object p1, p0, Lc22;->m:Ld22;

    .line 11
    .line 12
    invoke-virtual {p1, p0}, Ld22;->a(Ly00;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    return-object p0
.end method
