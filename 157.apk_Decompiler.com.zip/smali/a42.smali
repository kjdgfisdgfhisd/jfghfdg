###### Class defpackage.a42 (a42)
.class public final La42;
.super Lg70;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field public static final i:La42;

.field public static final j:La42;

.field public static final k:La42;

.field public static final l:La42;

.field public static final m:La42;

.field public static final n:La42;

.field public static final o:La42;

.field public static final p:La42;

.field public static final q:La42;


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, La42;

    .line 2
    .line 3
    const/16 v1, 0xc

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lg70;-><init>(I)V

    .line 6
    .line 7
    .line 8
    sput-object v0, La42;->i:La42;

    .line 9
    .line 10
    new-instance v0, La42;

    .line 11
    .line 12
    invoke-direct {v0, v1}, Lg70;-><init>(I)V

    .line 13
    .line 14
    .line 15
    sput-object v0, La42;->j:La42;

    .line 16
    .line 17
    new-instance v0, La42;

    .line 18
    .line 19
    invoke-direct {v0, v1}, Lg70;-><init>(I)V

    .line 20
    .line 21
    .line 22
    sput-object v0, La42;->k:La42;

    .line 23
    .line 24
    new-instance v0, La42;

    .line 25
    .line 26
    invoke-direct {v0, v1}, Lg70;-><init>(I)V

    .line 27
    .line 28
    .line 29
    sput-object v0, La42;->l:La42;

    .line 30
    .line 31
    new-instance v0, La42;

    .line 32
    .line 33
    invoke-direct {v0, v1}, Lg70;-><init>(I)V

    .line 34
    .line 35
    .line 36
    sput-object v0, La42;->m:La42;

    .line 37
    .line 38
    new-instance v0, La42;

    .line 39
    .line 40
    invoke-direct {v0, v1}, Lg70;-><init>(I)V

    .line 41
    .line 42
    .line 43
    sput-object v0, La42;->n:La42;

    .line 44
    .line 45
    new-instance v0, La42;

    .line 46
    .line 47
    invoke-direct {v0, v1}, Lg70;-><init>(I)V

    .line 48
    .line 49
    .line 50
    sput-object v0, La42;->o:La42;

    .line 51
    .line 52
    new-instance v0, La42;

    .line 53
    .line 54
    invoke-direct {v0, v1}, Lg70;-><init>(I)V

    .line 55
    .line 56
    .line 57
    sput-object v0, La42;->p:La42;

    .line 58
    .line 59
    new-instance v0, La42;

    .line 60
    .line 61
    invoke-direct {v0, v1}, Lg70;-><init>(I)V

    .line 62
    .line 63
    .line 64
    sput-object v0, La42;->q:La42;

    .line 65
    .line 66
    return-void
.end method
