###### Class defpackage.xe3 (xe3)
.class public final Lxe3;
.super Lze3;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final a:Lcl1;


# direct methods
.method public constructor <init>(Lcl1;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lxe3;->a:Lcl1;

    .line 5
    .line 6
    return-void
.end method
