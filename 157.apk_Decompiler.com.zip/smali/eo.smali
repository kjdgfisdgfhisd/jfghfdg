###### Class defpackage.eo (eo)
.class public abstract Leo;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field public static final a:Ljt3;

.field public static final b:Ljt3;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    sget-object v0, Lz6;->e:Lz6;

    .line 2
    .line 3
    sget v1, Lzn;->a:I

    .line 4
    .line 5
    new-instance v1, Ljt3;

    .line 6
    .line 7
    invoke-direct {v1, v0}, Ljt3;-><init>(Lft0;)V

    .line 8
    .line 9
    .line 10
    sput-object v1, Leo;->a:Ljt3;

    .line 11
    .line 12
    sget-object v0, Lz6;->f:Lz6;

    .line 13
    .line 14
    new-instance v1, Ljt3;

    .line 15
    .line 16
    invoke-direct {v1, v0}, Ljt3;-><init>(Lft0;)V

    .line 17
    .line 18
    .line 19
    sput-object v1, Leo;->b:Ljt3;

    .line 20
    .line 21
    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    .line 22
    .line 23
    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    .line 24
    .line 25
    .line 26
    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    .line 27
    .line 28
    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    .line 29
    .line 30
    .line 31
    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    .line 32
    .line 33
    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    .line 34
    .line 35
    .line 36
    return-void
.end method
