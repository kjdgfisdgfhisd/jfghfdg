###### Class defpackage.nb3 (nb3)
.class public abstract Lnb3;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field public static final DISPATCH_MODE_CONTINUE_ON_SUBTREE:I = 0x1

.field public static final DISPATCH_MODE_STOP:I


# instance fields
.field mDispachedInsets:Lqc3;

.field private final mDispatchMode:I


# direct methods
.method public constructor <init>(I)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput p1, p0, Lnb3;->mDispatchMode:I

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final getDispatchMode()I
    .registers 1

    .line 1
    iget p0, p0, Lnb3;->mDispatchMode:I

    .line 2
    .line 3
    return p0
.end method

.method public abstract onEnd(Lvb3;)V
.end method

.method public abstract onPrepare(Lvb3;)V
.end method

.method public abstract onProgress(Lqc3;Ljava/util/List;)Lqc3;
.end method

.method public onStart(Lvb3;Lmb3;)Lmb3;
    .registers 3

    .line 1
    return-object p2
.end method
