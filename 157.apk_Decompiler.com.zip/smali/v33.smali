###### Class defpackage.v33 (v33)
.class public final Lv33;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lif1;


# static fields
.field public static final a:Lv33;

.field public static final b:Lh11;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lv33;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lv33;->a:Lv33;

    .line 7
    .line 8
    const-string v0, "kotlin.UByte"

    .line 9
    .line 10
    sget-object v1, Lpn;->a:Lpn;

    .line 11
    .line 12
    invoke-static {v1, v0}, Liw0;->a(Lif1;Ljava/lang/String;)Lh11;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    sput-object v0, Lv33;->b:Lh11;

    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final deserialize(Lz60;)Ljava/lang/Object;
    .registers 2

    .line 1
    sget-object p0, Lv33;->b:Lh11;

    .line 2
    .line 3
    invoke-interface {p1, p0}, Lz60;->v(Lwk2;)Lz60;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    invoke-interface {p0}, Lz60;->u()B

    .line 8
    .line 9
    .line 10
    move-result p0

    .line 11
    new-instance p1, Lr33;

    .line 12
    .line 13
    invoke-direct {p1, p0}, Lr33;-><init>(B)V

    .line 14
    .line 15
    .line 16
    return-object p1
.end method

.method public final getDescriptor()Lwk2;
    .registers 1

    .line 1
    sget-object p0, Lv33;->b:Lh11;

    .line 2
    .line 3
    return-object p0
.end method

.method public final serialize(Lbi0;Ljava/lang/Object;)V
    .registers 3

    .line 1
    check-cast p2, Lr33;

    .line 2
    .line 3
    iget-byte p0, p2, Lr33;->a:B

    .line 4
    .line 5
    sget-object p2, Lv33;->b:Lh11;

    .line 6
    .line 7
    invoke-interface {p1, p2}, Lbi0;->j(Lwk2;)Lbi0;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    invoke-interface {p1, p0}, Lbi0;->h(B)V

    .line 12
    .line 13
    .line 14
    return-void
.end method
