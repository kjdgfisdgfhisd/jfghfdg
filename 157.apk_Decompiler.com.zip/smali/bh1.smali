###### Class defpackage.bh1 (bh1)
.class public final Lbh1;
.super Lzs;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final g:Lfk;

.field public final j:Lxc2;

.field public final l:Lxt1;

.field public final m:Lfk;

.field public final n:Lrv2;

.field public final o:Ljt;

.field public final p:Lot1;

.field public final q:Lua3;

.field public final r:Z

.field public final s:Llb0;

.field public final t:Lfh1;

.field public final u:Lvj2;

.field public final v:Ll11;

.field public final w:Luh1;

.field public final x:Lzg1;

.field public final y:Lzl1;


# direct methods
.method static constructor <clinit>()V
    .registers 7

    .line 1
    const-string v5, "notifyAll"

    .line 2
    .line 3
    const-string v6, "toString"

    .line 4
    .line 5
    const-string v0, "equals"

    .line 6
    .line 7
    const-string v1, "hashCode"

    .line 8
    .line 9
    const-string v2, "getClass"

    .line 10
    .line 11
    const-string v3, "wait"

    .line 12
    .line 13
    const-string v4, "notify"

    .line 14
    .line 15
    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-static {v0}, Lub;->U([Ljava/lang/Object;)Ljava/util/Set;

    .line 20
    .line 21
    .line 22
    return-void
.end method

.method public constructor <init>(Lfk;Lm60;Lxc2;Lxt1;)V
    .registers 13

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    iget-object v0, p1, Lfk;->a:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v0, Lx41;

    .line 13
    .line 14
    iget-object v0, v0, Lx41;->a:Lcm1;

    .line 15
    .line 16
    invoke-virtual {p3}, Lxc2;->e()Ldv1;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    invoke-static {p3}, Lby0;->A(Lp41;)Lbi2;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    invoke-direct {p0, v0, p2, v1, v2}, Lzs;-><init>(Lcm1;Lm60;Ldv1;Loq2;)V

    .line 25
    .line 26
    .line 27
    iput-object p1, p0, Lbh1;->g:Lfk;

    .line 28
    .line 29
    iput-object p3, p0, Lbh1;->j:Lxc2;

    .line 30
    .line 31
    iput-object p4, p0, Lbh1;->l:Lxt1;

    .line 32
    .line 33
    const/4 p2, 0x4

    .line 34
    invoke-static {p1, p0, p3, p2}, Lxm3;->b(Lfk;Lnt;Lxc2;I)Lfk;

    .line 35
    .line 36
    .line 37
    move-result-object v1

    .line 38
    iput-object v1, p0, Lbh1;->m:Lfk;

    .line 39
    .line 40
    iget-object p1, v1, Lfk;->a:Ljava/lang/Object;

    .line 41
    .line 42
    check-cast p1, Lx41;

    .line 43
    .line 44
    iget-object p1, p1, Lx41;->a:Lcm1;

    .line 45
    .line 46
    new-instance p2, Lah1;

    .line 47
    .line 48
    const/4 v0, 0x0

    .line 49
    invoke-direct {p2, p0, v0}, Lah1;-><init>(Lbh1;I)V

    .line 50
    .line 51
    .line 52
    new-instance v2, Lrv2;

    .line 53
    .line 54
    invoke-direct {v2, p2}, Lrv2;-><init>(Ldt0;)V

    .line 55
    .line 56
    .line 57
    iput-object v2, p0, Lbh1;->n:Lrv2;

    .line 58
    .line 59
    iget-object p2, p3, Lxc2;->a:Ljava/lang/Class;

    .line 60
    .line 61
    invoke-virtual {p2}, Ljava/lang/Class;->isAnnotation()Z

    .line 62
    .line 63
    .line 64
    move-result v2

    .line 65
    if-eqz v2, :cond_45

    .line 66
    .line 67
    sget-object v2, Ljt;->e:Ljt;

    .line 68
    .line 69
    goto :goto_59

    .line 70
    :cond_45
    invoke-virtual {p2}, Ljava/lang/Class;->isInterface()Z

    .line 71
    .line 72
    .line 73
    move-result v2

    .line 74
    if-eqz v2, :cond_4e

    .line 75
    .line 76
    sget-object v2, Ljt;->b:Ljt;

    .line 77
    .line 78
    goto :goto_59

    .line 79
    :cond_4e
    invoke-virtual {p2}, Ljava/lang/Class;->isEnum()Z

    .line 80
    .line 81
    .line 82
    move-result v2

    .line 83
    if-eqz v2, :cond_57

    .line 84
    .line 85
    sget-object v2, Ljt;->c:Ljt;

    .line 86
    .line 87
    goto :goto_59

    .line 88
    :cond_57
    sget-object v2, Ljt;->a:Ljt;

    .line 89
    .line 90
    :goto_59
    iput-object v2, p0, Lbh1;->o:Ljt;

    .line 91
    .line 92
    invoke-virtual {p2}, Ljava/lang/Class;->isAnnotation()Z

    .line 93
    .line 94
    .line 95
    move-result v2

    .line 96
    sget-object v3, Lot1;->b:Lot1;

    .line 97
    .line 98
    const/4 v6, 0x1

    .line 99
    if-nez v2, :cond_a4

    .line 100
    .line 101
    invoke-virtual {p2}, Ljava/lang/Class;->isEnum()Z

    .line 102
    .line 103
    .line 104
    move-result v2

    .line 105
    if-eqz v2, :cond_6b

    .line 106
    .line 107
    goto :goto_a4

    .line 108
    :cond_6b
    invoke-virtual {p3}, Lxc2;->h()Z

    .line 109
    .line 110
    .line 111
    move-result v2

    .line 112
    invoke-virtual {p3}, Lxc2;->h()Z

    .line 113
    .line 114
    .line 115
    move-result v4

    .line 116
    if-nez v4, :cond_88

    .line 117
    .line 118
    invoke-virtual {p2}, Ljava/lang/Class;->getModifiers()I

    .line 119
    .line 120
    .line 121
    move-result v4

    .line 122
    invoke-static {v4}, Ljava/lang/reflect/Modifier;->isAbstract(I)Z

    .line 123
    .line 124
    .line 125
    move-result v4

    .line 126
    if-nez v4, :cond_88

    .line 127
    .line 128
    invoke-virtual {p2}, Ljava/lang/Class;->isInterface()Z

    .line 129
    .line 130
    .line 131
    move-result v4

    .line 132
    if-eqz v4, :cond_86

    .line 133
    .line 134
    goto :goto_88

    .line 135
    :cond_86
    move v4, v0

    .line 136
    goto :goto_89

    .line 137
    :cond_88
    :goto_88
    move v4, v6

    .line 138
    :goto_89
    invoke-virtual {p2}, Ljava/lang/Class;->getModifiers()I

    .line 139
    .line 140
    .line 141
    move-result v5

    .line 142
    invoke-static {v5}, Ljava/lang/reflect/Modifier;->isFinal(I)Z

    .line 143
    .line 144
    .line 145
    move-result v5

    .line 146
    sget-object v7, Lot1;->a:Lxa1;

    .line 147
    .line 148
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 149
    .line 150
    .line 151
    if-eqz v2, :cond_9b

    .line 152
    .line 153
    sget-object v3, Lot1;->c:Lot1;

    .line 154
    .line 155
    goto :goto_a4

    .line 156
    :cond_9b
    if-eqz v4, :cond_a0

    .line 157
    .line 158
    sget-object v3, Lot1;->e:Lot1;

    .line 159
    .line 160
    goto :goto_a4

    .line 161
    :cond_a0
    if-nez v5, :cond_a4

    .line 162
    .line 163
    sget-object v3, Lot1;->d:Lot1;

    .line 164
    .line 165
    :cond_a4
    :goto_a4
    iput-object v3, p0, Lbh1;->p:Lot1;

    .line 166
    .line 167
    invoke-virtual {p2}, Ljava/lang/Class;->getModifiers()I

    .line 168
    .line 169
    .line 170
    move-result v2

    .line 171
    invoke-static {v2}, Ljava/lang/reflect/Modifier;->isPublic(I)Z

    .line 172
    .line 173
    .line 174
    move-result v3

    .line 175
    if-eqz v3, :cond_b3

    .line 176
    .line 177
    sget-object v2, Loa3;->c:Loa3;

    .line 178
    .line 179
    goto :goto_d0

    .line 180
    :cond_b3
    invoke-static {v2}, Ljava/lang/reflect/Modifier;->isPrivate(I)Z

    .line 181
    .line 182
    .line 183
    move-result v3

    .line 184
    if-eqz v3, :cond_bc

    .line 185
    .line 186
    sget-object v2, Lla3;->c:Lla3;

    .line 187
    .line 188
    goto :goto_d0

    .line 189
    :cond_bc
    invoke-static {v2}, Ljava/lang/reflect/Modifier;->isProtected(I)Z

    .line 190
    .line 191
    .line 192
    move-result v3

    .line 193
    if-eqz v3, :cond_ce

    .line 194
    .line 195
    invoke-static {v2}, Ljava/lang/reflect/Modifier;->isStatic(I)Z

    .line 196
    .line 197
    .line 198
    move-result v2

    .line 199
    if-eqz v2, :cond_cb

    .line 200
    .line 201
    sget-object v2, Lp51;->c:Lp51;

    .line 202
    .line 203
    goto :goto_d0

    .line 204
    :cond_cb
    sget-object v2, Lo51;->c:Lo51;

    .line 205
    .line 206
    goto :goto_d0

    .line 207
    :cond_ce
    sget-object v2, Ln51;->c:Ln51;

    .line 208
    .line 209
    :goto_d0
    iput-object v2, p0, Lbh1;->q:Lua3;

    .line 210
    .line 211
    invoke-virtual {p2}, Ljava/lang/Class;->getDeclaringClass()Ljava/lang/Class;

    .line 212
    .line 213
    .line 214
    move-result-object v2

    .line 215
    if-eqz v2, :cond_de

    .line 216
    .line 217
    new-instance v3, Lxc2;

    .line 218
    .line 219
    invoke-direct {v3, v2}, Lxc2;-><init>(Ljava/lang/Class;)V

    .line 220
    .line 221
    .line 222
    goto :goto_df

    .line 223
    :cond_de
    const/4 v3, 0x0

    .line 224
    :goto_df
    if-eqz v3, :cond_ed

    .line 225
    .line 226
    invoke-virtual {p2}, Ljava/lang/Class;->getModifiers()I

    .line 227
    .line 228
    .line 229
    move-result p2

    .line 230
    invoke-static {p2}, Ljava/lang/reflect/Modifier;->isStatic(I)Z

    .line 231
    .line 232
    .line 233
    move-result p2

    .line 234
    if-nez p2, :cond_ed

    .line 235
    .line 236
    move p2, v6

    .line 237
    goto :goto_ee

    .line 238
    :cond_ed
    move p2, v0

    .line 239
    :goto_ee
    iput-boolean p2, p0, Lbh1;->r:Z

    .line 240
    .line 241
    new-instance p2, Llb0;

    .line 242
    .line 243
    invoke-direct {p2, p0}, Llb0;-><init>(Lbh1;)V

    .line 244
    .line 245
    .line 246
    iput-object p2, p0, Lbh1;->s:Llb0;

    .line 247
    .line 248
    move p2, v0

    .line 249
    new-instance v0, Lfh1;

    .line 250
    .line 251
    if-eqz p4, :cond_fe

    .line 252
    .line 253
    move v4, v6

    .line 254
    goto :goto_ff

    .line 255
    :cond_fe
    move v4, p2

    .line 256
    :goto_ff
    const/4 v5, 0x0

    .line 257
    move-object v2, p0

    .line 258
    move-object v3, p3

    .line 259
    invoke-direct/range {v0 .. v5}, Lfh1;-><init>(Lfk;Lxt1;Lxc2;ZLfh1;)V

    .line 260
    .line 261
    .line 262
    iput-object v0, v2, Lbh1;->t:Lfh1;

    .line 263
    .line 264
    sget-object p0, Lvj2;->d:Lxa1;

    .line 265
    .line 266
    new-instance p2, Lk;

    .line 267
    .line 268
    const/16 p3, 0xf

    .line 269
    .line 270
    invoke-direct {p2, p3, v2}, Lk;-><init>(ILjava/lang/Object;)V

    .line 271
    .line 272
    .line 273
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 274
    .line 275
    .line 276
    new-instance p0, Lvj2;

    .line 277
    .line 278
    invoke-direct {p0, v2, p1, p2}, Lvj2;-><init>(Lo;Lcm1;Lft0;)V

    .line 279
    .line 280
    .line 281
    iput-object p0, v2, Lbh1;->u:Lvj2;

    .line 282
    .line 283
    new-instance p0, Ll11;

    .line 284
    .line 285
    invoke-direct {p0, v0}, Ll11;-><init>(Lvr1;)V

    .line 286
    .line 287
    .line 288
    iput-object p0, v2, Lbh1;->v:Ll11;

    .line 289
    .line 290
    new-instance p0, Luh1;

    .line 291
    .line 292
    invoke-direct {p0, v1, v3, v2}, Luh1;-><init>(Lfk;Lxc2;Lbh1;)V

    .line 293
    .line 294
    .line 295
    iput-object p0, v2, Lbh1;->w:Luh1;

    .line 296
    .line 297
    invoke-static {v1, v3}, Lk63;->A(Lfk;Lg41;)Lzg1;

    .line 298
    .line 299
    .line 300
    move-result-object p0

    .line 301
    iput-object p0, v2, Lbh1;->x:Lzg1;

    .line 302
    .line 303
    new-instance p0, Lah1;

    .line 304
    .line 305
    invoke-direct {p0, v2, v6}, Lah1;-><init>(Lbh1;I)V

    .line 306
    .line 307
    .line 308
    new-instance p2, Lzl1;

    .line 309
    .line 310
    invoke-direct {p2, p1, p0}, Lyl1;-><init>(Lcm1;Ldt0;)V

    .line 311
    .line 312
    .line 313
    iput-object p2, v2, Lbh1;->y:Lzl1;

    .line 314
    .line 315
    return-void
.end method


# virtual methods
.method public final A0()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final B()Lvr1;
    .registers 1

    .line 1
    iget-object p0, p0, Lbh1;->w:Luh1;

    .line 2
    .line 3
    return-object p0
.end method

.method public final B0()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final C()Lp13;
    .registers 1

    .line 1
    iget-object p0, p0, Lbh1;->s:Llb0;

    .line 2
    .line 3
    return-object p0
.end method

.method public final D()Lot1;
    .registers 1

    .line 1
    iget-object p0, p0, Lbh1;->p:Lot1;

    .line 2
    .line 3
    return-object p0
.end method

.method public final E0()Lfh1;
    .registers 1

    .line 1
    invoke-super {p0}, Lo;->q0()Lvr1;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    check-cast p0, Lfh1;

    .line 6
    .line 7
    return-object p0
.end method

.method public final Y()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final Z()Z
    .registers 1

    .line 1
    iget-boolean p0, p0, Lbh1;->r:Z

    .line 2
    .line 3
    return p0
.end method

.method public final a()Ljava/util/Collection;
    .registers 1

    .line 1
    iget-object p0, p0, Lbh1;->t:Lfh1;

    .line 2
    .line 3
    iget-object p0, p0, Lfh1;->q:Lzl1;

    .line 4
    .line 5
    invoke-virtual {p0}, Lzl1;->invoke()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    check-cast p0, Ljava/util/List;

    .line 10
    .line 11
    check-cast p0, Ljava/util/Collection;

    .line 12
    .line 13
    return-object p0
.end method

.method public final g()Lya0;
    .registers 3

    .line 1
    sget-object v0, Lza0;->a:Lya0;

    .line 2
    .line 3
    iget-object v1, p0, Lbh1;->q:Lua3;

    .line 4
    .line 5
    invoke-static {v1, v0}, Ld31;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_23

    .line 10
    .line 11
    iget-object p0, p0, Lbh1;->j:Lxc2;

    .line 12
    .line 13
    iget-object p0, p0, Lxc2;->a:Ljava/lang/Class;

    .line 14
    .line 15
    invoke-virtual {p0}, Ljava/lang/Class;->getDeclaringClass()Ljava/lang/Class;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    if-eqz p0, :cond_1a

    .line 20
    .line 21
    new-instance v0, Lxc2;

    .line 22
    .line 23
    invoke-direct {v0, p0}, Lxc2;-><init>(Ljava/lang/Class;)V

    .line 24
    .line 25
    .line 26
    goto :goto_1b

    .line 27
    :cond_1a
    const/4 v0, 0x0

    .line 28
    :goto_1b
    if-nez v0, :cond_23

    .line 29
    .line 30
    sget-object p0, Lo41;->a:Lya0;

    .line 31
    .line 32
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 33
    .line 34
    .line 35
    return-object p0

    .line 36
    :cond_23
    invoke-static {v1}, Lh50;->p(Lua3;)Lya0;

    .line 37
    .line 38
    .line 39
    move-result-object p0

    .line 40
    return-object p0
.end method

.method public final getAnnotations()Ll7;
    .registers 1

    .line 1
    iget-object p0, p0, Lbh1;->x:Lzg1;

    .line 2
    .line 3
    return-object p0
.end method

.method public final h0()Lvr1;
    .registers 1

    .line 1
    iget-object p0, p0, Lbh1;->v:Ll11;

    .line 2
    .line 3
    return-object p0
.end method

.method public final i()Ljt;
    .registers 1

    .line 1
    iget-object p0, p0, Lbh1;->o:Ljt;

    .line 2
    .line 3
    return-object p0
.end method

.method public final o()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final o0()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final q0()Lvr1;
    .registers 1

    .line 1
    invoke-super {p0}, Lo;->q0()Lvr1;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    check-cast p0, Lfh1;

    .line 6
    .line 7
    return-object p0
.end method

.method public final s0()Ljava/util/List;
    .registers 1

    .line 1
    iget-object p0, p0, Lbh1;->y:Lzl1;

    .line 2
    .line 3
    invoke-virtual {p0}, Lzl1;->invoke()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Ljava/util/List;

    .line 8
    .line 9
    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "Lazy Java class "

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget v1, Lxa0;->a:I

    .line 9
    .line 10
    invoke-static {p0}, Lva0;->g(Lm60;)Lar0;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 18
    .line 19
    .line 20
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    return-object p0
.end method

.method public final u0(Llg1;)Lvr1;
    .registers 3

    .line 1
    iget-object p0, p0, Lbh1;->u:Lvj2;

    .line 2
    .line 3
    iget-object p1, p0, Lvj2;->a:Lo;

    .line 4
    .line 5
    sget v0, Lxa0;->a:I

    .line 6
    .line 7
    invoke-static {p1}, Lva0;->d(Lm60;)Lzt1;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    iget-object p0, p0, Lvj2;->c:Lzl1;

    .line 15
    .line 16
    sget-object p1, Lvj2;->e:[Laf1;

    .line 17
    .line 18
    const/4 v0, 0x0

    .line 19
    aget-object p1, p1, v0

    .line 20
    .line 21
    invoke-static {p0, p1}, Lmw1;->p(Lax1;Laf1;)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object p0

    .line 25
    check-cast p0, Lvr1;

    .line 26
    .line 27
    check-cast p0, Lfh1;

    .line 28
    .line 29
    return-object p0
.end method

.method public final w0()Lvs;
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return-object p0
.end method

.method public final x0()Lu63;
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return-object p0
.end method

.method public final y()Ljava/util/Collection;
    .registers 12

    .line 1
    iget-object v0, p0, Lbh1;->p:Lot1;

    .line 2
    .line 3
    sget-object v1, Lot1;->c:Lot1;

    .line 4
    .line 5
    if-ne v0, v1, :cond_bb

    .line 6
    .line 7
    sget-object v0, Ly23;->b:Ly23;

    .line 8
    .line 9
    const/4 v1, 0x7

    .line 10
    const/4 v2, 0x0

    .line 11
    const/4 v4, 0x0

    .line 12
    invoke-static {v0, v2, v4, v1}, Ld31;->B(Ly23;ZLwh1;I)Ld51;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    iget-object v1, p0, Lbh1;->j:Lxc2;

    .line 17
    .line 18
    iget-object v1, v1, Lxc2;->a:Ljava/lang/Class;

    .line 19
    .line 20
    sget-object v3, Lyo1;->h:Lyx2;

    .line 21
    .line 22
    if-nez v3, :cond_46

    .line 23
    .line 24
    const-class v3, Ljava/lang/Class;

    .line 25
    .line 26
    :try_start_19
    new-instance v5, Lyx2;

    .line 27
    .line 28
    const-string v6, "isSealed"

    .line 29
    .line 30
    invoke-virtual {v3, v6, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 31
    .line 32
    .line 33
    move-result-object v6

    .line 34
    const-string v7, "getPermittedSubclasses"

    .line 35
    .line 36
    invoke-virtual {v3, v7, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 37
    .line 38
    .line 39
    move-result-object v7

    .line 40
    const-string v8, "isRecord"

    .line 41
    .line 42
    invoke-virtual {v3, v8, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 43
    .line 44
    .line 45
    move-result-object v8

    .line 46
    const-string v9, "getRecordComponents"

    .line 47
    .line 48
    invoke-virtual {v3, v9, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 49
    .line 50
    .line 51
    move-result-object v9

    .line 52
    const/16 v10, 0xe

    .line 53
    .line 54
    invoke-direct/range {v5 .. v10}, Lyx2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    :try_end_38
    .catch Ljava/lang/NoSuchMethodException; {:try_start_19 .. :try_end_38} :catch_3a

    .line 55
    .line 56
    .line 57
    move-object v3, v5

    .line 58
    goto :goto_44

    .line 59
    :catch_3a
    new-instance v3, Lyx2;

    .line 60
    .line 61
    const/16 v8, 0xe

    .line 62
    .line 63
    move-object v5, v4

    .line 64
    move-object v6, v4

    .line 65
    move-object v7, v4

    .line 66
    invoke-direct/range {v3 .. v8}, Lyx2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 67
    .line 68
    .line 69
    :goto_44
    sput-object v3, Lyo1;->h:Lyx2;

    .line 70
    .line 71
    :cond_46
    iget-object v3, v3, Lyx2;->d:Ljava/lang/Object;

    .line 72
    .line 73
    check-cast v3, Ljava/lang/reflect/Method;

    .line 74
    .line 75
    if-nez v3, :cond_4e

    .line 76
    .line 77
    move-object v1, v4

    .line 78
    goto :goto_57

    .line 79
    :cond_4e
    invoke-virtual {v3, v1, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object v1

    .line 83
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 84
    .line 85
    .line 86
    check-cast v1, [Ljava/lang/Class;

    .line 87
    .line 88
    :goto_57
    if-eqz v1, :cond_76

    .line 89
    .line 90
    new-instance v3, Ljava/util/ArrayList;

    .line 91
    .line 92
    array-length v5, v1

    .line 93
    invoke-direct {v3, v5}, Ljava/util/ArrayList;-><init>(I)V

    .line 94
    .line 95
    .line 96
    array-length v5, v1

    .line 97
    :goto_60
    if-ge v2, v5, :cond_6f

    .line 98
    .line 99
    aget-object v6, v1, v2

    .line 100
    .line 101
    new-instance v7, Lad2;

    .line 102
    .line 103
    invoke-direct {v7, v6}, Lad2;-><init>(Ljava/lang/reflect/Type;)V

    .line 104
    .line 105
    .line 106
    invoke-virtual {v3, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 107
    .line 108
    .line 109
    add-int/lit8 v2, v2, 0x1

    .line 110
    .line 111
    goto :goto_60

    .line 112
    :cond_6f
    new-instance v1, Lyb;

    .line 113
    .line 114
    const/4 v2, 0x1

    .line 115
    invoke-direct {v1, v2, v3}, Lyb;-><init>(ILjava/lang/Object;)V

    .line 116
    .line 117
    .line 118
    goto :goto_78

    .line 119
    :cond_76
    sget-object v1, Lwh0;->a:Lwh0;

    .line 120
    .line 121
    :goto_78
    new-instance v2, Ljava/util/ArrayList;

    .line 122
    .line 123
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 124
    .line 125
    .line 126
    invoke-interface {v1}, Lqk2;->iterator()Ljava/util/Iterator;

    .line 127
    .line 128
    .line 129
    move-result-object v1

    .line 130
    :cond_81
    :goto_81
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 131
    .line 132
    .line 133
    move-result v3

    .line 134
    if-eqz v3, :cond_ad

    .line 135
    .line 136
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 137
    .line 138
    .line 139
    move-result-object v3

    .line 140
    check-cast v3, Lad2;

    .line 141
    .line 142
    iget-object v5, p0, Lbh1;->m:Lfk;

    .line 143
    .line 144
    iget-object v5, v5, Lfk;->e:Ljava/lang/Object;

    .line 145
    .line 146
    check-cast v5, Lna;

    .line 147
    .line 148
    invoke-virtual {v5, v3, v0}, Lna;->U(Lld2;Ld51;)Lgg1;

    .line 149
    .line 150
    .line 151
    move-result-object v3

    .line 152
    invoke-virtual {v3}, Lgg1;->y()Lp13;

    .line 153
    .line 154
    .line 155
    move-result-object v3

    .line 156
    invoke-interface {v3}, Lp13;->c()Lau;

    .line 157
    .line 158
    .line 159
    move-result-object v3

    .line 160
    instance-of v5, v3, Lxt1;

    .line 161
    .line 162
    if-eqz v5, :cond_a6

    .line 163
    .line 164
    check-cast v3, Lxt1;

    .line 165
    .line 166
    goto :goto_a7

    .line 167
    :cond_a6
    move-object v3, v4

    .line 168
    :goto_a7
    if-eqz v3, :cond_81

    .line 169
    .line 170
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 171
    .line 172
    .line 173
    goto :goto_81

    .line 174
    :cond_ad
    new-instance p0, Lkr1;

    .line 175
    .line 176
    const/16 v0, 0xa

    .line 177
    .line 178
    invoke-direct {p0, v0}, Lkr1;-><init>(I)V

    .line 179
    .line 180
    .line 181
    invoke-static {v2, p0}, Lgv;->u0(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    .line 182
    .line 183
    .line 184
    move-result-object p0

    .line 185
    check-cast p0, Ljava/util/Collection;

    .line 186
    .line 187
    return-object p0

    .line 188
    :cond_bb
    sget-object p0, Lth0;->a:Lth0;

    .line 189
    .line 190
    return-object p0
.end method

.method public final y0()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final z0()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method
