###### Class defpackage.y73 (y73)
.class public interface abstract Ly73;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# virtual methods
.method public abstract d(Landroid/media/MediaMetadataRetriever;Ljava/lang/Object;)V
.end method

.method public abstract f(Landroid/media/MediaExtractor;Ljava/lang/Object;)V
.end method
