###### Class defpackage.n40 (n40)
.class public final Ln40;
.super Lwq1;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final s:Landroid/graphics/RectF;


# direct methods
.method public constructor <init>(Ln40;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lwq1;-><init>(Lwq1;)V

    .line 2
    .line 3
    .line 4
    iget-object p1, p1, Ln40;->s:Landroid/graphics/RectF;

    .line 5
    .line 6
    iput-object p1, p0, Ln40;->s:Landroid/graphics/RectF;

    .line 7
    .line 8
    return-void
.end method

.method public constructor <init>(Lvm2;Landroid/graphics/RectF;)V
    .registers 3

    .line 9
    invoke-direct {p0, p1}, Lwq1;-><init>(Ltm2;)V

    .line 10
    iput-object p2, p0, Ln40;->s:Landroid/graphics/RectF;

    return-void
.end method


# virtual methods
.method public final newDrawable()Landroid/graphics/drawable/Drawable;
    .registers 2

    .line 1
    new-instance v0, Lo40;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Lyq1;-><init>(Lwq1;)V

    .line 4
    .line 5
    .line 6
    iput-object p0, v0, Lo40;->J:Ln40;

    .line 7
    .line 8
    invoke-virtual {v0}, Lyq1;->invalidateSelf()V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method
