###### Class defpackage.zn1 (zn1)
.class public final synthetic Lzn1;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lft0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:Ljava/lang/String;

.field public final synthetic d:Ljava/lang/Object;

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic f:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lcc/bomber/ui/MainActivity;Ljava/lang/String;Ljava/lang/String;Ljava/util/Calendar;Ljava/util/Calendar;)V
    .registers 7

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lzn1;->a:I

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p4, p0, Lzn1;->d:Ljava/lang/Object;

    .line 8
    .line 9
    iput-object p1, p0, Lzn1;->f:Ljava/lang/Object;

    .line 10
    .line 11
    iput-object p5, p0, Lzn1;->e:Ljava/lang/Object;

    .line 12
    .line 13
    iput-object p2, p0, Lzn1;->b:Ljava/lang/String;

    .line 14
    .line 15
    iput-object p3, p0, Lzn1;->c:Ljava/lang/String;

    .line 16
    .line 17
    return-void
.end method

.method public synthetic constructor <init>(Lcc/bomber/x/g/c;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcc/bomber/x/g/c;)V
    .registers 7

    .line 18
    const/4 v0, 0x1

    iput v0, p0, Lzn1;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lzn1;->d:Ljava/lang/Object;

    iput-object p2, p0, Lzn1;->b:Ljava/lang/String;

    iput-object p3, p0, Lzn1;->c:Ljava/lang/String;

    iput-object p4, p0, Lzn1;->e:Ljava/lang/Object;

    iput-object p5, p0, Lzn1;->f:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;I)V
    .registers 7

    .line 19
    iput p6, p0, Lzn1;->a:I

    iput-object p1, p0, Lzn1;->b:Ljava/lang/String;

    iput-object p2, p0, Lzn1;->c:Ljava/lang/String;

    iput-object p3, p0, Lzn1;->d:Ljava/lang/Object;

    iput-object p4, p0, Lzn1;->e:Ljava/lang/Object;

    iput-object p5, p0, Lzn1;->f:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 13

    .line 1
    iget v0, p0, Lzn1;->a:I

    .line 2
    .line 3
    iget-object v1, p0, Lzn1;->f:Ljava/lang/Object;

    .line 4
    .line 5
    iget-object v2, p0, Lzn1;->e:Ljava/lang/Object;

    .line 6
    .line 7
    iget-object v3, p0, Lzn1;->d:Ljava/lang/Object;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_5e

    .line 10
    .line 11
    .line 12
    move-object v6, v3

    .line 13
    check-cast v6, Ljava/lang/String;

    .line 14
    .line 15
    move-object v7, v2

    .line 16
    check-cast v7, Ljava/lang/String;

    .line 17
    .line 18
    move-object v8, v1

    .line 19
    check-cast v8, Ljava/lang/String;

    .line 20
    .line 21
    move-object v9, p1

    .line 22
    check-cast v9, Lyx0;

    .line 23
    .line 24
    iget-object v4, p0, Lzn1;->b:Ljava/lang/String;

    .line 25
    .line 26
    iget-object v5, p0, Lzn1;->c:Ljava/lang/String;

    .line 27
    .line 28
    invoke-static/range {v4 .. v9}, Lcc/bomber/x/i/c;->z1(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lyx0;)Lw43;

    .line 29
    .line 30
    .line 31
    move-result-object p0

    .line 32
    return-object p0

    .line 33
    :pswitch_20
    check-cast v3, Ljava/lang/String;

    .line 34
    .line 35
    check-cast v2, Ljava/lang/String;

    .line 36
    .line 37
    move-object v4, v1

    .line 38
    check-cast v4, Lcc/bomber/x/g/c;

    .line 39
    .line 40
    move-object v5, p1

    .line 41
    check-cast v5, Lorg/json/JSONObject;

    .line 42
    .line 43
    iget-object v0, p0, Lzn1;->b:Ljava/lang/String;

    .line 44
    .line 45
    iget-object v1, p0, Lzn1;->c:Ljava/lang/String;

    .line 46
    .line 47
    move-object v10, v3

    .line 48
    move-object v3, v2

    .line 49
    move-object v2, v10

    .line 50
    invoke-static/range {v0 .. v5}, Lcc/bomber/x/i/c;->M(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcc/bomber/x/g/c;Lorg/json/JSONObject;)Lw43;

    .line 51
    .line 52
    .line 53
    move-result-object p0

    .line 54
    return-object p0

    .line 55
    :pswitch_36
    move-object v0, v3

    .line 56
    check-cast v0, Lcc/bomber/x/g/c;

    .line 57
    .line 58
    move-object v3, v2

    .line 59
    check-cast v3, Ljava/lang/String;

    .line 60
    .line 61
    move-object v4, v1

    .line 62
    check-cast v4, Lcc/bomber/x/g/c;

    .line 63
    .line 64
    move-object v5, p1

    .line 65
    check-cast v5, Lnu1;

    .line 66
    .line 67
    iget-object v1, p0, Lzn1;->b:Ljava/lang/String;

    .line 68
    .line 69
    iget-object v2, p0, Lzn1;->c:Ljava/lang/String;

    .line 70
    .line 71
    invoke-static/range {v0 .. v5}, Lcc/bomber/x/h/a;->W(Lcc/bomber/x/g/c;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcc/bomber/x/g/c;Lnu1;)Lw43;

    .line 72
    .line 73
    .line 74
    move-result-object p0

    .line 75
    return-object p0

    .line 76
    :pswitch_4b
    move-object v0, v3

    .line 77
    check-cast v0, Ljava/util/Calendar;

    .line 78
    .line 79
    check-cast v1, Lcc/bomber/ui/MainActivity;

    .line 80
    .line 81
    check-cast v2, Ljava/util/Calendar;

    .line 82
    .line 83
    iget-object v4, p0, Lzn1;->c:Ljava/lang/String;

    .line 84
    .line 85
    move-object v5, p1

    .line 86
    check-cast v5, Ljava/lang/Long;

    .line 87
    .line 88
    iget-object v3, p0, Lzn1;->b:Ljava/lang/String;

    .line 89
    .line 90
    invoke-static/range {v0 .. v5}, Lcc/bomber/ui/MainActivity;->A(Ljava/util/Calendar;Lcc/bomber/ui/MainActivity;Ljava/util/Calendar;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;)Lw43;

    .line 91
    .line 92
    .line 93
    move-result-object p0

    .line 94
    return-object p0

    .line 95
    :pswitch_data_5e
    .packed-switch 0x0
        :pswitch_4b
        :pswitch_36
        :pswitch_20
    .end packed-switch
.end method
