###### Class defpackage.iy1 (iy1)
.class public interface abstract Liy1;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# virtual methods
.method public abstract a(Lnm0;Ljava/lang/Object;)Liy1;
.end method

.method public abstract d(Lnm0;Z)Liy1;
.end method

.method public abstract e(Lnm0;I)Liy1;
.end method

.method public abstract f(Lnm0;D)Liy1;
.end method

.method public abstract g(Lnm0;J)Liy1;
.end method
