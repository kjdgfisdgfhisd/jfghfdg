###### Class defpackage.dq1 (dq1)
.class public final Ldq1;
.super Lub2;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final synthetic a:Lcom/google/android/material/datepicker/f;

.field public final synthetic b:Leq1;


# direct methods
.method public constructor <init>(Leq1;Lcom/google/android/material/datepicker/f;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Ldq1;->b:Leq1;

    .line 5
    .line 6
    iput-object p2, p0, Ldq1;->a:Lcom/google/android/material/datepicker/f;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a(Landroidx/recyclerview/widget/RecyclerView;I)V
    .registers 4

    .line 1
    if-nez p2, :cond_41

    .line 2
    .line 3
    iget-object p1, p0, Ldq1;->b:Leq1;

    .line 4
    .line 5
    iget-object p2, p1, Leq1;->v:Lf12;

    .line 6
    .line 7
    if-nez p2, :cond_9

    .line 8
    .line 9
    goto :goto_41

    .line 10
    :cond_9
    iget-object v0, p1, Leq1;->n:Landroidx/recyclerview/widget/RecyclerView;

    .line 11
    .line 12
    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/e;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Landroidx/recyclerview/widget/LinearLayoutManager;

    .line 17
    .line 18
    invoke-virtual {p2, v0}, Lf12;->e(Landroidx/recyclerview/widget/e;)Landroid/view/View;

    .line 19
    .line 20
    .line 21
    move-result-object p2

    .line 22
    if-eqz p2, :cond_3e

    .line 23
    .line 24
    invoke-static {p2}, Landroidx/recyclerview/widget/RecyclerView;->J(Landroid/view/View;)Landroidx/recyclerview/widget/g;

    .line 25
    .line 26
    .line 27
    move-result-object p2

    .line 28
    const/4 v0, -0x1

    .line 29
    if-eqz p2, :cond_23

    .line 30
    .line 31
    invoke-virtual {p2}, Landroidx/recyclerview/widget/g;->getAbsoluteAdapterPosition()I

    .line 32
    .line 33
    .line 34
    move-result p2

    .line 35
    goto :goto_24

    .line 36
    :cond_23
    move p2, v0

    .line 37
    :goto_24
    if-eq p2, v0, :cond_3e

    .line 38
    .line 39
    iget-object p0, p0, Ldq1;->a:Lcom/google/android/material/datepicker/f;

    .line 40
    .line 41
    invoke-virtual {p0, p2}, Lcom/google/android/material/datepicker/f;->a(I)Lcu1;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    iput-object v0, p1, Leq1;->f:Lcu1;

    .line 46
    .line 47
    iget-object v0, p1, Leq1;->t:Lcom/google/android/material/button/MaterialButton;

    .line 48
    .line 49
    invoke-virtual {p0, p2}, Lcom/google/android/material/datepicker/f;->a(I)Lcu1;

    .line 50
    .line 51
    .line 52
    move-result-object p0

    .line 53
    invoke-virtual {p0}, Lcu1;->d()Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object p0

    .line 57
    invoke-virtual {v0, p0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 58
    .line 59
    .line 60
    invoke-virtual {p1, p2}, Leq1;->t(I)V

    .line 61
    .line 62
    .line 63
    :cond_3e
    invoke-virtual {p1}, Leq1;->s()V

    .line 64
    .line 65
    .line 66
    :cond_41
    :goto_41
    return-void
.end method

.method public final b(Landroidx/recyclerview/widget/RecyclerView;II)V
    .registers 4

    .line 1
    iget-object p1, p0, Ldq1;->b:Leq1;

    .line 2
    .line 3
    iget-object p3, p1, Leq1;->n:Landroidx/recyclerview/widget/RecyclerView;

    .line 4
    .line 5
    if-gez p2, :cond_11

    .line 6
    .line 7
    invoke-virtual {p3}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/e;

    .line 8
    .line 9
    .line 10
    move-result-object p2

    .line 11
    check-cast p2, Landroidx/recyclerview/widget/LinearLayoutManager;

    .line 12
    .line 13
    invoke-virtual {p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->N0()I

    .line 14
    .line 15
    .line 16
    move-result p2

    .line 17
    goto :goto_1b

    .line 18
    :cond_11
    invoke-virtual {p3}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/e;

    .line 19
    .line 20
    .line 21
    move-result-object p2

    .line 22
    check-cast p2, Landroidx/recyclerview/widget/LinearLayoutManager;

    .line 23
    .line 24
    invoke-virtual {p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->O0()I

    .line 25
    .line 26
    .line 27
    move-result p2

    .line 28
    :goto_1b
    iget-object p3, p1, Leq1;->v:Lf12;

    .line 29
    .line 30
    iget-object p0, p0, Ldq1;->a:Lcom/google/android/material/datepicker/f;

    .line 31
    .line 32
    if-nez p3, :cond_27

    .line 33
    .line 34
    invoke-virtual {p0, p2}, Lcom/google/android/material/datepicker/f;->a(I)Lcu1;

    .line 35
    .line 36
    .line 37
    move-result-object p3

    .line 38
    iput-object p3, p1, Leq1;->f:Lcu1;

    .line 39
    .line 40
    :cond_27
    iget-object p3, p1, Leq1;->t:Lcom/google/android/material/button/MaterialButton;

    .line 41
    .line 42
    invoke-virtual {p0, p2}, Lcom/google/android/material/datepicker/f;->a(I)Lcu1;

    .line 43
    .line 44
    .line 45
    move-result-object p0

    .line 46
    invoke-virtual {p0}, Lcu1;->d()Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object p0

    .line 50
    invoke-virtual {p3, p0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 51
    .line 52
    .line 53
    invoke-virtual {p1, p2}, Leq1;->t(I)V

    .line 54
    .line 55
    .line 56
    return-void
.end method
