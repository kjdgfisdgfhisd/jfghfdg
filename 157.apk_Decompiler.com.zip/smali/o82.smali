###### Class defpackage.o82 (o82)
.class public interface abstract annotation Lo82;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Ljava/lang/annotation/Annotation;


# annotations
.annotation system Ldalvik/annotation/AnnotationDefault;
    value = .subannotation Lo82;
        intEncoding = .enum Ln82;->a:Ln82;
    .end subannotation
.end annotation


# virtual methods
.method public abstract intEncoding()Ln82;
.end method

.method public abstract tag()I
.end method
