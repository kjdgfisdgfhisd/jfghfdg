###### Class defpackage.cn1 (cn1)
.class public final Lcn1;
.super Lnw2;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final e:Lae0;

.field public final f:Lzd0;

.field public final g:Ljava/util/concurrent/atomic/AtomicReference;


# direct methods
.method public constructor <init>(Luw2;Lae0;Lzd0;)V
    .registers 5

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object p1, p3, Lzd0;->a:Ljava/lang/String;

    .line 5
    .line 6
    const-string v0, " dns"

    .line 7
    .line 8
    invoke-virtual {p1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-direct {p0, p1, v0}, Lnw2;-><init>(Ljava/lang/String;Z)V

    .line 14
    .line 15
    .line 16
    iput-object p2, p0, Lcn1;->e:Lae0;

    .line 17
    .line 18
    iput-object p3, p0, Lcn1;->f:Lzd0;

    .line 19
    .line 20
    new-instance p1, Ljava/util/concurrent/atomic/AtomicReference;

    .line 21
    .line 22
    sget-object p2, Lzm1;->b:Lzm1;

    .line 23
    .line 24
    invoke-direct {p1, p2}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    iput-object p1, p0, Lcn1;->g:Ljava/util/concurrent/atomic/AtomicReference;

    .line 28
    .line 29
    return-void
.end method


# virtual methods
.method public final a()J
    .registers 4

    .line 1
    sget-object v0, Lzm1;->a:Lzm1;

    .line 2
    .line 3
    iget-object v1, p0, Lcn1;->g:Ljava/util/concurrent/atomic/AtomicReference;

    .line 4
    .line 5
    iget-object v2, p0, Lcn1;->f:Lzd0;

    .line 6
    .line 7
    iget-object v2, v2, Lzd0;->a:Ljava/lang/String;

    .line 8
    .line 9
    :try_start_8
    iget-object p0, p0, Lcn1;->e:Lae0;

    .line 10
    .line 11
    invoke-interface {p0, v2}, Lae0;->a(Ljava/lang/String;)Ljava/util/List;

    .line 12
    .line 13
    .line 14
    :goto_d
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    move-object v2, p0

    .line 19
    check-cast v2, Lbn1;

    .line 20
    .line 21
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    .line 23
    .line 24
    instance-of v2, v2, Lan1;

    .line 25
    .line 26
    if-nez v2, :cond_1c

    .line 27
    .line 28
    goto :goto_22

    .line 29
    :cond_1c
    invoke-virtual {v1, p0, v0}, Ljava/util/concurrent/atomic/AtomicReference;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 30
    .line 31
    .line 32
    move-result v2

    .line 33
    if-eqz v2, :cond_25

    .line 34
    .line 35
    :goto_22
    check-cast p0, Lbn1;

    .line 36
    .line 37
    goto :goto_41

    .line 38
    :cond_25
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v2
    :try_end_29
    .catch Ljava/net/UnknownHostException; {:try_start_8 .. :try_end_29} :catch_2c

    .line 42
    if-eq v2, p0, :cond_1c

    .line 43
    .line 44
    goto :goto_d

    .line 45
    :catch_2c
    :goto_2c
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object p0

    .line 49
    move-object v2, p0

    .line 50
    check-cast v2, Lbn1;

    .line 51
    .line 52
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 53
    .line 54
    .line 55
    instance-of v2, v2, Lan1;

    .line 56
    .line 57
    if-nez v2, :cond_3b

    .line 58
    .line 59
    goto :goto_41

    .line 60
    :cond_3b
    invoke-virtual {v1, p0, v0}, Ljava/util/concurrent/atomic/AtomicReference;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 61
    .line 62
    .line 63
    move-result v2

    .line 64
    if-eqz v2, :cond_44

    .line 65
    .line 66
    :goto_41
    const-wide/16 v0, -0x1

    .line 67
    .line 68
    return-wide v0

    .line 69
    :cond_44
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object v2

    .line 73
    if-eq v2, p0, :cond_3b

    .line 74
    .line 75
    goto :goto_2c
.end method
