###### Class defpackage.fx (fx)
.class public interface abstract Lfx;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# virtual methods
.method public abstract k0(Ly8;)Ljava/lang/Object;
.end method
