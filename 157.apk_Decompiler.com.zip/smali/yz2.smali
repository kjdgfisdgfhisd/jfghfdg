###### Class defpackage.yz2 (yz2)
.class public abstract Lyz2;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Luz2;


# virtual methods
.method public a(Lwz2;)V
    .registers 2

    .line 1
    return-void
.end method

.method public b()V
    .registers 1

    .line 1
    return-void
.end method

.method public c()V
    .registers 1

    .line 1
    return-void
.end method

.method public f(Lwz2;)V
    .registers 2

    .line 1
    return-void
.end method
