###### Class defpackage.qi0 (qi0)
.class public final Lqi0;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lxl0;


# instance fields
.field public final a:Ll6;

.field public final b:Lis2;

.field public final c:Lni0;

.field public final d:Lo22;

.field public final e:Lni0;

.field public final f:Lrw0;

.field public final g:Lrw0;

.field public final j:Lrw0;

.field public final l:Ljava/util/concurrent/atomic/AtomicInteger;

.field public m:Lri0;

.field public n:Z

.field public o:Z

.field public p:Lqf2;

.field public q:Lu50;

.field public r:Z

.field public s:Lpw0;

.field public t:Z

.field public u:Lsi0;

.field public v:Lx60;

.field public volatile w:Z


# direct methods
.method static constructor <clinit>()V
    .registers 0

    .line 1
    return-void
.end method

.method public constructor <init>(Lrw0;Lrw0;Lrw0;Lrw0;Lni0;Lni0;Lna;)V
    .registers 10

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance p3, Ll6;

    .line 5
    .line 6
    new-instance v0, Ljava/util/ArrayList;

    .line 7
    .line 8
    const/4 v1, 0x2

    .line 9
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 10
    .line 11
    .line 12
    invoke-direct {p3, v0}, Ll6;-><init>(Ljava/util/ArrayList;)V

    .line 13
    .line 14
    .line 15
    iput-object p3, p0, Lqi0;->a:Ll6;

    .line 16
    .line 17
    new-instance p3, Lis2;

    .line 18
    .line 19
    invoke-direct {p3}, Ljava/lang/Object;-><init>()V

    .line 20
    .line 21
    .line 22
    iput-object p3, p0, Lqi0;->b:Lis2;

    .line 23
    .line 24
    new-instance p3, Ljava/util/concurrent/atomic/AtomicInteger;

    .line 25
    .line 26
    invoke-direct {p3}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    .line 27
    .line 28
    .line 29
    iput-object p3, p0, Lqi0;->l:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 30
    .line 31
    iput-object p1, p0, Lqi0;->f:Lrw0;

    .line 32
    .line 33
    iput-object p2, p0, Lqi0;->g:Lrw0;

    .line 34
    .line 35
    iput-object p4, p0, Lqi0;->j:Lrw0;

    .line 36
    .line 37
    iput-object p5, p0, Lqi0;->e:Lni0;

    .line 38
    .line 39
    iput-object p6, p0, Lqi0;->c:Lni0;

    .line 40
    .line 41
    iput-object p7, p0, Lqi0;->d:Lo22;

    .line 42
    .line 43
    return-void
.end method


# virtual methods
.method public final declared-synchronized a(Ljp2;Ljava/util/concurrent/Executor;)V
    .registers 5

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    iget-object v0, p0, Lqi0;->b:Lis2;

    .line 3
    .line 4
    invoke-virtual {v0}, Lis2;->a()V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lqi0;->a:Ll6;

    .line 8
    .line 9
    iget-object v0, v0, Ll6;->b:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v0, Ljava/util/ArrayList;

    .line 12
    .line 13
    new-instance v1, Lpi0;

    .line 14
    .line 15
    invoke-direct {v1, p1, p2}, Lpi0;-><init>(Ljp2;Ljava/util/concurrent/Executor;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 19
    .line 20
    .line 21
    iget-boolean v0, p0, Lqi0;->r:Z

    .line 22
    .line 23
    const/4 v1, 0x1

    .line 24
    if-eqz v0, :cond_27

    .line 25
    .line 26
    invoke-virtual {p0, v1}, Lqi0;->d(I)V

    .line 27
    .line 28
    .line 29
    new-instance v0, Loi0;

    .line 30
    .line 31
    invoke-direct {v0, p0, p1, v1}, Loi0;-><init>(Lqi0;Ljp2;I)V

    .line 32
    .line 33
    .line 34
    invoke-interface {p2, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 35
    .line 36
    .line 37
    goto :goto_40

    .line 38
    :catchall_25
    move-exception p1

    .line 39
    goto :goto_42

    .line 40
    :cond_27
    iget-boolean v0, p0, Lqi0;->t:Z

    .line 41
    .line 42
    if-eqz v0, :cond_38

    .line 43
    .line 44
    invoke-virtual {p0, v1}, Lqi0;->d(I)V

    .line 45
    .line 46
    .line 47
    new-instance v0, Loi0;

    .line 48
    .line 49
    const/4 v1, 0x0

    .line 50
    invoke-direct {v0, p0, p1, v1}, Loi0;-><init>(Lqi0;Ljp2;I)V

    .line 51
    .line 52
    .line 53
    invoke-interface {p2, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 54
    .line 55
    .line 56
    goto :goto_40

    .line 57
    :cond_38
    iget-boolean p1, p0, Lqi0;->w:Z

    .line 58
    .line 59
    xor-int/2addr p1, v1

    .line 60
    const-string p2, "Cannot add callbacks to a cancelled EngineJob"

    .line 61
    .line 62
    invoke-static {p2, p1}, Lia1;->i(Ljava/lang/String;Z)V
    :try_end_40
    .catchall {:try_start_1 .. :try_end_40} :catchall_25

    .line 63
    .line 64
    .line 65
    :goto_40
    monitor-exit p0

    .line 66
    return-void

    .line 67
    :goto_42
    :try_start_42
    monitor-exit p0
    :try_end_43
    .catchall {:try_start_42 .. :try_end_43} :catchall_25

    .line 68
    throw p1
.end method

.method public final b()Lis2;
    .registers 1

    .line 1
    iget-object p0, p0, Lqi0;->b:Lis2;

    .line 2
    .line 3
    return-object p0
.end method

.method public final c()V
    .registers 4

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    iget-object v0, p0, Lqi0;->b:Lis2;

    .line 3
    .line 4
    invoke-virtual {v0}, Lis2;->a()V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0}, Lqi0;->e()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    const-string v1, "Not yet complete!"

    .line 12
    .line 13
    invoke-static {v1, v0}, Lia1;->i(Ljava/lang/String;Z)V

    .line 14
    .line 15
    .line 16
    iget-object v0, p0, Lqi0;->l:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 17
    .line 18
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    if-ltz v0, :cond_19

    .line 23
    .line 24
    const/4 v1, 0x1

    .line 25
    goto :goto_1a

    .line 26
    :cond_19
    const/4 v1, 0x0

    .line 27
    :goto_1a
    const-string v2, "Can\'t decrement below 0"

    .line 28
    .line 29
    invoke-static {v2, v1}, Lia1;->i(Ljava/lang/String;Z)V

    .line 30
    .line 31
    .line 32
    if-nez v0, :cond_29

    .line 33
    .line 34
    iget-object v0, p0, Lqi0;->u:Lsi0;

    .line 35
    .line 36
    invoke-virtual {p0}, Lqi0;->f()V

    .line 37
    .line 38
    .line 39
    goto :goto_2a

    .line 40
    :catchall_27
    move-exception v0

    .line 41
    goto :goto_31

    .line 42
    :cond_29
    const/4 v0, 0x0

    .line 43
    :goto_2a
    monitor-exit p0
    :try_end_2b
    .catchall {:try_start_1 .. :try_end_2b} :catchall_27

    .line 44
    if-eqz v0, :cond_30

    .line 45
    .line 46
    invoke-virtual {v0}, Lsi0;->b()V

    .line 47
    .line 48
    .line 49
    :cond_30
    return-void

    .line 50
    :goto_31
    :try_start_31
    monitor-exit p0
    :try_end_32
    .catchall {:try_start_31 .. :try_end_32} :catchall_27

    .line 51
    throw v0
.end method

.method public final declared-synchronized d(I)V
    .registers 4

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    invoke-virtual {p0}, Lqi0;->e()Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    const-string v1, "Not yet complete!"

    .line 7
    .line 8
    invoke-static {v1, v0}, Lia1;->i(Ljava/lang/String;Z)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, Lqi0;->l:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 12
    .line 13
    invoke-virtual {v0, p1}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndAdd(I)I

    .line 14
    .line 15
    .line 16
    move-result p1

    .line 17
    if-nez p1, :cond_1c

    .line 18
    .line 19
    iget-object p1, p0, Lqi0;->u:Lsi0;

    .line 20
    .line 21
    if-eqz p1, :cond_1c

    .line 22
    .line 23
    invoke-virtual {p1}, Lsi0;->a()V
    :try_end_19
    .catchall {:try_start_1 .. :try_end_19} :catchall_1a

    .line 24
    .line 25
    .line 26
    goto :goto_1c

    .line 27
    :catchall_1a
    move-exception p1

    .line 28
    goto :goto_1e

    .line 29
    :cond_1c
    :goto_1c
    monitor-exit p0

    .line 30
    return-void

    .line 31
    :goto_1e
    :try_start_1e
    monitor-exit p0
    :try_end_1f
    .catchall {:try_start_1e .. :try_end_1f} :catchall_1a

    .line 32
    throw p1
.end method

.method public final e()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lqi0;->t:Z

    .line 2
    .line 3
    if-nez v0, :cond_f

    .line 4
    .line 5
    iget-boolean v0, p0, Lqi0;->r:Z

    .line 6
    .line 7
    if-nez v0, :cond_f

    .line 8
    .line 9
    iget-boolean p0, p0, Lqi0;->w:Z

    .line 10
    .line 11
    if-eqz p0, :cond_d

    .line 12
    .line 13
    goto :goto_f

    .line 14
    :cond_d
    const/4 p0, 0x0

    .line 15
    return p0

    .line 16
    :cond_f
    :goto_f
    const/4 p0, 0x1

    .line 17
    return p0
.end method

.method public final declared-synchronized f()V
    .registers 5

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    iget-object v0, p0, Lqi0;->m:Lri0;

    .line 3
    .line 4
    if-eqz v0, :cond_40

    .line 5
    .line 6
    iget-object v0, p0, Lqi0;->a:Ll6;

    .line 7
    .line 8
    iget-object v0, v0, Ll6;->b:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Ljava/util/ArrayList;

    .line 11
    .line 12
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 13
    .line 14
    .line 15
    const/4 v0, 0x0

    .line 16
    iput-object v0, p0, Lqi0;->m:Lri0;

    .line 17
    .line 18
    iput-object v0, p0, Lqi0;->u:Lsi0;

    .line 19
    .line 20
    iput-object v0, p0, Lqi0;->p:Lqf2;

    .line 21
    .line 22
    const/4 v1, 0x0

    .line 23
    iput-boolean v1, p0, Lqi0;->t:Z

    .line 24
    .line 25
    iput-boolean v1, p0, Lqi0;->w:Z

    .line 26
    .line 27
    iput-boolean v1, p0, Lqi0;->r:Z

    .line 28
    .line 29
    iget-object v1, p0, Lqi0;->v:Lx60;

    .line 30
    .line 31
    iget-object v2, v1, Lx60;->g:Lw60;

    .line 32
    .line 33
    monitor-enter v2
    :try_end_21
    .catchall {:try_start_1 .. :try_end_21} :catchall_3b

    .line 34
    const/4 v3, 0x1

    .line 35
    :try_start_22
    iput-boolean v3, v2, Lw60;->a:Z

    .line 36
    .line 37
    invoke-virtual {v2}, Lw60;->a()Z

    .line 38
    .line 39
    .line 40
    move-result v3
    :try_end_28
    .catchall {:try_start_22 .. :try_end_28} :catchall_3d

    .line 41
    :try_start_28
    monitor-exit v2

    .line 42
    if-eqz v3, :cond_2e

    .line 43
    .line 44
    invoke-virtual {v1}, Lx60;->k()V

    .line 45
    .line 46
    .line 47
    :cond_2e
    iput-object v0, p0, Lqi0;->v:Lx60;

    .line 48
    .line 49
    iput-object v0, p0, Lqi0;->s:Lpw0;

    .line 50
    .line 51
    iput-object v0, p0, Lqi0;->q:Lu50;

    .line 52
    .line 53
    iget-object v0, p0, Lqi0;->d:Lo22;

    .line 54
    .line 55
    invoke-interface {v0, p0}, Lo22;->a(Ljava/lang/Object;)Z
    :try_end_39
    .catchall {:try_start_28 .. :try_end_39} :catchall_3b

    .line 56
    .line 57
    .line 58
    monitor-exit p0

    .line 59
    return-void

    .line 60
    :catchall_3b
    move-exception v0

    .line 61
    goto :goto_46

    .line 62
    :catchall_3d
    move-exception v0

    .line 63
    :try_start_3e
    monitor-exit v2
    :try_end_3f
    .catchall {:try_start_3e .. :try_end_3f} :catchall_3d

    .line 64
    :try_start_3f
    throw v0

    .line 65
    :cond_40
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 66
    .line 67
    invoke-direct {v0}, Ljava/lang/IllegalArgumentException;-><init>()V

    .line 68
    .line 69
    .line 70
    throw v0

    .line 71
    :goto_46
    monitor-exit p0
    :try_end_47
    .catchall {:try_start_3f .. :try_end_47} :catchall_3b

    .line 72
    throw v0
.end method

.method public final declared-synchronized g(Ljp2;)V
    .registers 5

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    iget-object v0, p0, Lqi0;->b:Lis2;

    .line 3
    .line 4
    invoke-virtual {v0}, Lis2;->a()V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lqi0;->a:Ll6;

    .line 8
    .line 9
    iget-object v0, v0, Ll6;->b:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v0, Ljava/util/ArrayList;

    .line 12
    .line 13
    new-instance v1, Lpi0;

    .line 14
    .line 15
    sget-object v2, Lpf3;->b:Luc0;

    .line 16
    .line 17
    invoke-direct {v1, p1, v2}, Lpi0;-><init>(Ljp2;Ljava/util/concurrent/Executor;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    iget-object p1, p0, Lqi0;->a:Ll6;

    .line 24
    .line 25
    iget-object p1, p1, Ll6;->b:Ljava/lang/Object;

    .line 26
    .line 27
    check-cast p1, Ljava/util/ArrayList;

    .line 28
    .line 29
    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 30
    .line 31
    .line 32
    move-result p1

    .line 33
    if-eqz p1, :cond_68

    .line 34
    .line 35
    invoke-virtual {p0}, Lqi0;->e()Z

    .line 36
    .line 37
    .line 38
    move-result p1

    .line 39
    if-eqz p1, :cond_29

    .line 40
    .line 41
    goto :goto_4e

    .line 42
    :cond_29
    const/4 p1, 0x1

    .line 43
    iput-boolean p1, p0, Lqi0;->w:Z

    .line 44
    .line 45
    iget-object v0, p0, Lqi0;->v:Lx60;

    .line 46
    .line 47
    iput-boolean p1, v0, Lx60;->G:Z

    .line 48
    .line 49
    iget-object p1, v0, Lx60;->E:Ln50;

    .line 50
    .line 51
    if-eqz p1, :cond_37

    .line 52
    .line 53
    invoke-interface {p1}, Ln50;->cancel()V

    .line 54
    .line 55
    .line 56
    :cond_37
    iget-object p1, p0, Lqi0;->e:Lni0;

    .line 57
    .line 58
    iget-object v0, p0, Lqi0;->m:Lri0;

    .line 59
    .line 60
    monitor-enter p1
    :try_end_3c
    .catchall {:try_start_1 .. :try_end_3c} :catchall_57

    .line 61
    :try_start_3c
    iget-object v1, p1, Lni0;->a:Lt50;

    .line 62
    .line 63
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 64
    .line 65
    .line 66
    iget-object v1, v1, Lt50;->b:Ljava/util/HashMap;

    .line 67
    .line 68
    invoke-virtual {v1, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object v2

    .line 72
    if-eq p0, v2, :cond_4a

    .line 73
    .line 74
    goto :goto_4d

    .line 75
    :cond_4a
    invoke-virtual {v1, v0}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_4d
    .catchall {:try_start_3c .. :try_end_4d} :catchall_65

    .line 76
    .line 77
    .line 78
    :goto_4d
    :try_start_4d
    monitor-exit p1

    .line 79
    :goto_4e
    iget-boolean p1, p0, Lqi0;->r:Z

    .line 80
    .line 81
    if-nez p1, :cond_59

    .line 82
    .line 83
    iget-boolean p1, p0, Lqi0;->t:Z

    .line 84
    .line 85
    if-eqz p1, :cond_68

    .line 86
    .line 87
    goto :goto_59

    .line 88
    :catchall_57
    move-exception p1

    .line 89
    goto :goto_6a

    .line 90
    :cond_59
    :goto_59
    iget-object p1, p0, Lqi0;->l:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 91
    .line 92
    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    .line 93
    .line 94
    .line 95
    move-result p1

    .line 96
    if-nez p1, :cond_68

    .line 97
    .line 98
    invoke-virtual {p0}, Lqi0;->f()V
    :try_end_64
    .catchall {:try_start_4d .. :try_end_64} :catchall_57

    .line 99
    .line 100
    .line 101
    goto :goto_68

    .line 102
    :catchall_65
    move-exception v0

    .line 103
    :try_start_66
    monitor-exit p1
    :try_end_67
    .catchall {:try_start_66 .. :try_end_67} :catchall_65

    .line 104
    :try_start_67
    throw v0
    :try_end_68
    .catchall {:try_start_67 .. :try_end_68} :catchall_57

    .line 105
    :cond_68
    :goto_68
    monitor-exit p0

    .line 106
    return-void

    .line 107
    :goto_6a
    :try_start_6a
    monitor-exit p0
    :try_end_6b
    .catchall {:try_start_6a .. :try_end_6b} :catchall_57

    .line 108
    throw p1
.end method
