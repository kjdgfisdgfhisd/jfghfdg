###### Class defpackage.cf3 (cf3)
.class public final Lcf3;
.super Ly00;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public synthetic j:Ljava/lang/Object;

.field public final synthetic l:Ldf3;

.field public m:I


# direct methods
.method public constructor <init>(Ldf3;Ly00;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lcf3;->l:Ldf3;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Ly00;-><init>(Lw00;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    iput-object p1, p0, Lcf3;->j:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lcf3;->m:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lcf3;->m:I

    .line 9
    .line 10
    iget-object p1, p0, Lcf3;->l:Ldf3;

    .line 11
    .line 12
    invoke-virtual {p1, p0}, Ldf3;->c(Ly00;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    return-object p0
.end method
