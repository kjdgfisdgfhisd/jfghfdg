###### Class defpackage.dt2 (dt2)
.class public final Ldt2;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public a:Lha1;

.field public b:Lga1;

.field public c:Ljava/lang/String;

.field public d:Lz13;


# virtual methods
.method public final a(Lbl2;Lh13;Ljava/util/ArrayList;)Lt23;
    .registers 13

    .line 1
    iget-object v0, p0, Ldt2;->a:Lha1;

    .line 2
    .line 3
    sget-object v1, Lha1;->b:Lha1;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-ne v0, v1, :cond_8

    .line 7
    .line 8
    goto :goto_10

    .line 9
    :cond_8
    iget-object v0, p2, Lh13;->d:Ljava/lang/Class;

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/lang/Class;->isPrimitive()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_11

    .line 16
    .line 17
    :goto_10
    return-object v2

    .line 18
    :cond_11
    iget-object v0, p0, Ldt2;->a:Lha1;

    .line 19
    .line 20
    sget-object v1, Lha1;->c:Lha1;

    .line 21
    .line 22
    if-ne v0, v1, :cond_1a

    .line 23
    .line 24
    sget-object p0, Lac;->d:Lac;

    .line 25
    .line 26
    return-object p0

    .line 27
    :cond_1a
    iget-object v0, p1, Lvo1;->b:Lpi;

    .line 28
    .line 29
    iget-object v0, v0, Lpi;->a:Ly13;

    .line 30
    .line 31
    sget-object v1, Lxo1;->B:Lxo1;

    .line 32
    .line 33
    invoke-virtual {p1, v1}, Lvo1;->f(Lxo1;)Z

    .line 34
    .line 35
    .line 36
    iget-object v1, p0, Ldt2;->d:Lz13;

    .line 37
    .line 38
    const/4 v3, 0x3

    .line 39
    const/4 v4, 0x2

    .line 40
    const/4 v5, 0x1

    .line 41
    const/4 v6, 0x4

    .line 42
    if-eqz v1, :cond_2d

    .line 43
    .line 44
    goto/16 :goto_99

    .line 45
    .line 46
    :cond_2d
    iget-object v1, p0, Ldt2;->a:Lha1;

    .line 47
    .line 48
    if-eqz v1, :cond_d5

    .line 49
    .line 50
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 51
    .line 52
    .line 53
    move-result v1

    .line 54
    if-eqz v1, :cond_98

    .line 55
    .line 56
    if-eq v1, v5, :cond_92

    .line 57
    .line 58
    if-eq v1, v4, :cond_8c

    .line 59
    .line 60
    if-eq v1, v3, :cond_48

    .line 61
    .line 62
    if-ne v1, v6, :cond_40

    .line 63
    .line 64
    goto :goto_92

    .line 65
    :cond_40
    const-string p1, "Do not know how to construct standard type id resolver for idType: "

    .line 66
    .line 67
    iget-object p0, p0, Ldt2;->a:Lha1;

    .line 68
    .line 69
    invoke-static {p0, p1}, Lvn0;->s(Ljava/lang/Object;Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    return-object v2

    .line 73
    :cond_48
    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    .line 74
    .line 75
    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    .line 76
    .line 77
    .line 78
    sget-object v1, Lxo1;->w:Lxo1;

    .line 79
    .line 80
    invoke-virtual {p1, v1}, Lvo1;->f(Lxo1;)Z

    .line 81
    .line 82
    .line 83
    if-eqz p3, :cond_86

    .line 84
    .line 85
    invoke-interface {p3}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 86
    .line 87
    .line 88
    move-result-object p3

    .line 89
    :goto_58
    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    .line 90
    .line 91
    .line 92
    move-result v1

    .line 93
    if-eqz v1, :cond_86

    .line 94
    .line 95
    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 96
    .line 97
    .line 98
    move-result-object v1

    .line 99
    check-cast v1, Llv1;

    .line 100
    .line 101
    iget-object v7, v1, Llv1;->a:Ljava/lang/Class;

    .line 102
    .line 103
    iget-object v1, v1, Llv1;->c:Ljava/lang/String;

    .line 104
    .line 105
    if-eqz v1, :cond_6b

    .line 106
    .line 107
    goto :goto_7e

    .line 108
    :cond_6b
    invoke-virtual {v7}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 109
    .line 110
    .line 111
    move-result-object v1

    .line 112
    const/16 v8, 0x2e

    .line 113
    .line 114
    invoke-virtual {v1, v8}, Ljava/lang/String;->lastIndexOf(I)I

    .line 115
    .line 116
    .line 117
    move-result v8

    .line 118
    if-gez v8, :cond_78

    .line 119
    .line 120
    goto :goto_7e

    .line 121
    :cond_78
    add-int/lit8 v8, v8, 0x1

    .line 122
    .line 123
    invoke-virtual {v1, v8}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 124
    .line 125
    .line 126
    move-result-object v1

    .line 127
    :goto_7e
    invoke-virtual {v7}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 128
    .line 129
    .line 130
    move-result-object v7

    .line 131
    invoke-virtual {v0, v7, v1}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 132
    .line 133
    .line 134
    goto :goto_58

    .line 135
    :cond_86
    new-instance v1, Lk23;

    .line 136
    .line 137
    invoke-direct {v1, p1, p2, v0, v2}, Lk23;-><init>(Lbl2;Lh13;Ljava/util/concurrent/ConcurrentHashMap;Ljava/util/HashMap;)V

    .line 138
    .line 139
    .line 140
    goto :goto_99

    .line 141
    :cond_8c
    new-instance v1, Lmt1;

    .line 142
    .line 143
    invoke-direct {v1, p2, v0}, Lmt1;-><init>(Lh13;Ly13;)V

    .line 144
    .line 145
    .line 146
    goto :goto_99

    .line 147
    :cond_92
    :goto_92
    new-instance v1, Lmt;

    .line 148
    .line 149
    invoke-direct {v1, p2, v0}, Lz13;-><init>(Lh13;Ly13;)V

    .line 150
    .line 151
    .line 152
    goto :goto_99

    .line 153
    :cond_98
    move-object v1, v2

    .line 154
    :goto_99
    iget-object p1, p0, Ldt2;->b:Lga1;

    .line 155
    .line 156
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 157
    .line 158
    .line 159
    move-result p1

    .line 160
    if-eqz p1, :cond_cd

    .line 161
    .line 162
    if-eq p1, v5, :cond_c7

    .line 163
    .line 164
    if-eq p1, v4, :cond_c1

    .line 165
    .line 166
    if-eq p1, v3, :cond_b9

    .line 167
    .line 168
    if-ne p1, v6, :cond_b1

    .line 169
    .line 170
    new-instance p1, Lbc;

    .line 171
    .line 172
    iget-object p0, p0, Ldt2;->c:Ljava/lang/String;

    .line 173
    .line 174
    invoke-direct {p1, v1, v2, p0}, Ldc;-><init>(Lz13;Lwj;Ljava/lang/String;)V

    .line 175
    .line 176
    .line 177
    return-object p1

    .line 178
    :cond_b1
    const-string p1, "Do not know how to construct standard type serializer for inclusion type: "

    .line 179
    .line 180
    iget-object p0, p0, Ldt2;->b:Lga1;

    .line 181
    .line 182
    invoke-static {p0, p1}, Lvn0;->s(Ljava/lang/Object;Ljava/lang/String;)V

    .line 183
    .line 184
    .line 185
    return-object v2

    .line 186
    :cond_b9
    new-instance p1, Lcc;

    .line 187
    .line 188
    iget-object p0, p0, Ldt2;->c:Ljava/lang/String;

    .line 189
    .line 190
    invoke-direct {p1, v1, v2, p0}, Lcc;-><init>(Lz13;Lwj;Ljava/lang/String;)V

    .line 191
    .line 192
    .line 193
    return-object p1

    .line 194
    :cond_c1
    new-instance p0, Lac;

    .line 195
    .line 196
    invoke-direct {p0, v1, v2, v5}, Lac;-><init>(Lz13;Lwj;I)V

    .line 197
    .line 198
    .line 199
    return-object p0

    .line 200
    :cond_c7
    new-instance p0, Lac;

    .line 201
    .line 202
    invoke-direct {p0, v1, v2, v4}, Lac;-><init>(Lz13;Lwj;I)V

    .line 203
    .line 204
    .line 205
    return-object p0

    .line 206
    :cond_cd
    new-instance p1, Ldc;

    .line 207
    .line 208
    iget-object p0, p0, Ldt2;->c:Ljava/lang/String;

    .line 209
    .line 210
    invoke-direct {p1, v1, v2, p0}, Ldc;-><init>(Lz13;Lwj;Ljava/lang/String;)V

    .line 211
    .line 212
    .line 213
    return-object p1

    .line 214
    :cond_d5
    const-string p0, "Cannot build, \'init()\' not yet called"

    .line 215
    .line 216
    invoke-static {p0}, Ly0;->h(Ljava/lang/String;)V

    .line 217
    .line 218
    .line 219
    return-object v2
.end method
