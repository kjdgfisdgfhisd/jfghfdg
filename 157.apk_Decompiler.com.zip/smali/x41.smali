###### Class defpackage.x41 (x41)
.class public final Lx41;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final a:Lcm1;

.field public final b:Lyc2;

.field public final c:Lyc2;

.field public final d:Lrb0;

.field public final e:Lxa1;

.field public final f:Lrt1;

.field public final g:Lwm;

.field public final h:Lau1;

.field public final i:Lxd2;

.field public final j:Lf7;

.field public final k:Le51;

.field public final l:Lkw1;

.field public final m:Lg51;

.field public final n:Lwm;

.field public final o:Ltv2;


# direct methods
.method public constructor <init>(Lcm1;Lyc2;Lyc2;Lrb0;Lxa1;Lrt1;Lwm;Lau1;Lxd2;Lf7;Le51;Lkw1;Lg51;Lwm;)V
    .registers 16

    .line 1
    sget-object v0, Ltv2;->f0:Lsv2;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-virtual {p12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    sget-object v0, Lsv2;->b:Lih2;

    .line 13
    .line 14
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 18
    .line 19
    .line 20
    iput-object p1, p0, Lx41;->a:Lcm1;

    .line 21
    .line 22
    iput-object p2, p0, Lx41;->b:Lyc2;

    .line 23
    .line 24
    iput-object p3, p0, Lx41;->c:Lyc2;

    .line 25
    .line 26
    iput-object p4, p0, Lx41;->d:Lrb0;

    .line 27
    .line 28
    iput-object p5, p0, Lx41;->e:Lxa1;

    .line 29
    .line 30
    iput-object p6, p0, Lx41;->f:Lrt1;

    .line 31
    .line 32
    iput-object p7, p0, Lx41;->g:Lwm;

    .line 33
    .line 34
    iput-object p8, p0, Lx41;->h:Lau1;

    .line 35
    .line 36
    iput-object p9, p0, Lx41;->i:Lxd2;

    .line 37
    .line 38
    iput-object p10, p0, Lx41;->j:Lf7;

    .line 39
    .line 40
    iput-object p11, p0, Lx41;->k:Le51;

    .line 41
    .line 42
    iput-object p12, p0, Lx41;->l:Lkw1;

    .line 43
    .line 44
    iput-object p13, p0, Lx41;->m:Lg51;

    .line 45
    .line 46
    iput-object p14, p0, Lx41;->n:Lwm;

    .line 47
    .line 48
    iput-object v0, p0, Lx41;->o:Ltv2;

    .line 49
    .line 50
    return-void
.end method
