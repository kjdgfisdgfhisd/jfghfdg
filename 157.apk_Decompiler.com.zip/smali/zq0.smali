###### Class defpackage.zq0 (zq0)
.class public final Lzq0;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field public static final c:Lzq0;


# instance fields
.field public final a:Lar0;

.field public transient b:Lzq0;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lzq0;

    .line 2
    .line 3
    const-string v1, ""

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lzq0;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lzq0;->c:Lzq0;

    .line 9
    .line 10
    return-void
.end method

.method public constructor <init>(Lar0;)V
    .registers 2

    .line 20
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 21
    iput-object p1, p0, Lzq0;->a:Lar0;

    return-void
.end method

.method public constructor <init>(Lar0;Lzq0;)V
    .registers 3

    .line 22
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 23
    iput-object p1, p0, Lzq0;->a:Lar0;

    .line 24
    iput-object p2, p0, Lzq0;->b:Lzq0;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .registers 3

    .line 1
    if-eqz p1, :cond_d

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    new-instance v0, Lar0;

    .line 7
    .line 8
    invoke-direct {v0, p0, p1}, Lar0;-><init>(Lzq0;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iput-object v0, p0, Lzq0;->a:Lar0;

    .line 12
    .line 13
    return-void

    .line 14
    :cond_d
    const/4 p0, 0x1

    .line 15
    invoke-static {p0}, Lzq0;->a(I)V

    .line 16
    .line 17
    .line 18
    const/4 p0, 0x0

    .line 19
    throw p0
.end method

.method public static synthetic a(I)V
    .registers 8

    .line 1
    packed-switch p0, :pswitch_data_88

    .line 2
    .line 3
    .line 4
    :pswitch_3
    const-string v0, "Argument for @NotNull parameter \'%s\' of %s.%s must not be null"

    .line 5
    .line 6
    goto :goto_8

    .line 7
    :pswitch_6
    const-string v0, "@NotNull method %s.%s must not return null"

    .line 8
    .line 9
    :goto_8
    const/4 v1, 0x2

    .line 10
    packed-switch p0, :pswitch_data_9c

    .line 11
    .line 12
    .line 13
    :pswitch_c
    const/4 v2, 0x3

    .line 14
    goto :goto_f

    .line 15
    :pswitch_e
    move v2, v1

    .line 16
    :goto_f
    new-array v2, v2, [Ljava/lang/Object;

    .line 17
    .line 18
    const-string v3, "kotlin/reflect/jvm/internal/impl/name/FqName"

    .line 19
    .line 20
    const-string v4, "shortName"

    .line 21
    .line 22
    const/4 v5, 0x0

    .line 23
    packed-switch p0, :pswitch_data_b0

    .line 24
    .line 25
    .line 26
    const-string v6, "names"

    .line 27
    .line 28
    aput-object v6, v2, v5

    .line 29
    .line 30
    goto :goto_37

    .line 31
    :pswitch_1e
    aput-object v4, v2, v5

    .line 32
    .line 33
    goto :goto_37

    .line 34
    :pswitch_21
    const-string v6, "other"

    .line 35
    .line 36
    aput-object v6, v2, v5

    .line 37
    .line 38
    goto :goto_37

    .line 39
    :pswitch_26
    const-string v6, "segment"

    .line 40
    .line 41
    aput-object v6, v2, v5

    .line 42
    .line 43
    goto :goto_37

    .line 44
    :pswitch_2b
    const-string v6, "name"

    .line 45
    .line 46
    aput-object v6, v2, v5

    .line 47
    .line 48
    goto :goto_37

    .line 49
    :pswitch_30
    aput-object v3, v2, v5

    .line 50
    .line 51
    goto :goto_37

    .line 52
    :pswitch_33
    const-string v6, "fqName"

    .line 53
    .line 54
    aput-object v6, v2, v5

    .line 55
    .line 56
    :goto_37
    const/4 v5, 0x1

    .line 57
    packed-switch p0, :pswitch_data_d0

    .line 58
    .line 59
    .line 60
    :pswitch_3b
    aput-object v3, v2, v5

    .line 61
    .line 62
    goto :goto_59

    .line 63
    :pswitch_3e
    const-string v3, "pathSegments"

    .line 64
    .line 65
    aput-object v3, v2, v5

    .line 66
    .line 67
    goto :goto_59

    .line 68
    :pswitch_43
    const-string v3, "shortNameOrSpecial"

    .line 69
    .line 70
    aput-object v3, v2, v5

    .line 71
    .line 72
    goto :goto_59

    .line 73
    :pswitch_48
    aput-object v4, v2, v5

    .line 74
    .line 75
    goto :goto_59

    .line 76
    :pswitch_4b
    const-string v3, "parent"

    .line 77
    .line 78
    aput-object v3, v2, v5

    .line 79
    .line 80
    goto :goto_59

    .line 81
    :pswitch_50
    const-string v3, "toUnsafe"

    .line 82
    .line 83
    aput-object v3, v2, v5

    .line 84
    .line 85
    goto :goto_59

    .line 86
    :pswitch_55
    const-string v3, "asString"

    .line 87
    .line 88
    aput-object v3, v2, v5

    .line 89
    .line 90
    :goto_59
    packed-switch p0, :pswitch_data_e4

    .line 91
    .line 92
    .line 93
    const-string v3, "fromSegments"

    .line 94
    .line 95
    aput-object v3, v2, v1

    .line 96
    .line 97
    goto :goto_74

    .line 98
    :pswitch_61
    const-string v3, "topLevel"

    .line 99
    .line 100
    aput-object v3, v2, v1

    .line 101
    .line 102
    goto :goto_74

    .line 103
    :pswitch_66
    const-string v3, "startsWith"

    .line 104
    .line 105
    aput-object v3, v2, v1

    .line 106
    .line 107
    goto :goto_74

    .line 108
    :pswitch_6b
    const-string v3, "child"

    .line 109
    .line 110
    aput-object v3, v2, v1

    .line 111
    .line 112
    goto :goto_74

    .line 113
    :pswitch_70
    const-string v3, "<init>"

    .line 114
    .line 115
    aput-object v3, v2, v1

    .line 116
    .line 117
    :goto_74
    :pswitch_74
    invoke-static {v0, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 118
    .line 119
    .line 120
    move-result-object v0

    .line 121
    packed-switch p0, :pswitch_data_104

    .line 122
    .line 123
    .line 124
    :pswitch_7b
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 125
    .line 126
    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 127
    .line 128
    .line 129
    goto :goto_86

    .line 130
    :pswitch_81
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 131
    .line 132
    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 133
    .line 134
    .line 135
    :goto_86
    throw p0

    .line 136
    nop

    .line 137
    :pswitch_data_88
    .packed-switch 0x4
        :pswitch_6
        :pswitch_6
        :pswitch_6
        :pswitch_6
        :pswitch_3
        :pswitch_6
        :pswitch_6
        :pswitch_6
    .end packed-switch

    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    :pswitch_data_9c
    .packed-switch 0x4
        :pswitch_e
        :pswitch_e
        :pswitch_e
        :pswitch_e
        :pswitch_c
        :pswitch_e
        :pswitch_e
        :pswitch_e
    .end packed-switch

    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    :pswitch_data_b0
    .packed-switch 0x1
        :pswitch_33
        :pswitch_33
        :pswitch_33
        :pswitch_30
        :pswitch_30
        :pswitch_30
        :pswitch_30
        :pswitch_2b
        :pswitch_30
        :pswitch_30
        :pswitch_30
        :pswitch_26
        :pswitch_21
        :pswitch_1e
    .end packed-switch

    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    :pswitch_data_d0
    .packed-switch 0x4
        :pswitch_55
        :pswitch_50
        :pswitch_4b
        :pswitch_4b
        :pswitch_3b
        :pswitch_48
        :pswitch_43
        :pswitch_3e
    .end packed-switch

    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    :pswitch_data_e4
    .packed-switch 0x1
        :pswitch_70
        :pswitch_70
        :pswitch_70
        :pswitch_74
        :pswitch_74
        :pswitch_74
        :pswitch_74
        :pswitch_6b
        :pswitch_74
        :pswitch_74
        :pswitch_74
        :pswitch_66
        :pswitch_66
        :pswitch_61
    .end packed-switch

    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    :pswitch_data_104
    .packed-switch 0x4
        :pswitch_81
        :pswitch_81
        :pswitch_81
        :pswitch_81
        :pswitch_7b
        :pswitch_81
        :pswitch_81
        :pswitch_81
    .end packed-switch
.end method

.method public static j(Ldv1;)Lzq0;
    .registers 5

    .line 1
    if-eqz p0, :cond_17

    .line 2
    .line 3
    new-instance v0, Lzq0;

    .line 4
    .line 5
    new-instance v1, Lar0;

    .line 6
    .line 7
    invoke-virtual {p0}, Ldv1;->b()Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v2

    .line 11
    sget-object v3, Lzq0;->c:Lzq0;

    .line 12
    .line 13
    invoke-virtual {v3}, Lzq0;->i()Lar0;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    invoke-direct {v1, v2, v3, p0}, Lar0;-><init>(Ljava/lang/String;Lar0;Ldv1;)V

    .line 18
    .line 19
    .line 20
    invoke-direct {v0, v1}, Lzq0;-><init>(Lar0;)V

    .line 21
    .line 22
    .line 23
    return-object v0

    .line 24
    :cond_17
    const/16 p0, 0xe

    .line 25
    .line 26
    invoke-static {p0}, Lzq0;->a(I)V

    .line 27
    .line 28
    .line 29
    const/4 p0, 0x0

    .line 30
    throw p0
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .registers 1

    .line 1
    iget-object p0, p0, Lzq0;->a:Lar0;

    .line 2
    .line 3
    iget-object p0, p0, Lar0;->a:Ljava/lang/String;

    .line 4
    .line 5
    if-eqz p0, :cond_7

    .line 6
    .line 7
    return-object p0

    .line 8
    :cond_7
    const/4 p0, 0x4

    .line 9
    invoke-static {p0}, Lar0;->a(I)V

    .line 10
    .line 11
    .line 12
    const/4 p0, 0x0

    .line 13
    throw p0
.end method

.method public final c(Ldv1;)Lzq0;
    .registers 4

    .line 1
    if-eqz p1, :cond_e

    .line 2
    .line 3
    new-instance v0, Lzq0;

    .line 4
    .line 5
    iget-object v1, p0, Lzq0;->a:Lar0;

    .line 6
    .line 7
    invoke-virtual {v1, p1}, Lar0;->b(Ldv1;)Lar0;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    invoke-direct {v0, p1, p0}, Lzq0;-><init>(Lar0;Lzq0;)V

    .line 12
    .line 13
    .line 14
    return-object v0

    .line 15
    :cond_e
    const/16 p0, 0x8

    .line 16
    .line 17
    invoke-static {p0}, Lzq0;->a(I)V

    .line 18
    .line 19
    .line 20
    const/4 p0, 0x0

    .line 21
    throw p0
.end method

.method public final d()Z
    .registers 1

    .line 1
    iget-object p0, p0, Lzq0;->a:Lar0;

    .line 2
    .line 3
    iget-object p0, p0, Lar0;->a:Ljava/lang/String;

    .line 4
    .line 5
    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    .line 6
    .line 7
    .line 8
    move-result p0

    .line 9
    return p0
.end method

.method public final e()Lzq0;
    .registers 6

    .line 1
    iget-object v0, p0, Lzq0;->b:Lzq0;

    .line 2
    .line 3
    if-eqz v0, :cond_5

    .line 4
    .line 5
    return-object v0

    .line 6
    :cond_5
    invoke-virtual {p0}, Lzq0;->d()Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    const/4 v1, 0x0

    .line 11
    const-string v2, "root"

    .line 12
    .line 13
    if-nez v0, :cond_36

    .line 14
    .line 15
    new-instance v0, Lzq0;

    .line 16
    .line 17
    iget-object v3, p0, Lzq0;->a:Lar0;

    .line 18
    .line 19
    iget-object v4, v3, Lar0;->c:Lar0;

    .line 20
    .line 21
    if-eqz v4, :cond_17

    .line 22
    .line 23
    goto :goto_26

    .line 24
    :cond_17
    iget-object v4, v3, Lar0;->a:Ljava/lang/String;

    .line 25
    .line 26
    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    .line 27
    .line 28
    .line 29
    move-result v4

    .line 30
    if-nez v4, :cond_32

    .line 31
    .line 32
    invoke-virtual {v3}, Lar0;->c()V

    .line 33
    .line 34
    .line 35
    iget-object v4, v3, Lar0;->c:Lar0;

    .line 36
    .line 37
    if-eqz v4, :cond_2c

    .line 38
    .line 39
    :goto_26
    invoke-direct {v0, v4}, Lzq0;-><init>(Lar0;)V

    .line 40
    .line 41
    .line 42
    iput-object v0, p0, Lzq0;->b:Lzq0;

    .line 43
    .line 44
    return-object v0

    .line 45
    :cond_2c
    const/16 p0, 0x8

    .line 46
    .line 47
    invoke-static {p0}, Lar0;->a(I)V

    .line 48
    .line 49
    .line 50
    throw v1

    .line 51
    :cond_32
    invoke-static {v2}, Ly0;->h(Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    return-object v1

    .line 55
    :cond_36
    invoke-static {v2}, Ly0;->h(Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    return-object v1
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 5

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_4

    .line 3
    .line 4
    return v0

    .line 5
    :cond_4
    instance-of v1, p1, Lzq0;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_a

    .line 9
    .line 10
    return v2

    .line 11
    :cond_a
    check-cast p1, Lzq0;

    .line 12
    .line 13
    iget-object p0, p0, Lzq0;->a:Lar0;

    .line 14
    .line 15
    iget-object p1, p1, Lzq0;->a:Lar0;

    .line 16
    .line 17
    invoke-virtual {p0, p1}, Lar0;->equals(Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result p0

    .line 21
    if-nez p0, :cond_17

    .line 22
    .line 23
    return v2

    .line 24
    :cond_17
    return v0
.end method

.method public final f()Ldv1;
    .registers 1

    .line 1
    iget-object p0, p0, Lzq0;->a:Lar0;

    .line 2
    .line 3
    invoke-virtual {p0}, Lar0;->f()Ldv1;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    if-eqz p0, :cond_9

    .line 8
    .line 9
    return-object p0

    .line 10
    :cond_9
    const/16 p0, 0x9

    .line 11
    .line 12
    invoke-static {p0}, Lzq0;->a(I)V

    .line 13
    .line 14
    .line 15
    const/4 p0, 0x0

    .line 16
    throw p0
.end method

.method public final g()Ldv1;
    .registers 3

    .line 1
    iget-object p0, p0, Lzq0;->a:Lar0;

    .line 2
    .line 3
    iget-object v0, p0, Lar0;->a:Ljava/lang/String;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    const/4 v1, 0x0

    .line 10
    if-eqz v0, :cond_16

    .line 11
    .line 12
    sget-object p0, Lar0;->e:Ldv1;

    .line 13
    .line 14
    if-eqz p0, :cond_10

    .line 15
    .line 16
    return-object p0

    .line 17
    :cond_10
    const/16 p0, 0xc

    .line 18
    .line 19
    invoke-static {p0}, Lar0;->a(I)V

    .line 20
    .line 21
    .line 22
    throw v1

    .line 23
    :cond_16
    invoke-virtual {p0}, Lar0;->f()Ldv1;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    if-eqz p0, :cond_1d

    .line 28
    .line 29
    return-object p0

    .line 30
    :cond_1d
    const/16 p0, 0xd

    .line 31
    .line 32
    invoke-static {p0}, Lar0;->a(I)V

    .line 33
    .line 34
    .line 35
    throw v1
.end method

.method public final h(Ldv1;)Z
    .registers 5

    .line 1
    if-eqz p1, :cond_2e

    .line 2
    .line 3
    iget-object p0, p0, Lzq0;->a:Lar0;

    .line 4
    .line 5
    iget-object p0, p0, Lar0;->a:Ljava/lang/String;

    .line 6
    .line 7
    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    const/4 v1, 0x0

    .line 12
    if-eqz v0, :cond_e

    .line 13
    .line 14
    goto :goto_2d

    .line 15
    :cond_e
    const/16 v0, 0x2e

    .line 16
    .line 17
    invoke-virtual {p0, v0}, Ljava/lang/String;->indexOf(I)I

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    const/4 v2, -0x1

    .line 22
    if-ne v0, v2, :cond_1b

    .line 23
    .line 24
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    :cond_1b
    invoke-virtual {p1}, Ldv1;->b()Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 33
    .line 34
    .line 35
    move-result v2

    .line 36
    if-ne v0, v2, :cond_2d

    .line 37
    .line 38
    invoke-virtual {p0, v1, p1, v1, v0}, Ljava/lang/String;->regionMatches(ILjava/lang/String;II)Z

    .line 39
    .line 40
    .line 41
    move-result p0

    .line 42
    if-eqz p0, :cond_2d

    .line 43
    .line 44
    const/4 p0, 0x1

    .line 45
    return p0

    .line 46
    :cond_2d
    :goto_2d
    return v1

    .line 47
    :cond_2e
    const/16 p0, 0xc

    .line 48
    .line 49
    invoke-static {p0}, Lzq0;->a(I)V

    .line 50
    .line 51
    .line 52
    const/4 p0, 0x0

    .line 53
    throw p0
.end method

.method public final hashCode()I
    .registers 1

    .line 1
    iget-object p0, p0, Lzq0;->a:Lar0;

    .line 2
    .line 3
    iget-object p0, p0, Lar0;->a:Ljava/lang/String;

    .line 4
    .line 5
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    .line 6
    .line 7
    .line 8
    move-result p0

    .line 9
    return p0
.end method

.method public final i()Lar0;
    .registers 1

    .line 1
    iget-object p0, p0, Lzq0;->a:Lar0;

    .line 2
    .line 3
    if-eqz p0, :cond_5

    .line 4
    .line 5
    return-object p0

    .line 6
    :cond_5
    const/4 p0, 0x5

    .line 7
    invoke-static {p0}, Lzq0;->a(I)V

    .line 8
    .line 9
    .line 10
    const/4 p0, 0x0

    .line 11
    throw p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 1

    .line 1
    iget-object p0, p0, Lzq0;->a:Lar0;

    .line 2
    .line 3
    invoke-virtual {p0}, Lar0;->toString()Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method
