###### Class defpackage.h71 (h71)
.class public final Lh71;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lwk2;


# instance fields
.field public final a:Lrv2;


# direct methods
.method public constructor <init>(Ldt0;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lrv2;

    .line 5
    .line 6
    invoke-direct {v0, p1}, Lrv2;-><init>(Ldt0;)V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Lh71;->a:Lrv2;

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;)I
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lh71;->e()Lwk2;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    invoke-interface {p0, p1}, Lwk2;->a(Ljava/lang/String;)I

    .line 9
    .line 10
    .line 11
    move-result p0

    .line 12
    return p0
.end method

.method public final b()Ljava/lang/String;
    .registers 1

    .line 1
    invoke-virtual {p0}, Lh71;->e()Lwk2;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-interface {p0}, Lwk2;->b()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public final c()I
    .registers 1

    .line 1
    invoke-virtual {p0}, Lh71;->e()Lwk2;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-interface {p0}, Lwk2;->c()I

    .line 6
    .line 7
    .line 8
    move-result p0

    .line 9
    return p0
.end method

.method public final d(I)Ljava/lang/String;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lh71;->e()Lwk2;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-interface {p0, p1}, Lwk2;->d(I)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public final e()Lwk2;
    .registers 1

    .line 1
    iget-object p0, p0, Lh71;->a:Lrv2;

    .line 2
    .line 3
    invoke-virtual {p0}, Lrv2;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lwk2;

    .line 8
    .line 9
    return-object p0
.end method

.method public final g(I)Ljava/util/List;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lh71;->e()Lwk2;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-interface {p0, p1}, Lwk2;->g(I)Ljava/util/List;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public final h(I)Lwk2;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lh71;->e()Lwk2;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-interface {p0, p1}, Lwk2;->h(I)Lwk2;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public final i(I)Z
    .registers 2

    .line 1
    invoke-virtual {p0}, Lh71;->e()Lwk2;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-interface {p0, p1}, Lwk2;->i(I)Z

    .line 6
    .line 7
    .line 8
    move-result p0

    .line 9
    return p0
.end method

.method public final j()Lg70;
    .registers 1

    .line 1
    invoke-virtual {p0}, Lh71;->e()Lwk2;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-interface {p0}, Lwk2;->j()Lg70;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method
