###### Class defpackage.em3 (em3)
.class public final Lem3;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final a:J

.field public final b:J

.field public final c:Z

.field public final d:Lhr3;


# direct methods
.method public constructor <init>(JJZLhr3;)V
    .registers 7

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-wide p1, p0, Lem3;->a:J

    .line 5
    .line 6
    iput-wide p3, p0, Lem3;->b:J

    .line 7
    .line 8
    iput-boolean p5, p0, Lem3;->c:Z

    .line 9
    .line 10
    iput-object p6, p0, Lem3;->d:Lhr3;

    .line 11
    .line 12
    return-void
.end method
