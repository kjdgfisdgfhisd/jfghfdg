###### Class defpackage.j4 (j4)
.class public final Lj4;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# instance fields
.field public final synthetic a:Ln4;

.field public final synthetic b:Lk4;


# direct methods
.method public constructor <init>(Lk4;Ln4;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lj4;->b:Lk4;

    .line 5
    .line 6
    iput-object p2, p0, Lj4;->a:Ln4;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .registers 6

    .line 1
    iget-object p1, p0, Lj4;->b:Lk4;

    .line 2
    .line 3
    iget-object p2, p1, Lk4;->k:Landroid/content/DialogInterface$OnClickListener;

    .line 4
    .line 5
    iget-object p0, p0, Lj4;->a:Ln4;

    .line 6
    .line 7
    iget-object p4, p0, Ln4;->b:Lp4;

    .line 8
    .line 9
    invoke-interface {p2, p4, p3}, Landroid/content/DialogInterface$OnClickListener;->onClick(Landroid/content/DialogInterface;I)V

    .line 10
    .line 11
    .line 12
    iget-boolean p1, p1, Lk4;->m:Z

    .line 13
    .line 14
    if-nez p1, :cond_14

    .line 15
    .line 16
    iget-object p0, p0, Ln4;->b:Lp4;

    .line 17
    .line 18
    invoke-virtual {p0}, Lw8;->dismiss()V

    .line 19
    .line 20
    .line 21
    :cond_14
    return-void
.end method
