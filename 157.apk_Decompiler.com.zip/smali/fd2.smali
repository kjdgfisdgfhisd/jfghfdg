###### Class defpackage.fd2 (fd2)
.class public final Lfd2;
.super Loc2;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final b:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Ldv1;Ljava/lang/Object;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1}, Loc2;-><init>(Ldv1;)V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, Lfd2;->b:Ljava/lang/Object;

    .line 5
    .line 6
    return-void
.end method
