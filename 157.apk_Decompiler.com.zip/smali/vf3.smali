###### Class defpackage.vf3 (vf3)
.class public final synthetic Lvf3;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lut0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:Lcc/bomber/x/g/c;

.field public final synthetic d:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lcc/bomber/x/g/c;Ljava/lang/String;Ljava/lang/String;)V
    .registers 5

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lvf3;->a:I

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p2, p0, Lvf3;->b:Ljava/lang/String;

    .line 8
    .line 9
    iput-object p3, p0, Lvf3;->d:Ljava/lang/String;

    .line 10
    .line 11
    iput-object p1, p0, Lvf3;->c:Lcc/bomber/x/g/c;

    .line 12
    .line 13
    return-void
.end method

.method public synthetic constructor <init>(Lcc/bomber/x/g/c;Ljava/lang/String;Ljava/lang/String;I)V
    .registers 5

    .line 14
    iput p4, p0, Lvf3;->a:I

    iput-object p2, p0, Lvf3;->b:Ljava/lang/String;

    iput-object p1, p0, Lvf3;->c:Lcc/bomber/x/g/c;

    iput-object p3, p0, Lvf3;->d:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 11

    .line 1
    iget v0, p0, Lvf3;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_7e

    .line 4
    .line 5
    .line 6
    move-object v4, p1

    .line 7
    check-cast v4, Lcc/bomber/x/g/c;

    .line 8
    .line 9
    move-object v5, p2

    .line 10
    check-cast v5, Lio;

    .line 11
    .line 12
    move-object v6, p3

    .line 13
    check-cast v6, Lfg2;

    .line 14
    .line 15
    iget-object v1, p0, Lvf3;->b:Ljava/lang/String;

    .line 16
    .line 17
    iget-object v2, p0, Lvf3;->c:Lcc/bomber/x/g/c;

    .line 18
    .line 19
    iget-object v3, p0, Lvf3;->d:Ljava/lang/String;

    .line 20
    .line 21
    invoke-static/range {v1 .. v6}, Lcc/bomber/x/i/c;->n(Ljava/lang/String;Lcc/bomber/x/g/c;Ljava/lang/String;Lcc/bomber/x/g/c;Lio;Lfg2;)Lw43;

    .line 22
    .line 23
    .line 24
    move-result-object p0

    .line 25
    return-object p0

    .line 26
    :pswitch_19
    move-object v3, p1

    .line 27
    check-cast v3, Lcc/bomber/x/g/c;

    .line 28
    .line 29
    move-object v4, p2

    .line 30
    check-cast v4, Lio;

    .line 31
    .line 32
    move-object v5, p3

    .line 33
    check-cast v5, Lfg2;

    .line 34
    .line 35
    iget-object v0, p0, Lvf3;->b:Ljava/lang/String;

    .line 36
    .line 37
    iget-object v1, p0, Lvf3;->c:Lcc/bomber/x/g/c;

    .line 38
    .line 39
    iget-object v2, p0, Lvf3;->d:Ljava/lang/String;

    .line 40
    .line 41
    invoke-static/range {v0 .. v5}, Lcc/bomber/x/i/c;->t4(Ljava/lang/String;Lcc/bomber/x/g/c;Ljava/lang/String;Lcc/bomber/x/g/c;Lio;Lfg2;)Lw43;

    .line 42
    .line 43
    .line 44
    move-result-object p0

    .line 45
    return-object p0

    .line 46
    :pswitch_2d
    move-object v3, p1

    .line 47
    check-cast v3, Lcc/bomber/x/g/c;

    .line 48
    .line 49
    move-object v4, p2

    .line 50
    check-cast v4, Lio;

    .line 51
    .line 52
    move-object v5, p3

    .line 53
    check-cast v5, Lfg2;

    .line 54
    .line 55
    iget-object v0, p0, Lvf3;->b:Ljava/lang/String;

    .line 56
    .line 57
    iget-object v1, p0, Lvf3;->c:Lcc/bomber/x/g/c;

    .line 58
    .line 59
    iget-object v2, p0, Lvf3;->d:Ljava/lang/String;

    .line 60
    .line 61
    invoke-static/range {v0 .. v5}, Lcc/bomber/x/i/c;->E5(Ljava/lang/String;Lcc/bomber/x/g/c;Ljava/lang/String;Lcc/bomber/x/g/c;Lio;Lfg2;)Lw43;

    .line 62
    .line 63
    .line 64
    move-result-object p0

    .line 65
    return-object p0

    .line 66
    :pswitch_41
    move-object v3, p1

    .line 67
    check-cast v3, Lcc/bomber/x/g/c;

    .line 68
    .line 69
    move-object v4, p2

    .line 70
    check-cast v4, Lio;

    .line 71
    .line 72
    move-object v5, p3

    .line 73
    check-cast v5, Lfg2;

    .line 74
    .line 75
    iget-object v0, p0, Lvf3;->b:Ljava/lang/String;

    .line 76
    .line 77
    iget-object v1, p0, Lvf3;->c:Lcc/bomber/x/g/c;

    .line 78
    .line 79
    iget-object v2, p0, Lvf3;->d:Ljava/lang/String;

    .line 80
    .line 81
    invoke-static/range {v0 .. v5}, Lcc/bomber/x/i/c;->m1(Ljava/lang/String;Lcc/bomber/x/g/c;Ljava/lang/String;Lcc/bomber/x/g/c;Lio;Lfg2;)Lw43;

    .line 82
    .line 83
    .line 84
    move-result-object p0

    .line 85
    return-object p0

    .line 86
    :pswitch_55
    move-object v3, p1

    .line 87
    check-cast v3, Lcc/bomber/x/g/c;

    .line 88
    .line 89
    move-object v4, p2

    .line 90
    check-cast v4, Lio;

    .line 91
    .line 92
    move-object v5, p3

    .line 93
    check-cast v5, Lfg2;

    .line 94
    .line 95
    iget-object v0, p0, Lvf3;->b:Ljava/lang/String;

    .line 96
    .line 97
    iget-object v1, p0, Lvf3;->c:Lcc/bomber/x/g/c;

    .line 98
    .line 99
    iget-object v2, p0, Lvf3;->d:Ljava/lang/String;

    .line 100
    .line 101
    invoke-static/range {v0 .. v5}, Lcc/bomber/x/i/a;->n(Ljava/lang/String;Lcc/bomber/x/g/c;Ljava/lang/String;Lcc/bomber/x/g/c;Lio;Lfg2;)Lw43;

    .line 102
    .line 103
    .line 104
    move-result-object p0

    .line 105
    return-object p0

    .line 106
    :pswitch_69
    move-object v3, p1

    .line 107
    check-cast v3, Lcc/bomber/x/g/c;

    .line 108
    .line 109
    move-object v4, p2

    .line 110
    check-cast v4, Lio;

    .line 111
    .line 112
    move-object v5, p3

    .line 113
    check-cast v5, Lfg2;

    .line 114
    .line 115
    iget-object v0, p0, Lvf3;->b:Ljava/lang/String;

    .line 116
    .line 117
    iget-object v1, p0, Lvf3;->c:Lcc/bomber/x/g/c;

    .line 118
    .line 119
    iget-object v2, p0, Lvf3;->d:Ljava/lang/String;

    .line 120
    .line 121
    invoke-static/range {v0 .. v5}, Lcc/bomber/x/h/a;->x(Ljava/lang/String;Lcc/bomber/x/g/c;Ljava/lang/String;Lcc/bomber/x/g/c;Lio;Lfg2;)Lw43;

    .line 122
    .line 123
    .line 124
    move-result-object p0

    .line 125
    return-object p0

    .line 126
    nop

    .line 127
    :pswitch_data_7e
    .packed-switch 0x0
        :pswitch_69
        :pswitch_55
        :pswitch_41
        :pswitch_2d
        :pswitch_19
    .end packed-switch
.end method
