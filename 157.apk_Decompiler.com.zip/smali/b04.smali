###### Class defpackage.b04 (b04)
.class public final Lb04;
.super Lwu3;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field public static final n:[Ljava/lang/String;

.field public static final o:[Ljava/lang/String;


# instance fields
.field public e:Ljava/security/SecureRandom;

.field public final f:Ljava/util/concurrent/atomic/AtomicLong;

.field public g:I

.field public j:Ler1;

.field public l:Ljava/lang/Boolean;

.field public m:Ljava/lang/Integer;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    const-string v0, "google_"

    .line 2
    .line 3
    const-string v1, "ga_"

    .line 4
    .line 5
    const-string v2, "firebase_"

    .line 6
    .line 7
    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    sput-object v0, Lb04;->n:[Ljava/lang/String;

    .line 12
    .line 13
    const-string v0, "_err"

    .line 14
    .line 15
    filled-new-array {v0}, [Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    sput-object v0, Lb04;->o:[Ljava/lang/String;

    .line 20
    .line 21
    return-void
.end method

.method public constructor <init>(Lzt3;)V
    .registers 4

    .line 1
    invoke-direct {p0, p1}, Lwu3;-><init>(Lzt3;)V

    .line 2
    .line 3
    .line 4
    const/4 p1, 0x0

    .line 5
    iput-object p1, p0, Lb04;->m:Ljava/lang/Integer;

    .line 6
    .line 7
    new-instance p1, Ljava/util/concurrent/atomic/AtomicLong;

    .line 8
    .line 9
    const-wide/16 v0, 0x0

    .line 10
    .line 11
    invoke-direct {p1, v0, v1}, Ljava/util/concurrent/atomic/AtomicLong;-><init>(J)V

    .line 12
    .line 13
    .line 14
    iput-object p1, p0, Lb04;->f:Ljava/util/concurrent/atomic/AtomicLong;

    .line 15
    .line 16
    return-void
.end method

.method public static C1(Ljava/util/List;)Ljava/util/ArrayList;
    .registers 7

    .line 1
    if-nez p0, :cond_9

    .line 2
    .line 3
    new-instance p0, Ljava/util/ArrayList;

    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    invoke-direct {p0, v0}, Ljava/util/ArrayList;-><init>(I)V

    .line 7
    .line 8
    .line 9
    return-object p0

    .line 10
    :cond_9
    new-instance v0, Ljava/util/ArrayList;

    .line 11
    .line 12
    invoke-interface {p0}, Ljava/util/List;->size()I

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 17
    .line 18
    .line 19
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    :goto_16
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    if-eqz v1, :cond_c5

    .line 28
    .line 29
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    check-cast v1, Lll3;

    .line 34
    .line 35
    new-instance v2, Landroid/os/Bundle;

    .line 36
    .line 37
    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    .line 38
    .line 39
    .line 40
    const-string v3, "app_id"

    .line 41
    .line 42
    iget-object v4, v1, Lll3;->a:Ljava/lang/String;

    .line 43
    .line 44
    invoke-virtual {v2, v3, v4}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    const-string v3, "origin"

    .line 48
    .line 49
    iget-object v4, v1, Lll3;->b:Ljava/lang/String;

    .line 50
    .line 51
    invoke-virtual {v2, v3, v4}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    const-string v3, "creation_timestamp"

    .line 55
    .line 56
    iget-wide v4, v1, Lll3;->d:J

    .line 57
    .line 58
    invoke-virtual {v2, v3, v4, v5}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    .line 59
    .line 60
    .line 61
    iget-object v3, v1, Lll3;->c:Lvz3;

    .line 62
    .line 63
    iget-object v3, v3, Lvz3;->b:Ljava/lang/String;

    .line 64
    .line 65
    const-string v4, "name"

    .line 66
    .line 67
    invoke-virtual {v2, v4, v3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 68
    .line 69
    .line 70
    iget-object v3, v1, Lll3;->c:Lvz3;

    .line 71
    .line 72
    invoke-virtual {v3}, Lvz3;->a()Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v3

    .line 76
    invoke-static {v3}, Lmw1;->k(Ljava/lang/Object;)V

    .line 77
    .line 78
    .line 79
    invoke-static {v2, v3}, Ll60;->D(Landroid/os/Bundle;Ljava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    const-string v3, "active"

    .line 83
    .line 84
    iget-boolean v4, v1, Lll3;->e:Z

    .line 85
    .line 86
    invoke-virtual {v2, v3, v4}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    .line 87
    .line 88
    .line 89
    iget-object v3, v1, Lll3;->f:Ljava/lang/String;

    .line 90
    .line 91
    if-eqz v3, :cond_61

    .line 92
    .line 93
    const-string v4, "trigger_event_name"

    .line 94
    .line 95
    invoke-virtual {v2, v4, v3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 96
    .line 97
    .line 98
    :cond_61
    iget-object v3, v1, Lll3;->g:Lhn3;

    .line 99
    .line 100
    if-eqz v3, :cond_79

    .line 101
    .line 102
    const-string v4, "timed_out_event_name"

    .line 103
    .line 104
    iget-object v5, v3, Lhn3;->a:Ljava/lang/String;

    .line 105
    .line 106
    invoke-virtual {v2, v4, v5}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 107
    .line 108
    .line 109
    iget-object v3, v3, Lhn3;->b:Lgn3;

    .line 110
    .line 111
    if-eqz v3, :cond_79

    .line 112
    .line 113
    const-string v4, "timed_out_event_params"

    .line 114
    .line 115
    invoke-virtual {v3}, Lgn3;->c()Landroid/os/Bundle;

    .line 116
    .line 117
    .line 118
    move-result-object v3

    .line 119
    invoke-virtual {v2, v4, v3}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 120
    .line 121
    .line 122
    :cond_79
    const-string v3, "trigger_timeout"

    .line 123
    .line 124
    iget-wide v4, v1, Lll3;->j:J

    .line 125
    .line 126
    invoke-virtual {v2, v3, v4, v5}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    .line 127
    .line 128
    .line 129
    iget-object v3, v1, Lll3;->l:Lhn3;

    .line 130
    .line 131
    if-eqz v3, :cond_98

    .line 132
    .line 133
    const-string v4, "triggered_event_name"

    .line 134
    .line 135
    iget-object v5, v3, Lhn3;->a:Ljava/lang/String;

    .line 136
    .line 137
    invoke-virtual {v2, v4, v5}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 138
    .line 139
    .line 140
    iget-object v3, v3, Lhn3;->b:Lgn3;

    .line 141
    .line 142
    if-eqz v3, :cond_98

    .line 143
    .line 144
    const-string v4, "triggered_event_params"

    .line 145
    .line 146
    invoke-virtual {v3}, Lgn3;->c()Landroid/os/Bundle;

    .line 147
    .line 148
    .line 149
    move-result-object v3

    .line 150
    invoke-virtual {v2, v4, v3}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 151
    .line 152
    .line 153
    :cond_98
    iget-object v3, v1, Lll3;->c:Lvz3;

    .line 154
    .line 155
    iget-wide v3, v3, Lvz3;->c:J

    .line 156
    .line 157
    const-string v5, "triggered_timestamp"

    .line 158
    .line 159
    invoke-virtual {v2, v5, v3, v4}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    .line 160
    .line 161
    .line 162
    const-string v3, "time_to_live"

    .line 163
    .line 164
    iget-wide v4, v1, Lll3;->m:J

    .line 165
    .line 166
    invoke-virtual {v2, v3, v4, v5}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    .line 167
    .line 168
    .line 169
    iget-object v1, v1, Lll3;->n:Lhn3;

    .line 170
    .line 171
    if-eqz v1, :cond_c0

    .line 172
    .line 173
    const-string v3, "expired_event_name"

    .line 174
    .line 175
    iget-object v4, v1, Lhn3;->a:Ljava/lang/String;

    .line 176
    .line 177
    invoke-virtual {v2, v3, v4}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 178
    .line 179
    .line 180
    iget-object v1, v1, Lhn3;->b:Lgn3;

    .line 181
    .line 182
    if-eqz v1, :cond_c0

    .line 183
    .line 184
    const-string v3, "expired_event_params"

    .line 185
    .line 186
    invoke-virtual {v1}, Lgn3;->c()Landroid/os/Bundle;

    .line 187
    .line 188
    .line 189
    move-result-object v1

    .line 190
    invoke-virtual {v2, v3, v1}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 191
    .line 192
    .line 193
    :cond_c0
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 194
    .line 195
    .line 196
    goto/16 :goto_16

    .line 197
    .line 198
    :cond_c5
    return-object v0
.end method

.method public static D1(ILandroid/os/Bundle;)Z
    .registers 7

    .line 1
    const-string v0, "_err"

    .line 2
    .line 3
    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;)J

    .line 4
    .line 5
    .line 6
    move-result-wide v1

    .line 7
    const-wide/16 v3, 0x0

    .line 8
    .line 9
    cmp-long v1, v1, v3

    .line 10
    .line 11
    if-nez v1, :cond_12

    .line 12
    .line 13
    int-to-long v1, p0

    .line 14
    invoke-virtual {p1, v0, v1, v2}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    .line 15
    .line 16
    .line 17
    const/4 p0, 0x1

    .line 18
    return p0

    .line 19
    :cond_12
    const/4 p0, 0x0

    .line 20
    return p0
.end method

.method public static K1(Ljava/lang/String;)Z
    .registers 3

    .line 1
    sget-object v0, Ljn3;->z0:Lxr3;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-virtual {v0, v1}, Lxr3;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    check-cast v0, Ljava/lang/String;

    .line 9
    .line 10
    const-string v1, "*"

    .line 11
    .line 12
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    if-nez v1, :cond_24

    .line 17
    .line 18
    const-string v1, ","

    .line 19
    .line 20
    invoke-virtual {v0, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    invoke-interface {v0, p0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result p0

    .line 32
    if-eqz p0, :cond_22

    .line 33
    .line 34
    goto :goto_24

    .line 35
    :cond_22
    const/4 p0, 0x0

    .line 36
    return p0

    .line 37
    :cond_24
    :goto_24
    const/4 p0, 0x1

    .line 38
    return p0
.end method

.method public static M1(Ljava/lang/String;)Z
    .registers 2

    .line 1
    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_10

    .line 6
    .line 7
    const-string v0, "_"

    .line 8
    .line 9
    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 10
    .line 11
    .line 12
    move-result p0

    .line 13
    if-eqz p0, :cond_10

    .line 14
    .line 15
    const/4 p0, 0x1

    .line 16
    return p0

    .line 17
    :cond_10
    const/4 p0, 0x0

    .line 18
    return p0
.end method

.method public static N1(Ljava/lang/String;)Z
    .registers 4

    .line 1
    invoke-static {p0}, Lmw1;->g(Ljava/lang/String;)V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-virtual {p0, v0}, Ljava/lang/String;->charAt(I)C

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const/16 v2, 0x5f

    .line 10
    .line 11
    if-ne v1, v2, :cond_16

    .line 12
    .line 13
    const-string v1, "_ep"

    .line 14
    .line 15
    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    if-eqz p0, :cond_15

    .line 20
    .line 21
    goto :goto_16

    .line 22
    :cond_15
    return v0

    .line 23
    :cond_16
    :goto_16
    const/4 p0, 0x1

    .line 24
    return p0
.end method

.method public static O0(Lgn3;)J
    .registers 6

    .line 1
    const-wide/16 v0, 0x0

    .line 2
    .line 3
    if-nez p0, :cond_5

    .line 4
    .line 5
    return-wide v0

    .line 6
    :cond_5
    iget-object p0, p0, Lgn3;->a:Landroid/os/Bundle;

    .line 7
    .line 8
    invoke-virtual {p0}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    .line 9
    .line 10
    .line 11
    move-result-object v2

    .line 12
    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    :cond_f
    :goto_f
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 17
    .line 18
    .line 19
    move-result v3

    .line 20
    if-eqz v3, :cond_29

    .line 21
    .line 22
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v3

    .line 26
    check-cast v3, Ljava/lang/String;

    .line 27
    .line 28
    invoke-virtual {p0, v3}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v3

    .line 32
    instance-of v4, v3, [Landroid/os/Parcelable;

    .line 33
    .line 34
    if-eqz v4, :cond_f

    .line 35
    .line 36
    check-cast v3, [Landroid/os/Parcelable;

    .line 37
    .line 38
    array-length v3, v3

    .line 39
    int-to-long v3, v3

    .line 40
    add-long/2addr v0, v3

    .line 41
    goto :goto_f

    .line 42
    :cond_29
    return-wide v0
.end method

.method public static P0([B)J
    .registers 9

    .line 1
    invoke-static {p0}, Lmw1;->k(Ljava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    array-length v0, p0

    .line 5
    if-lez v0, :cond_21

    .line 6
    .line 7
    array-length v0, p0

    .line 8
    add-int/lit8 v0, v0, -0x1

    .line 9
    .line 10
    const/4 v1, 0x0

    .line 11
    const-wide/16 v2, 0x0

    .line 12
    .line 13
    :goto_c
    if-ltz v0, :cond_20

    .line 14
    .line 15
    array-length v4, p0

    .line 16
    add-int/lit8 v4, v4, -0x8

    .line 17
    .line 18
    if-lt v0, v4, :cond_20

    .line 19
    .line 20
    aget-byte v4, p0, v0

    .line 21
    .line 22
    int-to-long v4, v4

    .line 23
    const-wide/16 v6, 0xff

    .line 24
    .line 25
    and-long/2addr v4, v6

    .line 26
    shl-long/2addr v4, v1

    .line 27
    add-long/2addr v2, v4

    .line 28
    add-int/lit8 v1, v1, 0x8

    .line 29
    .line 30
    add-int/lit8 v0, v0, -0x1

    .line 31
    .line 32
    goto :goto_c

    .line 33
    :cond_20
    return-wide v2

    .line 34
    :cond_21
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 35
    .line 36
    invoke-direct {p0}, Ljava/lang/IllegalStateException;-><init>()V

    .line 37
    .line 38
    .line 39
    throw p0
.end method

.method public static P1(Ljava/lang/String;)I
    .registers 2

    .line 1
    const-string v0, "_ldl"

    .line 2
    .line 3
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_b

    .line 8
    .line 9
    const/16 p0, 0x800

    .line 10
    .line 11
    return p0

    .line 12
    :cond_b
    const-string v0, "_id"

    .line 13
    .line 14
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_16

    .line 19
    .line 20
    const/16 p0, 0x100

    .line 21
    .line 22
    return p0

    .line 23
    :cond_16
    const-string v0, "_lgclid"

    .line 24
    .line 25
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result p0

    .line 29
    if-eqz p0, :cond_21

    .line 30
    .line 31
    const/16 p0, 0x64

    .line 32
    .line 33
    return p0

    .line 34
    :cond_21
    const/16 p0, 0x24

    .line 35
    .line 36
    return p0
.end method

.method public static T0(Ljava/util/List;)Landroid/os/Bundle;
    .registers 5

    .line 1
    new-instance v0, Landroid/os/Bundle;

    .line 2
    .line 3
    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 4
    .line 5
    .line 6
    if-nez p0, :cond_8

    .line 7
    .line 8
    goto :goto_3a

    .line 9
    :cond_8
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    :cond_c
    :goto_c
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    if-eqz v1, :cond_3a

    .line 18
    .line 19
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    check-cast v1, Lvz3;

    .line 24
    .line 25
    iget-object v2, v1, Lvz3;->e:Ljava/lang/String;

    .line 26
    .line 27
    iget-object v3, v1, Lvz3;->b:Ljava/lang/String;

    .line 28
    .line 29
    if-eqz v2, :cond_22

    .line 30
    .line 31
    invoke-virtual {v0, v3, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    goto :goto_c

    .line 35
    :cond_22
    iget-object v2, v1, Lvz3;->d:Ljava/lang/Long;

    .line 36
    .line 37
    if-eqz v2, :cond_2e

    .line 38
    .line 39
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 40
    .line 41
    .line 42
    move-result-wide v1

    .line 43
    invoke-virtual {v0, v3, v1, v2}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    .line 44
    .line 45
    .line 46
    goto :goto_c

    .line 47
    :cond_2e
    iget-object v1, v1, Lvz3;->g:Ljava/lang/Double;

    .line 48
    .line 49
    if-eqz v1, :cond_c

    .line 50
    .line 51
    invoke-virtual {v1}, Ljava/lang/Double;->doubleValue()D

    .line 52
    .line 53
    .line 54
    move-result-wide v1

    .line 55
    invoke-virtual {v0, v3, v1, v2}, Landroid/os/BaseBundle;->putDouble(Ljava/lang/String;D)V

    .line 56
    .line 57
    .line 58
    goto :goto_c

    .line 59
    :cond_3a
    :goto_3a
    return-object v0
.end method

.method public static U1()Ljava/security/MessageDigest;
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    :goto_1
    const/4 v1, 0x2

    .line 3
    if-ge v0, v1, :cond_10

    .line 4
    .line 5
    :try_start_4
    const-string v1, "MD5"

    .line 6
    .line 7
    invoke-static {v1}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    .line 8
    .line 9
    .line 10
    move-result-object v1
    :try_end_a
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_4 .. :try_end_a} :catch_d

    .line 11
    if-eqz v1, :cond_d

    .line 12
    .line 13
    return-object v1

    .line 14
    :catch_d
    :cond_d
    add-int/lit8 v0, v0, 0x1

    .line 15
    .line 16
    goto :goto_1

    .line 17
    :cond_10
    const/4 v0, 0x0

    .line 18
    return-object v0
.end method

.method public static V0(ILjava/lang/String;Z)Ljava/lang/String;
    .registers 5

    .line 1
    if-nez p1, :cond_3

    .line 2
    .line 3
    goto :goto_1f

    .line 4
    :cond_3
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    const/4 v1, 0x0

    .line 9
    invoke-virtual {p1, v1, v0}, Ljava/lang/String;->codePointCount(II)I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-le v0, p0, :cond_21

    .line 14
    .line 15
    if-eqz p2, :cond_1f

    .line 16
    .line 17
    invoke-virtual {p1, v1, p0}, Ljava/lang/String;->offsetByCodePoints(II)I

    .line 18
    .line 19
    .line 20
    move-result p0

    .line 21
    invoke-virtual {p1, v1, p0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object p0

    .line 25
    const-string p1, "..."

    .line 26
    .line 27
    invoke-virtual {p0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    return-object p0

    .line 32
    :cond_1f
    :goto_1f
    const/4 p0, 0x0

    .line 33
    return-object p0

    .line 34
    :cond_21
    return-object p1
.end method

.method public static Y0(Landroid/os/Bundle;ILjava/lang/String;Ljava/lang/Object;)V
    .registers 5

    .line 1
    invoke-static {p1, p0}, Lb04;->D1(ILandroid/os/Bundle;)Z

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    if-eqz p1, :cond_2a

    .line 6
    .line 7
    const/16 p1, 0x28

    .line 8
    .line 9
    const/4 v0, 0x1

    .line 10
    invoke-static {p1, p2, v0}, Lb04;->V0(ILjava/lang/String;Z)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    const-string p2, "_ev"

    .line 15
    .line 16
    invoke-virtual {p0, p2, p1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    if-eqz p3, :cond_2a

    .line 20
    .line 21
    instance-of p1, p3, Ljava/lang/String;

    .line 22
    .line 23
    if-nez p1, :cond_1c

    .line 24
    .line 25
    instance-of p1, p3, Ljava/lang/CharSequence;

    .line 26
    .line 27
    if-eqz p1, :cond_2a

    .line 28
    .line 29
    :cond_1c
    invoke-static {p3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 34
    .line 35
    .line 36
    move-result p1

    .line 37
    int-to-long p1, p1

    .line 38
    const-string p3, "_el"

    .line 39
    .line 40
    invoke-virtual {p0, p3, p1, p2}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    .line 41
    .line 42
    .line 43
    :cond_2a
    return-void
.end method

.method public static k1(Luw3;Landroid/os/Bundle;Z)V
    .registers 7

    .line 1
    const-string v0, "_si"

    .line 2
    .line 3
    const-string v1, "_sn"

    .line 4
    .line 5
    const-string v2, "_sc"

    .line 6
    .line 7
    if-eqz p1, :cond_2e

    .line 8
    .line 9
    if-eqz p0, :cond_2e

    .line 10
    .line 11
    invoke-virtual {p1, v2}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 12
    .line 13
    .line 14
    move-result v3

    .line 15
    if-eqz v3, :cond_12

    .line 16
    .line 17
    if-eqz p2, :cond_2e

    .line 18
    .line 19
    :cond_12
    iget-object p2, p0, Luw3;->a:Ljava/lang/String;

    .line 20
    .line 21
    if-eqz p2, :cond_1a

    .line 22
    .line 23
    invoke-virtual {p1, v1, p2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    goto :goto_1d

    .line 27
    :cond_1a
    invoke-virtual {p1, v1}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    :goto_1d
    iget-object p2, p0, Luw3;->b:Ljava/lang/String;

    .line 31
    .line 32
    if-eqz p2, :cond_25

    .line 33
    .line 34
    invoke-virtual {p1, v2, p2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    goto :goto_28

    .line 38
    :cond_25
    invoke-virtual {p1, v2}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    :goto_28
    iget-wide v1, p0, Luw3;->c:J

    .line 42
    .line 43
    invoke-virtual {p1, v0, v1, v2}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    .line 44
    .line 45
    .line 46
    return-void

    .line 47
    :cond_2e
    if-eqz p1, :cond_3d

    .line 48
    .line 49
    if-nez p0, :cond_3d

    .line 50
    .line 51
    if-eqz p2, :cond_3d

    .line 52
    .line 53
    invoke-virtual {p1, v1}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    invoke-virtual {p1, v2}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    invoke-virtual {p1, v0}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    :cond_3d
    return-void
.end method

.method public static l1(Lzz3;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;I)V
    .registers 8

    .line 1
    new-instance v0, Landroid/os/Bundle;

    .line 2
    .line 3
    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-static {p2, v0}, Lb04;->D1(ILandroid/os/Bundle;)Z

    .line 7
    .line 8
    .line 9
    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    if-nez v1, :cond_17

    .line 14
    .line 15
    invoke-static {p4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 16
    .line 17
    .line 18
    move-result v1

    .line 19
    if-nez v1, :cond_17

    .line 20
    .line 21
    invoke-virtual {v0, p3, p4}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    :cond_17
    const/4 p3, 0x6

    .line 25
    if-eq p2, p3, :cond_20

    .line 26
    .line 27
    const/4 p3, 0x7

    .line 28
    if-eq p2, p3, :cond_20

    .line 29
    .line 30
    const/4 p3, 0x2

    .line 31
    if-ne p2, p3, :cond_26

    .line 32
    .line 33
    :cond_20
    const-string p2, "_el"

    .line 34
    .line 35
    int-to-long p3, p5

    .line 36
    invoke-virtual {v0, p2, p3, p4}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    .line 37
    .line 38
    .line 39
    :cond_26
    const-string p2, "_err"

    .line 40
    .line 41
    invoke-interface {p0, p1, p2, v0}, Lzz3;->a(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)V

    .line 42
    .line 43
    .line 44
    return-void
.end method

.method public static n1(Landroid/content/Context;)Z
    .registers 5

    .line 1
    invoke-static {p0}, Lmw1;->k(Ljava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    :try_start_4
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    if-nez v1, :cond_b

    .line 10
    .line 11
    goto :goto_1e

    .line 12
    :cond_b
    new-instance v2, Landroid/content/ComponentName;

    .line 13
    .line 14
    const-string v3, "com.google.android.gms.measurement.AppMeasurementReceiver"

    .line 15
    .line 16
    invoke-direct {v2, p0, v3}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {v1, v2, v0}, Landroid/content/pm/PackageManager;->getReceiverInfo(Landroid/content/ComponentName;I)Landroid/content/pm/ActivityInfo;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    if-eqz p0, :cond_1e

    .line 24
    .line 25
    iget-boolean p0, p0, Landroid/content/pm/ActivityInfo;->enabled:Z
    :try_end_1a
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_4 .. :try_end_1a} :catch_1e

    .line 26
    .line 27
    if-eqz p0, :cond_1e

    .line 28
    .line 29
    const/4 p0, 0x1

    .line 30
    return p0

    .line 31
    :catch_1e
    :cond_1e
    :goto_1e
    return v0
.end method

.method public static o1(Landroid/content/Intent;)Z
    .registers 2

    .line 1
    const-string v0, "android.intent.extra.REFERRER_NAME"

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    const-string v0, "android-app://com.google.android.googlequicksearchbox/https/www.google.com"

    .line 8
    .line 9
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-nez v0, :cond_21

    .line 14
    .line 15
    const-string v0, "https://www.google.com"

    .line 16
    .line 17
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-nez v0, :cond_21

    .line 22
    .line 23
    const-string v0, "android-app://com.google.appcrawler"

    .line 24
    .line 25
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result p0

    .line 29
    if-eqz p0, :cond_1f

    .line 30
    .line 31
    goto :goto_21

    .line 32
    :cond_1f
    const/4 p0, 0x0

    .line 33
    return p0

    .line 34
    :cond_21
    :goto_21
    const/4 p0, 0x1

    .line 35
    return p0
.end method

.method public static p1(Ljava/lang/Object;)Z
    .registers 2

    .line 1
    instance-of v0, p0, [Landroid/os/Parcelable;

    .line 2
    .line 3
    if-nez v0, :cond_f

    .line 4
    .line 5
    instance-of v0, p0, Ljava/util/ArrayList;

    .line 6
    .line 7
    if-nez v0, :cond_f

    .line 8
    .line 9
    instance-of p0, p0, Landroid/os/Bundle;

    .line 10
    .line 11
    if-eqz p0, :cond_d

    .line 12
    .line 13
    goto :goto_f

    .line 14
    :cond_d
    const/4 p0, 0x0

    .line 15
    return p0

    .line 16
    :cond_f
    :goto_f
    const/4 p0, 0x1

    .line 17
    return p0
.end method

.method public static u1(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z
    .registers 6

    .line 1
    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    if-nez v0, :cond_16

    .line 10
    .line 11
    if-nez v1, :cond_16

    .line 12
    .line 13
    invoke-static {p0}, Lmw1;->k(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    move-result p0

    .line 20
    if-nez p0, :cond_59

    .line 21
    .line 22
    goto :goto_5b

    .line 23
    :cond_16
    if-eqz v0, :cond_34

    .line 24
    .line 25
    if-eqz v1, :cond_34

    .line 26
    .line 27
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 28
    .line 29
    .line 30
    move-result p0

    .line 31
    if-nez p0, :cond_2d

    .line 32
    .line 33
    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 34
    .line 35
    .line 36
    move-result p0

    .line 37
    if-nez p0, :cond_2d

    .line 38
    .line 39
    invoke-virtual {p2, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    move-result p0

    .line 43
    if-nez p0, :cond_59

    .line 44
    .line 45
    goto :goto_5b

    .line 46
    :cond_2d
    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 47
    .line 48
    .line 49
    move-result p0

    .line 50
    if-nez p0, :cond_59

    .line 51
    .line 52
    goto :goto_5b

    .line 53
    :cond_34
    if-nez v0, :cond_4c

    .line 54
    .line 55
    if-eqz v1, :cond_4c

    .line 56
    .line 57
    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 58
    .line 59
    .line 60
    move-result p0

    .line 61
    if-eqz p0, :cond_3f

    .line 62
    .line 63
    goto :goto_59

    .line 64
    :cond_3f
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 65
    .line 66
    .line 67
    move-result p0

    .line 68
    if-nez p0, :cond_5b

    .line 69
    .line 70
    invoke-virtual {p2, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 71
    .line 72
    .line 73
    move-result p0

    .line 74
    if-nez p0, :cond_59

    .line 75
    .line 76
    goto :goto_5b

    .line 77
    :cond_4c
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 78
    .line 79
    .line 80
    move-result p0

    .line 81
    if-nez p0, :cond_5b

    .line 82
    .line 83
    invoke-virtual {p2, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 84
    .line 85
    .line 86
    move-result p0

    .line 87
    if-nez p0, :cond_59

    .line 88
    .line 89
    goto :goto_5b

    .line 90
    :cond_59
    :goto_59
    const/4 p0, 0x0

    .line 91
    return p0

    .line 92
    :cond_5b
    :goto_5b
    const/4 p0, 0x1

    .line 93
    return p0
.end method

.method public static v1(Ljava/lang/String;[Ljava/lang/String;)Z
    .registers 6

    .line 1
    invoke-static {p1}, Lmw1;->k(Ljava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    array-length v0, p1

    .line 5
    const/4 v1, 0x0

    .line 6
    move v2, v1

    .line 7
    :goto_6
    if-ge v2, v0, :cond_15

    .line 8
    .line 9
    aget-object v3, p1, v2

    .line 10
    .line 11
    invoke-static {p0, v3}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 12
    .line 13
    .line 14
    move-result v3

    .line 15
    if-eqz v3, :cond_12

    .line 16
    .line 17
    const/4 p0, 0x1

    .line 18
    return p0

    .line 19
    :cond_12
    add-int/lit8 v2, v2, 0x1

    .line 20
    .line 21
    goto :goto_6

    .line 22
    :cond_15
    return v1
.end method

.method public static x1(Landroid/os/Parcelable;)[B
    .registers 3

    .line 1
    if-nez p0, :cond_4

    .line 2
    .line 3
    const/4 p0, 0x0

    .line 4
    return-object p0

    .line 5
    :cond_4
    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    const/4 v1, 0x0

    .line 10
    :try_start_9
    invoke-interface {p0, v0, v1}, Landroid/os/Parcelable;->writeToParcel(Landroid/os/Parcel;I)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {v0}, Landroid/os/Parcel;->marshall()[B

    .line 14
    .line 15
    .line 16
    move-result-object p0
    :try_end_10
    .catchall {:try_start_9 .. :try_end_10} :catchall_14

    .line 17
    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    .line 18
    .line 19
    .line 20
    return-object p0

    .line 21
    :catchall_14
    move-exception p0

    .line 22
    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    .line 23
    .line 24
    .line 25
    throw p0
.end method

.method public static z1(Landroid/content/Context;)Z
    .registers 5

    .line 1
    invoke-static {p0}, Lmw1;->k(Ljava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    const-string v0, "com.google.android.gms.measurement.AppMeasurementJobService"

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    :try_start_6
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 8
    .line 9
    .line 10
    move-result-object v2

    .line 11
    if-nez v2, :cond_d

    .line 12
    .line 13
    goto :goto_1e

    .line 14
    :cond_d
    new-instance v3, Landroid/content/ComponentName;

    .line 15
    .line 16
    invoke-direct {v3, p0, v0}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {v2, v3, v1}, Landroid/content/pm/PackageManager;->getServiceInfo(Landroid/content/ComponentName;I)Landroid/content/pm/ServiceInfo;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    if-eqz p0, :cond_1e

    .line 24
    .line 25
    iget-boolean p0, p0, Landroid/content/pm/ServiceInfo;->enabled:Z
    :try_end_1a
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_6 .. :try_end_1a} :catch_1e

    .line 26
    .line 27
    if-eqz p0, :cond_1e

    .line 28
    .line 29
    const/4 p0, 0x1

    .line 30
    return p0

    .line 31
    :catch_1e
    :cond_1e
    :goto_1e
    return v1
.end method


# virtual methods
.method public final A1(Ljava/lang/String;)I
    .registers 6

    .line 1
    const-string v0, "user property"

    .line 2
    .line 3
    invoke-virtual {p0, v0, p1}, Lb04;->F1(Ljava/lang/String;Ljava/lang/String;)Z

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    const/4 v2, 0x6

    .line 8
    if-nez v1, :cond_a

    .line 9
    .line 10
    return v2

    .line 11
    :cond_a
    sget-object v1, Lls0;->e:[Ljava/lang/String;

    .line 12
    .line 13
    const/4 v3, 0x0

    .line 14
    invoke-virtual {p0, v0, v1, v3, p1}, Lb04;->w1(Ljava/lang/String;[Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Z

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    if-nez v1, :cond_16

    .line 19
    .line 20
    const/16 p0, 0xf

    .line 21
    .line 22
    return p0

    .line 23
    :cond_16
    const/16 v1, 0x18

    .line 24
    .line 25
    invoke-virtual {p0, v0, p1, v1}, Lb04;->s1(Ljava/lang/String;Ljava/lang/String;I)Z

    .line 26
    .line 27
    .line 28
    move-result p0

    .line 29
    if-nez p0, :cond_1f

    .line 30
    .line 31
    return v2

    .line 32
    :cond_1f
    const/4 p0, 0x0

    .line 33
    return p0
.end method

.method public final B1(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;
    .registers 8

    .line 1
    iget-object v0, p0, Lov;->a:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lzt3;

    .line 4
    .line 5
    const-string v1, "_ev"

    .line 6
    .line 7
    invoke-virtual {v1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    const/16 v2, 0x100

    .line 12
    .line 13
    const/4 v3, 0x1

    .line 14
    const/16 v4, 0x1f4

    .line 15
    .line 16
    if-eqz v1, :cond_1f

    .line 17
    .line 18
    iget-object p2, v0, Lzt3;->g:Lrl3;

    .line 19
    .line 20
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 21
    .line 22
    .line 23
    invoke-static {v4, v2}, Ljava/lang/Math;->max(II)I

    .line 24
    .line 25
    .line 26
    move-result p2

    .line 27
    invoke-virtual {p0, p2, p1, v3, v3}, Lb04;->U0(ILjava/lang/Object;ZZ)Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    return-object p0

    .line 32
    :cond_1f
    invoke-static {p2}, Lb04;->M1(Ljava/lang/String;)Z

    .line 33
    .line 34
    .line 35
    move-result p2

    .line 36
    if-eqz p2, :cond_2f

    .line 37
    .line 38
    iget-object p2, v0, Lzt3;->g:Lrl3;

    .line 39
    .line 40
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 41
    .line 42
    .line 43
    invoke-static {v4, v2}, Ljava/lang/Math;->max(II)I

    .line 44
    .line 45
    .line 46
    move-result v4

    .line 47
    goto :goto_34

    .line 48
    :cond_2f
    iget-object p2, v0, Lzt3;->g:Lrl3;

    .line 49
    .line 50
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 51
    .line 52
    .line 53
    :goto_34
    const/4 p2, 0x0

    .line 54
    invoke-virtual {p0, v4, p1, p2, v3}, Lb04;->U0(ILjava/lang/Object;ZZ)Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object p0

    .line 58
    return-object p0
.end method

.method public final E1(Landroid/content/Context;Ljava/lang/String;)Z
    .registers 5

    .line 1
    new-instance v0, Ljavax/security/auth/x500/X500Principal;

    .line 2
    .line 3
    const-string v1, "CN=Android Debug,O=Android,C=US"

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljavax/security/auth/x500/X500Principal;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    :try_start_7
    invoke-static {p1}, Lgf3;->a(Landroid/content/Context;)Lz40;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    const/16 v1, 0x40

    .line 13
    .line 14
    invoke-virtual {p1, v1, p2}, Lz40;->c(ILjava/lang/String;)Landroid/content/pm/PackageInfo;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    if-eqz p1, :cond_56

    .line 19
    .line 20
    iget-object p1, p1, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    .line 21
    .line 22
    if-eqz p1, :cond_56

    .line 23
    .line 24
    array-length p2, p1

    .line 25
    if-lez p2, :cond_56

    .line 26
    .line 27
    const/4 p2, 0x0

    .line 28
    aget-object p1, p1, p2

    .line 29
    .line 30
    const-string p2, "X.509"

    .line 31
    .line 32
    invoke-static {p2}, Ljava/security/cert/CertificateFactory;->getInstance(Ljava/lang/String;)Ljava/security/cert/CertificateFactory;

    .line 33
    .line 34
    .line 35
    move-result-object p2

    .line 36
    new-instance v1, Ljava/io/ByteArrayInputStream;

    .line 37
    .line 38
    invoke-virtual {p1}, Landroid/content/pm/Signature;->toByteArray()[B

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    invoke-direct {v1, p1}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    .line 43
    .line 44
    .line 45
    invoke-virtual {p2, v1}, Ljava/security/cert/CertificateFactory;->generateCertificate(Ljava/io/InputStream;)Ljava/security/cert/Certificate;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    check-cast p1, Ljava/security/cert/X509Certificate;

    .line 50
    .line 51
    invoke-virtual {p1}, Ljava/security/cert/X509Certificate;->getSubjectX500Principal()Ljavax/security/auth/x500/X500Principal;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    invoke-virtual {p1, v0}, Ljavax/security/auth/x500/X500Principal;->equals(Ljava/lang/Object;)Z

    .line 56
    .line 57
    .line 58
    move-result p0
    :try_end_3a
    .catch Ljava/security/cert/CertificateException; {:try_start_7 .. :try_end_3a} :catch_3d
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_7 .. :try_end_3a} :catch_3b

    .line 59
    return p0

    .line 60
    :catch_3b
    move-exception p1

    .line 61
    goto :goto_3f

    .line 62
    :catch_3d
    move-exception p1

    .line 63
    goto :goto_4b

    .line 64
    :goto_3f
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 65
    .line 66
    .line 67
    move-result-object p0

    .line 68
    iget-object p0, p0, Lqs3;->j:Lts3;

    .line 69
    .line 70
    const-string p2, "Package name not found"

    .line 71
    .line 72
    invoke-virtual {p0, p1, p2}, Lts3;->b(Ljava/lang/Object;Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    goto :goto_56

    .line 76
    :goto_4b
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 77
    .line 78
    .line 79
    move-result-object p0

    .line 80
    iget-object p0, p0, Lqs3;->j:Lts3;

    .line 81
    .line 82
    const-string p2, "Error obtaining certificate"

    .line 83
    .line 84
    invoke-virtual {p0, p1, p2}, Lts3;->b(Ljava/lang/Object;Ljava/lang/String;)V

    .line 85
    .line 86
    .line 87
    :cond_56
    :goto_56
    const/4 p0, 0x1

    .line 88
    return p0
.end method

.method public final F1(Ljava/lang/String;Ljava/lang/String;)Z
    .registers 9

    .line 1
    const/4 v0, 0x0

    .line 2
    if-nez p2, :cond_f

    .line 3
    .line 4
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    iget-object p0, p0, Lqs3;->m:Lts3;

    .line 9
    .line 10
    const-string p2, "Name is required and can\'t be null. Type"

    .line 11
    .line 12
    invoke-virtual {p0, p1, p2}, Lts3;->b(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    return v0

    .line 16
    :cond_f
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    if-nez v1, :cond_21

    .line 21
    .line 22
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    iget-object p0, p0, Lqs3;->m:Lts3;

    .line 27
    .line 28
    const-string p2, "Name is required and can\'t be empty. Type"

    .line 29
    .line 30
    invoke-virtual {p0, p1, p2}, Lts3;->b(Ljava/lang/Object;Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    return v0

    .line 34
    :cond_21
    invoke-virtual {p2, v0}, Ljava/lang/String;->codePointAt(I)I

    .line 35
    .line 36
    .line 37
    move-result v1

    .line 38
    invoke-static {v1}, Ljava/lang/Character;->isLetter(I)Z

    .line 39
    .line 40
    .line 41
    move-result v2

    .line 42
    const/16 v3, 0x5f

    .line 43
    .line 44
    if-nez v2, :cond_3b

    .line 45
    .line 46
    if-eq v1, v3, :cond_3b

    .line 47
    .line 48
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 49
    .line 50
    .line 51
    move-result-object p0

    .line 52
    iget-object p0, p0, Lqs3;->m:Lts3;

    .line 53
    .line 54
    const-string v1, "Name must start with a letter or _ (underscore). Type, name"

    .line 55
    .line 56
    invoke-virtual {p0, p1, p2, v1}, Lts3;->a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    return v0

    .line 60
    :cond_3b
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    .line 61
    .line 62
    .line 63
    move-result v2

    .line 64
    invoke-static {v1}, Ljava/lang/Character;->charCount(I)I

    .line 65
    .line 66
    .line 67
    move-result v1

    .line 68
    :goto_43
    if-ge v1, v2, :cond_63

    .line 69
    .line 70
    invoke-virtual {p2, v1}, Ljava/lang/String;->codePointAt(I)I

    .line 71
    .line 72
    .line 73
    move-result v4

    .line 74
    if-eq v4, v3, :cond_5d

    .line 75
    .line 76
    invoke-static {v4}, Ljava/lang/Character;->isLetterOrDigit(I)Z

    .line 77
    .line 78
    .line 79
    move-result v5

    .line 80
    if-nez v5, :cond_5d

    .line 81
    .line 82
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 83
    .line 84
    .line 85
    move-result-object p0

    .line 86
    iget-object p0, p0, Lqs3;->m:Lts3;

    .line 87
    .line 88
    const-string v1, "Name must consist of letters, digits or _ (underscores). Type, name"

    .line 89
    .line 90
    invoke-virtual {p0, p1, p2, v1}, Lts3;->a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    .line 91
    .line 92
    .line 93
    return v0

    .line 94
    :cond_5d
    invoke-static {v4}, Ljava/lang/Character;->charCount(I)I

    .line 95
    .line 96
    .line 97
    move-result v4

    .line 98
    add-int/2addr v1, v4

    .line 99
    goto :goto_43

    .line 100
    :cond_63
    const/4 p0, 0x1

    .line 101
    return p0
.end method

.method public final G1(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;
    .registers 5

    .line 1
    const-string v0, "_ldl"

    .line 2
    .line 3
    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/4 v1, 0x0

    .line 8
    if-eqz v0, :cond_13

    .line 9
    .line 10
    invoke-static {p2}, Lb04;->P1(Ljava/lang/String;)I

    .line 11
    .line 12
    .line 13
    move-result p2

    .line 14
    const/4 v0, 0x1

    .line 15
    invoke-virtual {p0, p2, p1, v0, v1}, Lb04;->U0(ILjava/lang/Object;ZZ)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    return-object p0

    .line 20
    :cond_13
    invoke-static {p2}, Lb04;->P1(Ljava/lang/String;)I

    .line 21
    .line 22
    .line 23
    move-result p2

    .line 24
    invoke-virtual {p0, p2, p1, v1, v1}, Lb04;->U0(ILjava/lang/Object;ZZ)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object p0

    .line 28
    return-object p0
.end method

.method public final H1(Ljava/lang/String;Ljava/lang/String;)Z
    .registers 8

    .line 1
    const/4 v0, 0x0

    .line 2
    if-nez p2, :cond_f

    .line 3
    .line 4
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    iget-object p0, p0, Lqs3;->m:Lts3;

    .line 9
    .line 10
    const-string p2, "Name is required and can\'t be null. Type"

    .line 11
    .line 12
    invoke-virtual {p0, p1, p2}, Lts3;->b(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    return v0

    .line 16
    :cond_f
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    if-nez v1, :cond_21

    .line 21
    .line 22
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    iget-object p0, p0, Lqs3;->m:Lts3;

    .line 27
    .line 28
    const-string p2, "Name is required and can\'t be empty. Type"

    .line 29
    .line 30
    invoke-virtual {p0, p1, p2}, Lts3;->b(Ljava/lang/Object;Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    return v0

    .line 34
    :cond_21
    invoke-virtual {p2, v0}, Ljava/lang/String;->codePointAt(I)I

    .line 35
    .line 36
    .line 37
    move-result v1

    .line 38
    invoke-static {v1}, Ljava/lang/Character;->isLetter(I)Z

    .line 39
    .line 40
    .line 41
    move-result v2

    .line 42
    if-nez v2, :cond_37

    .line 43
    .line 44
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 45
    .line 46
    .line 47
    move-result-object p0

    .line 48
    iget-object p0, p0, Lqs3;->m:Lts3;

    .line 49
    .line 50
    const-string v1, "Name must start with a letter. Type, name"

    .line 51
    .line 52
    invoke-virtual {p0, p1, p2, v1}, Lts3;->a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    .line 53
    .line 54
    .line 55
    return v0

    .line 56
    :cond_37
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    .line 57
    .line 58
    .line 59
    move-result v2

    .line 60
    invoke-static {v1}, Ljava/lang/Character;->charCount(I)I

    .line 61
    .line 62
    .line 63
    move-result v1

    .line 64
    :goto_3f
    if-ge v1, v2, :cond_61

    .line 65
    .line 66
    invoke-virtual {p2, v1}, Ljava/lang/String;->codePointAt(I)I

    .line 67
    .line 68
    .line 69
    move-result v3

    .line 70
    const/16 v4, 0x5f

    .line 71
    .line 72
    if-eq v3, v4, :cond_5b

    .line 73
    .line 74
    invoke-static {v3}, Ljava/lang/Character;->isLetterOrDigit(I)Z

    .line 75
    .line 76
    .line 77
    move-result v4

    .line 78
    if-nez v4, :cond_5b

    .line 79
    .line 80
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 81
    .line 82
    .line 83
    move-result-object p0

    .line 84
    iget-object p0, p0, Lqs3;->m:Lts3;

    .line 85
    .line 86
    const-string v1, "Name must consist of letters, digits or _ (underscores). Type, name"

    .line 87
    .line 88
    invoke-virtual {p0, p1, p2, v1}, Lts3;->a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    .line 89
    .line 90
    .line 91
    return v0

    .line 92
    :cond_5b
    invoke-static {v3}, Ljava/lang/Character;->charCount(I)I

    .line 93
    .line 94
    .line 95
    move-result v3

    .line 96
    add-int/2addr v1, v3

    .line 97
    goto :goto_3f

    .line 98
    :cond_61
    const/4 p0, 0x1

    .line 99
    return p0
.end method

.method public final I1(Ljava/lang/String;Ljava/lang/String;)Z
    .registers 6

    .line 1
    invoke-static {}, Lv04;->a()V

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lov;->a:Ljava/lang/Object;

    .line 5
    .line 6
    check-cast p0, Lzt3;

    .line 7
    .line 8
    iget-object v0, p0, Lzt3;->g:Lrl3;

    .line 9
    .line 10
    sget-object v1, Ljn3;->x0:Lxr3;

    .line 11
    .line 12
    const/4 v2, 0x0

    .line 13
    invoke-virtual {v0, v2, v1}, Lrl3;->R0(Ljava/lang/String;Lxr3;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_1a

    .line 18
    .line 19
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 20
    .line 21
    .line 22
    move-result p2

    .line 23
    if-nez p2, :cond_1a

    .line 24
    .line 25
    const/4 p0, 0x1

    .line 26
    return p0

    .line 27
    :cond_1a
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 28
    .line 29
    .line 30
    move-result p2

    .line 31
    if-eqz p2, :cond_22

    .line 32
    .line 33
    const/4 p0, 0x0

    .line 34
    return p0

    .line 35
    :cond_22
    iget-object p0, p0, Lzt3;->g:Lrl3;

    .line 36
    .line 37
    const-string p2, "debug.firebase.analytics.app"

    .line 38
    .line 39
    invoke-virtual {p0, p2}, Lrl3;->J0(Ljava/lang/String;)Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object p0

    .line 43
    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 44
    .line 45
    .line 46
    move-result p0

    .line 47
    return p0
.end method

.method public final J1(Ljava/lang/String;)Z
    .registers 3

    .line 1
    invoke-virtual {p0}, Lov;->H0()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lov;->a:Ljava/lang/Object;

    .line 5
    .line 6
    check-cast v0, Lzt3;

    .line 7
    .line 8
    iget-object v0, v0, Lzt3;->a:Landroid/content/Context;

    .line 9
    .line 10
    invoke-static {v0}, Lgf3;->a(Landroid/content/Context;)Lz40;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iget-object v0, v0, Lz40;->b:Landroid/content/Context;

    .line 15
    .line 16
    invoke-virtual {v0, p1}, Landroid/content/Context;->checkCallingOrSelfPermission(Ljava/lang/String;)I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-nez v0, :cond_17

    .line 21
    .line 22
    const/4 p0, 0x1

    .line 23
    return p0

    .line 24
    :cond_17
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 25
    .line 26
    .line 27
    move-result-object p0

    .line 28
    iget-object p0, p0, Lqs3;->r:Lts3;

    .line 29
    .line 30
    const-string v0, "Permission not granted"

    .line 31
    .line 32
    invoke-virtual {p0, p1, v0}, Lts3;->b(Ljava/lang/Object;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    const/4 p0, 0x0

    .line 36
    return p0
.end method

.method public final K0()Z
    .registers 1

    .line 1
    const/4 p0, 0x1

    .line 2
    return p0
.end method

.method public final L0(Ljava/lang/Object;Ljava/lang/String;)I
    .registers 5

    .line 1
    const-string v0, "_ldl"

    .line 2
    .line 3
    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_13

    .line 8
    .line 9
    const-string v0, "user property referrer"

    .line 10
    .line 11
    invoke-static {p2}, Lb04;->P1(Ljava/lang/String;)I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    invoke-virtual {p0, v0, p2, v1, p1}, Lb04;->t1(Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Z

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    goto :goto_1d

    .line 20
    :cond_13
    const-string v0, "user property"

    .line 21
    .line 22
    invoke-static {p2}, Lb04;->P1(Ljava/lang/String;)I

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    invoke-virtual {p0, v0, p2, v1, p1}, Lb04;->t1(Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Z

    .line 27
    .line 28
    .line 29
    move-result p0

    .line 30
    :goto_1d
    if-eqz p0, :cond_21

    .line 31
    .line 32
    const/4 p0, 0x0

    .line 33
    return p0

    .line 34
    :cond_21
    const/4 p0, 0x7

    .line 35
    return p0
.end method

.method public final L1()I
    .registers 4

    .line 1
    iget-object v0, p0, Lb04;->m:Ljava/lang/Integer;

    .line 2
    .line 3
    if-nez v0, :cond_2e

    .line 4
    .line 5
    sget-object v0, Lax0;->b:Lax0;

    .line 6
    .line 7
    iget-object v1, p0, Lov;->a:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v1, Lzt3;

    .line 10
    .line 11
    iget-object v1, v1, Lzt3;->a:Landroid/content/Context;

    .line 12
    .line 13
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    sget v0, Lex0;->e:I

    .line 17
    .line 18
    const/4 v0, 0x0

    .line 19
    :try_start_12
    invoke-virtual {v1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    const-string v2, "com.google.android.gms"

    .line 24
    .line 25
    invoke-virtual {v1, v2, v0}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    .line 26
    .line 27
    .line 28
    move-result-object v0
    :try_end_1c
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_12 .. :try_end_1c} :catch_1f

    .line 29
    iget v0, v0, Landroid/content/pm/PackageInfo;->versionCode:I

    .line 30
    .line 31
    goto :goto_26

    .line 32
    :catch_1f
    const-string v1, "GooglePlayServicesUtil"

    .line 33
    .line 34
    const-string v2, "Google Play services is missing."

    .line 35
    .line 36
    invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 37
    .line 38
    .line 39
    :goto_26
    div-int/lit16 v0, v0, 0x3e8

    .line 40
    .line 41
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    iput-object v0, p0, Lb04;->m:Ljava/lang/Integer;

    .line 46
    .line 47
    :cond_2e
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 48
    .line 49
    .line 50
    move-result p0

    .line 51
    return p0
.end method

.method public final M0(Ljava/lang/String;)I
    .registers 6

    .line 1
    const-string v0, "event"

    .line 2
    .line 3
    invoke-virtual {p0, v0, p1}, Lb04;->F1(Ljava/lang/String;Ljava/lang/String;)Z

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    const/4 v2, 0x2

    .line 8
    if-nez v1, :cond_a

    .line 9
    .line 10
    return v2

    .line 11
    :cond_a
    sget-object v1, Ljw0;->e:[Ljava/lang/String;

    .line 12
    .line 13
    sget-object v3, Ljw0;->f:[Ljava/lang/String;

    .line 14
    .line 15
    invoke-virtual {p0, v0, v1, v3, p1}, Lb04;->w1(Ljava/lang/String;[Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Z

    .line 16
    .line 17
    .line 18
    move-result v1

    .line 19
    if-nez v1, :cond_17

    .line 20
    .line 21
    const/16 p0, 0xd

    .line 22
    .line 23
    return p0

    .line 24
    :cond_17
    const/16 v1, 0x28

    .line 25
    .line 26
    invoke-virtual {p0, v0, p1, v1}, Lb04;->s1(Ljava/lang/String;Ljava/lang/String;I)Z

    .line 27
    .line 28
    .line 29
    move-result p0

    .line 30
    if-nez p0, :cond_20

    .line 31
    .line 32
    return v2

    .line 33
    :cond_20
    const/4 p0, 0x0

    .line 34
    return p0
.end method

.method public final N0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;Landroid/os/Bundle;Ljava/util/List;ZZ)I
    .registers 19

    .line 1
    iget-object v1, p0, Lov;->a:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v1, Lzt3;

    .line 4
    .line 5
    invoke-virtual {p0}, Lov;->H0()V

    .line 6
    .line 7
    .line 8
    invoke-static {p3}, Lb04;->p1(Ljava/lang/Object;)Z

    .line 9
    .line 10
    .line 11
    move-result v2

    .line 12
    const-string v3, "param"

    .line 13
    .line 14
    const/4 v4, 0x0

    .line 15
    if-eqz v2, :cond_96

    .line 16
    .line 17
    if-eqz p7, :cond_93

    .line 18
    .line 19
    sget-object v2, Lyo1;->f:[Ljava/lang/String;

    .line 20
    .line 21
    invoke-static {p2, v2}, Lb04;->v1(Ljava/lang/String;[Ljava/lang/String;)Z

    .line 22
    .line 23
    .line 24
    move-result v2

    .line 25
    if-nez v2, :cond_1d

    .line 26
    .line 27
    const/16 p0, 0x14

    .line 28
    .line 29
    return p0

    .line 30
    :cond_1d
    invoke-virtual {v1}, Lzt3;->o()Lbx3;

    .line 31
    .line 32
    .line 33
    move-result-object v2

    .line 34
    invoke-virtual {v2}, Lgp3;->H0()V

    .line 35
    .line 36
    .line 37
    invoke-virtual {v2}, Let3;->L0()V

    .line 38
    .line 39
    .line 40
    invoke-virtual {v2}, Lbx3;->X0()Z

    .line 41
    .line 42
    .line 43
    move-result v5

    .line 44
    if-nez v5, :cond_2e

    .line 45
    .line 46
    goto :goto_3b

    .line 47
    :cond_2e
    invoke-virtual {v2}, Lov;->G0()Lb04;

    .line 48
    .line 49
    .line 50
    move-result-object v2

    .line 51
    invoke-virtual {v2}, Lb04;->L1()I

    .line 52
    .line 53
    .line 54
    move-result v2

    .line 55
    const v5, 0x310c4

    .line 56
    .line 57
    .line 58
    if-lt v2, v5, :cond_90

    .line 59
    .line 60
    :goto_3b
    instance-of v2, p3, [Landroid/os/Parcelable;

    .line 61
    .line 62
    if-eqz v2, :cond_44

    .line 63
    .line 64
    move-object v5, p3

    .line 65
    check-cast v5, [Landroid/os/Parcelable;

    .line 66
    .line 67
    array-length v5, v5

    .line 68
    goto :goto_4f

    .line 69
    :cond_44
    instance-of v5, p3, Ljava/util/ArrayList;

    .line 70
    .line 71
    if-eqz v5, :cond_96

    .line 72
    .line 73
    move-object v5, p3

    .line 74
    check-cast v5, Ljava/util/ArrayList;

    .line 75
    .line 76
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    .line 77
    .line 78
    .line 79
    move-result v5

    .line 80
    :goto_4f
    const/16 v6, 0xc8

    .line 81
    .line 82
    if-le v5, v6, :cond_96

    .line 83
    .line 84
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 85
    .line 86
    .line 87
    move-result-object v7

    .line 88
    iget-object v7, v7, Lqs3;->p:Lts3;

    .line 89
    .line 90
    const-string v8, "Parameter array is too long; discarded. Value kind, name, array length"

    .line 91
    .line 92
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 93
    .line 94
    .line 95
    move-result-object v5

    .line 96
    invoke-virtual {v7, v8, v3, p2, v5}, Lts3;->d(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 97
    .line 98
    .line 99
    if-eqz v2, :cond_74

    .line 100
    .line 101
    move-object v2, p3

    .line 102
    check-cast v2, [Landroid/os/Parcelable;

    .line 103
    .line 104
    array-length v5, v2

    .line 105
    if-le v5, v6, :cond_8d

    .line 106
    .line 107
    invoke-static {v2, v6}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    move-result-object v2

    .line 111
    check-cast v2, [Landroid/os/Parcelable;

    .line 112
    .line 113
    invoke-virtual {p4, p2, v2}, Landroid/os/Bundle;->putParcelableArray(Ljava/lang/String;[Landroid/os/Parcelable;)V

    .line 114
    .line 115
    .line 116
    goto :goto_8d

    .line 117
    :cond_74
    instance-of v2, p3, Ljava/util/ArrayList;

    .line 118
    .line 119
    if-eqz v2, :cond_8d

    .line 120
    .line 121
    move-object v2, p3

    .line 122
    check-cast v2, Ljava/util/ArrayList;

    .line 123
    .line 124
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 125
    .line 126
    .line 127
    move-result v5

    .line 128
    if-le v5, v6, :cond_8d

    .line 129
    .line 130
    new-instance v5, Ljava/util/ArrayList;

    .line 131
    .line 132
    invoke-virtual {v2, v4, v6}, Ljava/util/ArrayList;->subList(II)Ljava/util/List;

    .line 133
    .line 134
    .line 135
    move-result-object v2

    .line 136
    invoke-direct {v5, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 137
    .line 138
    .line 139
    invoke-virtual {p4, p2, v5}, Landroid/os/Bundle;->putParcelableArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    .line 140
    .line 141
    .line 142
    :cond_8d
    :goto_8d
    const/16 v0, 0x11

    .line 143
    .line 144
    goto :goto_97

    .line 145
    :cond_90
    const/16 p0, 0x19

    .line 146
    .line 147
    return p0

    .line 148
    :cond_93
    const/16 p0, 0x15

    .line 149
    .line 150
    return p0

    .line 151
    :cond_96
    move v0, v4

    .line 152
    :goto_97
    invoke-static {p1}, Lb04;->M1(Ljava/lang/String;)Z

    .line 153
    .line 154
    .line 155
    move-result v2

    .line 156
    const/16 v5, 0x1f4

    .line 157
    .line 158
    if-nez v2, :cond_ac

    .line 159
    .line 160
    invoke-static {p2}, Lb04;->M1(Ljava/lang/String;)Z

    .line 161
    .line 162
    .line 163
    move-result v2

    .line 164
    if-eqz v2, :cond_a6

    .line 165
    .line 166
    goto :goto_ac

    .line 167
    :cond_a6
    iget-object v1, v1, Lzt3;->g:Lrl3;

    .line 168
    .line 169
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 170
    .line 171
    .line 172
    goto :goto_b7

    .line 173
    :cond_ac
    :goto_ac
    iget-object v1, v1, Lzt3;->g:Lrl3;

    .line 174
    .line 175
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 176
    .line 177
    .line 178
    const/16 v1, 0x100

    .line 179
    .line 180
    invoke-static {v5, v1}, Ljava/lang/Math;->max(II)I

    .line 181
    .line 182
    .line 183
    move-result v5

    .line 184
    :goto_b7
    invoke-virtual {p0, v3, p2, v5, p3}, Lb04;->t1(Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Z

    .line 185
    .line 186
    .line 187
    move-result v1

    .line 188
    if-eqz v1, :cond_bf

    .line 189
    .line 190
    goto/16 :goto_13d

    .line 191
    .line 192
    :cond_bf
    if-eqz p7, :cond_13e

    .line 193
    .line 194
    instance-of v1, p3, Landroid/os/Bundle;

    .line 195
    .line 196
    if-eqz v1, :cond_d3

    .line 197
    .line 198
    move-object v8, p3

    .line 199
    check-cast v8, Landroid/os/Bundle;

    .line 200
    .line 201
    move-object v5, p0

    .line 202
    move-object v6, p1

    .line 203
    move-object v7, p2

    .line 204
    move-object/from16 v9, p5

    .line 205
    .line 206
    move/from16 v10, p6

    .line 207
    .line 208
    invoke-virtual/range {v5 .. v10}, Lb04;->c1(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;Ljava/util/List;Z)V

    .line 209
    .line 210
    .line 211
    return v0

    .line 212
    :cond_d3
    instance-of v1, p3, [Landroid/os/Parcelable;

    .line 213
    .line 214
    if-eqz v1, :cond_103

    .line 215
    .line 216
    check-cast p3, [Landroid/os/Parcelable;

    .line 217
    .line 218
    array-length v7, p3

    .line 219
    move v8, v4

    .line 220
    :goto_db
    if-ge v8, v7, :cond_13d

    .line 221
    .line 222
    aget-object v1, p3, v8

    .line 223
    .line 224
    instance-of v2, v1, Landroid/os/Bundle;

    .line 225
    .line 226
    if-nez v2, :cond_f3

    .line 227
    .line 228
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 229
    .line 230
    .line 231
    move-result-object p0

    .line 232
    iget-object p0, p0, Lqs3;->p:Lts3;

    .line 233
    .line 234
    const-string p1, "All Parcelable[] elements must be of type Bundle. Value type, name"

    .line 235
    .line 236
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 237
    .line 238
    .line 239
    move-result-object p3

    .line 240
    invoke-virtual {p0, p3, p2, p1}, Lts3;->a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    .line 241
    .line 242
    .line 243
    goto :goto_13e

    .line 244
    :cond_f3
    move-object v4, v1

    .line 245
    check-cast v4, Landroid/os/Bundle;

    .line 246
    .line 247
    move-object v1, p0

    .line 248
    move-object v2, p1

    .line 249
    move-object v3, p2

    .line 250
    move-object/from16 v5, p5

    .line 251
    .line 252
    move/from16 v6, p6

    .line 253
    .line 254
    invoke-virtual/range {v1 .. v6}, Lb04;->c1(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;Ljava/util/List;Z)V

    .line 255
    .line 256
    .line 257
    add-int/lit8 v8, v8, 0x1

    .line 258
    .line 259
    goto :goto_db

    .line 260
    :cond_103
    instance-of v1, p3, Ljava/util/ArrayList;

    .line 261
    .line 262
    if-eqz v1, :cond_13e

    .line 263
    .line 264
    check-cast p3, Ljava/util/ArrayList;

    .line 265
    .line 266
    invoke-virtual {p3}, Ljava/util/ArrayList;->size()I

    .line 267
    .line 268
    .line 269
    move-result v7

    .line 270
    :goto_10d
    if-ge v4, v7, :cond_13d

    .line 271
    .line 272
    invoke-virtual {p3, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 273
    .line 274
    .line 275
    move-result-object v1

    .line 276
    add-int/lit8 v8, v4, 0x1

    .line 277
    .line 278
    instance-of v2, v1, Landroid/os/Bundle;

    .line 279
    .line 280
    if-nez v2, :cond_12e

    .line 281
    .line 282
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 283
    .line 284
    .line 285
    move-result-object p0

    .line 286
    iget-object p0, p0, Lqs3;->p:Lts3;

    .line 287
    .line 288
    if-eqz v1, :cond_126

    .line 289
    .line 290
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 291
    .line 292
    .line 293
    move-result-object p1

    .line 294
    goto :goto_128

    .line 295
    :cond_126
    const-string p1, "null"

    .line 296
    .line 297
    :goto_128
    const-string p3, "All ArrayList elements must be of type Bundle. Value type, name"

    .line 298
    .line 299
    invoke-virtual {p0, p1, p2, p3}, Lts3;->a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    .line 300
    .line 301
    .line 302
    goto :goto_13e

    .line 303
    :cond_12e
    move-object v4, v1

    .line 304
    check-cast v4, Landroid/os/Bundle;

    .line 305
    .line 306
    move-object v1, p0

    .line 307
    move-object v2, p1

    .line 308
    move-object v3, p2

    .line 309
    move-object/from16 v5, p5

    .line 310
    .line 311
    move/from16 v6, p6

    .line 312
    .line 313
    invoke-virtual/range {v1 .. v6}, Lb04;->c1(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;Ljava/util/List;Z)V

    .line 314
    .line 315
    .line 316
    move v4, v8

    .line 317
    goto :goto_10d

    .line 318
    :cond_13d
    :goto_13d
    return v0

    .line 319
    :cond_13e
    :goto_13e
    const/4 p0, 0x4

    .line 320
    return p0
.end method

.method public final O1(Ljava/lang/String;)Z
    .registers 5

    .line 1
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-eqz v0, :cond_8

    .line 7
    .line 8
    return v1

    .line 9
    :cond_8
    iget-object p0, p0, Lov;->a:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast p0, Lzt3;

    .line 12
    .line 13
    iget-object p0, p0, Lzt3;->a:Landroid/content/Context;

    .line 14
    .line 15
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    new-instance v0, Landroid/content/Intent;

    .line 20
    .line 21
    const-string v2, "android.intent.action.VIEW"

    .line 22
    .line 23
    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    invoke-direct {v0, v2, p1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {p0, v0, v1}, Landroid/content/pm/PackageManager;->queryIntentActivities(Landroid/content/Intent;I)Ljava/util/List;

    .line 31
    .line 32
    .line 33
    move-result-object p0

    .line 34
    if-eqz p0, :cond_2b

    .line 35
    .line 36
    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    .line 37
    .line 38
    .line 39
    move-result p0

    .line 40
    if-nez p0, :cond_2b

    .line 41
    .line 42
    const/4 p0, 0x1

    .line 43
    return p0

    .line 44
    :cond_2b
    return v1
.end method

.method public final Q0(Landroid/net/Uri;Z)Landroid/os/Bundle;
    .registers 20

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_7

    .line 5
    .line 6
    goto/16 :goto_8d

    .line 7
    .line 8
    :cond_7
    :try_start_7
    invoke-virtual {v0}, Landroid/net/Uri;->isHierarchical()Z

    .line 9
    .line 10
    .line 11
    move-result v2
    :try_end_b
    .catch Ljava/lang/UnsupportedOperationException; {:try_start_7 .. :try_end_b} :catch_34

    .line 12
    const-string v3, "sfmc_id"

    .line 13
    .line 14
    const-string v4, "srsltid"

    .line 15
    .line 16
    const-string v5, "dclid"

    .line 17
    .line 18
    const-string v6, "gbraid"

    .line 19
    .line 20
    const-string v7, "gclid"

    .line 21
    .line 22
    if-eqz v2, :cond_4b

    .line 23
    .line 24
    :try_start_17
    const-string v2, "utm_campaign"

    .line 25
    .line 26
    invoke-virtual {v0, v2}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v2

    .line 30
    const-string v8, "utm_source"

    .line 31
    .line 32
    invoke-virtual {v0, v8}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v8

    .line 36
    const-string v9, "utm_medium"

    .line 37
    .line 38
    invoke-virtual {v0, v9}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object v9

    .line 42
    invoke-virtual {v0, v7}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object v10

    .line 46
    if-eqz p2, :cond_37

    .line 47
    .line 48
    invoke-virtual {v0, v6}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object v11

    .line 52
    goto :goto_38

    .line 53
    :catch_34
    move-exception v0

    .line 54
    goto/16 :goto_189

    .line 55
    .line 56
    :cond_37
    move-object v11, v1

    .line 57
    :goto_38
    const-string v12, "utm_id"

    .line 58
    .line 59
    invoke-virtual {v0, v12}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object v12

    .line 63
    invoke-virtual {v0, v5}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object v13

    .line 67
    invoke-virtual {v0, v4}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v14

    .line 71
    invoke-virtual {v0, v3}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object v15
    :try_end_4a
    .catch Ljava/lang/UnsupportedOperationException; {:try_start_17 .. :try_end_4a} :catch_34

    .line 75
    goto :goto_54

    .line 76
    :cond_4b
    move-object v2, v1

    .line 77
    move-object v8, v2

    .line 78
    move-object v9, v8

    .line 79
    move-object v10, v9

    .line 80
    move-object v11, v10

    .line 81
    move-object v12, v11

    .line 82
    move-object v13, v12

    .line 83
    move-object v14, v13

    .line 84
    move-object v15, v14

    .line 85
    :goto_54
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 86
    .line 87
    .line 88
    move-result v16

    .line 89
    if-eqz v16, :cond_8e

    .line 90
    .line 91
    invoke-static {v8}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 92
    .line 93
    .line 94
    move-result v16

    .line 95
    if-eqz v16, :cond_8e

    .line 96
    .line 97
    invoke-static {v9}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 98
    .line 99
    .line 100
    move-result v16

    .line 101
    if-eqz v16, :cond_8e

    .line 102
    .line 103
    invoke-static {v10}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 104
    .line 105
    .line 106
    move-result v16

    .line 107
    if-eqz v16, :cond_8e

    .line 108
    .line 109
    if-eqz p2, :cond_74

    .line 110
    .line 111
    invoke-static {v11}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 112
    .line 113
    .line 114
    move-result v16

    .line 115
    if-eqz v16, :cond_8e

    .line 116
    .line 117
    :cond_74
    invoke-static {v12}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 118
    .line 119
    .line 120
    move-result v16

    .line 121
    if-eqz v16, :cond_8e

    .line 122
    .line 123
    invoke-static {v13}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 124
    .line 125
    .line 126
    move-result v16

    .line 127
    if-eqz v16, :cond_8e

    .line 128
    .line 129
    invoke-static {v14}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 130
    .line 131
    .line 132
    move-result v16

    .line 133
    if-eqz v16, :cond_8e

    .line 134
    .line 135
    invoke-static {v15}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 136
    .line 137
    .line 138
    move-result v16

    .line 139
    if-nez v16, :cond_8d

    .line 140
    .line 141
    goto :goto_8e

    .line 142
    :cond_8d
    :goto_8d
    return-object v1

    .line 143
    :cond_8e
    :goto_8e
    new-instance v1, Landroid/os/Bundle;

    .line 144
    .line 145
    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    .line 146
    .line 147
    .line 148
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 149
    .line 150
    .line 151
    move-result v16

    .line 152
    if-nez v16, :cond_a1

    .line 153
    .line 154
    move-object/from16 v16, v3

    .line 155
    .line 156
    const-string v3, "campaign"

    .line 157
    .line 158
    invoke-virtual {v1, v3, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 159
    .line 160
    .line 161
    goto :goto_a3

    .line 162
    :cond_a1
    move-object/from16 v16, v3

    .line 163
    .line 164
    :goto_a3
    invoke-static {v8}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 165
    .line 166
    .line 167
    move-result v2

    .line 168
    if-nez v2, :cond_ae

    .line 169
    .line 170
    const-string v2, "source"

    .line 171
    .line 172
    invoke-virtual {v1, v2, v8}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 173
    .line 174
    .line 175
    :cond_ae
    invoke-static {v9}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 176
    .line 177
    .line 178
    move-result v2

    .line 179
    if-nez v2, :cond_b9

    .line 180
    .line 181
    const-string v2, "medium"

    .line 182
    .line 183
    invoke-virtual {v1, v2, v9}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 184
    .line 185
    .line 186
    :cond_b9
    invoke-static {v10}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 187
    .line 188
    .line 189
    move-result v2

    .line 190
    if-nez v2, :cond_c2

    .line 191
    .line 192
    invoke-virtual {v1, v7, v10}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 193
    .line 194
    .line 195
    :cond_c2
    if-eqz p2, :cond_cd

    .line 196
    .line 197
    invoke-static {v11}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 198
    .line 199
    .line 200
    move-result v2

    .line 201
    if-nez v2, :cond_cd

    .line 202
    .line 203
    invoke-virtual {v1, v6, v11}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 204
    .line 205
    .line 206
    :cond_cd
    const-string v2, "gad_source"

    .line 207
    .line 208
    invoke-virtual {v0, v2}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 209
    .line 210
    .line 211
    move-result-object v3

    .line 212
    if-eqz p2, :cond_de

    .line 213
    .line 214
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 215
    .line 216
    .line 217
    move-result v6

    .line 218
    if-nez v6, :cond_de

    .line 219
    .line 220
    invoke-virtual {v1, v2, v3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 221
    .line 222
    .line 223
    :cond_de
    const-string v2, "utm_term"

    .line 224
    .line 225
    invoke-virtual {v0, v2}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 226
    .line 227
    .line 228
    move-result-object v2

    .line 229
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 230
    .line 231
    .line 232
    move-result v3

    .line 233
    if-nez v3, :cond_ef

    .line 234
    .line 235
    const-string v3, "term"

    .line 236
    .line 237
    invoke-virtual {v1, v3, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 238
    .line 239
    .line 240
    :cond_ef
    const-string v2, "utm_content"

    .line 241
    .line 242
    invoke-virtual {v0, v2}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 243
    .line 244
    .line 245
    move-result-object v2

    .line 246
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 247
    .line 248
    .line 249
    move-result v3

    .line 250
    if-nez v3, :cond_100

    .line 251
    .line 252
    const-string v3, "content"

    .line 253
    .line 254
    invoke-virtual {v1, v3, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 255
    .line 256
    .line 257
    :cond_100
    const-string v2, "aclid"

    .line 258
    .line 259
    invoke-virtual {v0, v2}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 260
    .line 261
    .line 262
    move-result-object v3

    .line 263
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 264
    .line 265
    .line 266
    move-result v6

    .line 267
    if-nez v6, :cond_10f

    .line 268
    .line 269
    invoke-virtual {v1, v2, v3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 270
    .line 271
    .line 272
    :cond_10f
    const-string v2, "cp1"

    .line 273
    .line 274
    invoke-virtual {v0, v2}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 275
    .line 276
    .line 277
    move-result-object v3

    .line 278
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 279
    .line 280
    .line 281
    move-result v6

    .line 282
    if-nez v6, :cond_11e

    .line 283
    .line 284
    invoke-virtual {v1, v2, v3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 285
    .line 286
    .line 287
    :cond_11e
    const-string v2, "anid"

    .line 288
    .line 289
    invoke-virtual {v0, v2}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 290
    .line 291
    .line 292
    move-result-object v3

    .line 293
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 294
    .line 295
    .line 296
    move-result v6

    .line 297
    if-nez v6, :cond_12d

    .line 298
    .line 299
    invoke-virtual {v1, v2, v3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 300
    .line 301
    .line 302
    :cond_12d
    invoke-static {v12}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 303
    .line 304
    .line 305
    move-result v2

    .line 306
    if-nez v2, :cond_138

    .line 307
    .line 308
    const-string v2, "campaign_id"

    .line 309
    .line 310
    invoke-virtual {v1, v2, v12}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 311
    .line 312
    .line 313
    :cond_138
    invoke-static {v13}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 314
    .line 315
    .line 316
    move-result v2

    .line 317
    if-nez v2, :cond_141

    .line 318
    .line 319
    invoke-virtual {v1, v5, v13}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 320
    .line 321
    .line 322
    :cond_141
    const-string v2, "utm_source_platform"

    .line 323
    .line 324
    invoke-virtual {v0, v2}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 325
    .line 326
    .line 327
    move-result-object v2

    .line 328
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 329
    .line 330
    .line 331
    move-result v3

    .line 332
    if-nez v3, :cond_152

    .line 333
    .line 334
    const-string v3, "source_platform"

    .line 335
    .line 336
    invoke-virtual {v1, v3, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 337
    .line 338
    .line 339
    :cond_152
    const-string v2, "utm_creative_format"

    .line 340
    .line 341
    invoke-virtual {v0, v2}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 342
    .line 343
    .line 344
    move-result-object v2

    .line 345
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 346
    .line 347
    .line 348
    move-result v3

    .line 349
    if-nez v3, :cond_163

    .line 350
    .line 351
    const-string v3, "creative_format"

    .line 352
    .line 353
    invoke-virtual {v1, v3, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 354
    .line 355
    .line 356
    :cond_163
    const-string v2, "utm_marketing_tactic"

    .line 357
    .line 358
    invoke-virtual {v0, v2}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 359
    .line 360
    .line 361
    move-result-object v0

    .line 362
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 363
    .line 364
    .line 365
    move-result v2

    .line 366
    if-nez v2, :cond_174

    .line 367
    .line 368
    const-string v2, "marketing_tactic"

    .line 369
    .line 370
    invoke-virtual {v1, v2, v0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 371
    .line 372
    .line 373
    :cond_174
    invoke-static {v14}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 374
    .line 375
    .line 376
    move-result v0

    .line 377
    if-nez v0, :cond_17d

    .line 378
    .line 379
    invoke-virtual {v1, v4, v14}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 380
    .line 381
    .line 382
    :cond_17d
    invoke-static {v15}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 383
    .line 384
    .line 385
    move-result v0

    .line 386
    if-nez v0, :cond_188

    .line 387
    .line 388
    move-object/from16 v0, v16

    .line 389
    .line 390
    invoke-virtual {v1, v0, v15}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 391
    .line 392
    .line 393
    :cond_188
    return-object v1

    .line 394
    :goto_189
    invoke-virtual/range {p0 .. p0}, Lov;->l()Lqs3;

    .line 395
    .line 396
    .line 397
    move-result-object v2

    .line 398
    iget-object v2, v2, Lqs3;->n:Lts3;

    .line 399
    .line 400
    const-string v3, "Install referrer url isn\'t a hierarchical URI"

    .line 401
    .line 402
    invoke-virtual {v2, v0, v3}, Lts3;->b(Ljava/lang/Object;Ljava/lang/String;)V

    .line 403
    .line 404
    .line 405
    return-object v1
.end method

.method public final Q1()J
    .registers 11

    .line 1
    invoke-virtual {p0}, Lov;->H0()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lov;->a:Ljava/lang/Object;

    .line 5
    .line 6
    check-cast v0, Lzt3;

    .line 7
    .line 8
    invoke-virtual {v0}, Lzt3;->m()Lis3;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-virtual {v0}, Lis3;->O0()Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    sget-object v1, Ljn3;->d0:Lxr3;

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v1, v2}, Lxr3;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    check-cast v1, Ljava/lang/String;

    .line 24
    .line 25
    const-string v3, "*"

    .line 26
    .line 27
    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v3

    .line 31
    const-wide/16 v4, 0x0

    .line 32
    .line 33
    if-nez v3, :cond_34

    .line 34
    .line 35
    const-string v3, ","

    .line 36
    .line 37
    invoke-virtual {v1, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object v1

    .line 41
    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    invoke-interface {v1, v0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    if-eqz v0, :cond_33

    .line 50
    .line 51
    goto :goto_34

    .line 52
    :cond_33
    return-wide v4

    .line 53
    :cond_34
    :goto_34
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 54
    .line 55
    const/4 v1, 0x0

    .line 56
    const/16 v3, 0x1e

    .line 57
    .line 58
    if-ge v0, v3, :cond_3e

    .line 59
    .line 60
    const-wide/16 v6, 0x4

    .line 61
    .line 62
    goto :goto_69

    .line 63
    :cond_3e
    invoke-static {}, Lk1;->b()I

    .line 64
    .line 65
    .line 66
    move-result v6

    .line 67
    const/4 v7, 0x4

    .line 68
    if-ge v6, v7, :cond_48

    .line 69
    .line 70
    const-wide/16 v6, 0x8

    .line 71
    .line 72
    goto :goto_69

    .line 73
    :cond_48
    if-lt v0, v3, :cond_56

    .line 74
    .line 75
    invoke-static {}, Lk1;->b()I

    .line 76
    .line 77
    .line 78
    move-result v0

    .line 79
    const/4 v3, 0x3

    .line 80
    if-le v0, v3, :cond_56

    .line 81
    .line 82
    invoke-static {}, Lk1;->s()I

    .line 83
    .line 84
    .line 85
    move-result v0

    .line 86
    goto :goto_57

    .line 87
    :cond_56
    move v0, v1

    .line 88
    :goto_57
    sget-object v3, Ljn3;->X:Lxr3;

    .line 89
    .line 90
    invoke-virtual {v3, v2}, Lxr3;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 91
    .line 92
    .line 93
    move-result-object v3

    .line 94
    check-cast v3, Ljava/lang/Integer;

    .line 95
    .line 96
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 97
    .line 98
    .line 99
    move-result v3

    .line 100
    if-ge v0, v3, :cond_68

    .line 101
    .line 102
    const-wide/16 v6, 0x10

    .line 103
    .line 104
    goto :goto_69

    .line 105
    :cond_68
    move-wide v6, v4

    .line 106
    :goto_69
    const-string v0, "android.permission.ACCESS_ADSERVICES_ATTRIBUTION"

    .line 107
    .line 108
    invoke-virtual {p0, v0}, Lb04;->J1(Ljava/lang/String;)Z

    .line 109
    .line 110
    .line 111
    move-result v0

    .line 112
    if-nez v0, :cond_74

    .line 113
    .line 114
    const-wide/16 v8, 0x2

    .line 115
    .line 116
    or-long/2addr v6, v8

    .line 117
    :cond_74
    cmp-long v0, v6, v4

    .line 118
    .line 119
    if-nez v0, :cond_d9

    .line 120
    .line 121
    iget-object v0, p0, Lb04;->l:Ljava/lang/Boolean;

    .line 122
    .line 123
    if-nez v0, :cond_ce

    .line 124
    .line 125
    invoke-virtual {p0}, Lb04;->S1()Ler1;

    .line 126
    .line 127
    .line 128
    move-result-object v0

    .line 129
    if-nez v0, :cond_83

    .line 130
    .line 131
    goto :goto_d4

    .line 132
    :cond_83
    invoke-virtual {v0}, Ler1;->b()Lwk1;

    .line 133
    .line 134
    .line 135
    move-result-object v0

    .line 136
    :try_start_87
    sget-object v3, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    .line 137
    .line 138
    const-wide/16 v8, 0x2710

    .line 139
    .line 140
    invoke-interface {v0, v8, v9, v3}, Ljava/util/concurrent/Future;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    .line 141
    .line 142
    .line 143
    move-result-object v0

    .line 144
    check-cast v0, Ljava/lang/Integer;
    :try_end_91
    .catch Ljava/util/concurrent/CancellationException; {:try_start_87 .. :try_end_91} :catch_b2
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_87 .. :try_end_91} :catch_b0
    .catch Ljava/lang/InterruptedException; {:try_start_87 .. :try_end_91} :catch_ae
    .catch Ljava/util/concurrent/TimeoutException; {:try_start_87 .. :try_end_91} :catch_ac

    .line 145
    .line 146
    if-eqz v0, :cond_a5

    .line 147
    .line 148
    :try_start_93
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 149
    .line 150
    .line 151
    move-result v2

    .line 152
    const/4 v3, 0x1

    .line 153
    if-ne v2, v3, :cond_a5

    .line 154
    .line 155
    move v1, v3

    .line 156
    goto :goto_a5

    .line 157
    :catch_9c
    move-exception v1

    .line 158
    :goto_9d
    move-object v2, v0

    .line 159
    goto :goto_b3

    .line 160
    :catch_9f
    move-exception v1

    .line 161
    goto :goto_9d

    .line 162
    :catch_a1
    move-exception v1

    .line 163
    goto :goto_9d

    .line 164
    :catch_a3
    move-exception v1

    .line 165
    goto :goto_9d

    .line 166
    :cond_a5
    :goto_a5
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 167
    .line 168
    .line 169
    move-result-object v1

    .line 170
    iput-object v1, p0, Lb04;->l:Ljava/lang/Boolean;
    :try_end_ab
    .catch Ljava/util/concurrent/CancellationException; {:try_start_93 .. :try_end_ab} :catch_a3
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_93 .. :try_end_ab} :catch_a1
    .catch Ljava/lang/InterruptedException; {:try_start_93 .. :try_end_ab} :catch_9f
    .catch Ljava/util/concurrent/TimeoutException; {:try_start_93 .. :try_end_ab} :catch_9c

    .line 171
    .line 172
    goto :goto_c3

    .line 173
    :catch_ac
    move-exception v1

    .line 174
    goto :goto_b3

    .line 175
    :catch_ae
    move-exception v1

    .line 176
    goto :goto_b3

    .line 177
    :catch_b0
    move-exception v1

    .line 178
    goto :goto_b3

    .line 179
    :catch_b2
    move-exception v1

    .line 180
    :goto_b3
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 181
    .line 182
    .line 183
    move-result-object v0

    .line 184
    iget-object v0, v0, Lqs3;->n:Lts3;

    .line 185
    .line 186
    const-string v3, "Measurement manager api exception"

    .line 187
    .line 188
    invoke-virtual {v0, v1, v3}, Lts3;->b(Ljava/lang/Object;Ljava/lang/String;)V

    .line 189
    .line 190
    .line 191
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 192
    .line 193
    iput-object v0, p0, Lb04;->l:Ljava/lang/Boolean;

    .line 194
    .line 195
    move-object v0, v2

    .line 196
    :goto_c3
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 197
    .line 198
    .line 199
    move-result-object v1

    .line 200
    iget-object v1, v1, Lqs3;->s:Lts3;

    .line 201
    .line 202
    const-string v2, "Measurement manager api status result"

    .line 203
    .line 204
    invoke-virtual {v1, v0, v2}, Lts3;->b(Ljava/lang/Object;Ljava/lang/String;)V

    .line 205
    .line 206
    .line 207
    :cond_ce
    iget-object p0, p0, Lb04;->l:Ljava/lang/Boolean;

    .line 208
    .line 209
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 210
    .line 211
    .line 212
    move-result v1

    .line 213
    :goto_d4
    if-nez v1, :cond_d9

    .line 214
    .line 215
    const-wide/16 v0, 0x40

    .line 216
    .line 217
    or-long/2addr v6, v0

    .line 218
    :cond_d9
    cmp-long p0, v6, v4

    .line 219
    .line 220
    if-nez p0, :cond_e0

    .line 221
    .line 222
    const-wide/16 v0, 0x1

    .line 223
    .line 224
    return-wide v0

    .line 225
    :cond_e0
    return-wide v6
.end method

.method public final R0(Landroid/os/Bundle;)Landroid/os/Bundle;
    .registers 7

    .line 1
    new-instance v0, Landroid/os/Bundle;

    .line 2
    .line 3
    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 4
    .line 5
    .line 6
    if-eqz p1, :cond_3f

    .line 7
    .line 8
    invoke-virtual {p1}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    :goto_f
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    if-eqz v2, :cond_3f

    .line 21
    .line 22
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    check-cast v2, Ljava/lang/String;

    .line 27
    .line 28
    invoke-virtual {p1, v2}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v3

    .line 32
    invoke-virtual {p0, v3, v2}, Lb04;->B1(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v3

    .line 36
    if-nez v3, :cond_3b

    .line 37
    .line 38
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 39
    .line 40
    .line 41
    move-result-object v3

    .line 42
    iget-object v3, v3, Lqs3;->p:Lts3;

    .line 43
    .line 44
    iget-object v4, p0, Lov;->a:Ljava/lang/Object;

    .line 45
    .line 46
    check-cast v4, Lzt3;

    .line 47
    .line 48
    iget-object v4, v4, Lzt3;->p:Ljs3;

    .line 49
    .line 50
    invoke-virtual {v4, v2}, Ljs3;->f(Ljava/lang/String;)Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v2

    .line 54
    const-string v4, "Param value can\'t be null"

    .line 55
    .line 56
    invoke-virtual {v3, v2, v4}, Lts3;->b(Ljava/lang/Object;Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    goto :goto_f

    .line 60
    :cond_3b
    invoke-virtual {p0, v0, v2, v3}, Lb04;->b1(Landroid/os/Bundle;Ljava/lang/String;Ljava/lang/Object;)V

    .line 61
    .line 62
    .line 63
    goto :goto_f

    .line 64
    :cond_3f
    return-object v0
.end method

.method public final R1()J
    .registers 7

    .line 1
    iget-object v0, p0, Lb04;->f:Ljava/util/concurrent/atomic/AtomicLong;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    .line 4
    .line 5
    .line 6
    move-result-wide v0

    .line 7
    const-wide/16 v2, 0x0

    .line 8
    .line 9
    cmp-long v0, v0, v2

    .line 10
    .line 11
    iget-object v1, p0, Lb04;->f:Ljava/util/concurrent/atomic/AtomicLong;

    .line 12
    .line 13
    if-nez v0, :cond_37

    .line 14
    .line 15
    monitor-enter v1

    .line 16
    :try_start_f
    new-instance v0, Ljava/util/Random;

    .line 17
    .line 18
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    .line 19
    .line 20
    .line 21
    move-result-wide v2

    .line 22
    iget-object v4, p0, Lov;->a:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v4, Lzt3;

    .line 25
    .line 26
    iget-object v4, v4, Lzt3;->q:Lwn0;

    .line 27
    .line 28
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 29
    .line 30
    .line 31
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 32
    .line 33
    .line 34
    move-result-wide v4

    .line 35
    xor-long/2addr v2, v4

    .line 36
    invoke-direct {v0, v2, v3}, Ljava/util/Random;-><init>(J)V

    .line 37
    .line 38
    .line 39
    invoke-virtual {v0}, Ljava/util/Random;->nextLong()J

    .line 40
    .line 41
    .line 42
    move-result-wide v2

    .line 43
    iget v0, p0, Lb04;->g:I

    .line 44
    .line 45
    add-int/lit8 v0, v0, 0x1

    .line 46
    .line 47
    iput v0, p0, Lb04;->g:I

    .line 48
    .line 49
    int-to-long v4, v0

    .line 50
    add-long/2addr v2, v4

    .line 51
    monitor-exit v1

    .line 52
    return-wide v2

    .line 53
    :catchall_34
    move-exception p0

    .line 54
    monitor-exit v1
    :try_end_36
    .catchall {:try_start_f .. :try_end_36} :catchall_34

    .line 55
    throw p0

    .line 56
    :cond_37
    monitor-enter v1

    .line 57
    :try_start_38
    iget-object v0, p0, Lb04;->f:Ljava/util/concurrent/atomic/AtomicLong;

    .line 58
    .line 59
    const-wide/16 v2, -0x1

    .line 60
    .line 61
    const-wide/16 v4, 0x1

    .line 62
    .line 63
    invoke-virtual {v0, v2, v3, v4, v5}, Ljava/util/concurrent/atomic/AtomicLong;->compareAndSet(JJ)Z

    .line 64
    .line 65
    .line 66
    iget-object p0, p0, Lb04;->f:Ljava/util/concurrent/atomic/AtomicLong;

    .line 67
    .line 68
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->getAndIncrement()J

    .line 69
    .line 70
    .line 71
    move-result-wide v2

    .line 72
    monitor-exit v1

    .line 73
    return-wide v2

    .line 74
    :catchall_49
    move-exception p0

    .line 75
    monitor-exit v1
    :try_end_4b
    .catchall {:try_start_38 .. :try_end_4b} :catchall_49

    .line 76
    throw p0
.end method

.method public final S0(Ljava/lang/String;Landroid/os/Bundle;Ljava/util/List;Z)Landroid/os/Bundle;
    .registers 22

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v8, p2

    .line 6
    .line 7
    move-object/from16 v5, p3

    .line 8
    .line 9
    iget-object v2, v0, Lov;->a:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v2, Lzt3;

    .line 12
    .line 13
    sget-object v3, Ljw0;->j:[Ljava/lang/String;

    .line 14
    .line 15
    invoke-static {v1, v3}, Lb04;->v1(Ljava/lang/String;[Ljava/lang/String;)Z

    .line 16
    .line 17
    .line 18
    move-result v7

    .line 19
    const/4 v9, 0x0

    .line 20
    if-eqz v8, :cond_107

    .line 21
    .line 22
    new-instance v4, Landroid/os/Bundle;

    .line 23
    .line 24
    invoke-direct {v4, v8}, Landroid/os/Bundle;-><init>(Landroid/os/Bundle;)V

    .line 25
    .line 26
    .line 27
    iget-object v3, v2, Lzt3;->g:Lrl3;

    .line 28
    .line 29
    iget-object v10, v2, Lzt3;->p:Ljs3;

    .line 30
    .line 31
    invoke-virtual {v3}, Lov;->G0()Lb04;

    .line 32
    .line 33
    .line 34
    move-result-object v2

    .line 35
    const v3, 0xc02a560

    .line 36
    .line 37
    .line 38
    invoke-virtual {v2, v3}, Lb04;->y1(I)Z

    .line 39
    .line 40
    .line 41
    move-result v2

    .line 42
    if-eqz v2, :cond_2f

    .line 43
    .line 44
    const/16 v2, 0x64

    .line 45
    .line 46
    :goto_2d
    move v11, v2

    .line 47
    goto :goto_32

    .line 48
    :cond_2f
    const/16 v2, 0x19

    .line 49
    .line 50
    goto :goto_2d

    .line 51
    :goto_32
    new-instance v2, Ljava/util/TreeSet;

    .line 52
    .line 53
    invoke-virtual {v8}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    .line 54
    .line 55
    .line 56
    move-result-object v3

    .line 57
    invoke-direct {v2, v3}, Ljava/util/TreeSet;-><init>(Ljava/util/Collection;)V

    .line 58
    .line 59
    .line 60
    invoke-virtual {v2}, Ljava/util/TreeSet;->iterator()Ljava/util/Iterator;

    .line 61
    .line 62
    .line 63
    move-result-object v12

    .line 64
    const/4 v14, 0x0

    .line 65
    :goto_40
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    .line 66
    .line 67
    .line 68
    move-result v2

    .line 69
    if-eqz v2, :cond_106

    .line 70
    .line 71
    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object v2

    .line 75
    check-cast v2, Ljava/lang/String;

    .line 76
    .line 77
    const/4 v3, 0x3

    .line 78
    if-eqz v5, :cond_58

    .line 79
    .line 80
    invoke-interface {v5, v2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 81
    .line 82
    .line 83
    move-result v6

    .line 84
    if-nez v6, :cond_56

    .line 85
    .line 86
    goto :goto_58

    .line 87
    :cond_56
    const/4 v13, 0x0

    .line 88
    goto :goto_98

    .line 89
    :cond_58
    :goto_58
    const/16 v6, 0x28

    .line 90
    .line 91
    const/16 v15, 0xe

    .line 92
    .line 93
    const-string v13, "event param"

    .line 94
    .line 95
    if-nez p4, :cond_79

    .line 96
    .line 97
    invoke-virtual {v0, v13, v2}, Lb04;->H1(Ljava/lang/String;Ljava/lang/String;)Z

    .line 98
    .line 99
    .line 100
    move-result v16

    .line 101
    if-nez v16, :cond_69

    .line 102
    .line 103
    :goto_66
    move/from16 v16, v3

    .line 104
    .line 105
    goto :goto_7b

    .line 106
    :cond_69
    invoke-virtual {v0, v13, v9, v9, v2}, Lb04;->w1(Ljava/lang/String;[Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Z

    .line 107
    .line 108
    .line 109
    move-result v16

    .line 110
    if-nez v16, :cond_72

    .line 111
    .line 112
    move/from16 v16, v15

    .line 113
    .line 114
    goto :goto_7b

    .line 115
    :cond_72
    invoke-virtual {v0, v13, v2, v6}, Lb04;->s1(Ljava/lang/String;Ljava/lang/String;I)Z

    .line 116
    .line 117
    .line 118
    move-result v16

    .line 119
    if-nez v16, :cond_79

    .line 120
    .line 121
    goto :goto_66

    .line 122
    :cond_79
    const/16 v16, 0x0

    .line 123
    .line 124
    :goto_7b
    if-nez v16, :cond_96

    .line 125
    .line 126
    invoke-virtual {v0, v13, v2}, Lb04;->F1(Ljava/lang/String;Ljava/lang/String;)Z

    .line 127
    .line 128
    .line 129
    move-result v16

    .line 130
    if-nez v16, :cond_85

    .line 131
    .line 132
    :goto_83
    move v15, v3

    .line 133
    goto :goto_94

    .line 134
    :cond_85
    invoke-virtual {v0, v13, v9, v9, v2}, Lb04;->w1(Ljava/lang/String;[Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Z

    .line 135
    .line 136
    .line 137
    move-result v16

    .line 138
    if-nez v16, :cond_8c

    .line 139
    .line 140
    goto :goto_94

    .line 141
    :cond_8c
    invoke-virtual {v0, v13, v2, v6}, Lb04;->s1(Ljava/lang/String;Ljava/lang/String;I)Z

    .line 142
    .line 143
    .line 144
    move-result v6

    .line 145
    if-nez v6, :cond_93

    .line 146
    .line 147
    goto :goto_83

    .line 148
    :cond_93
    const/4 v15, 0x0

    .line 149
    :goto_94
    move v13, v15

    .line 150
    goto :goto_98

    .line 151
    :cond_96
    move/from16 v13, v16

    .line 152
    .line 153
    :goto_98
    if-eqz v13, :cond_a6

    .line 154
    .line 155
    if-ne v13, v3, :cond_9e

    .line 156
    .line 157
    move-object v3, v2

    .line 158
    goto :goto_9f

    .line 159
    :cond_9e
    move-object v3, v9

    .line 160
    :goto_9f
    invoke-static {v4, v13, v2, v3}, Lb04;->Y0(Landroid/os/Bundle;ILjava/lang/String;Ljava/lang/Object;)V

    .line 161
    .line 162
    .line 163
    invoke-virtual {v4, v2}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 164
    .line 165
    .line 166
    goto :goto_d5

    .line 167
    :cond_a6
    invoke-virtual {v8, v2}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    .line 168
    .line 169
    .line 170
    move-result-object v3

    .line 171
    move/from16 v6, p4

    .line 172
    .line 173
    invoke-virtual/range {v0 .. v7}, Lb04;->N0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;Landroid/os/Bundle;Ljava/util/List;ZZ)I

    .line 174
    .line 175
    .line 176
    move-result v3

    .line 177
    const/16 v0, 0x11

    .line 178
    .line 179
    if-ne v3, v0, :cond_ba

    .line 180
    .line 181
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 182
    .line 183
    invoke-static {v4, v3, v2, v0}, Lb04;->Y0(Landroid/os/Bundle;ILjava/lang/String;Ljava/lang/Object;)V

    .line 184
    .line 185
    .line 186
    goto :goto_db

    .line 187
    :cond_ba
    if-eqz v3, :cond_db

    .line 188
    .line 189
    const-string v0, "_ev"

    .line 190
    .line 191
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 192
    .line 193
    .line 194
    move-result v0

    .line 195
    if-nez v0, :cond_db

    .line 196
    .line 197
    const/16 v0, 0x15

    .line 198
    .line 199
    if-ne v3, v0, :cond_ca

    .line 200
    .line 201
    move-object v0, v1

    .line 202
    goto :goto_cb

    .line 203
    :cond_ca
    move-object v0, v2

    .line 204
    :goto_cb
    invoke-virtual {v8, v2}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    .line 205
    .line 206
    .line 207
    move-result-object v5

    .line 208
    invoke-static {v4, v3, v0, v5}, Lb04;->Y0(Landroid/os/Bundle;ILjava/lang/String;Ljava/lang/Object;)V

    .line 209
    .line 210
    .line 211
    invoke-virtual {v4, v2}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 212
    .line 213
    .line 214
    :cond_d5
    :goto_d5
    move-object/from16 v0, p0

    .line 215
    .line 216
    move-object/from16 v5, p3

    .line 217
    .line 218
    goto/16 :goto_40

    .line 219
    .line 220
    :cond_db
    :goto_db
    invoke-static {v2}, Lb04;->N1(Ljava/lang/String;)Z

    .line 221
    .line 222
    .line 223
    move-result v0

    .line 224
    if-eqz v0, :cond_d5

    .line 225
    .line 226
    add-int/lit8 v14, v14, 0x1

    .line 227
    .line 228
    if-le v14, v11, :cond_d5

    .line 229
    .line 230
    const-string v0, "Event can\'t contain more than "

    .line 231
    .line 232
    const-string v3, " params"

    .line 233
    .line 234
    invoke-static {v0, v3, v11}, Ln10;->h(Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;

    .line 235
    .line 236
    .line 237
    move-result-object v0

    .line 238
    invoke-virtual/range {p0 .. p0}, Lov;->l()Lqs3;

    .line 239
    .line 240
    .line 241
    move-result-object v3

    .line 242
    iget-object v3, v3, Lqs3;->m:Lts3;

    .line 243
    .line 244
    invoke-virtual {v10, v1}, Ljs3;->b(Ljava/lang/String;)Ljava/lang/String;

    .line 245
    .line 246
    .line 247
    move-result-object v5

    .line 248
    invoke-virtual {v10, v8}, Ljs3;->a(Landroid/os/Bundle;)Ljava/lang/String;

    .line 249
    .line 250
    .line 251
    move-result-object v6

    .line 252
    invoke-virtual {v3, v5, v6, v0}, Lts3;->a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    .line 253
    .line 254
    .line 255
    const/4 v0, 0x5

    .line 256
    invoke-static {v0, v4}, Lb04;->D1(ILandroid/os/Bundle;)Z

    .line 257
    .line 258
    .line 259
    invoke-virtual {v4, v2}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 260
    .line 261
    .line 262
    goto :goto_d5

    .line 263
    :cond_106
    return-object v4

    .line 264
    :cond_107
    return-object v9
.end method

.method public final S1()Ler1;
    .registers 8

    .line 1
    iget-object v0, p0, Lb04;->j:Ler1;

    .line 2
    .line 3
    if-nez v0, :cond_4a

    .line 4
    .line 5
    iget-object v0, p0, Lov;->a:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v0, Lzt3;

    .line 8
    .line 9
    iget-object v0, v0, Lzt3;->a:Landroid/content/Context;

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    new-instance v1, Ljava/lang/StringBuilder;

    .line 15
    .line 16
    const-string v2, "AdServicesInfo.version="

    .line 17
    .line 18
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 22
    .line 23
    const/4 v3, 0x0

    .line 24
    sget-object v4, Ly3;->a:Ly3;

    .line 25
    .line 26
    const/16 v5, 0x1e

    .line 27
    .line 28
    if-lt v2, v5, :cond_22

    .line 29
    .line 30
    invoke-virtual {v4}, Ly3;->a()I

    .line 31
    .line 32
    .line 33
    move-result v6

    .line 34
    goto :goto_23

    .line 35
    :cond_22
    move v6, v3

    .line 36
    :goto_23
    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 37
    .line 38
    .line 39
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    const-string v6, "MeasurementManager"

    .line 44
    .line 45
    invoke-static {v6, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 46
    .line 47
    .line 48
    if-lt v2, v5, :cond_35

    .line 49
    .line 50
    invoke-virtual {v4}, Ly3;->a()I

    .line 51
    .line 52
    .line 53
    move-result v3

    .line 54
    :cond_35
    const/4 v1, 0x5

    .line 55
    const/4 v2, 0x0

    .line 56
    if-lt v3, v1, :cond_3f

    .line 57
    .line 58
    new-instance v1, Ldr1;

    .line 59
    .line 60
    invoke-direct {v1, v0}, Ldr1;-><init>(Landroid/content/Context;)V

    .line 61
    .line 62
    .line 63
    goto :goto_40

    .line 64
    :cond_3f
    move-object v1, v2

    .line 65
    :goto_40
    if-eqz v1, :cond_47

    .line 66
    .line 67
    new-instance v2, Ler1;

    .line 68
    .line 69
    invoke-direct {v2, v1}, Ler1;-><init>(Ldr1;)V

    .line 70
    .line 71
    .line 72
    :cond_47
    iput-object v2, p0, Lb04;->j:Ler1;

    .line 73
    .line 74
    return-object v2

    .line 75
    :cond_4a
    return-object v0
.end method

.method public final T1()Ljava/lang/String;
    .registers 4

    .line 1
    const/16 v0, 0x10

    .line 2
    .line 3
    new-array v0, v0, [B

    .line 4
    .line 5
    invoke-virtual {p0}, Lb04;->V1()Ljava/security/SecureRandom;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    invoke-virtual {p0, v0}, Ljava/security/SecureRandom;->nextBytes([B)V

    .line 10
    .line 11
    .line 12
    sget-object p0, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 13
    .line 14
    new-instance v1, Ljava/math/BigInteger;

    .line 15
    .line 16
    const/4 v2, 0x1

    .line 17
    invoke-direct {v1, v2, v0}, Ljava/math/BigInteger;-><init>(I[B)V

    .line 18
    .line 19
    .line 20
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    const-string v1, "%032x"

    .line 25
    .line 26
    invoke-static {p0, v1, v0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    return-object p0
.end method

.method public final U0(ILjava/lang/Object;ZZ)Ljava/lang/Object;
    .registers 7

    .line 1
    if-nez p2, :cond_4

    .line 2
    .line 3
    goto/16 :goto_a7

    .line 4
    .line 5
    :cond_4
    instance-of v0, p2, Ljava/lang/Long;

    .line 6
    .line 7
    if-nez v0, :cond_b2

    .line 8
    .line 9
    instance-of v0, p2, Ljava/lang/Double;

    .line 10
    .line 11
    if-eqz v0, :cond_d

    .line 12
    .line 13
    return-object p2

    .line 14
    :cond_d
    instance-of v0, p2, Ljava/lang/Integer;

    .line 15
    .line 16
    if-eqz v0, :cond_1d

    .line 17
    .line 18
    check-cast p2, Ljava/lang/Integer;

    .line 19
    .line 20
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 21
    .line 22
    .line 23
    move-result p0

    .line 24
    int-to-long p0, p0

    .line 25
    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 26
    .line 27
    .line 28
    move-result-object p0

    .line 29
    return-object p0

    .line 30
    :cond_1d
    instance-of v0, p2, Ljava/lang/Byte;

    .line 31
    .line 32
    if-eqz v0, :cond_2d

    .line 33
    .line 34
    check-cast p2, Ljava/lang/Byte;

    .line 35
    .line 36
    invoke-virtual {p2}, Ljava/lang/Byte;->byteValue()B

    .line 37
    .line 38
    .line 39
    move-result p0

    .line 40
    int-to-long p0, p0

    .line 41
    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 42
    .line 43
    .line 44
    move-result-object p0

    .line 45
    return-object p0

    .line 46
    :cond_2d
    instance-of v0, p2, Ljava/lang/Short;

    .line 47
    .line 48
    if-eqz v0, :cond_3d

    .line 49
    .line 50
    check-cast p2, Ljava/lang/Short;

    .line 51
    .line 52
    invoke-virtual {p2}, Ljava/lang/Short;->shortValue()S

    .line 53
    .line 54
    .line 55
    move-result p0

    .line 56
    int-to-long p0, p0

    .line 57
    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 58
    .line 59
    .line 60
    move-result-object p0

    .line 61
    return-object p0

    .line 62
    :cond_3d
    instance-of v0, p2, Ljava/lang/Boolean;

    .line 63
    .line 64
    if-eqz v0, :cond_53

    .line 65
    .line 66
    check-cast p2, Ljava/lang/Boolean;

    .line 67
    .line 68
    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 69
    .line 70
    .line 71
    move-result p0

    .line 72
    if-eqz p0, :cond_4c

    .line 73
    .line 74
    const-wide/16 p0, 0x1

    .line 75
    .line 76
    goto :goto_4e

    .line 77
    :cond_4c
    const-wide/16 p0, 0x0

    .line 78
    .line 79
    :goto_4e
    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 80
    .line 81
    .line 82
    move-result-object p0

    .line 83
    return-object p0

    .line 84
    :cond_53
    instance-of v0, p2, Ljava/lang/Float;

    .line 85
    .line 86
    if-eqz v0, :cond_62

    .line 87
    .line 88
    check-cast p2, Ljava/lang/Float;

    .line 89
    .line 90
    invoke-virtual {p2}, Ljava/lang/Float;->doubleValue()D

    .line 91
    .line 92
    .line 93
    move-result-wide p0

    .line 94
    invoke-static {p0, p1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 95
    .line 96
    .line 97
    move-result-object p0

    .line 98
    return-object p0

    .line 99
    :cond_62
    instance-of v0, p2, Ljava/lang/String;

    .line 100
    .line 101
    if-nez v0, :cond_a9

    .line 102
    .line 103
    instance-of v0, p2, Ljava/lang/Character;

    .line 104
    .line 105
    if-nez v0, :cond_a9

    .line 106
    .line 107
    instance-of v0, p2, Ljava/lang/CharSequence;

    .line 108
    .line 109
    if-eqz v0, :cond_6f

    .line 110
    .line 111
    goto :goto_a9

    .line 112
    :cond_6f
    if-eqz p4, :cond_a7

    .line 113
    .line 114
    instance-of p1, p2, [Landroid/os/Bundle;

    .line 115
    .line 116
    if-nez p1, :cond_79

    .line 117
    .line 118
    instance-of p1, p2, [Landroid/os/Parcelable;

    .line 119
    .line 120
    if-eqz p1, :cond_a7

    .line 121
    .line 122
    :cond_79
    new-instance p1, Ljava/util/ArrayList;

    .line 123
    .line 124
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 125
    .line 126
    .line 127
    check-cast p2, [Landroid/os/Parcelable;

    .line 128
    .line 129
    array-length p3, p2

    .line 130
    const/4 p4, 0x0

    .line 131
    :goto_82
    if-ge p4, p3, :cond_9c

    .line 132
    .line 133
    aget-object v0, p2, p4

    .line 134
    .line 135
    instance-of v1, v0, Landroid/os/Bundle;

    .line 136
    .line 137
    if-eqz v1, :cond_99

    .line 138
    .line 139
    check-cast v0, Landroid/os/Bundle;

    .line 140
    .line 141
    invoke-virtual {p0, v0}, Lb04;->R0(Landroid/os/Bundle;)Landroid/os/Bundle;

    .line 142
    .line 143
    .line 144
    move-result-object v0

    .line 145
    invoke-virtual {v0}, Landroid/os/BaseBundle;->isEmpty()Z

    .line 146
    .line 147
    .line 148
    move-result v1

    .line 149
    if-nez v1, :cond_99

    .line 150
    .line 151
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 152
    .line 153
    .line 154
    :cond_99
    add-int/lit8 p4, p4, 0x1

    .line 155
    .line 156
    goto :goto_82

    .line 157
    :cond_9c
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    .line 158
    .line 159
    .line 160
    move-result p0

    .line 161
    new-array p0, p0, [Landroid/os/Bundle;

    .line 162
    .line 163
    invoke-virtual {p1, p0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 164
    .line 165
    .line 166
    move-result-object p0

    .line 167
    return-object p0

    .line 168
    :cond_a7
    :goto_a7
    const/4 p0, 0x0

    .line 169
    return-object p0

    .line 170
    :cond_a9
    :goto_a9
    invoke-static {p2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 171
    .line 172
    .line 173
    move-result-object p0

    .line 174
    invoke-static {p1, p0, p3}, Lb04;->V0(ILjava/lang/String;Z)Ljava/lang/String;

    .line 175
    .line 176
    .line 177
    move-result-object p0

    .line 178
    return-object p0

    .line 179
    :cond_b2
    return-object p2
.end method

.method public final V1()Ljava/security/SecureRandom;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lov;->H0()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lb04;->e:Ljava/security/SecureRandom;

    .line 5
    .line 6
    if-nez v0, :cond_e

    .line 7
    .line 8
    new-instance v0, Ljava/security/SecureRandom;

    .line 9
    .line 10
    invoke-direct {v0}, Ljava/security/SecureRandom;-><init>()V

    .line 11
    .line 12
    .line 13
    iput-object v0, p0, Lb04;->e:Ljava/security/SecureRandom;

    .line 14
    .line 15
    :cond_e
    return-object v0
.end method

.method public final W0(Ljava/lang/String;Landroid/os/Bundle;Ljava/lang/String;JZ)Lhn3;
    .registers 13

    .line 1
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-eqz v0, :cond_8

    .line 7
    .line 8
    return-object v1

    .line 9
    :cond_8
    invoke-virtual {p0, p1}, Lb04;->M0(Ljava/lang/String;)I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-nez v0, :cond_3e

    .line 14
    .line 15
    new-instance v0, Landroid/os/Bundle;

    .line 16
    .line 17
    if-eqz p2, :cond_16

    .line 18
    .line 19
    invoke-direct {v0, p2}, Landroid/os/Bundle;-><init>(Landroid/os/Bundle;)V

    .line 20
    .line 21
    .line 22
    goto :goto_19

    .line 23
    :cond_16
    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 24
    .line 25
    .line 26
    :goto_19
    const-string p2, "_o"

    .line 27
    .line 28
    invoke-virtual {v0, p2, p3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    invoke-static {p2}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 32
    .line 33
    .line 34
    move-result-object p2

    .line 35
    const/4 v1, 0x1

    .line 36
    invoke-virtual {p0, p1, v0, p2, v1}, Lb04;->S0(Ljava/lang/String;Landroid/os/Bundle;Ljava/util/List;Z)Landroid/os/Bundle;

    .line 37
    .line 38
    .line 39
    move-result-object p2

    .line 40
    if-eqz p6, :cond_2d

    .line 41
    .line 42
    invoke-virtual {p0, p2}, Lb04;->R0(Landroid/os/Bundle;)Landroid/os/Bundle;

    .line 43
    .line 44
    .line 45
    move-result-object p2

    .line 46
    :cond_2d
    invoke-static {p2}, Lmw1;->k(Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    new-instance v0, Lhn3;

    .line 50
    .line 51
    new-instance v2, Lgn3;

    .line 52
    .line 53
    invoke-direct {v2, p2}, Lgn3;-><init>(Landroid/os/Bundle;)V

    .line 54
    .line 55
    .line 56
    move-object v1, p1

    .line 57
    move-object v3, p3

    .line 58
    move-wide v4, p4

    .line 59
    invoke-direct/range {v0 .. v5}, Lhn3;-><init>(Ljava/lang/String;Lgn3;Ljava/lang/String;J)V

    .line 60
    .line 61
    .line 62
    return-object v0

    .line 63
    :cond_3e
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 64
    .line 65
    .line 66
    move-result-object p2

    .line 67
    iget-object p2, p2, Lqs3;->j:Lts3;

    .line 68
    .line 69
    iget-object p0, p0, Lov;->a:Ljava/lang/Object;

    .line 70
    .line 71
    check-cast p0, Lzt3;

    .line 72
    .line 73
    iget-object p0, p0, Lzt3;->p:Ljs3;

    .line 74
    .line 75
    invoke-virtual {p0, p1}, Ljs3;->g(Ljava/lang/String;)Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object p0

    .line 79
    const-string p1, "Invalid conditional property event name"

    .line 80
    .line 81
    invoke-virtual {p2, p0, p1}, Lts3;->b(Ljava/lang/Object;Ljava/lang/String;)V

    .line 82
    .line 83
    .line 84
    invoke-static {}, Lt12;->b()V

    .line 85
    .line 86
    .line 87
    return-object v1
.end method

.method public final X0(Log0;I)V
    .registers 12

    .line 1
    iget-object v0, p0, Lov;->a:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lzt3;

    .line 4
    .line 5
    new-instance v1, Ljava/util/TreeSet;

    .line 6
    .line 7
    iget-object v2, p1, Log0;->e:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v2, Landroid/os/Bundle;

    .line 10
    .line 11
    invoke-virtual {v2}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    .line 12
    .line 13
    .line 14
    move-result-object v3

    .line 15
    invoke-direct {v1, v3}, Ljava/util/TreeSet;-><init>(Ljava/util/Collection;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {v1}, Ljava/util/TreeSet;->iterator()Ljava/util/Iterator;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    const/4 v3, 0x0

    .line 23
    :cond_16
    :goto_16
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 24
    .line 25
    .line 26
    move-result v4

    .line 27
    if-eqz v4, :cond_55

    .line 28
    .line 29
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v4

    .line 33
    check-cast v4, Ljava/lang/String;

    .line 34
    .line 35
    invoke-static {v4}, Lb04;->N1(Ljava/lang/String;)Z

    .line 36
    .line 37
    .line 38
    move-result v5

    .line 39
    if-eqz v5, :cond_16

    .line 40
    .line 41
    add-int/lit8 v3, v3, 0x1

    .line 42
    .line 43
    if-le v3, p2, :cond_16

    .line 44
    .line 45
    const-string v5, "Event can\'t contain more than "

    .line 46
    .line 47
    const-string v6, " params"

    .line 48
    .line 49
    invoke-static {v5, v6, p2}, Ln10;->h(Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object v5

    .line 53
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 54
    .line 55
    .line 56
    move-result-object v6

    .line 57
    iget-object v6, v6, Lqs3;->m:Lts3;

    .line 58
    .line 59
    iget-object v7, v0, Lzt3;->p:Ljs3;

    .line 60
    .line 61
    iget-object v8, p1, Log0;->c:Ljava/lang/Object;

    .line 62
    .line 63
    check-cast v8, Ljava/lang/String;

    .line 64
    .line 65
    invoke-virtual {v7, v8}, Ljs3;->b(Ljava/lang/String;)Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v7

    .line 69
    iget-object v8, v0, Lzt3;->p:Ljs3;

    .line 70
    .line 71
    invoke-virtual {v8, v2}, Ljs3;->a(Landroid/os/Bundle;)Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object v8

    .line 75
    invoke-virtual {v6, v7, v8, v5}, Lts3;->a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    .line 76
    .line 77
    .line 78
    const/4 v5, 0x5

    .line 79
    invoke-static {v5, v2}, Lb04;->D1(ILandroid/os/Bundle;)Z

    .line 80
    .line 81
    .line 82
    invoke-virtual {v2, v4}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 83
    .line 84
    .line 85
    goto :goto_16

    .line 86
    :cond_55
    return-void
.end method

.method public final Z0(Landroid/os/Bundle;J)V
    .registers 9

    .line 1
    const-string v0, "_et"

    .line 2
    .line 3
    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;)J

    .line 4
    .line 5
    .line 6
    move-result-wide v1

    .line 7
    const-wide/16 v3, 0x0

    .line 8
    .line 9
    cmp-long v3, v1, v3

    .line 10
    .line 11
    if-eqz v3, :cond_1b

    .line 12
    .line 13
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    iget-object p0, p0, Lqs3;->n:Lts3;

    .line 18
    .line 19
    const-string v3, "Params already contained engagement"

    .line 20
    .line 21
    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 22
    .line 23
    .line 24
    move-result-object v4

    .line 25
    invoke-virtual {p0, v4, v3}, Lts3;->b(Ljava/lang/Object;Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    :cond_1b
    add-long/2addr p2, v1

    .line 29
    invoke-virtual {p1, v0, p2, p3}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    .line 30
    .line 31
    .line 32
    return-void
.end method

.method public final a1(Landroid/os/Bundle;Landroid/os/Bundle;)V
    .registers 7

    .line 1
    if-nez p2, :cond_3

    .line 2
    .line 3
    goto :goto_29

    .line 4
    :cond_3
    invoke-virtual {p2}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    :cond_b
    :goto_b
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    if-eqz v1, :cond_29

    .line 17
    .line 18
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    check-cast v1, Ljava/lang/String;

    .line 23
    .line 24
    invoke-virtual {p1, v1}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 25
    .line 26
    .line 27
    move-result v2

    .line 28
    if-nez v2, :cond_b

    .line 29
    .line 30
    invoke-virtual {p0}, Lov;->G0()Lb04;

    .line 31
    .line 32
    .line 33
    move-result-object v2

    .line 34
    invoke-virtual {p2, v1}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v3

    .line 38
    invoke-virtual {v2, p1, v1, v3}, Lb04;->b1(Landroid/os/Bundle;Ljava/lang/String;Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    goto :goto_b

    .line 42
    :cond_29
    :goto_29
    return-void
.end method

.method public final b1(Landroid/os/Bundle;Ljava/lang/String;Ljava/lang/Object;)V
    .registers 6

    .line 1
    if-nez p1, :cond_3

    .line 2
    .line 3
    goto :goto_58

    .line 4
    :cond_3
    instance-of v0, p3, Ljava/lang/Long;

    .line 5
    .line 6
    if-eqz v0, :cond_11

    .line 7
    .line 8
    check-cast p3, Ljava/lang/Long;

    .line 9
    .line 10
    invoke-virtual {p3}, Ljava/lang/Long;->longValue()J

    .line 11
    .line 12
    .line 13
    move-result-wide v0

    .line 14
    invoke-virtual {p1, p2, v0, v1}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :cond_11
    instance-of v0, p3, Ljava/lang/String;

    .line 19
    .line 20
    if-eqz v0, :cond_1d

    .line 21
    .line 22
    invoke-static {p3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    invoke-virtual {p1, p2, p0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :cond_1d
    instance-of v0, p3, Ljava/lang/Double;

    .line 31
    .line 32
    if-eqz v0, :cond_2b

    .line 33
    .line 34
    check-cast p3, Ljava/lang/Double;

    .line 35
    .line 36
    invoke-virtual {p3}, Ljava/lang/Double;->doubleValue()D

    .line 37
    .line 38
    .line 39
    move-result-wide v0

    .line 40
    invoke-virtual {p1, p2, v0, v1}, Landroid/os/BaseBundle;->putDouble(Ljava/lang/String;D)V

    .line 41
    .line 42
    .line 43
    return-void

    .line 44
    :cond_2b
    instance-of v0, p3, [Landroid/os/Bundle;

    .line 45
    .line 46
    if-eqz v0, :cond_35

    .line 47
    .line 48
    check-cast p3, [Landroid/os/Bundle;

    .line 49
    .line 50
    invoke-virtual {p1, p2, p3}, Landroid/os/Bundle;->putParcelableArray(Ljava/lang/String;[Landroid/os/Parcelable;)V

    .line 51
    .line 52
    .line 53
    return-void

    .line 54
    :cond_35
    if-eqz p2, :cond_58

    .line 55
    .line 56
    if-eqz p3, :cond_42

    .line 57
    .line 58
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 59
    .line 60
    .line 61
    move-result-object p1

    .line 62
    invoke-virtual {p1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object p1

    .line 66
    goto :goto_43

    .line 67
    :cond_42
    const/4 p1, 0x0

    .line 68
    :goto_43
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 69
    .line 70
    .line 71
    move-result-object p3

    .line 72
    iget-object p3, p3, Lqs3;->p:Lts3;

    .line 73
    .line 74
    iget-object p0, p0, Lov;->a:Ljava/lang/Object;

    .line 75
    .line 76
    check-cast p0, Lzt3;

    .line 77
    .line 78
    iget-object p0, p0, Lzt3;->p:Ljs3;

    .line 79
    .line 80
    invoke-virtual {p0, p2}, Ljs3;->f(Ljava/lang/String;)Ljava/lang/String;

    .line 81
    .line 82
    .line 83
    move-result-object p0

    .line 84
    const-string p2, "Not putting event parameter. Invalid value type. name, type"

    .line 85
    .line 86
    invoke-virtual {p3, p0, p1, p2}, Lts3;->a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    .line 87
    .line 88
    .line 89
    :cond_58
    :goto_58
    return-void
.end method

.method public final c1(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;Ljava/util/List;Z)V
    .registers 23

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v4, p3

    .line 6
    .line 7
    move-object/from16 v5, p4

    .line 8
    .line 9
    iget-object v2, v0, Lov;->a:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v2, Lzt3;

    .line 12
    .line 13
    iget-object v3, v2, Lzt3;->g:Lrl3;

    .line 14
    .line 15
    iget-object v8, v2, Lzt3;->p:Ljs3;

    .line 16
    .line 17
    invoke-virtual {v3}, Lov;->G0()Lb04;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    const v9, 0xdc64e60

    .line 22
    .line 23
    .line 24
    invoke-virtual {v2, v9}, Lb04;->y1(I)Z

    .line 25
    .line 26
    .line 27
    move-result v2

    .line 28
    const/4 v10, 0x0

    .line 29
    if-eqz v2, :cond_22

    .line 30
    .line 31
    const/16 v2, 0x23

    .line 32
    .line 33
    move v11, v2

    .line 34
    goto :goto_23

    .line 35
    :cond_22
    move v11, v10

    .line 36
    :goto_23
    new-instance v2, Ljava/util/TreeSet;

    .line 37
    .line 38
    invoke-virtual {v4}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    .line 39
    .line 40
    .line 41
    move-result-object v3

    .line 42
    invoke-direct {v2, v3}, Ljava/util/TreeSet;-><init>(Ljava/util/Collection;)V

    .line 43
    .line 44
    .line 45
    invoke-virtual {v2}, Ljava/util/TreeSet;->iterator()Ljava/util/Iterator;

    .line 46
    .line 47
    .line 48
    move-result-object v12

    .line 49
    move v13, v10

    .line 50
    :goto_31
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    .line 51
    .line 52
    .line 53
    move-result v2

    .line 54
    if-eqz v2, :cond_12a

    .line 55
    .line 56
    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object v2

    .line 60
    check-cast v2, Ljava/lang/String;

    .line 61
    .line 62
    const/4 v3, 0x3

    .line 63
    const/4 v6, 0x0

    .line 64
    if-eqz v5, :cond_4a

    .line 65
    .line 66
    invoke-interface {v5, v2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 67
    .line 68
    .line 69
    move-result v7

    .line 70
    if-nez v7, :cond_48

    .line 71
    .line 72
    goto :goto_4a

    .line 73
    :cond_48
    move v14, v10

    .line 74
    goto :goto_87

    .line 75
    :cond_4a
    :goto_4a
    const/16 v7, 0x28

    .line 76
    .line 77
    const/16 v14, 0xe

    .line 78
    .line 79
    const-string v15, "event param"

    .line 80
    .line 81
    if-nez p5, :cond_6b

    .line 82
    .line 83
    invoke-virtual {v0, v15, v2}, Lb04;->H1(Ljava/lang/String;Ljava/lang/String;)Z

    .line 84
    .line 85
    .line 86
    move-result v16

    .line 87
    if-nez v16, :cond_5b

    .line 88
    .line 89
    :goto_58
    move/from16 v16, v3

    .line 90
    .line 91
    goto :goto_6d

    .line 92
    :cond_5b
    invoke-virtual {v0, v15, v6, v6, v2}, Lb04;->w1(Ljava/lang/String;[Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Z

    .line 93
    .line 94
    .line 95
    move-result v16

    .line 96
    if-nez v16, :cond_64

    .line 97
    .line 98
    move/from16 v16, v14

    .line 99
    .line 100
    goto :goto_6d

    .line 101
    :cond_64
    invoke-virtual {v0, v15, v2, v7}, Lb04;->s1(Ljava/lang/String;Ljava/lang/String;I)Z

    .line 102
    .line 103
    .line 104
    move-result v16

    .line 105
    if-nez v16, :cond_6b

    .line 106
    .line 107
    goto :goto_58

    .line 108
    :cond_6b
    move/from16 v16, v10

    .line 109
    .line 110
    :goto_6d
    if-nez v16, :cond_85

    .line 111
    .line 112
    invoke-virtual {v0, v15, v2}, Lb04;->F1(Ljava/lang/String;Ljava/lang/String;)Z

    .line 113
    .line 114
    .line 115
    move-result v16

    .line 116
    if-nez v16, :cond_77

    .line 117
    .line 118
    :goto_75
    move v14, v3

    .line 119
    goto :goto_87

    .line 120
    :cond_77
    invoke-virtual {v0, v15, v6, v6, v2}, Lb04;->w1(Ljava/lang/String;[Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Z

    .line 121
    .line 122
    .line 123
    move-result v16

    .line 124
    if-nez v16, :cond_7e

    .line 125
    .line 126
    goto :goto_87

    .line 127
    :cond_7e
    invoke-virtual {v0, v15, v2, v7}, Lb04;->s1(Ljava/lang/String;Ljava/lang/String;I)Z

    .line 128
    .line 129
    .line 130
    move-result v7

    .line 131
    if-nez v7, :cond_48

    .line 132
    .line 133
    goto :goto_75

    .line 134
    :cond_85
    move/from16 v14, v16

    .line 135
    .line 136
    :goto_87
    if-eqz v14, :cond_95

    .line 137
    .line 138
    if-ne v14, v3, :cond_8c

    .line 139
    .line 140
    move-object v6, v2

    .line 141
    :cond_8c
    invoke-static {v4, v14, v2, v6}, Lb04;->Y0(Landroid/os/Bundle;ILjava/lang/String;Ljava/lang/Object;)V

    .line 142
    .line 143
    .line 144
    invoke-virtual {v4, v2}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 145
    .line 146
    .line 147
    move-object/from16 v14, p2

    .line 148
    .line 149
    goto :goto_d0

    .line 150
    :cond_95
    invoke-virtual {v4, v2}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    .line 151
    .line 152
    .line 153
    move-result-object v3

    .line 154
    invoke-static {v3}, Lb04;->p1(Ljava/lang/Object;)Z

    .line 155
    .line 156
    .line 157
    move-result v3

    .line 158
    if-eqz v3, :cond_af

    .line 159
    .line 160
    invoke-virtual {v0}, Lov;->l()Lqs3;

    .line 161
    .line 162
    .line 163
    move-result-object v3

    .line 164
    iget-object v3, v3, Lqs3;->p:Lts3;

    .line 165
    .line 166
    const-string v6, "Nested Bundle parameters are not allowed; discarded. event name, param name, child param name"

    .line 167
    .line 168
    move-object/from16 v14, p2

    .line 169
    .line 170
    invoke-virtual {v3, v6, v1, v14, v2}, Lts3;->d(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 171
    .line 172
    .line 173
    const/16 v3, 0x16

    .line 174
    .line 175
    goto :goto_bc

    .line 176
    :cond_af
    move-object/from16 v14, p2

    .line 177
    .line 178
    invoke-virtual {v4, v2}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    .line 179
    .line 180
    .line 181
    move-result-object v3

    .line 182
    const/4 v7, 0x0

    .line 183
    move/from16 v6, p5

    .line 184
    .line 185
    invoke-virtual/range {v0 .. v7}, Lb04;->N0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;Landroid/os/Bundle;Ljava/util/List;ZZ)I

    .line 186
    .line 187
    .line 188
    move-result v3

    .line 189
    :goto_bc
    if-eqz v3, :cond_d4

    .line 190
    .line 191
    const-string v5, "_ev"

    .line 192
    .line 193
    invoke-virtual {v5, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 194
    .line 195
    .line 196
    move-result v5

    .line 197
    if-nez v5, :cond_d4

    .line 198
    .line 199
    invoke-virtual {v4, v2}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    .line 200
    .line 201
    .line 202
    move-result-object v5

    .line 203
    invoke-static {v4, v3, v2, v5}, Lb04;->Y0(Landroid/os/Bundle;ILjava/lang/String;Ljava/lang/Object;)V

    .line 204
    .line 205
    .line 206
    invoke-virtual {v4, v2}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 207
    .line 208
    .line 209
    :cond_d0
    :goto_d0
    move-object/from16 v5, p4

    .line 210
    .line 211
    goto/16 :goto_31

    .line 212
    .line 213
    :cond_d4
    invoke-static {v2}, Lb04;->N1(Ljava/lang/String;)Z

    .line 214
    .line 215
    .line 216
    move-result v3

    .line 217
    if-eqz v3, :cond_d0

    .line 218
    .line 219
    sget-object v3, Lyo1;->g:[Ljava/lang/String;

    .line 220
    .line 221
    invoke-static {v2, v3}, Lb04;->v1(Ljava/lang/String;[Ljava/lang/String;)Z

    .line 222
    .line 223
    .line 224
    move-result v3

    .line 225
    if-nez v3, :cond_d0

    .line 226
    .line 227
    add-int/lit8 v13, v13, 0x1

    .line 228
    .line 229
    invoke-virtual {v0, v9}, Lb04;->y1(I)Z

    .line 230
    .line 231
    .line 232
    move-result v3

    .line 233
    if-nez v3, :cond_106

    .line 234
    .line 235
    invoke-virtual {v0}, Lov;->l()Lqs3;

    .line 236
    .line 237
    .line 238
    move-result-object v3

    .line 239
    iget-object v3, v3, Lqs3;->m:Lts3;

    .line 240
    .line 241
    invoke-virtual {v8, v1}, Ljs3;->b(Ljava/lang/String;)Ljava/lang/String;

    .line 242
    .line 243
    .line 244
    move-result-object v5

    .line 245
    invoke-virtual {v8, v4}, Ljs3;->a(Landroid/os/Bundle;)Ljava/lang/String;

    .line 246
    .line 247
    .line 248
    move-result-object v6

    .line 249
    const-string v7, "Item array not supported on client\'s version of Google Play Services (Android Only)"

    .line 250
    .line 251
    invoke-virtual {v3, v5, v6, v7}, Lts3;->a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    .line 252
    .line 253
    .line 254
    const/16 v3, 0x17

    .line 255
    .line 256
    invoke-static {v3, v4}, Lb04;->D1(ILandroid/os/Bundle;)Z

    .line 257
    .line 258
    .line 259
    invoke-virtual {v4, v2}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 260
    .line 261
    .line 262
    goto :goto_d0

    .line 263
    :cond_106
    if-le v13, v11, :cond_d0

    .line 264
    .line 265
    invoke-virtual {v0}, Lov;->l()Lqs3;

    .line 266
    .line 267
    .line 268
    move-result-object v3

    .line 269
    iget-object v3, v3, Lqs3;->m:Lts3;

    .line 270
    .line 271
    const-string v5, "Item can\'t contain more than "

    .line 272
    .line 273
    const-string v6, " item-scoped custom params"

    .line 274
    .line 275
    invoke-static {v5, v6, v11}, Ln10;->h(Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;

    .line 276
    .line 277
    .line 278
    move-result-object v5

    .line 279
    invoke-virtual {v8, v1}, Ljs3;->b(Ljava/lang/String;)Ljava/lang/String;

    .line 280
    .line 281
    .line 282
    move-result-object v6

    .line 283
    invoke-virtual {v8, v4}, Ljs3;->a(Landroid/os/Bundle;)Ljava/lang/String;

    .line 284
    .line 285
    .line 286
    move-result-object v7

    .line 287
    invoke-virtual {v3, v6, v7, v5}, Lts3;->a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    .line 288
    .line 289
    .line 290
    const/16 v3, 0x1c

    .line 291
    .line 292
    invoke-static {v3, v4}, Lb04;->D1(ILandroid/os/Bundle;)Z

    .line 293
    .line 294
    .line 295
    invoke-virtual {v4, v2}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 296
    .line 297
    .line 298
    goto :goto_d0

    .line 299
    :cond_12a
    return-void
.end method

.method public final d1(Ljava/lang/String;Loo3;)V
    .registers 5

    .line 1
    new-instance v0, Landroid/os/Bundle;

    .line 2
    .line 3
    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 4
    .line 5
    .line 6
    const-string v1, "r"

    .line 7
    .line 8
    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    :try_start_a
    invoke-interface {p2, v0}, Loo3;->f(Landroid/os/Bundle;)V
    :try_end_d
    .catch Landroid/os/RemoteException; {:try_start_a .. :try_end_d} :catch_e

    .line 12
    .line 13
    .line 14
    return-void

    .line 15
    :catch_e
    move-exception p1

    .line 16
    iget-object p0, p0, Lov;->a:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast p0, Lzt3;

    .line 19
    .line 20
    iget-object p0, p0, Lzt3;->l:Lqs3;

    .line 21
    .line 22
    invoke-static {p0}, Lzt3;->e(Lwu3;)V

    .line 23
    .line 24
    .line 25
    iget-object p0, p0, Lqs3;->n:Lts3;

    .line 26
    .line 27
    const-string p2, "Error returning string value to wrapper"

    .line 28
    .line 29
    invoke-virtual {p0, p1, p2}, Lts3;->b(Ljava/lang/Object;Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    return-void
.end method

.method public final e1(Loo3;I)V
    .registers 5

    .line 1
    new-instance v0, Landroid/os/Bundle;

    .line 2
    .line 3
    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 4
    .line 5
    .line 6
    const-string v1, "r"

    .line 7
    .line 8
    invoke-virtual {v0, v1, p2}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 9
    .line 10
    .line 11
    :try_start_a
    invoke-interface {p1, v0}, Loo3;->f(Landroid/os/Bundle;)V
    :try_end_d
    .catch Landroid/os/RemoteException; {:try_start_a .. :try_end_d} :catch_e

    .line 12
    .line 13
    .line 14
    return-void

    .line 15
    :catch_e
    move-exception p1

    .line 16
    iget-object p0, p0, Lov;->a:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast p0, Lzt3;

    .line 19
    .line 20
    iget-object p0, p0, Lzt3;->l:Lqs3;

    .line 21
    .line 22
    invoke-static {p0}, Lzt3;->e(Lwu3;)V

    .line 23
    .line 24
    .line 25
    iget-object p0, p0, Lqs3;->n:Lts3;

    .line 26
    .line 27
    const-string p2, "Error returning int value to wrapper"

    .line 28
    .line 29
    invoke-virtual {p0, p1, p2}, Lts3;->b(Ljava/lang/Object;Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    return-void
.end method

.method public final f1(Loo3;J)V
    .registers 6

    .line 1
    new-instance v0, Landroid/os/Bundle;

    .line 2
    .line 3
    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 4
    .line 5
    .line 6
    const-string v1, "r"

    .line 7
    .line 8
    invoke-virtual {v0, v1, p2, p3}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    .line 9
    .line 10
    .line 11
    :try_start_a
    invoke-interface {p1, v0}, Loo3;->f(Landroid/os/Bundle;)V
    :try_end_d
    .catch Landroid/os/RemoteException; {:try_start_a .. :try_end_d} :catch_e

    .line 12
    .line 13
    .line 14
    return-void

    .line 15
    :catch_e
    move-exception p1

    .line 16
    iget-object p0, p0, Lov;->a:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast p0, Lzt3;

    .line 19
    .line 20
    iget-object p0, p0, Lzt3;->l:Lqs3;

    .line 21
    .line 22
    invoke-static {p0}, Lzt3;->e(Lwu3;)V

    .line 23
    .line 24
    .line 25
    iget-object p0, p0, Lqs3;->n:Lts3;

    .line 26
    .line 27
    const-string p2, "Error returning long value to wrapper"

    .line 28
    .line 29
    invoke-virtual {p0, p1, p2}, Lts3;->b(Ljava/lang/Object;Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    return-void
.end method

.method public final g1(Loo3;Landroid/os/Bundle;)V
    .registers 3

    .line 1
    :try_start_0
    invoke-interface {p1, p2}, Loo3;->f(Landroid/os/Bundle;)V
    :try_end_3
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_3} :catch_4

    .line 2
    .line 3
    .line 4
    return-void

    .line 5
    :catch_4
    move-exception p1

    .line 6
    iget-object p0, p0, Lov;->a:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast p0, Lzt3;

    .line 9
    .line 10
    iget-object p0, p0, Lzt3;->l:Lqs3;

    .line 11
    .line 12
    invoke-static {p0}, Lzt3;->e(Lwu3;)V

    .line 13
    .line 14
    .line 15
    iget-object p0, p0, Lqs3;->n:Lts3;

    .line 16
    .line 17
    const-string p2, "Error returning bundle value to wrapper"

    .line 18
    .line 19
    invoke-virtual {p0, p1, p2}, Lts3;->b(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    return-void
.end method

.method public final h1(Loo3;Ljava/util/ArrayList;)V
    .registers 5

    .line 1
    new-instance v0, Landroid/os/Bundle;

    .line 2
    .line 3
    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 4
    .line 5
    .line 6
    const-string v1, "r"

    .line 7
    .line 8
    invoke-virtual {v0, v1, p2}, Landroid/os/Bundle;->putParcelableArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    .line 9
    .line 10
    .line 11
    :try_start_a
    invoke-interface {p1, v0}, Loo3;->f(Landroid/os/Bundle;)V
    :try_end_d
    .catch Landroid/os/RemoteException; {:try_start_a .. :try_end_d} :catch_e

    .line 12
    .line 13
    .line 14
    return-void

    .line 15
    :catch_e
    move-exception p1

    .line 16
    iget-object p0, p0, Lov;->a:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast p0, Lzt3;

    .line 19
    .line 20
    iget-object p0, p0, Lzt3;->l:Lqs3;

    .line 21
    .line 22
    invoke-static {p0}, Lzt3;->e(Lwu3;)V

    .line 23
    .line 24
    .line 25
    iget-object p0, p0, Lqs3;->n:Lts3;

    .line 26
    .line 27
    const-string p2, "Error returning bundle list to wrapper"

    .line 28
    .line 29
    invoke-virtual {p0, p1, p2}, Lts3;->b(Ljava/lang/Object;Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    return-void
.end method

.method public final i1(Loo3;Z)V
    .registers 5

    .line 1
    new-instance v0, Landroid/os/Bundle;

    .line 2
    .line 3
    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 4
    .line 5
    .line 6
    const-string v1, "r"

    .line 7
    .line 8
    invoke-virtual {v0, v1, p2}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    .line 9
    .line 10
    .line 11
    :try_start_a
    invoke-interface {p1, v0}, Loo3;->f(Landroid/os/Bundle;)V
    :try_end_d
    .catch Landroid/os/RemoteException; {:try_start_a .. :try_end_d} :catch_e

    .line 12
    .line 13
    .line 14
    return-void

    .line 15
    :catch_e
    move-exception p1

    .line 16
    iget-object p0, p0, Lov;->a:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast p0, Lzt3;

    .line 19
    .line 20
    iget-object p0, p0, Lzt3;->l:Lqs3;

    .line 21
    .line 22
    invoke-static {p0}, Lzt3;->e(Lwu3;)V

    .line 23
    .line 24
    .line 25
    iget-object p0, p0, Lqs3;->n:Lts3;

    .line 26
    .line 27
    const-string p2, "Error returning boolean value to wrapper"

    .line 28
    .line 29
    invoke-virtual {p0, p1, p2}, Lts3;->b(Ljava/lang/Object;Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    return-void
.end method

.method public final j1(Loo3;[B)V
    .registers 5

    .line 1
    new-instance v0, Landroid/os/Bundle;

    .line 2
    .line 3
    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 4
    .line 5
    .line 6
    const-string v1, "r"

    .line 7
    .line 8
    invoke-virtual {v0, v1, p2}, Landroid/os/Bundle;->putByteArray(Ljava/lang/String;[B)V

    .line 9
    .line 10
    .line 11
    :try_start_a
    invoke-interface {p1, v0}, Loo3;->f(Landroid/os/Bundle;)V
    :try_end_d
    .catch Landroid/os/RemoteException; {:try_start_a .. :try_end_d} :catch_e

    .line 12
    .line 13
    .line 14
    return-void

    .line 15
    :catch_e
    move-exception p1

    .line 16
    iget-object p0, p0, Lov;->a:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast p0, Lzt3;

    .line 19
    .line 20
    iget-object p0, p0, Lzt3;->l:Lqs3;

    .line 21
    .line 22
    invoke-static {p0}, Lzt3;->e(Lwu3;)V

    .line 23
    .line 24
    .line 25
    iget-object p0, p0, Lqs3;->n:Lts3;

    .line 26
    .line 27
    const-string p2, "Error returning byte array to wrapper"

    .line 28
    .line 29
    invoke-virtual {p0, p1, p2}, Lts3;->b(Ljava/lang/Object;Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    return-void
.end method

.method public final m1([Landroid/os/Parcelable;I)V
    .registers 15

    .line 1
    iget-object v0, p0, Lov;->a:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lzt3;

    .line 4
    .line 5
    invoke-static {p1}, Lmw1;->k(Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    array-length v1, p1

    .line 9
    const/4 v2, 0x0

    .line 10
    move v3, v2

    .line 11
    :goto_a
    if-ge v3, v1, :cond_65

    .line 12
    .line 13
    aget-object v4, p1, v3

    .line 14
    .line 15
    check-cast v4, Landroid/os/Bundle;

    .line 16
    .line 17
    new-instance v5, Ljava/util/TreeSet;

    .line 18
    .line 19
    invoke-virtual {v4}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    .line 20
    .line 21
    .line 22
    move-result-object v6

    .line 23
    invoke-direct {v5, v6}, Ljava/util/TreeSet;-><init>(Ljava/util/Collection;)V

    .line 24
    .line 25
    .line 26
    invoke-virtual {v5}, Ljava/util/TreeSet;->iterator()Ljava/util/Iterator;

    .line 27
    .line 28
    .line 29
    move-result-object v5

    .line 30
    move v6, v2

    .line 31
    :cond_1e
    :goto_1e
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 32
    .line 33
    .line 34
    move-result v7

    .line 35
    if-eqz v7, :cond_62

    .line 36
    .line 37
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v7

    .line 41
    check-cast v7, Ljava/lang/String;

    .line 42
    .line 43
    invoke-static {v7}, Lb04;->N1(Ljava/lang/String;)Z

    .line 44
    .line 45
    .line 46
    move-result v8

    .line 47
    if-eqz v8, :cond_1e

    .line 48
    .line 49
    sget-object v8, Lyo1;->g:[Ljava/lang/String;

    .line 50
    .line 51
    invoke-static {v7, v8}, Lb04;->v1(Ljava/lang/String;[Ljava/lang/String;)Z

    .line 52
    .line 53
    .line 54
    move-result v8

    .line 55
    if-nez v8, :cond_1e

    .line 56
    .line 57
    add-int/lit8 v6, v6, 0x1

    .line 58
    .line 59
    if-le v6, p2, :cond_1e

    .line 60
    .line 61
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 62
    .line 63
    .line 64
    move-result-object v8

    .line 65
    iget-object v8, v8, Lqs3;->m:Lts3;

    .line 66
    .line 67
    const-string v9, "Param can\'t contain more than "

    .line 68
    .line 69
    const-string v10, " item-scoped custom parameters"

    .line 70
    .line 71
    invoke-static {v9, v10, p2}, Ln10;->h(Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object v9

    .line 75
    iget-object v10, v0, Lzt3;->p:Ljs3;

    .line 76
    .line 77
    invoke-virtual {v10, v7}, Ljs3;->f(Ljava/lang/String;)Ljava/lang/String;

    .line 78
    .line 79
    .line 80
    move-result-object v10

    .line 81
    iget-object v11, v0, Lzt3;->p:Ljs3;

    .line 82
    .line 83
    invoke-virtual {v11, v4}, Ljs3;->a(Landroid/os/Bundle;)Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object v11

    .line 87
    invoke-virtual {v8, v10, v11, v9}, Lts3;->a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    .line 88
    .line 89
    .line 90
    const/16 v8, 0x1c

    .line 91
    .line 92
    invoke-static {v8, v4}, Lb04;->D1(ILandroid/os/Bundle;)Z

    .line 93
    .line 94
    .line 95
    invoke-virtual {v4, v7}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 96
    .line 97
    .line 98
    goto :goto_1e

    .line 99
    :cond_62
    add-int/lit8 v3, v3, 0x1

    .line 100
    .line 101
    goto :goto_a

    .line 102
    :cond_65
    return-void
.end method

.method public final q1(Ljava/lang/String;D)Z
    .registers 7

    .line 1
    const/4 v0, 0x0

    .line 2
    :try_start_1
    iget-object v1, p0, Lov;->a:Ljava/lang/Object;

    .line 3
    .line 4
    check-cast v1, Lzt3;

    .line 5
    .line 6
    iget-object v1, v1, Lzt3;->a:Landroid/content/Context;

    .line 7
    .line 8
    const-string v2, "google.analytics.deferred.deeplink.prefs"

    .line 9
    .line 10
    invoke-virtual {v1, v2, v0}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    const-string v2, "deeplink"

    .line 19
    .line 20
    invoke-interface {v1, v2, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 21
    .line 22
    .line 23
    const-string p1, "timestamp"

    .line 24
    .line 25
    invoke-static {p2, p3}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    .line 26
    .line 27
    .line 28
    move-result-wide p2

    .line 29
    invoke-interface {v1, p1, p2, p3}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    .line 30
    .line 31
    .line 32
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    .line 33
    .line 34
    .line 35
    move-result p0
    :try_end_23
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_23} :catch_24

    .line 36
    return p0

    .line 37
    :catch_24
    move-exception p1

    .line 38
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 39
    .line 40
    .line 41
    move-result-object p0

    .line 42
    iget-object p0, p0, Lqs3;->j:Lts3;

    .line 43
    .line 44
    const-string p2, "Failed to persist Deferred Deep Link. exception"

    .line 45
    .line 46
    invoke-virtual {p0, p1, p2}, Lts3;->b(Ljava/lang/Object;Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    return v0
.end method

.method public final r1(Ljava/lang/String;Ljava/lang/String;)Z
    .registers 7

    .line 1
    iget-object v0, p0, Lov;->a:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lzt3;

    .line 4
    .line 5
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const-string v2, "^(1:\\d+:android:[a-f0-9]+|ca-app-pub-.*)$"

    .line 10
    .line 11
    const/4 v3, 0x0

    .line 12
    if-nez v1, :cond_2e

    .line 13
    .line 14
    invoke-static {p1}, Lmw1;->k(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {p1, v2}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    .line 18
    .line 19
    .line 20
    move-result p2

    .line 21
    if-nez p2, :cond_4d

    .line 22
    .line 23
    iget-object p2, v0, Lzt3;->b:Ljava/lang/String;

    .line 24
    .line 25
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 26
    .line 27
    .line 28
    move-result p2

    .line 29
    if-eqz p2, :cond_62

    .line 30
    .line 31
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 32
    .line 33
    .line 34
    move-result-object p0

    .line 35
    iget-object p0, p0, Lqs3;->m:Lts3;

    .line 36
    .line 37
    const-string p2, "Invalid google_app_id. Firebase Analytics disabled. See https://goo.gl/NAOOOI. provided id"

    .line 38
    .line 39
    invoke-static {p1}, Lqs3;->N0(Ljava/lang/String;)Lrs3;

    .line 40
    .line 41
    .line 42
    move-result-object p1

    .line 43
    invoke-virtual {p0, p1, p2}, Lts3;->b(Ljava/lang/Object;Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    return v3

    .line 47
    :cond_2e
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 48
    .line 49
    .line 50
    move-result p1

    .line 51
    if-nez p1, :cond_4f

    .line 52
    .line 53
    invoke-static {p2}, Lmw1;->k(Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    invoke-virtual {p2, v2}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    .line 57
    .line 58
    .line 59
    move-result p1

    .line 60
    if-nez p1, :cond_4d

    .line 61
    .line 62
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 63
    .line 64
    .line 65
    move-result-object p0

    .line 66
    iget-object p0, p0, Lqs3;->m:Lts3;

    .line 67
    .line 68
    const-string p1, "Invalid admob_app_id. Analytics disabled."

    .line 69
    .line 70
    invoke-static {p2}, Lqs3;->N0(Ljava/lang/String;)Lrs3;

    .line 71
    .line 72
    .line 73
    move-result-object p2

    .line 74
    invoke-virtual {p0, p2, p1}, Lts3;->b(Ljava/lang/Object;Ljava/lang/String;)V

    .line 75
    .line 76
    .line 77
    return v3

    .line 78
    :cond_4d
    const/4 p0, 0x1

    .line 79
    return p0

    .line 80
    :cond_4f
    iget-object p1, v0, Lzt3;->b:Ljava/lang/String;

    .line 81
    .line 82
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 83
    .line 84
    .line 85
    move-result p1

    .line 86
    if-eqz p1, :cond_62

    .line 87
    .line 88
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 89
    .line 90
    .line 91
    move-result-object p0

    .line 92
    iget-object p0, p0, Lqs3;->m:Lts3;

    .line 93
    .line 94
    const-string p1, "Missing google_app_id. Firebase Analytics disabled. See https://goo.gl/NAOOOI"

    .line 95
    .line 96
    invoke-virtual {p0, p1}, Lts3;->c(Ljava/lang/String;)V

    .line 97
    .line 98
    .line 99
    :cond_62
    return v3
.end method

.method public final s1(Ljava/lang/String;Ljava/lang/String;I)Z
    .registers 6

    .line 1
    const/4 v0, 0x0

    .line 2
    if-nez p2, :cond_f

    .line 3
    .line 4
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    iget-object p0, p0, Lqs3;->m:Lts3;

    .line 9
    .line 10
    const-string p2, "Name is required and can\'t be null. Type"

    .line 11
    .line 12
    invoke-virtual {p0, p1, p2}, Lts3;->b(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    return v0

    .line 16
    :cond_f
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    invoke-virtual {p2, v0, v1}, Ljava/lang/String;->codePointCount(II)I

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    if-le v1, p3, :cond_29

    .line 25
    .line 26
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    iget-object p0, p0, Lqs3;->m:Lts3;

    .line 31
    .line 32
    const-string v1, "Name is too long. Type, maximum supported length, name"

    .line 33
    .line 34
    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 35
    .line 36
    .line 37
    move-result-object p3

    .line 38
    invoke-virtual {p0, v1, p1, p3, p2}, Lts3;->d(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    return v0

    .line 42
    :cond_29
    const/4 p0, 0x1

    .line 43
    return p0
.end method

.method public final t1(Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Z
    .registers 7

    .line 1
    if-nez p4, :cond_3

    .line 2
    .line 3
    goto :goto_51

    .line 4
    :cond_3
    instance-of v0, p4, Ljava/lang/Long;

    .line 5
    .line 6
    if-nez v0, :cond_51

    .line 7
    .line 8
    instance-of v0, p4, Ljava/lang/Float;

    .line 9
    .line 10
    if-nez v0, :cond_51

    .line 11
    .line 12
    instance-of v0, p4, Ljava/lang/Integer;

    .line 13
    .line 14
    if-nez v0, :cond_51

    .line 15
    .line 16
    instance-of v0, p4, Ljava/lang/Byte;

    .line 17
    .line 18
    if-nez v0, :cond_51

    .line 19
    .line 20
    instance-of v0, p4, Ljava/lang/Short;

    .line 21
    .line 22
    if-nez v0, :cond_51

    .line 23
    .line 24
    instance-of v0, p4, Ljava/lang/Boolean;

    .line 25
    .line 26
    if-nez v0, :cond_51

    .line 27
    .line 28
    instance-of v0, p4, Ljava/lang/Double;

    .line 29
    .line 30
    if-eqz v0, :cond_20

    .line 31
    .line 32
    goto :goto_51

    .line 33
    :cond_20
    instance-of v0, p4, Ljava/lang/String;

    .line 34
    .line 35
    const/4 v1, 0x0

    .line 36
    if-nez v0, :cond_2f

    .line 37
    .line 38
    instance-of v0, p4, Ljava/lang/Character;

    .line 39
    .line 40
    if-nez v0, :cond_2f

    .line 41
    .line 42
    instance-of v0, p4, Ljava/lang/CharSequence;

    .line 43
    .line 44
    if-eqz v0, :cond_2e

    .line 45
    .line 46
    goto :goto_2f

    .line 47
    :cond_2e
    return v1

    .line 48
    :cond_2f
    :goto_2f
    invoke-static {p4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object p4

    .line 52
    invoke-virtual {p4}, Ljava/lang/String;->length()I

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    invoke-virtual {p4, v1, v0}, Ljava/lang/String;->codePointCount(II)I

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    if-le v0, p3, :cond_51

    .line 61
    .line 62
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 63
    .line 64
    .line 65
    move-result-object p0

    .line 66
    iget-object p0, p0, Lqs3;->p:Lts3;

    .line 67
    .line 68
    invoke-virtual {p4}, Ljava/lang/String;->length()I

    .line 69
    .line 70
    .line 71
    move-result p3

    .line 72
    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 73
    .line 74
    .line 75
    move-result-object p3

    .line 76
    const-string p4, "Value is too long; discarded. Value kind, name, value length"

    .line 77
    .line 78
    invoke-virtual {p0, p4, p1, p2, p3}, Lts3;->d(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 79
    .line 80
    .line 81
    return v1

    .line 82
    :cond_51
    :goto_51
    const/4 p0, 0x1

    .line 83
    return p0
.end method

.method public final w1(Ljava/lang/String;[Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Z
    .registers 8

    .line 1
    const/4 v0, 0x0

    .line 2
    if-nez p4, :cond_f

    .line 3
    .line 4
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    iget-object p0, p0, Lqs3;->m:Lts3;

    .line 9
    .line 10
    const-string p2, "Name is required and can\'t be null. Type"

    .line 11
    .line 12
    invoke-virtual {p0, p1, p2}, Lts3;->b(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    return v0

    .line 16
    :cond_f
    move v1, v0

    .line 17
    :goto_10
    const/4 v2, 0x3

    .line 18
    if-ge v1, v2, :cond_2c

    .line 19
    .line 20
    sget-object v2, Lb04;->n:[Ljava/lang/String;

    .line 21
    .line 22
    aget-object v2, v2, v1

    .line 23
    .line 24
    invoke-virtual {p4, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 25
    .line 26
    .line 27
    move-result v2

    .line 28
    if-eqz v2, :cond_29

    .line 29
    .line 30
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 31
    .line 32
    .line 33
    move-result-object p0

    .line 34
    iget-object p0, p0, Lqs3;->m:Lts3;

    .line 35
    .line 36
    const-string p2, "Name starts with reserved prefix. Type, name"

    .line 37
    .line 38
    invoke-virtual {p0, p1, p4, p2}, Lts3;->a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    return v0

    .line 42
    :cond_29
    add-int/lit8 v1, v1, 0x1

    .line 43
    .line 44
    goto :goto_10

    .line 45
    :cond_2c
    if-eqz p2, :cond_48

    .line 46
    .line 47
    invoke-static {p4, p2}, Lb04;->v1(Ljava/lang/String;[Ljava/lang/String;)Z

    .line 48
    .line 49
    .line 50
    move-result p2

    .line 51
    if-eqz p2, :cond_48

    .line 52
    .line 53
    if-eqz p3, :cond_3c

    .line 54
    .line 55
    invoke-static {p4, p3}, Lb04;->v1(Ljava/lang/String;[Ljava/lang/String;)Z

    .line 56
    .line 57
    .line 58
    move-result p2

    .line 59
    if-nez p2, :cond_48

    .line 60
    .line 61
    :cond_3c
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 62
    .line 63
    .line 64
    move-result-object p0

    .line 65
    iget-object p0, p0, Lqs3;->m:Lts3;

    .line 66
    .line 67
    const-string p2, "Name is reserved. Type, name"

    .line 68
    .line 69
    invoke-virtual {p0, p1, p4, p2}, Lts3;->a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    return v0

    .line 73
    :cond_48
    const/4 p0, 0x1

    .line 74
    return p0
.end method

.method public final y1(I)Z
    .registers 3

    .line 1
    iget-object v0, p0, Lov;->a:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lzt3;

    .line 4
    .line 5
    invoke-virtual {v0}, Lzt3;->o()Lbx3;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iget-object v0, v0, Lbx3;->g:Ljava/lang/Boolean;

    .line 10
    .line 11
    invoke-virtual {p0}, Lb04;->L1()I

    .line 12
    .line 13
    .line 14
    move-result p0

    .line 15
    div-int/lit16 p1, p1, 0x3e8

    .line 16
    .line 17
    if-ge p0, p1, :cond_1d

    .line 18
    .line 19
    if-eqz v0, :cond_1b

    .line 20
    .line 21
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 22
    .line 23
    .line 24
    move-result p0

    .line 25
    if-nez p0, :cond_1b

    .line 26
    .line 27
    goto :goto_1d

    .line 28
    :cond_1b
    const/4 p0, 0x0

    .line 29
    return p0

    .line 30
    :cond_1d
    :goto_1d
    const/4 p0, 0x1

    .line 31
    return p0
.end method
