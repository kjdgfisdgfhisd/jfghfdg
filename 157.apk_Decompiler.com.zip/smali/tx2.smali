###### Class defpackage.tx2 (tx2)
.class public final Ltx2;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final a:Lr10;

.field public final b:[Ljava/lang/Object;

.field public final c:[Lpx2;

.field public d:I


# direct methods
.method public constructor <init>(ILr10;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, Ltx2;->a:Lr10;

    .line 5
    .line 6
    new-array p2, p1, [Ljava/lang/Object;

    .line 7
    .line 8
    iput-object p2, p0, Ltx2;->b:[Ljava/lang/Object;

    .line 9
    .line 10
    new-array p1, p1, [Lpx2;

    .line 11
    .line 12
    iput-object p1, p0, Ltx2;->c:[Lpx2;

    .line 13
    .line 14
    return-void
.end method
