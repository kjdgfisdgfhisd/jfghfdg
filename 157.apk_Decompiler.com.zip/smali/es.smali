###### Class defpackage.es (es)
.class public final synthetic Les;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 1
    iput p1, p0, Les;->a:I

    .line 2
    .line 3
    iput-object p2, p0, Les;->b:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .registers 4

    .line 1
    iget v0, p0, Les;->a:I

    .line 2
    .line 3
    iget-object p0, p0, Les;->b:Ljava/lang/Object;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_20

    .line 6
    .line 7
    .line 8
    check-cast p0, Lcc/bomber/x/a/f;

    .line 9
    .line 10
    invoke-static {p0, p1, p2}, Lcc/bomber/x/l/g;->t(Lcc/bomber/x/a/f;Landroid/widget/CompoundButton;Z)V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :pswitch_d
    check-cast p0, Lcc/bomber/x/l/c;

    .line 15
    .line 16
    invoke-static {p0, p1, p2}, Lcc/bomber/x/l/c;->y(Lcc/bomber/x/l/c;Landroid/widget/CompoundButton;Z)V

    .line 17
    .line 18
    .line 19
    return-void

    .line 20
    :pswitch_13
    check-cast p0, Lcom/google/android/material/chip/Chip;

    .line 21
    .line 22
    sget-object v0, Lcom/google/android/material/chip/Chip;->z:Landroid/graphics/Rect;

    .line 23
    .line 24
    iget-object p0, p0, Lcom/google/android/material/chip/Chip;->l:Landroid/widget/CompoundButton$OnCheckedChangeListener;

    .line 25
    .line 26
    if-eqz p0, :cond_1e

    .line 27
    .line 28
    invoke-interface {p0, p1, p2}, Landroid/widget/CompoundButton$OnCheckedChangeListener;->onCheckedChanged(Landroid/widget/CompoundButton;Z)V

    .line 29
    .line 30
    .line 31
    :cond_1e
    return-void

    .line 32
    nop

    .line 33
    :pswitch_data_20
    .packed-switch 0x0
        :pswitch_13
        :pswitch_d
    .end packed-switch
.end method
