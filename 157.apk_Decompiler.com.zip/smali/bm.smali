###### Class defpackage.bm (bm)
.class public final Lbm;
.super Ly00;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public synthetic j:Ljava/lang/Object;

.field public final synthetic l:Ldm;

.field public m:I


# direct methods
.method public constructor <init>(Ldm;Ly00;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lbm;->l:Ldm;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Ly00;-><init>(Lw00;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    iput-object p1, p0, Lbm;->j:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lbm;->m:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lbm;->m:I

    .line 9
    .line 10
    iget-object p1, p0, Lbm;->l:Ldm;

    .line 11
    .line 12
    invoke-static {p1, p0}, Ldm;->D(Ldm;Ly00;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    sget-object p1, Lb20;->a:Lb20;

    .line 17
    .line 18
    if-ne p0, p1, :cond_14

    .line 19
    .line 20
    return-object p0

    .line 21
    :cond_14
    new-instance p1, Llr;

    .line 22
    .line 23
    invoke-direct {p1, p0}, Llr;-><init>(Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    return-object p1
.end method
