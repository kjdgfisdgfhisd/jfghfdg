###### Class defpackage.rv (rv)
.class public final Lrv;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final a:I

.field public final b:Ljava/lang/String;


# direct methods
.method public constructor <init>(ILjava/lang/String;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput p1, p0, Lrv;->a:I

    .line 5
    .line 6
    iput-object p2, p0, Lrv;->b:Ljava/lang/String;

    .line 7
    .line 8
    return-void
.end method
