###### Class defpackage.is3 (is3)
.class public final Lis3;
.super Let3;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public e:Ljava/lang/String;

.field public f:Ljava/lang/String;

.field public g:I

.field public j:Ljava/lang/String;

.field public l:J

.field public m:J

.field public n:Ljava/util/List;

.field public o:Ljava/lang/String;

.field public p:I

.field public q:Ljava/lang/String;

.field public r:Ljava/lang/String;

.field public s:Ljava/lang/String;

.field public t:J

.field public u:Ljava/lang/String;


# virtual methods
.method public final N0()Z
    .registers 1

    .line 1
    const/4 p0, 0x1

    .line 2
    return p0
.end method

.method public final O0()Ljava/lang/String;
    .registers 2

    .line 1
    invoke-virtual {p0}, Let3;->L0()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lis3;->e:Ljava/lang/String;

    .line 5
    .line 6
    invoke-static {v0}, Lmw1;->k(Ljava/lang/Object;)V

    .line 7
    .line 8
    .line 9
    iget-object p0, p0, Lis3;->e:Ljava/lang/String;

    .line 10
    .line 11
    return-object p0
.end method

.method public final P0()Ljava/lang/String;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lgp3;->H0()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Let3;->L0()V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lis3;->q:Ljava/lang/String;

    .line 8
    .line 9
    invoke-static {v0}, Lmw1;->k(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    iget-object p0, p0, Lis3;->q:Ljava/lang/String;

    .line 13
    .line 14
    return-object p0
.end method

.method public final Q0()V
    .registers 5

    .line 1
    invoke-virtual {p0}, Lgp3;->H0()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lov;->F0()Lgt3;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-virtual {v0}, Lgt3;->R0()Lyu3;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    sget-object v1, Lxu3;->c:Lxu3;

    .line 13
    .line 14
    invoke-virtual {v0, v1}, Lyu3;->i(Lxu3;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-nez v0, :cond_20

    .line 19
    .line 20
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    iget-object v0, v0, Lqs3;->r:Lts3;

    .line 25
    .line 26
    const-string v1, "Analytics Storage consent is not granted"

    .line 27
    .line 28
    invoke-virtual {v0, v1}, Lts3;->c(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    const/4 v0, 0x0

    .line 32
    goto :goto_41

    .line 33
    :cond_20
    const/16 v0, 0x10

    .line 34
    .line 35
    new-array v0, v0, [B

    .line 36
    .line 37
    invoke-virtual {p0}, Lov;->G0()Lb04;

    .line 38
    .line 39
    .line 40
    move-result-object v1

    .line 41
    invoke-virtual {v1}, Lb04;->V1()Ljava/security/SecureRandom;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    invoke-virtual {v1, v0}, Ljava/security/SecureRandom;->nextBytes([B)V

    .line 46
    .line 47
    .line 48
    sget-object v1, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 49
    .line 50
    new-instance v2, Ljava/math/BigInteger;

    .line 51
    .line 52
    const/4 v3, 0x1

    .line 53
    invoke-direct {v2, v3, v0}, Ljava/math/BigInteger;-><init>(I[B)V

    .line 54
    .line 55
    .line 56
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    const-string v2, "%032x"

    .line 61
    .line 62
    invoke-static {v1, v2, v0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    :goto_41
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 67
    .line 68
    .line 69
    move-result-object v1

    .line 70
    iget-object v1, v1, Lqs3;->r:Lts3;

    .line 71
    .line 72
    if-nez v0, :cond_4c

    .line 73
    .line 74
    const-string v2, "null"

    .line 75
    .line 76
    goto :goto_4e

    .line 77
    :cond_4c
    const-string v2, "not null"

    .line 78
    .line 79
    :goto_4e
    const-string v3, "Resetting session stitching token to "

    .line 80
    .line 81
    invoke-virtual {v3, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 82
    .line 83
    .line 84
    move-result-object v2

    .line 85
    invoke-virtual {v1, v2}, Lts3;->c(Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    iput-object v0, p0, Lis3;->s:Ljava/lang/String;

    .line 89
    .line 90
    iget-object v0, p0, Lov;->a:Ljava/lang/Object;

    .line 91
    .line 92
    check-cast v0, Lzt3;

    .line 93
    .line 94
    iget-object v0, v0, Lzt3;->q:Lwn0;

    .line 95
    .line 96
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 97
    .line 98
    .line 99
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 100
    .line 101
    .line 102
    move-result-wide v0

    .line 103
    iput-wide v0, p0, Lis3;->t:J

    .line 104
    .line 105
    return-void
.end method
