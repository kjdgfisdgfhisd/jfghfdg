###### Class defpackage.r60 (r60)
.class public interface abstract Lr60;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lm60;


# virtual methods
.method public abstract g()Lya0;
.end method
