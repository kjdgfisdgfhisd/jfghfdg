###### Class defpackage.zf1 (zf1)
.class public interface abstract Lzf1;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# virtual methods
.method public abstract i()V
.end method

.method public abstract j(Ldv1;Lkt;)V
.end method

.method public abstract k(Ldv1;)Lag1;
.end method

.method public abstract l(Ldv1;Lft;Ldv1;)V
.end method

.method public abstract m(Ldv1;Ljava/lang/Object;)V
.end method

.method public abstract o(Lft;Ldv1;)Lzf1;
.end method
