###### Class defpackage.wd1 (wd1)
.class public interface abstract Lwd1;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lse1;
.implements Lbe1;


# virtual methods
.method public abstract f()Lxd1;
.end method
