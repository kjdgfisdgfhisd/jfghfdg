###### Class defpackage.ia3 (ia3)
.class public final Lia3;
.super Lua3;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field public static final c:Lia3;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    new-instance v0, Lia3;

    .line 2
    .line 3
    const-string v1, "internal"

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-direct {v0, v1, v2}, Lua3;-><init>(Ljava/lang/String;Z)V

    .line 7
    .line 8
    .line 9
    sput-object v0, Lia3;->c:Lia3;

    .line 10
    .line 11
    return-void
.end method
