###### Class defpackage.zv0 (zv0)
.class public final Lzv0;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Llw2;


# instance fields
.field public a:Lxe2;

.field public final b:Landroid/os/Handler;

.field public final c:I

.field public final d:J

.field public e:Landroid/graphics/Bitmap;


# direct methods
.method public constructor <init>(Landroid/os/Handler;IJ)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/high16 v0, -0x80000000

    .line 5
    .line 6
    invoke-static {v0, v0}, Lk63;->u(II)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-eqz v0, :cond_12

    .line 11
    .line 12
    iput-object p1, p0, Lzv0;->b:Landroid/os/Handler;

    .line 13
    .line 14
    iput p2, p0, Lzv0;->c:I

    .line 15
    .line 16
    iput-wide p3, p0, Lzv0;->d:J

    .line 17
    .line 18
    return-void

    .line 19
    :cond_12
    const-string p0, "Width and height must both be > 0 or Target#SIZE_ORIGINAL, but given width: -2147483648 and height: -2147483648"

    .line 20
    .line 21
    invoke-static {p0}, Lm03;->g(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    const/4 p0, 0x0

    .line 25
    throw p0
.end method


# virtual methods
.method public final a(Landroid/graphics/drawable/Drawable;)V
    .registers 2

    .line 1
    return-void
.end method

.method public final b()V
    .registers 1

    .line 1
    return-void
.end method

.method public final c(Ljp2;)V
    .registers 2

    .line 1
    return-void
.end method

.method public final d(Ljava/lang/Object;Lvz2;)V
    .registers 5

    .line 1
    check-cast p1, Landroid/graphics/Bitmap;

    .line 2
    .line 3
    iput-object p1, p0, Lzv0;->e:Landroid/graphics/Bitmap;

    .line 4
    .line 5
    const/4 p1, 0x1

    .line 6
    iget-object p2, p0, Lzv0;->b:Landroid/os/Handler;

    .line 7
    .line 8
    invoke-virtual {p2, p1, p0}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    iget-wide v0, p0, Lzv0;->d:J

    .line 13
    .line 14
    invoke-virtual {p2, p1, v0, v1}, Landroid/os/Handler;->sendMessageAtTime(Landroid/os/Message;J)Z

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method public final e(Ljp2;)V
    .registers 2

    .line 1
    const/high16 p0, -0x80000000

    .line 2
    .line 3
    invoke-virtual {p1, p0, p0}, Ljp2;->m(II)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final f(Lxe2;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lzv0;->a:Lxe2;

    .line 2
    .line 3
    return-void
.end method

.method public final g(Landroid/graphics/drawable/Drawable;)V
    .registers 2

    .line 1
    return-void
.end method

.method public final h()Lxe2;
    .registers 1

    .line 1
    iget-object p0, p0, Lzv0;->a:Lxe2;

    .line 2
    .line 3
    return-object p0
.end method

.method public final i(Landroid/graphics/drawable/Drawable;)V
    .registers 2

    .line 1
    const/4 p1, 0x0

    .line 2
    iput-object p1, p0, Lzv0;->e:Landroid/graphics/Bitmap;

    .line 3
    .line 4
    return-void
.end method

.method public final j()V
    .registers 1

    .line 1
    return-void
.end method

.method public final k()V
    .registers 1

    .line 1
    return-void
.end method
