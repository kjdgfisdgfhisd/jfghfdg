###### Class defpackage.yu2 (yu2)
.class public final Lyu2;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public A:Ljava/lang/CharSequence;

.field public B:Ljava/lang/CharSequence;

.field public C:Landroid/content/res/ColorStateList;

.field public D:Landroid/graphics/PorterDuff$Mode;

.field public final synthetic E:Lzu2;

.field public final a:Landroid/view/Menu;

.field public b:I

.field public c:I

.field public d:I

.field public e:I

.field public f:Z

.field public g:Z

.field public h:Z

.field public i:I

.field public j:I

.field public k:Ljava/lang/CharSequence;

.field public l:Ljava/lang/CharSequence;

.field public m:I

.field public n:C

.field public o:I

.field public p:C

.field public q:I

.field public r:I

.field public s:Z

.field public t:Z

.field public u:Z

.field public v:I

.field public w:I

.field public x:Ljava/lang/String;

.field public y:Ljava/lang/String;

.field public z:Lls1;


# direct methods
.method public constructor <init>(Lzu2;Landroid/view/Menu;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lyu2;->E:Lzu2;

    .line 5
    .line 6
    const/4 p1, 0x0

    .line 7
    iput-object p1, p0, Lyu2;->C:Landroid/content/res/ColorStateList;

    .line 8
    .line 9
    iput-object p1, p0, Lyu2;->D:Landroid/graphics/PorterDuff$Mode;

    .line 10
    .line 11
    iput-object p2, p0, Lyu2;->a:Landroid/view/Menu;

    .line 12
    .line 13
    const/4 p1, 0x0

    .line 14
    iput p1, p0, Lyu2;->b:I

    .line 15
    .line 16
    iput p1, p0, Lyu2;->c:I

    .line 17
    .line 18
    iput p1, p0, Lyu2;->d:I

    .line 19
    .line 20
    iput p1, p0, Lyu2;->e:I

    .line 21
    .line 22
    const/4 p1, 0x1

    .line 23
    iput-boolean p1, p0, Lyu2;->f:Z

    .line 24
    .line 25
    iput-boolean p1, p0, Lyu2;->g:Z

    .line 26
    .line 27
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 1
    :try_start_0
    iget-object p0, p0, Lyu2;->E:Lzu2;

    .line 2
    .line 3
    iget-object p0, p0, Lzu2;->c:Landroid/content/Context;

    .line 4
    .line 5
    invoke-virtual {p0}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    const/4 v0, 0x0

    .line 10
    invoke-static {p1, v0, p0}, Ljava/lang/Class;->forName(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    invoke-virtual {p0, p2}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    const/4 p2, 0x1

    .line 19
    invoke-virtual {p0, p2}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {p0, p3}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object p0
    :try_end_19
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_19} :catch_1a

    .line 26
    return-object p0

    .line 27
    :catch_1a
    move-exception p0

    .line 28
    new-instance p2, Ljava/lang/StringBuilder;

    .line 29
    .line 30
    const-string p3, "Cannot instantiate class: "

    .line 31
    .line 32
    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 36
    .line 37
    .line 38
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    const-string p2, "SupportMenuInflater"

    .line 43
    .line 44
    invoke-static {p2, p1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 45
    .line 46
    .line 47
    const/4 p0, 0x0

    .line 48
    return-object p0
.end method

.method public final b(Landroid/view/MenuItem;)V
    .registers 10

    .line 1
    iget-object v0, p0, Lyu2;->E:Lzu2;

    .line 2
    .line 3
    iget-object v1, v0, Lzu2;->c:Landroid/content/Context;

    .line 4
    .line 5
    iget-boolean v2, p0, Lyu2;->s:Z

    .line 6
    .line 7
    invoke-interface {p1, v2}, Landroid/view/MenuItem;->setChecked(Z)Landroid/view/MenuItem;

    .line 8
    .line 9
    .line 10
    move-result-object v2

    .line 11
    iget-boolean v3, p0, Lyu2;->t:Z

    .line 12
    .line 13
    invoke-interface {v2, v3}, Landroid/view/MenuItem;->setVisible(Z)Landroid/view/MenuItem;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    iget-boolean v3, p0, Lyu2;->u:Z

    .line 18
    .line 19
    invoke-interface {v2, v3}, Landroid/view/MenuItem;->setEnabled(Z)Landroid/view/MenuItem;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    iget v3, p0, Lyu2;->r:I

    .line 24
    .line 25
    const/4 v4, 0x0

    .line 26
    const/4 v5, 0x1

    .line 27
    if-lt v3, v5, :cond_1e

    .line 28
    .line 29
    move v3, v5

    .line 30
    goto :goto_1f

    .line 31
    :cond_1e
    move v3, v4

    .line 32
    :goto_1f
    invoke-interface {v2, v3}, Landroid/view/MenuItem;->setCheckable(Z)Landroid/view/MenuItem;

    .line 33
    .line 34
    .line 35
    move-result-object v2

    .line 36
    iget-object v3, p0, Lyu2;->l:Ljava/lang/CharSequence;

    .line 37
    .line 38
    invoke-interface {v2, v3}, Landroid/view/MenuItem;->setTitleCondensed(Ljava/lang/CharSequence;)Landroid/view/MenuItem;

    .line 39
    .line 40
    .line 41
    move-result-object v2

    .line 42
    iget v3, p0, Lyu2;->m:I

    .line 43
    .line 44
    invoke-interface {v2, v3}, Landroid/view/MenuItem;->setIcon(I)Landroid/view/MenuItem;

    .line 45
    .line 46
    .line 47
    iget v2, p0, Lyu2;->v:I

    .line 48
    .line 49
    if-ltz v2, :cond_35

    .line 50
    .line 51
    invoke-interface {p1, v2}, Landroid/view/MenuItem;->setShowAsAction(I)V

    .line 52
    .line 53
    .line 54
    :cond_35
    iget-object v2, p0, Lyu2;->y:Ljava/lang/String;

    .line 55
    .line 56
    if-eqz v2, :cond_8c

    .line 57
    .line 58
    invoke-virtual {v1}, Landroid/content/Context;->isRestricted()Z

    .line 59
    .line 60
    .line 61
    move-result v2

    .line 62
    if-nez v2, :cond_86

    .line 63
    .line 64
    new-instance v2, Lxu2;

    .line 65
    .line 66
    iget-object v3, v0, Lzu2;->d:Ljava/lang/Object;

    .line 67
    .line 68
    if-nez v3, :cond_4b

    .line 69
    .line 70
    invoke-static {v1}, Lzu2;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object v3

    .line 74
    iput-object v3, v0, Lzu2;->d:Ljava/lang/Object;

    .line 75
    .line 76
    :cond_4b
    iget-object v1, p0, Lyu2;->y:Ljava/lang/String;

    .line 77
    .line 78
    invoke-direct {v2}, Lxu2;-><init>()V

    .line 79
    .line 80
    .line 81
    iput-object v3, v2, Lxu2;->b:Ljava/lang/Object;

    .line 82
    .line 83
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 84
    .line 85
    .line 86
    move-result-object v3

    .line 87
    :try_start_56
    sget-object v6, Lxu2;->d:[Ljava/lang/Class;

    .line 88
    .line 89
    invoke-virtual {v3, v1, v6}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 90
    .line 91
    .line 92
    move-result-object v6

    .line 93
    iput-object v6, v2, Lxu2;->c:Ljava/lang/Object;
    :try_end_5e
    .catch Ljava/lang/Exception; {:try_start_56 .. :try_end_5e} :catch_62

    .line 94
    .line 95
    invoke-interface {p1, v2}, Landroid/view/MenuItem;->setOnMenuItemClickListener(Landroid/view/MenuItem$OnMenuItemClickListener;)Landroid/view/MenuItem;

    .line 96
    .line 97
    .line 98
    goto :goto_8c

    .line 99
    :catch_62
    move-exception p0

    .line 100
    new-instance p1, Landroid/view/InflateException;

    .line 101
    .line 102
    new-instance v0, Ljava/lang/StringBuilder;

    .line 103
    .line 104
    const-string v2, "Couldn\'t resolve menu item onClick handler "

    .line 105
    .line 106
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 107
    .line 108
    .line 109
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 110
    .line 111
    .line 112
    const-string v1, " in class "

    .line 113
    .line 114
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 115
    .line 116
    .line 117
    invoke-virtual {v3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 118
    .line 119
    .line 120
    move-result-object v1

    .line 121
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 122
    .line 123
    .line 124
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 125
    .line 126
    .line 127
    move-result-object v0

    .line 128
    invoke-direct {p1, v0}, Landroid/view/InflateException;-><init>(Ljava/lang/String;)V

    .line 129
    .line 130
    .line 131
    invoke-virtual {p1, p0}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    .line 132
    .line 133
    .line 134
    throw p1

    .line 135
    :cond_86
    const-string p0, "The android:onClick attribute cannot be used within a restricted context"

    .line 136
    .line 137
    invoke-static {p0}, Ly0;->h(Ljava/lang/String;)V

    .line 138
    .line 139
    .line 140
    return-void

    .line 141
    :cond_8c
    :goto_8c
    iget v1, p0, Lyu2;->r:I

    .line 142
    .line 143
    const/4 v2, 0x2

    .line 144
    if-lt v1, v2, :cond_d4

    .line 145
    .line 146
    instance-of v1, p1, Lks1;

    .line 147
    .line 148
    if-eqz v1, :cond_a1

    .line 149
    .line 150
    move-object v1, p1

    .line 151
    check-cast v1, Lks1;

    .line 152
    .line 153
    iget v2, v1, Lks1;->A:I

    .line 154
    .line 155
    and-int/lit8 v2, v2, -0x5

    .line 156
    .line 157
    or-int/lit8 v2, v2, 0x4

    .line 158
    .line 159
    iput v2, v1, Lks1;->A:I

    .line 160
    .line 161
    goto :goto_d4

    .line 162
    :cond_a1
    instance-of v1, p1, Los1;

    .line 163
    .line 164
    if-eqz v1, :cond_d4

    .line 165
    .line 166
    move-object v1, p1

    .line 167
    check-cast v1, Los1;

    .line 168
    .line 169
    iget-object v2, v1, Los1;->c:Lav2;

    .line 170
    .line 171
    :try_start_aa
    iget-object v3, v1, Los1;->d:Ljava/lang/reflect/Method;

    .line 172
    .line 173
    if-nez v3, :cond_c3

    .line 174
    .line 175
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 176
    .line 177
    .line 178
    move-result-object v3

    .line 179
    const-string v6, "setExclusiveCheckable"

    .line 180
    .line 181
    sget-object v7, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    .line 182
    .line 183
    filled-new-array {v7}, [Ljava/lang/Class;

    .line 184
    .line 185
    .line 186
    move-result-object v7

    .line 187
    invoke-virtual {v3, v6, v7}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 188
    .line 189
    .line 190
    move-result-object v3

    .line 191
    iput-object v3, v1, Los1;->d:Ljava/lang/reflect/Method;

    .line 192
    .line 193
    goto :goto_c3

    .line 194
    :catch_c1
    move-exception v1

    .line 195
    goto :goto_cd

    .line 196
    :cond_c3
    :goto_c3
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 197
    .line 198
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 199
    .line 200
    .line 201
    move-result-object v1

    .line 202
    invoke-virtual {v3, v2, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_cc
    .catch Ljava/lang/Exception; {:try_start_aa .. :try_end_cc} :catch_c1

    .line 203
    .line 204
    .line 205
    goto :goto_d4

    .line 206
    :goto_cd
    const-string v2, "MenuItemWrapper"

    .line 207
    .line 208
    const-string v3, "Error while calling setExclusiveCheckable"

    .line 209
    .line 210
    invoke-static {v2, v3, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 211
    .line 212
    .line 213
    :cond_d4
    :goto_d4
    iget-object v1, p0, Lyu2;->x:Ljava/lang/String;

    .line 214
    .line 215
    if-eqz v1, :cond_e6

    .line 216
    .line 217
    sget-object v2, Lzu2;->e:[Ljava/lang/Class;

    .line 218
    .line 219
    iget-object v0, v0, Lzu2;->a:[Ljava/lang/Object;

    .line 220
    .line 221
    invoke-virtual {p0, v1, v2, v0}, Lyu2;->a(Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 222
    .line 223
    .line 224
    move-result-object v0

    .line 225
    check-cast v0, Landroid/view/View;

    .line 226
    .line 227
    invoke-interface {p1, v0}, Landroid/view/MenuItem;->setActionView(Landroid/view/View;)Landroid/view/MenuItem;

    .line 228
    .line 229
    .line 230
    move v4, v5

    .line 231
    :cond_e6
    iget v0, p0, Lyu2;->w:I

    .line 232
    .line 233
    if-lez v0, :cond_f7

    .line 234
    .line 235
    if-nez v4, :cond_f0

    .line 236
    .line 237
    invoke-interface {p1, v0}, Landroid/view/MenuItem;->setActionView(I)Landroid/view/MenuItem;

    .line 238
    .line 239
    .line 240
    goto :goto_f7

    .line 241
    :cond_f0
    const-string v0, "SupportMenuInflater"

    .line 242
    .line 243
    const-string v1, "Ignoring attribute \'itemActionViewLayout\'. Action view already specified."

    .line 244
    .line 245
    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 246
    .line 247
    .line 248
    :cond_f7
    :goto_f7
    iget-object v0, p0, Lyu2;->z:Lls1;

    .line 249
    .line 250
    if-eqz v0, :cond_10d

    .line 251
    .line 252
    instance-of v1, p1, Lav2;

    .line 253
    .line 254
    if-eqz v1, :cond_106

    .line 255
    .line 256
    move-object v1, p1

    .line 257
    check-cast v1, Lav2;

    .line 258
    .line 259
    invoke-interface {v1, v0}, Lav2;->a(Lls1;)Lav2;

    .line 260
    .line 261
    .line 262
    goto :goto_10d

    .line 263
    :cond_106
    const-string v0, "MenuItemCompat"

    .line 264
    .line 265
    const-string v1, "setActionProvider: item does not implement SupportMenuItem; ignoring"

    .line 266
    .line 267
    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 268
    .line 269
    .line 270
    :cond_10d
    :goto_10d
    iget-object v0, p0, Lyu2;->A:Ljava/lang/CharSequence;

    .line 271
    .line 272
    instance-of v1, p1, Lav2;

    .line 273
    .line 274
    const/16 v2, 0x1a

    .line 275
    .line 276
    if-eqz v1, :cond_11c

    .line 277
    .line 278
    move-object v3, p1

    .line 279
    check-cast v3, Lav2;

    .line 280
    .line 281
    invoke-interface {v3, v0}, Lav2;->setContentDescription(Ljava/lang/CharSequence;)Lav2;

    .line 282
    .line 283
    .line 284
    goto :goto_123

    .line 285
    :cond_11c
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 286
    .line 287
    if-lt v3, v2, :cond_123

    .line 288
    .line 289
    invoke-static {p1, v0}, Lv9;->l(Landroid/view/MenuItem;Ljava/lang/CharSequence;)V

    .line 290
    .line 291
    .line 292
    :cond_123
    :goto_123
    iget-object v0, p0, Lyu2;->B:Ljava/lang/CharSequence;

    .line 293
    .line 294
    if-eqz v1, :cond_12e

    .line 295
    .line 296
    move-object v3, p1

    .line 297
    check-cast v3, Lav2;

    .line 298
    .line 299
    invoke-interface {v3, v0}, Lav2;->setTooltipText(Ljava/lang/CharSequence;)Lav2;

    .line 300
    .line 301
    .line 302
    goto :goto_135

    .line 303
    :cond_12e
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 304
    .line 305
    if-lt v3, v2, :cond_135

    .line 306
    .line 307
    invoke-static {p1, v0}, Lv9;->t(Landroid/view/MenuItem;Ljava/lang/CharSequence;)V

    .line 308
    .line 309
    .line 310
    :cond_135
    :goto_135
    iget-char v0, p0, Lyu2;->n:C

    .line 311
    .line 312
    iget v3, p0, Lyu2;->o:I

    .line 313
    .line 314
    if-eqz v1, :cond_142

    .line 315
    .line 316
    move-object v4, p1

    .line 317
    check-cast v4, Lav2;

    .line 318
    .line 319
    invoke-interface {v4, v0, v3}, Lav2;->setAlphabeticShortcut(CI)Landroid/view/MenuItem;

    .line 320
    .line 321
    .line 322
    goto :goto_149

    .line 323
    :cond_142
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 324
    .line 325
    if-lt v4, v2, :cond_149

    .line 326
    .line 327
    invoke-static {p1, v0, v3}, Lv9;->j(Landroid/view/MenuItem;CI)V

    .line 328
    .line 329
    .line 330
    :cond_149
    :goto_149
    iget-char v0, p0, Lyu2;->p:C

    .line 331
    .line 332
    iget v3, p0, Lyu2;->q:I

    .line 333
    .line 334
    if-eqz v1, :cond_156

    .line 335
    .line 336
    move-object v4, p1

    .line 337
    check-cast v4, Lav2;

    .line 338
    .line 339
    invoke-interface {v4, v0, v3}, Lav2;->setNumericShortcut(CI)Landroid/view/MenuItem;

    .line 340
    .line 341
    .line 342
    goto :goto_15d

    .line 343
    :cond_156
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 344
    .line 345
    if-lt v4, v2, :cond_15d

    .line 346
    .line 347
    invoke-static {p1, v0, v3}, Lv9;->p(Landroid/view/MenuItem;CI)V

    .line 348
    .line 349
    .line 350
    :cond_15d
    :goto_15d
    iget-object v0, p0, Lyu2;->D:Landroid/graphics/PorterDuff$Mode;

    .line 351
    .line 352
    if-eqz v0, :cond_171

    .line 353
    .line 354
    if-eqz v1, :cond_16a

    .line 355
    .line 356
    move-object v3, p1

    .line 357
    check-cast v3, Lav2;

    .line 358
    .line 359
    invoke-interface {v3, v0}, Lav2;->setIconTintMode(Landroid/graphics/PorterDuff$Mode;)Landroid/view/MenuItem;

    .line 360
    .line 361
    .line 362
    goto :goto_171

    .line 363
    :cond_16a
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 364
    .line 365
    if-lt v3, v2, :cond_171

    .line 366
    .line 367
    invoke-static {p1, v0}, Lv9;->o(Landroid/view/MenuItem;Landroid/graphics/PorterDuff$Mode;)V

    .line 368
    .line 369
    .line 370
    :cond_171
    :goto_171
    iget-object p0, p0, Lyu2;->C:Landroid/content/res/ColorStateList;

    .line 371
    .line 372
    if-eqz p0, :cond_184

    .line 373
    .line 374
    if-eqz v1, :cond_17d

    .line 375
    .line 376
    check-cast p1, Lav2;

    .line 377
    .line 378
    invoke-interface {p1, p0}, Lav2;->setIconTintList(Landroid/content/res/ColorStateList;)Landroid/view/MenuItem;

    .line 379
    .line 380
    .line 381
    goto :goto_184

    .line 382
    :cond_17d
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 383
    .line 384
    if-lt v0, v2, :cond_184

    .line 385
    .line 386
    invoke-static {p1, p0}, Lv9;->n(Landroid/view/MenuItem;Landroid/content/res/ColorStateList;)V

    .line 387
    .line 388
    .line 389
    :cond_184
    :goto_184
    return-void
.end method
