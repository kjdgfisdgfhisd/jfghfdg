###### Class defpackage.sx0 (sx0)
.class public final Lsx0;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field public static final d:Z

.field public static final e:Z

.field public static final f:Ljava/io/File;

.field public static volatile g:Lsx0;


# instance fields
.field public a:I

.field public b:Z

.field public final c:Ljava/util/concurrent/atomic/AtomicBoolean;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/16 v1, 0x1d

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v3, 0x1

    .line 7
    if-ge v0, v1, :cond_a

    .line 8
    .line 9
    move v1, v3

    .line 10
    goto :goto_b

    .line 11
    :cond_a
    move v1, v2

    .line 12
    :goto_b
    sput-boolean v1, Lsx0;->d:Z

    .line 13
    .line 14
    const/16 v1, 0x1c

    .line 15
    .line 16
    if-lt v0, v1, :cond_12

    .line 17
    .line 18
    move v2, v3

    .line 19
    :cond_12
    sput-boolean v2, Lsx0;->e:Z

    .line 20
    .line 21
    new-instance v0, Ljava/io/File;

    .line 22
    .line 23
    const-string v1, "/proc/self/fd"

    .line 24
    .line 25
    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    sput-object v0, Lsx0;->f:Ljava/io/File;

    .line 29
    .line 30
    return-void
.end method

.method public constructor <init>()V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    iput-boolean v0, p0, Lsx0;->b:Z

    .line 6
    .line 7
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 8
    .line 9
    const/4 v1, 0x0

    .line 10
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 11
    .line 12
    .line 13
    iput-object v0, p0, Lsx0;->c:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 14
    .line 15
    return-void
.end method

.method public static a()Lsx0;
    .registers 2

    .line 1
    sget-object v0, Lsx0;->g:Lsx0;

    .line 2
    .line 3
    if-nez v0, :cond_19

    .line 4
    .line 5
    const-class v0, Lsx0;

    .line 6
    .line 7
    monitor-enter v0

    .line 8
    :try_start_7
    sget-object v1, Lsx0;->g:Lsx0;

    .line 9
    .line 10
    if-nez v1, :cond_15

    .line 11
    .line 12
    new-instance v1, Lsx0;

    .line 13
    .line 14
    invoke-direct {v1}, Lsx0;-><init>()V

    .line 15
    .line 16
    .line 17
    sput-object v1, Lsx0;->g:Lsx0;

    .line 18
    .line 19
    goto :goto_15

    .line 20
    :catchall_13
    move-exception v1

    .line 21
    goto :goto_17

    .line 22
    :cond_15
    :goto_15
    monitor-exit v0

    .line 23
    goto :goto_19

    .line 24
    :goto_17
    monitor-exit v0
    :try_end_18
    .catchall {:try_start_7 .. :try_end_18} :catchall_13

    .line 25
    throw v1

    .line 26
    :cond_19
    :goto_19
    sget-object v0, Lsx0;->g:Lsx0;

    .line 27
    .line 28
    return-object v0
.end method


# virtual methods
.method public final b()I
    .registers 16

    .line 1
    sget p0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/16 v0, 0x1c

    .line 4
    .line 5
    if-eq p0, v0, :cond_7

    .line 6
    .line 7
    goto :goto_46

    .line 8
    :cond_7
    const-string v13, "ONEPLUS A6010"

    .line 9
    .line 10
    const-string v14, "ONEPLUS A6013"

    .line 11
    .line 12
    const-string v1, "GM1900"

    .line 13
    .line 14
    const-string v2, "GM1901"

    .line 15
    .line 16
    const-string v3, "GM1903"

    .line 17
    .line 18
    const-string v4, "GM1911"

    .line 19
    .line 20
    const-string v5, "GM1915"

    .line 21
    .line 22
    const-string v6, "ONEPLUS A3000"

    .line 23
    .line 24
    const-string v7, "ONEPLUS A3010"

    .line 25
    .line 26
    const-string v8, "ONEPLUS A5010"

    .line 27
    .line 28
    const-string v9, "ONEPLUS A5000"

    .line 29
    .line 30
    const-string v10, "ONEPLUS A3003"

    .line 31
    .line 32
    const-string v11, "ONEPLUS A6000"

    .line 33
    .line 34
    const-string v12, "ONEPLUS A6003"

    .line 35
    .line 36
    filled-new-array/range {v1 .. v14}, [Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object p0

    .line 40
    invoke-static {p0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 41
    .line 42
    .line 43
    move-result-object p0

    .line 44
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 45
    .line 46
    .line 47
    move-result-object p0

    .line 48
    :cond_2f
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    if-eqz v0, :cond_46

    .line 53
    .line 54
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    check-cast v0, Ljava/lang/String;

    .line 59
    .line 60
    sget-object v1, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 61
    .line 62
    invoke-virtual {v1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    if-eqz v0, :cond_2f

    .line 67
    .line 68
    const/16 p0, 0x1f4

    .line 69
    .line 70
    return p0

    .line 71
    :cond_46
    :goto_46
    const/16 p0, 0x4e20

    .line 72
    .line 73
    return p0
.end method

.method public final c(IIZZ)Z
    .registers 11

    .line 1
    const/4 v0, 0x2

    .line 2
    const/4 v1, 0x0

    .line 3
    if-nez p3, :cond_14

    .line 4
    .line 5
    const-string p0, "HardwareConfig"

    .line 6
    .line 7
    invoke-static {p0, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 8
    .line 9
    .line 10
    move-result p0

    .line 11
    if-eqz p0, :cond_ce

    .line 12
    .line 13
    const-string p0, "HardwareConfig"

    .line 14
    .line 15
    const-string p1, "Hardware config disallowed by caller"

    .line 16
    .line 17
    invoke-static {p0, p1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 18
    .line 19
    .line 20
    return v1

    .line 21
    :cond_14
    sget-boolean p3, Lsx0;->e:Z

    .line 22
    .line 23
    if-nez p3, :cond_28

    .line 24
    .line 25
    const-string p0, "HardwareConfig"

    .line 26
    .line 27
    invoke-static {p0, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 28
    .line 29
    .line 30
    move-result p0

    .line 31
    if-eqz p0, :cond_ce

    .line 32
    .line 33
    const-string p0, "HardwareConfig"

    .line 34
    .line 35
    const-string p1, "Hardware config disallowed by sdk"

    .line 36
    .line 37
    invoke-static {p0, p1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 38
    .line 39
    .line 40
    return v1

    .line 41
    :cond_28
    sget-boolean p3, Lsx0;->d:Z

    .line 42
    .line 43
    if-eqz p3, :cond_44

    .line 44
    .line 45
    iget-object p3, p0, Lsx0;->c:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 46
    .line 47
    invoke-virtual {p3}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 48
    .line 49
    .line 50
    move-result p3

    .line 51
    if-nez p3, :cond_44

    .line 52
    .line 53
    const-string p0, "HardwareConfig"

    .line 54
    .line 55
    invoke-static {p0, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 56
    .line 57
    .line 58
    move-result p0

    .line 59
    if-eqz p0, :cond_ce

    .line 60
    .line 61
    const-string p0, "HardwareConfig"

    .line 62
    .line 63
    const-string p1, "Hardware config disallowed by app state"

    .line 64
    .line 65
    invoke-static {p0, p1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 66
    .line 67
    .line 68
    return v1

    .line 69
    :cond_44
    if-eqz p4, :cond_56

    .line 70
    .line 71
    const-string p0, "HardwareConfig"

    .line 72
    .line 73
    invoke-static {p0, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 74
    .line 75
    .line 76
    move-result p0

    .line 77
    if-eqz p0, :cond_ce

    .line 78
    .line 79
    const-string p0, "HardwareConfig"

    .line 80
    .line 81
    const-string p1, "Hardware config disallowed because exif orientation is required"

    .line 82
    .line 83
    invoke-static {p0, p1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 84
    .line 85
    .line 86
    return v1

    .line 87
    :cond_56
    if-ltz p1, :cond_bf

    .line 88
    .line 89
    if-gez p2, :cond_5b

    .line 90
    .line 91
    goto :goto_bf

    .line 92
    :cond_5b
    const-string p1, "Excluding HARDWARE bitmap config because we\'re over the file descriptor limit, file descriptors "

    .line 93
    .line 94
    monitor-enter p0

    .line 95
    :try_start_5e
    iget p2, p0, Lsx0;->a:I

    .line 96
    .line 97
    const/4 p3, 0x1

    .line 98
    add-int/2addr p2, p3

    .line 99
    iput p2, p0, Lsx0;->a:I

    .line 100
    .line 101
    const/16 p4, 0x32

    .line 102
    .line 103
    if-lt p2, p4, :cond_a7

    .line 104
    .line 105
    iput v1, p0, Lsx0;->a:I

    .line 106
    .line 107
    sget-object p2, Lsx0;->f:Ljava/io/File;

    .line 108
    .line 109
    invoke-virtual {p2}, Ljava/io/File;->list()[Ljava/lang/String;

    .line 110
    .line 111
    .line 112
    move-result-object p2

    .line 113
    array-length p2, p2

    .line 114
    invoke-virtual {p0}, Lsx0;->b()I

    .line 115
    .line 116
    .line 117
    move-result p4

    .line 118
    int-to-long v2, p4

    .line 119
    int-to-long v4, p2

    .line 120
    cmp-long p4, v4, v2

    .line 121
    .line 122
    if-gez p4, :cond_7d

    .line 123
    .line 124
    move p4, p3

    .line 125
    goto :goto_7e

    .line 126
    :cond_7d
    move p4, v1

    .line 127
    :goto_7e
    iput-boolean p4, p0, Lsx0;->b:Z

    .line 128
    .line 129
    if-nez p4, :cond_a7

    .line 130
    .line 131
    const-string p4, "Downsampler"

    .line 132
    .line 133
    const/4 v4, 0x5

    .line 134
    invoke-static {p4, v4}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 135
    .line 136
    .line 137
    move-result p4

    .line 138
    if-eqz p4, :cond_a7

    .line 139
    .line 140
    const-string p4, "Downsampler"

    .line 141
    .line 142
    new-instance v4, Ljava/lang/StringBuilder;

    .line 143
    .line 144
    invoke-direct {v4, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 145
    .line 146
    .line 147
    invoke-virtual {v4, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 148
    .line 149
    .line 150
    const-string p1, ", limit "

    .line 151
    .line 152
    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 153
    .line 154
    .line 155
    invoke-virtual {v4, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 156
    .line 157
    .line 158
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 159
    .line 160
    .line 161
    move-result-object p1

    .line 162
    invoke-static {p4, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 163
    .line 164
    .line 165
    goto :goto_a7

    .line 166
    :catchall_a5
    move-exception p1

    .line 167
    goto :goto_bd

    .line 168
    :cond_a7
    :goto_a7
    iget-boolean p1, p0, Lsx0;->b:Z
    :try_end_a9
    .catchall {:try_start_5e .. :try_end_a9} :catchall_a5

    .line 169
    .line 170
    monitor-exit p0

    .line 171
    if-nez p1, :cond_bc

    .line 172
    .line 173
    const-string p0, "HardwareConfig"

    .line 174
    .line 175
    invoke-static {p0, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 176
    .line 177
    .line 178
    move-result p0

    .line 179
    if-eqz p0, :cond_ce

    .line 180
    .line 181
    const-string p0, "HardwareConfig"

    .line 182
    .line 183
    const-string p1, "Hardware config disallowed because there are insufficient FDs"

    .line 184
    .line 185
    invoke-static {p0, p1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 186
    .line 187
    .line 188
    return v1

    .line 189
    :cond_bc
    return p3

    .line 190
    :goto_bd
    :try_start_bd
    monitor-exit p0
    :try_end_be
    .catchall {:try_start_bd .. :try_end_be} :catchall_a5

    .line 191
    throw p1

    .line 192
    :cond_bf
    :goto_bf
    const-string p0, "HardwareConfig"

    .line 193
    .line 194
    invoke-static {p0, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 195
    .line 196
    .line 197
    move-result p0

    .line 198
    if-eqz p0, :cond_ce

    .line 199
    .line 200
    const-string p0, "HardwareConfig"

    .line 201
    .line 202
    const-string p1, "Hardware config disallowed because of invalid dimensions"

    .line 203
    .line 204
    invoke-static {p0, p1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 205
    .line 206
    .line 207
    :cond_ce
    return v1
.end method
