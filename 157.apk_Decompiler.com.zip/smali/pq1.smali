###### Class defpackage.pq1 (pq1)
.class public Lpq1;
.super Landroidx/fragment/app/g;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<S:",
        "Ljava/lang/Object;",
        ">",
        "Landroidx/fragment/app/g;"
    }
.end annotation


# instance fields
.field public P:Ljava/lang/CharSequence;

.field public Q:I

.field public V:Ljava/lang/CharSequence;

.field public X:I

.field public Y:Ljava/lang/CharSequence;

.field public Z:Landroid/widget/TextView;

.field public final b:Ljava/util/LinkedHashSet;

.field public final c:Ljava/util/LinkedHashSet;

.field public final d:Ljava/util/LinkedHashSet;

.field public final e:Ljava/util/LinkedHashSet;

.field public f:I

.field public j:Lro2;

.field public l:Lq12;

.field public m:Lgo;

.field public n:Leq1;

.field public p:I

.field public p0:Landroid/widget/TextView;

.field public q:Ljava/lang/CharSequence;

.field public q0:Lcom/google/android/material/internal/CheckableImageButton;

.field public r:Z

.field public r0:Lyq1;

.field public s:I

.field public s0:Landroid/widget/Button;

.field public t:I

.field public t0:Z

.field public u:Ljava/lang/CharSequence;

.field public u0:Ljava/lang/CharSequence;

.field public v:I

.field public v0:Ljava/lang/CharSequence;


# direct methods
.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Landroidx/fragment/app/g;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/util/LinkedHashSet;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Lpq1;->b:Ljava/util/LinkedHashSet;

    .line 10
    .line 11
    new-instance v0, Ljava/util/LinkedHashSet;

    .line 12
    .line 13
    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    .line 14
    .line 15
    .line 16
    iput-object v0, p0, Lpq1;->c:Ljava/util/LinkedHashSet;

    .line 17
    .line 18
    new-instance v0, Ljava/util/LinkedHashSet;

    .line 19
    .line 20
    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    .line 21
    .line 22
    .line 23
    iput-object v0, p0, Lpq1;->d:Ljava/util/LinkedHashSet;

    .line 24
    .line 25
    new-instance v0, Ljava/util/LinkedHashSet;

    .line 26
    .line 27
    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    .line 28
    .line 29
    .line 30
    iput-object v0, p0, Lpq1;->e:Ljava/util/LinkedHashSet;

    .line 31
    .line 32
    return-void
.end method

.method public static q(Landroid/content/Context;)I
    .registers 7

    .line 1
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    const v0, 0x7f0703b6

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0, v0}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    invoke-static {}, Lf63;->d()Ljava/util/Calendar;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    const/4 v2, 0x5

    .line 17
    const/4 v3, 0x1

    .line 18
    invoke-virtual {v1, v2, v3}, Ljava/util/Calendar;->set(II)V

    .line 19
    .line 20
    .line 21
    invoke-static {v1}, Lf63;->c(Ljava/util/Calendar;)Ljava/util/Calendar;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    const/4 v4, 0x2

    .line 26
    invoke-virtual {v1, v4}, Ljava/util/Calendar;->get(I)I

    .line 27
    .line 28
    .line 29
    invoke-virtual {v1, v3}, Ljava/util/Calendar;->get(I)I

    .line 30
    .line 31
    .line 32
    const/4 v5, 0x7

    .line 33
    invoke-virtual {v1, v5}, Ljava/util/Calendar;->getMaximum(I)I

    .line 34
    .line 35
    .line 36
    move-result v5

    .line 37
    invoke-virtual {v1, v2}, Ljava/util/Calendar;->getActualMaximum(I)I

    .line 38
    .line 39
    .line 40
    invoke-virtual {v1}, Ljava/util/Calendar;->getTimeInMillis()J

    .line 41
    .line 42
    .line 43
    const v1, 0x7f0703bc

    .line 44
    .line 45
    .line 46
    invoke-virtual {p0, v1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 47
    .line 48
    .line 49
    move-result v1

    .line 50
    const v2, 0x7f0703ca

    .line 51
    .line 52
    .line 53
    invoke-virtual {p0, v2}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    .line 54
    .line 55
    .line 56
    move-result p0

    .line 57
    mul-int/2addr v0, v4

    .line 58
    mul-int/2addr v1, v5

    .line 59
    add-int/2addr v1, v0

    .line 60
    sub-int/2addr v5, v3

    .line 61
    mul-int/2addr v5, p0

    .line 62
    add-int/2addr v5, v1

    .line 63
    return v5
.end method

.method public static r(Landroid/content/Context;I)Z
    .registers 4

    .line 1
    const-class v0, Leq1;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const v1, 0x7f040386

    .line 8
    .line 9
    .line 10
    invoke-static {v1, p0, v0}, Llw0;->m0(ILandroid/content/Context;Ljava/lang/String;)Landroid/util/TypedValue;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iget v0, v0, Landroid/util/TypedValue;->data:I

    .line 15
    .line 16
    filled-new-array {p1}, [I

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    invoke-virtual {p0, v0, p1}, Landroid/content/Context;->obtainStyledAttributes(I[I)Landroid/content/res/TypedArray;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    const/4 p1, 0x0

    .line 25
    invoke-virtual {p0, p1, p1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 26
    .line 27
    .line 28
    move-result p1

    .line 29
    invoke-virtual {p0}, Landroid/content/res/TypedArray;->recycle()V

    .line 30
    .line 31
    .line 32
    return p1
.end method


# virtual methods
.method public final o()Lro2;
    .registers 3

    .line 1
    iget-object v0, p0, Lpq1;->j:Lro2;

    .line 2
    .line 3
    if-nez v0, :cond_12

    .line 4
    .line 5
    invoke-virtual {p0}, Landroidx/fragment/app/m;->getArguments()Landroid/os/Bundle;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    const-string v1, "DATE_SELECTOR_KEY"

    .line 10
    .line 11
    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    check-cast v0, Lro2;

    .line 16
    .line 17
    iput-object v0, p0, Lpq1;->j:Lro2;

    .line 18
    .line 19
    :cond_12
    return-object v0
.end method

.method public final onCancel(Landroid/content/DialogInterface;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lpq1;->d:Ljava/util/LinkedHashSet;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    :goto_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-eqz v1, :cond_16

    .line 12
    .line 13
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    check-cast v1, Landroid/content/DialogInterface$OnCancelListener;

    .line 18
    .line 19
    invoke-interface {v1, p1}, Landroid/content/DialogInterface$OnCancelListener;->onCancel(Landroid/content/DialogInterface;)V

    .line 20
    .line 21
    .line 22
    goto :goto_6

    .line 23
    :cond_16
    invoke-super {p0, p1}, Landroidx/fragment/app/g;->onCancel(Landroid/content/DialogInterface;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .registers 5

    .line 1
    invoke-super {p0, p1}, Landroidx/fragment/app/g;->onCreate(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    if-nez p1, :cond_9

    .line 5
    .line 6
    invoke-virtual {p0}, Landroidx/fragment/app/m;->getArguments()Landroid/os/Bundle;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    :cond_9
    const-string v0, "OVERRIDE_THEME_RES_ID"

    .line 11
    .line 12
    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    iput v0, p0, Lpq1;->f:I

    .line 17
    .line 18
    const-string v0, "DATE_SELECTOR_KEY"

    .line 19
    .line 20
    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    check-cast v0, Lro2;

    .line 25
    .line 26
    iput-object v0, p0, Lpq1;->j:Lro2;

    .line 27
    .line 28
    const-string v0, "CALENDAR_CONSTRAINTS_KEY"

    .line 29
    .line 30
    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    check-cast v0, Lgo;

    .line 35
    .line 36
    iput-object v0, p0, Lpq1;->m:Lgo;

    .line 37
    .line 38
    const-string v0, "DAY_VIEW_DECORATOR_KEY"

    .line 39
    .line 40
    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    if-nez v0, :cond_b2

    .line 45
    .line 46
    const-string v0, "TITLE_TEXT_RES_ID_KEY"

    .line 47
    .line 48
    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    iput v0, p0, Lpq1;->p:I

    .line 53
    .line 54
    const-string v0, "TITLE_TEXT_KEY"

    .line 55
    .line 56
    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    iput-object v0, p0, Lpq1;->q:Ljava/lang/CharSequence;

    .line 61
    .line 62
    const-string v0, "INPUT_MODE_KEY"

    .line 63
    .line 64
    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    iput v0, p0, Lpq1;->s:I

    .line 69
    .line 70
    const-string v0, "POSITIVE_BUTTON_TEXT_RES_ID_KEY"

    .line 71
    .line 72
    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    iput v0, p0, Lpq1;->t:I

    .line 77
    .line 78
    const-string v0, "POSITIVE_BUTTON_TEXT_KEY"

    .line 79
    .line 80
    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    iput-object v0, p0, Lpq1;->u:Ljava/lang/CharSequence;

    .line 85
    .line 86
    const-string v0, "POSITIVE_BUTTON_CONTENT_DESCRIPTION_RES_ID_KEY"

    .line 87
    .line 88
    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    .line 89
    .line 90
    .line 91
    move-result v0

    .line 92
    iput v0, p0, Lpq1;->v:I

    .line 93
    .line 94
    const-string v0, "POSITIVE_BUTTON_CONTENT_DESCRIPTION_KEY"

    .line 95
    .line 96
    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    iput-object v0, p0, Lpq1;->P:Ljava/lang/CharSequence;

    .line 101
    .line 102
    const-string v0, "NEGATIVE_BUTTON_TEXT_RES_ID_KEY"

    .line 103
    .line 104
    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    .line 105
    .line 106
    .line 107
    move-result v0

    .line 108
    iput v0, p0, Lpq1;->Q:I

    .line 109
    .line 110
    const-string v0, "NEGATIVE_BUTTON_TEXT_KEY"

    .line 111
    .line 112
    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    .line 113
    .line 114
    .line 115
    move-result-object v0

    .line 116
    iput-object v0, p0, Lpq1;->V:Ljava/lang/CharSequence;

    .line 117
    .line 118
    const-string v0, "NEGATIVE_BUTTON_CONTENT_DESCRIPTION_RES_ID_KEY"

    .line 119
    .line 120
    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    .line 121
    .line 122
    .line 123
    move-result v0

    .line 124
    iput v0, p0, Lpq1;->X:I

    .line 125
    .line 126
    const-string v0, "NEGATIVE_BUTTON_CONTENT_DESCRIPTION_KEY"

    .line 127
    .line 128
    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    .line 129
    .line 130
    .line 131
    move-result-object p1

    .line 132
    iput-object p1, p0, Lpq1;->Y:Ljava/lang/CharSequence;

    .line 133
    .line 134
    iget-object p1, p0, Lpq1;->q:Ljava/lang/CharSequence;

    .line 135
    .line 136
    if-eqz p1, :cond_8a

    .line 137
    .line 138
    goto :goto_98

    .line 139
    :cond_8a
    invoke-virtual {p0}, Landroidx/fragment/app/m;->requireContext()Landroid/content/Context;

    .line 140
    .line 141
    .line 142
    move-result-object p1

    .line 143
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 144
    .line 145
    .line 146
    move-result-object p1

    .line 147
    iget v0, p0, Lpq1;->p:I

    .line 148
    .line 149
    invoke-virtual {p1, v0}, Landroid/content/res/Resources;->getText(I)Ljava/lang/CharSequence;

    .line 150
    .line 151
    .line 152
    move-result-object p1

    .line 153
    :goto_98
    iput-object p1, p0, Lpq1;->u0:Ljava/lang/CharSequence;

    .line 154
    .line 155
    if-eqz p1, :cond_ae

    .line 156
    .line 157
    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 158
    .line 159
    .line 160
    move-result-object v0

    .line 161
    const-string v1, "\n"

    .line 162
    .line 163
    invoke-static {v0, v1}, Landroid/text/TextUtils;->split(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    .line 164
    .line 165
    .line 166
    move-result-object v0

    .line 167
    array-length v1, v0

    .line 168
    const/4 v2, 0x1

    .line 169
    if-le v1, v2, :cond_af

    .line 170
    .line 171
    const/4 p1, 0x0

    .line 172
    aget-object p1, v0, p1

    .line 173
    .line 174
    goto :goto_af

    .line 175
    :cond_ae
    const/4 p1, 0x0

    .line 176
    :cond_af
    :goto_af
    iput-object p1, p0, Lpq1;->v0:Ljava/lang/CharSequence;

    .line 177
    .line 178
    return-void

    .line 179
    :cond_b2
    invoke-static {}, Lvn0;->b()V

    .line 180
    .line 181
    .line 182
    return-void
.end method

.method public final onCreateDialog(Landroid/os/Bundle;)Landroid/app/Dialog;
    .registers 7

    .line 1
    new-instance p1, Landroid/app/Dialog;

    .line 2
    .line 3
    invoke-virtual {p0}, Landroidx/fragment/app/m;->requireContext()Landroid/content/Context;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-virtual {p0}, Landroidx/fragment/app/m;->requireContext()Landroid/content/Context;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    iget v2, p0, Lpq1;->f:I

    .line 12
    .line 13
    if-eqz v2, :cond_f

    .line 14
    .line 15
    goto :goto_25

    .line 16
    :cond_f
    invoke-virtual {p0}, Lpq1;->o()Lro2;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 21
    .line 22
    .line 23
    const-class v2, Lpq1;

    .line 24
    .line 25
    invoke-virtual {v2}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v2

    .line 29
    const v3, 0x7f040387

    .line 30
    .line 31
    .line 32
    invoke-static {v3, v1, v2}, Llw0;->m0(ILandroid/content/Context;Ljava/lang/String;)Landroid/util/TypedValue;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    iget v2, v1, Landroid/util/TypedValue;->data:I

    .line 37
    .line 38
    :goto_25
    invoke-direct {p1, v0, v2}, Landroid/app/Dialog;-><init>(Landroid/content/Context;I)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {p1}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    const v1, 0x101020d

    .line 46
    .line 47
    .line 48
    invoke-static {v0, v1}, Lpq1;->r(Landroid/content/Context;I)Z

    .line 49
    .line 50
    .line 51
    move-result v1

    .line 52
    iput-boolean v1, p0, Lpq1;->r:Z

    .line 53
    .line 54
    new-instance v1, Lyq1;

    .line 55
    .line 56
    const/4 v2, 0x0

    .line 57
    const v3, 0x7f040386

    .line 58
    .line 59
    .line 60
    const v4, 0x7f1305d4

    .line 61
    .line 62
    .line 63
    invoke-direct {v1, v0, v2, v3, v4}, Lyq1;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    .line 64
    .line 65
    .line 66
    iput-object v1, p0, Lpq1;->r0:Lyq1;

    .line 67
    .line 68
    sget-object v1, Lz92;->s:[I

    .line 69
    .line 70
    invoke-virtual {v0, v2, v1, v3, v4}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    .line 71
    .line 72
    .line 73
    move-result-object v1

    .line 74
    const/4 v2, 0x1

    .line 75
    const/4 v3, 0x0

    .line 76
    invoke-virtual {v1, v2, v3}, Landroid/content/res/TypedArray;->getColor(II)I

    .line 77
    .line 78
    .line 79
    move-result v2

    .line 80
    invoke-virtual {v1}, Landroid/content/res/TypedArray;->recycle()V

    .line 81
    .line 82
    .line 83
    iget-object v1, p0, Lpq1;->r0:Lyq1;

    .line 84
    .line 85
    invoke-virtual {v1, v0}, Lyq1;->p(Landroid/content/Context;)V

    .line 86
    .line 87
    .line 88
    iget-object v0, p0, Lpq1;->r0:Lyq1;

    .line 89
    .line 90
    invoke-static {v2}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    .line 91
    .line 92
    .line 93
    move-result-object v1

    .line 94
    invoke-virtual {v0, v1}, Lyq1;->t(Landroid/content/res/ColorStateList;)V

    .line 95
    .line 96
    .line 97
    iget-object p0, p0, Lpq1;->r0:Lyq1;

    .line 98
    .line 99
    invoke-virtual {p1}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 100
    .line 101
    .line 102
    move-result-object v0

    .line 103
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 104
    .line 105
    .line 106
    move-result-object v0

    .line 107
    invoke-virtual {v0}, Landroid/view/View;->getElevation()F

    .line 108
    .line 109
    .line 110
    move-result v0

    .line 111
    invoke-virtual {p0, v0}, Lyq1;->s(F)V

    .line 112
    .line 113
    .line 114
    return-object p1
.end method

.method public final onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .registers 9

    .line 1
    iget-boolean p3, p0, Lpq1;->r:Z

    .line 2
    .line 3
    if-eqz p3, :cond_8

    .line 4
    .line 5
    const p3, 0x7f0c006c

    .line 6
    .line 7
    .line 8
    goto :goto_b

    .line 9
    :cond_8
    const p3, 0x7f0c006b

    .line 10
    .line 11
    .line 12
    :goto_b
    invoke-virtual {p1, p3, p2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 17
    .line 18
    .line 19
    move-result-object p2

    .line 20
    iget-boolean p3, p0, Lpq1;->r:Z

    .line 21
    .line 22
    if-eqz p3, :cond_2c

    .line 23
    .line 24
    const p3, 0x7f09016c

    .line 25
    .line 26
    .line 27
    invoke-virtual {p1, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 28
    .line 29
    .line 30
    move-result-object p3

    .line 31
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    .line 32
    .line 33
    invoke-static {p2}, Lpq1;->q(Landroid/content/Context;)I

    .line 34
    .line 35
    .line 36
    move-result v1

    .line 37
    const/4 v2, -0x2

    .line 38
    invoke-direct {v0, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {p3, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 42
    .line 43
    .line 44
    goto :goto_40

    .line 45
    :cond_2c
    const p3, 0x7f09016d

    .line 46
    .line 47
    .line 48
    invoke-virtual {p1, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 49
    .line 50
    .line 51
    move-result-object p3

    .line 52
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    .line 53
    .line 54
    invoke-static {p2}, Lpq1;->q(Landroid/content/Context;)I

    .line 55
    .line 56
    .line 57
    move-result v1

    .line 58
    const/4 v2, -0x1

    .line 59
    invoke-direct {v0, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 60
    .line 61
    .line 62
    invoke-virtual {p3, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 63
    .line 64
    .line 65
    :goto_40
    const p3, 0x7f09017b

    .line 66
    .line 67
    .line 68
    invoke-virtual {p1, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 69
    .line 70
    .line 71
    move-result-object p3

    .line 72
    check-cast p3, Landroid/widget/TextView;

    .line 73
    .line 74
    iput-object p3, p0, Lpq1;->p0:Landroid/widget/TextView;

    .line 75
    .line 76
    const/4 v0, 0x1

    .line 77
    invoke-virtual {p3, v0}, Landroid/view/View;->setAccessibilityLiveRegion(I)V

    .line 78
    .line 79
    .line 80
    const p3, 0x7f09017d

    .line 81
    .line 82
    .line 83
    invoke-virtual {p1, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 84
    .line 85
    .line 86
    move-result-object p3

    .line 87
    check-cast p3, Lcom/google/android/material/internal/CheckableImageButton;

    .line 88
    .line 89
    iput-object p3, p0, Lpq1;->q0:Lcom/google/android/material/internal/CheckableImageButton;

    .line 90
    .line 91
    const p3, 0x7f090181

    .line 92
    .line 93
    .line 94
    invoke-virtual {p1, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 95
    .line 96
    .line 97
    move-result-object p3

    .line 98
    check-cast p3, Landroid/widget/TextView;

    .line 99
    .line 100
    iput-object p3, p0, Lpq1;->Z:Landroid/widget/TextView;

    .line 101
    .line 102
    iget-object p3, p0, Lpq1;->q0:Lcom/google/android/material/internal/CheckableImageButton;

    .line 103
    .line 104
    const-string v1, "TOGGLE_BUTTON_TAG"

    .line 105
    .line 106
    invoke-virtual {p3, v1}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 107
    .line 108
    .line 109
    iget-object p3, p0, Lpq1;->q0:Lcom/google/android/material/internal/CheckableImageButton;

    .line 110
    .line 111
    new-instance v1, Landroid/graphics/drawable/StateListDrawable;

    .line 112
    .line 113
    invoke-direct {v1}, Landroid/graphics/drawable/StateListDrawable;-><init>()V

    .line 114
    .line 115
    .line 116
    const v2, 0x10100a0

    .line 117
    .line 118
    .line 119
    filled-new-array {v2}, [I

    .line 120
    .line 121
    .line 122
    move-result-object v2

    .line 123
    const v3, 0x7f080100

    .line 124
    .line 125
    .line 126
    invoke-static {p2, v3}, Lc10;->o(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 127
    .line 128
    .line 129
    move-result-object v3

    .line 130
    invoke-virtual {v1, v2, v3}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    .line 131
    .line 132
    .line 133
    const/4 v2, 0x0

    .line 134
    new-array v3, v2, [I

    .line 135
    .line 136
    const v4, 0x7f080102

    .line 137
    .line 138
    .line 139
    invoke-static {p2, v4}, Lc10;->o(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 140
    .line 141
    .line 142
    move-result-object p2

    .line 143
    invoke-virtual {v1, v3, p2}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    .line 144
    .line 145
    .line 146
    invoke-virtual {p3, v1}, Ld9;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 147
    .line 148
    .line 149
    iget-object p2, p0, Lpq1;->q0:Lcom/google/android/material/internal/CheckableImageButton;

    .line 150
    .line 151
    iget p3, p0, Lpq1;->s:I

    .line 152
    .line 153
    if-eqz p3, :cond_9c

    .line 154
    .line 155
    move p3, v0

    .line 156
    goto :goto_9d

    .line 157
    :cond_9c
    move p3, v2

    .line 158
    :goto_9d
    invoke-virtual {p2, p3}, Lcom/google/android/material/internal/CheckableImageButton;->setChecked(Z)V

    .line 159
    .line 160
    .line 161
    iget-object p2, p0, Lpq1;->q0:Lcom/google/android/material/internal/CheckableImageButton;

    .line 162
    .line 163
    const/4 p3, 0x0

    .line 164
    invoke-static {p2, p3}, Ln83;->n(Landroid/view/View;Lg1;)V

    .line 165
    .line 166
    .line 167
    iget-object p2, p0, Lpq1;->q0:Lcom/google/android/material/internal/CheckableImageButton;

    .line 168
    .line 169
    invoke-virtual {p0, p2}, Lpq1;->u(Lcom/google/android/material/internal/CheckableImageButton;)V

    .line 170
    .line 171
    .line 172
    iget-object p2, p0, Lpq1;->q0:Lcom/google/android/material/internal/CheckableImageButton;

    .line 173
    .line 174
    invoke-virtual {p0, p2}, Lpq1;->v(Lcom/google/android/material/internal/CheckableImageButton;)V

    .line 175
    .line 176
    .line 177
    iget-object p2, p0, Lpq1;->q0:Lcom/google/android/material/internal/CheckableImageButton;

    .line 178
    .line 179
    new-instance p3, Lmq1;

    .line 180
    .line 181
    const/4 v1, 0x2

    .line 182
    invoke-direct {p3, p0, v1}, Lmq1;-><init>(Lpq1;I)V

    .line 183
    .line 184
    .line 185
    invoke-virtual {p2, p3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 186
    .line 187
    .line 188
    const p2, 0x7f0900a8

    .line 189
    .line 190
    .line 191
    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 192
    .line 193
    .line 194
    move-result-object p2

    .line 195
    check-cast p2, Landroid/widget/Button;

    .line 196
    .line 197
    iput-object p2, p0, Lpq1;->s0:Landroid/widget/Button;

    .line 198
    .line 199
    invoke-virtual {p0}, Lpq1;->o()Lro2;

    .line 200
    .line 201
    .line 202
    move-result-object p2

    .line 203
    iget-object p2, p2, Lro2;->a:Ljava/lang/Long;

    .line 204
    .line 205
    if-eqz p2, :cond_d0

    .line 206
    .line 207
    move p2, v0

    .line 208
    goto :goto_d1

    .line 209
    :cond_d0
    move p2, v2

    .line 210
    :goto_d1
    iget-object p3, p0, Lpq1;->s0:Landroid/widget/Button;

    .line 211
    .line 212
    if-eqz p2, :cond_d9

    .line 213
    .line 214
    invoke-virtual {p3, v0}, Landroid/view/View;->setEnabled(Z)V

    .line 215
    .line 216
    .line 217
    goto :goto_dc

    .line 218
    :cond_d9
    invoke-virtual {p3, v2}, Landroid/view/View;->setEnabled(Z)V

    .line 219
    .line 220
    .line 221
    :goto_dc
    iget-object p2, p0, Lpq1;->s0:Landroid/widget/Button;

    .line 222
    .line 223
    const-string p3, "CONFIRM_BUTTON_TAG"

    .line 224
    .line 225
    invoke-virtual {p2, p3}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 226
    .line 227
    .line 228
    iget-object p2, p0, Lpq1;->u:Ljava/lang/CharSequence;

    .line 229
    .line 230
    if-eqz p2, :cond_ed

    .line 231
    .line 232
    iget-object p3, p0, Lpq1;->s0:Landroid/widget/Button;

    .line 233
    .line 234
    invoke-virtual {p3, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 235
    .line 236
    .line 237
    goto :goto_f6

    .line 238
    :cond_ed
    iget p2, p0, Lpq1;->t:I

    .line 239
    .line 240
    if-eqz p2, :cond_f6

    .line 241
    .line 242
    iget-object p3, p0, Lpq1;->s0:Landroid/widget/Button;

    .line 243
    .line 244
    invoke-virtual {p3, p2}, Landroid/widget/TextView;->setText(I)V

    .line 245
    .line 246
    .line 247
    :cond_f6
    :goto_f6
    iget-object p2, p0, Lpq1;->P:Ljava/lang/CharSequence;

    .line 248
    .line 249
    if-eqz p2, :cond_100

    .line 250
    .line 251
    iget-object p3, p0, Lpq1;->s0:Landroid/widget/Button;

    .line 252
    .line 253
    invoke-virtual {p3, p2}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 254
    .line 255
    .line 256
    goto :goto_117

    .line 257
    :cond_100
    iget p2, p0, Lpq1;->v:I

    .line 258
    .line 259
    if-eqz p2, :cond_117

    .line 260
    .line 261
    iget-object p2, p0, Lpq1;->s0:Landroid/widget/Button;

    .line 262
    .line 263
    invoke-virtual {p0}, Landroidx/fragment/app/m;->getContext()Landroid/content/Context;

    .line 264
    .line 265
    .line 266
    move-result-object p3

    .line 267
    invoke-virtual {p3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 268
    .line 269
    .line 270
    move-result-object p3

    .line 271
    iget v1, p0, Lpq1;->v:I

    .line 272
    .line 273
    invoke-virtual {p3, v1}, Landroid/content/res/Resources;->getText(I)Ljava/lang/CharSequence;

    .line 274
    .line 275
    .line 276
    move-result-object p3

    .line 277
    invoke-virtual {p2, p3}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 278
    .line 279
    .line 280
    :cond_117
    :goto_117
    iget-object p2, p0, Lpq1;->s0:Landroid/widget/Button;

    .line 281
    .line 282
    new-instance p3, Lmq1;

    .line 283
    .line 284
    invoke-direct {p3, p0, v2}, Lmq1;-><init>(Lpq1;I)V

    .line 285
    .line 286
    .line 287
    invoke-virtual {p2, p3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 288
    .line 289
    .line 290
    const p2, 0x7f090087

    .line 291
    .line 292
    .line 293
    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 294
    .line 295
    .line 296
    move-result-object p2

    .line 297
    check-cast p2, Landroid/widget/Button;

    .line 298
    .line 299
    const-string p3, "CANCEL_BUTTON_TAG"

    .line 300
    .line 301
    invoke-virtual {p2, p3}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 302
    .line 303
    .line 304
    iget-object p3, p0, Lpq1;->V:Ljava/lang/CharSequence;

    .line 305
    .line 306
    if-eqz p3, :cond_137

    .line 307
    .line 308
    invoke-virtual {p2, p3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 309
    .line 310
    .line 311
    goto :goto_13e

    .line 312
    :cond_137
    iget p3, p0, Lpq1;->Q:I

    .line 313
    .line 314
    if-eqz p3, :cond_13e

    .line 315
    .line 316
    invoke-virtual {p2, p3}, Landroid/widget/TextView;->setText(I)V

    .line 317
    .line 318
    .line 319
    :cond_13e
    :goto_13e
    iget-object p3, p0, Lpq1;->Y:Ljava/lang/CharSequence;

    .line 320
    .line 321
    if-eqz p3, :cond_146

    .line 322
    .line 323
    invoke-virtual {p2, p3}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 324
    .line 325
    .line 326
    goto :goto_15b

    .line 327
    :cond_146
    iget p3, p0, Lpq1;->X:I

    .line 328
    .line 329
    if-eqz p3, :cond_15b

    .line 330
    .line 331
    invoke-virtual {p0}, Landroidx/fragment/app/m;->getContext()Landroid/content/Context;

    .line 332
    .line 333
    .line 334
    move-result-object p3

    .line 335
    invoke-virtual {p3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 336
    .line 337
    .line 338
    move-result-object p3

    .line 339
    iget v1, p0, Lpq1;->X:I

    .line 340
    .line 341
    invoke-virtual {p3, v1}, Landroid/content/res/Resources;->getText(I)Ljava/lang/CharSequence;

    .line 342
    .line 343
    .line 344
    move-result-object p3

    .line 345
    invoke-virtual {p2, p3}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 346
    .line 347
    .line 348
    :cond_15b
    :goto_15b
    new-instance p3, Lmq1;

    .line 349
    .line 350
    invoke-direct {p3, p0, v0}, Lmq1;-><init>(Lpq1;I)V

    .line 351
    .line 352
    .line 353
    invoke-virtual {p2, p3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 354
    .line 355
    .line 356
    return-object p1
.end method

.method public final onDismiss(Landroid/content/DialogInterface;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lpq1;->e:Ljava/util/LinkedHashSet;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    :goto_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-eqz v1, :cond_16

    .line 12
    .line 13
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    check-cast v1, Landroid/content/DialogInterface$OnDismissListener;

    .line 18
    .line 19
    invoke-interface {v1, p1}, Landroid/content/DialogInterface$OnDismissListener;->onDismiss(Landroid/content/DialogInterface;)V

    .line 20
    .line 21
    .line 22
    goto :goto_6

    .line 23
    :cond_16
    invoke-virtual {p0}, Landroidx/fragment/app/m;->getView()Landroid/view/View;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    check-cast v0, Landroid/view/ViewGroup;

    .line 28
    .line 29
    if-eqz v0, :cond_21

    .line 30
    .line 31
    invoke-virtual {v0}, Landroid/view/ViewGroup;->removeAllViews()V

    .line 32
    .line 33
    .line 34
    :cond_21
    invoke-super {p0, p1}, Landroidx/fragment/app/g;->onDismiss(Landroid/content/DialogInterface;)V

    .line 35
    .line 36
    .line 37
    return-void
.end method

.method public final onSaveInstanceState(Landroid/os/Bundle;)V
    .registers 7

    .line 1
    invoke-super {p0, p1}, Landroidx/fragment/app/g;->onSaveInstanceState(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    const-string v0, "OVERRIDE_THEME_RES_ID"

    .line 5
    .line 6
    iget v1, p0, Lpq1;->f:I

    .line 7
    .line 8
    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 9
    .line 10
    .line 11
    const-string v0, "DATE_SELECTOR_KEY"

    .line 12
    .line 13
    iget-object v1, p0, Lpq1;->j:Lro2;

    .line 14
    .line 15
    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    .line 16
    .line 17
    .line 18
    new-instance v0, Lfo;

    .line 19
    .line 20
    iget-object v1, p0, Lpq1;->m:Lgo;

    .line 21
    .line 22
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 23
    .line 24
    .line 25
    sget-wide v2, Lfo;->f:J

    .line 26
    .line 27
    iput-wide v2, v0, Lfo;->a:J

    .line 28
    .line 29
    sget-wide v2, Lfo;->g:J

    .line 30
    .line 31
    iput-wide v2, v0, Lfo;->b:J

    .line 32
    .line 33
    new-instance v2, Li60;

    .line 34
    .line 35
    const-wide/high16 v3, -0x8000000000000000L

    .line 36
    .line 37
    invoke-direct {v2, v3, v4}, Li60;-><init>(J)V

    .line 38
    .line 39
    .line 40
    iput-object v2, v0, Lfo;->e:Li60;

    .line 41
    .line 42
    iget-object v2, v1, Lgo;->a:Lcu1;

    .line 43
    .line 44
    iget-wide v2, v2, Lcu1;->f:J

    .line 45
    .line 46
    iput-wide v2, v0, Lfo;->a:J

    .line 47
    .line 48
    iget-object v2, v1, Lgo;->b:Lcu1;

    .line 49
    .line 50
    iget-wide v2, v2, Lcu1;->f:J

    .line 51
    .line 52
    iput-wide v2, v0, Lfo;->b:J

    .line 53
    .line 54
    iget-object v2, v1, Lgo;->d:Lcu1;

    .line 55
    .line 56
    iget-wide v2, v2, Lcu1;->f:J

    .line 57
    .line 58
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 59
    .line 60
    .line 61
    move-result-object v2

    .line 62
    iput-object v2, v0, Lfo;->c:Ljava/lang/Long;

    .line 63
    .line 64
    iget v2, v1, Lgo;->e:I

    .line 65
    .line 66
    iput v2, v0, Lfo;->d:I

    .line 67
    .line 68
    iget-object v1, v1, Lgo;->c:Li60;

    .line 69
    .line 70
    iput-object v1, v0, Lfo;->e:Li60;

    .line 71
    .line 72
    iget-object v1, p0, Lpq1;->n:Leq1;

    .line 73
    .line 74
    const/4 v2, 0x0

    .line 75
    if-nez v1, :cond_4e

    .line 76
    .line 77
    move-object v1, v2

    .line 78
    goto :goto_50

    .line 79
    :cond_4e
    iget-object v1, v1, Leq1;->f:Lcu1;

    .line 80
    .line 81
    :goto_50
    if-eqz v1, :cond_5a

    .line 82
    .line 83
    iget-wide v3, v1, Lcu1;->f:J

    .line 84
    .line 85
    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 86
    .line 87
    .line 88
    move-result-object v1

    .line 89
    iput-object v1, v0, Lfo;->c:Ljava/lang/Long;

    .line 90
    .line 91
    :cond_5a
    const-string v1, "CALENDAR_CONSTRAINTS_KEY"

    .line 92
    .line 93
    invoke-virtual {v0}, Lfo;->a()Lgo;

    .line 94
    .line 95
    .line 96
    move-result-object v0

    .line 97
    invoke-virtual {p1, v1, v0}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    .line 98
    .line 99
    .line 100
    const-string v0, "DAY_VIEW_DECORATOR_KEY"

    .line 101
    .line 102
    invoke-virtual {p1, v0, v2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    .line 103
    .line 104
    .line 105
    const-string v0, "TITLE_TEXT_RES_ID_KEY"

    .line 106
    .line 107
    iget v1, p0, Lpq1;->p:I

    .line 108
    .line 109
    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 110
    .line 111
    .line 112
    const-string v0, "TITLE_TEXT_KEY"

    .line 113
    .line 114
    iget-object v1, p0, Lpq1;->q:Ljava/lang/CharSequence;

    .line 115
    .line 116
    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    .line 117
    .line 118
    .line 119
    const-string v0, "INPUT_MODE_KEY"

    .line 120
    .line 121
    iget v1, p0, Lpq1;->s:I

    .line 122
    .line 123
    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 124
    .line 125
    .line 126
    const-string v0, "POSITIVE_BUTTON_TEXT_RES_ID_KEY"

    .line 127
    .line 128
    iget v1, p0, Lpq1;->t:I

    .line 129
    .line 130
    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 131
    .line 132
    .line 133
    const-string v0, "POSITIVE_BUTTON_TEXT_KEY"

    .line 134
    .line 135
    iget-object v1, p0, Lpq1;->u:Ljava/lang/CharSequence;

    .line 136
    .line 137
    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    .line 138
    .line 139
    .line 140
    const-string v0, "POSITIVE_BUTTON_CONTENT_DESCRIPTION_RES_ID_KEY"

    .line 141
    .line 142
    iget v1, p0, Lpq1;->v:I

    .line 143
    .line 144
    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 145
    .line 146
    .line 147
    const-string v0, "POSITIVE_BUTTON_CONTENT_DESCRIPTION_KEY"

    .line 148
    .line 149
    iget-object v1, p0, Lpq1;->P:Ljava/lang/CharSequence;

    .line 150
    .line 151
    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    .line 152
    .line 153
    .line 154
    const-string v0, "NEGATIVE_BUTTON_TEXT_RES_ID_KEY"

    .line 155
    .line 156
    iget v1, p0, Lpq1;->Q:I

    .line 157
    .line 158
    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 159
    .line 160
    .line 161
    const-string v0, "NEGATIVE_BUTTON_TEXT_KEY"

    .line 162
    .line 163
    iget-object v1, p0, Lpq1;->V:Ljava/lang/CharSequence;

    .line 164
    .line 165
    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    .line 166
    .line 167
    .line 168
    const-string v0, "NEGATIVE_BUTTON_CONTENT_DESCRIPTION_RES_ID_KEY"

    .line 169
    .line 170
    iget v1, p0, Lpq1;->X:I

    .line 171
    .line 172
    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 173
    .line 174
    .line 175
    const-string v0, "NEGATIVE_BUTTON_CONTENT_DESCRIPTION_KEY"

    .line 176
    .line 177
    iget-object p0, p0, Lpq1;->Y:Ljava/lang/CharSequence;

    .line 178
    .line 179
    invoke-virtual {p1, v0, p0}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    .line 180
    .line 181
    .line 182
    return-void
.end method

.method public final onStart()V
    .registers 13

    .line 1
    invoke-super {p0}, Landroidx/fragment/app/g;->onStart()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Landroidx/fragment/app/g;->requireDialog()Landroid/app/Dialog;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    iget-boolean v1, p0, Lpq1;->r:Z

    .line 13
    .line 14
    if-eqz v1, :cond_131

    .line 15
    .line 16
    const/4 v1, -0x1

    .line 17
    invoke-virtual {v0, v1, v1}, Landroid/view/Window;->setLayout(II)V

    .line 18
    .line 19
    .line 20
    iget-object v1, p0, Lpq1;->r0:Lyq1;

    .line 21
    .line 22
    invoke-virtual {v0, v1}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 23
    .line 24
    .line 25
    iget-boolean v1, p0, Lpq1;->t0:Z

    .line 26
    .line 27
    if-eqz v1, :cond_1e

    .line 28
    .line 29
    goto/16 :goto_162

    .line 30
    .line 31
    :cond_1e
    invoke-virtual {p0}, Landroidx/fragment/app/m;->requireView()Landroid/view/View;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    const v2, 0x7f09010b

    .line 36
    .line 37
    .line 38
    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 39
    .line 40
    .line 41
    move-result-object v4

    .line 42
    invoke-virtual {v4}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    invoke-static {v1}, Lxm3;->n(Landroid/graphics/drawable/Drawable;)Landroid/content/res/ColorStateList;

    .line 47
    .line 48
    .line 49
    move-result-object v1

    .line 50
    if-eqz v1, :cond_3c

    .line 51
    .line 52
    invoke-virtual {v1}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    .line 53
    .line 54
    .line 55
    move-result v1

    .line 56
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 57
    .line 58
    .line 59
    move-result-object v1

    .line 60
    goto :goto_3d

    .line 61
    :cond_3c
    const/4 v1, 0x0

    .line 62
    :goto_3d
    const/4 v2, 0x0

    .line 63
    const/4 v9, 0x1

    .line 64
    if-eqz v1, :cond_4a

    .line 65
    .line 66
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 67
    .line 68
    .line 69
    move-result v3

    .line 70
    if-nez v3, :cond_48

    .line 71
    .line 72
    goto :goto_4a

    .line 73
    :cond_48
    move v3, v2

    .line 74
    goto :goto_4b

    .line 75
    :cond_4a
    :goto_4a
    move v3, v9

    .line 76
    :goto_4b
    invoke-virtual {v0}, Landroid/view/Window;->getContext()Landroid/content/Context;

    .line 77
    .line 78
    .line 79
    move-result-object v5

    .line 80
    const v6, 0x1010031

    .line 81
    .line 82
    .line 83
    invoke-static {v5, v6}, Lmw0;->g(Landroid/content/Context;I)Ljava/lang/Integer;

    .line 84
    .line 85
    .line 86
    move-result-object v5

    .line 87
    const/high16 v6, -0x1000000

    .line 88
    .line 89
    if-eqz v5, :cond_5f

    .line 90
    .line 91
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    .line 92
    .line 93
    .line 94
    move-result v5

    .line 95
    goto :goto_60

    .line 96
    :cond_5f
    move v5, v6

    .line 97
    :goto_60
    if-eqz v3, :cond_66

    .line 98
    .line 99
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 100
    .line 101
    .line 102
    move-result-object v1

    .line 103
    :cond_66
    invoke-static {v0, v2}, Ld31;->w(Landroid/view/Window;Z)V

    .line 104
    .line 105
    .line 106
    invoke-virtual {v0}, Landroid/view/Window;->getContext()Landroid/content/Context;

    .line 107
    .line 108
    .line 109
    invoke-virtual {v0}, Landroid/view/Window;->getContext()Landroid/content/Context;

    .line 110
    .line 111
    .line 112
    move-result-object v3

    .line 113
    sget v7, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 114
    .line 115
    const/16 v8, 0x1b

    .line 116
    .line 117
    if-ge v7, v8, :cond_8a

    .line 118
    .line 119
    const v8, 0x1010452

    .line 120
    .line 121
    .line 122
    invoke-static {v3, v8}, Lmw0;->g(Landroid/content/Context;I)Ljava/lang/Integer;

    .line 123
    .line 124
    .line 125
    move-result-object v3

    .line 126
    if-eqz v3, :cond_83

    .line 127
    .line 128
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 129
    .line 130
    .line 131
    move-result v6

    .line 132
    :cond_83
    const/16 v3, 0x80

    .line 133
    .line 134
    invoke-static {v6, v3}, Lxv;->f(II)I

    .line 135
    .line 136
    .line 137
    move-result v3

    .line 138
    goto :goto_8b

    .line 139
    :cond_8a
    move v3, v2

    .line 140
    :goto_8b
    const/16 v6, 0x23

    .line 141
    .line 142
    if-ge v7, v6, :cond_92

    .line 143
    .line 144
    invoke-virtual {v0, v2}, Landroid/view/Window;->setStatusBarColor(I)V

    .line 145
    .line 146
    .line 147
    :cond_92
    if-ge v7, v6, :cond_97

    .line 148
    .line 149
    invoke-virtual {v0, v3}, Landroid/view/Window;->setNavigationBarColor(I)V

    .line 150
    .line 151
    .line 152
    :cond_97
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 153
    .line 154
    .line 155
    move-result v1

    .line 156
    invoke-static {v1}, Lmw0;->j(I)Z

    .line 157
    .line 158
    .line 159
    move-result v1

    .line 160
    invoke-static {v2}, Lmw0;->j(I)Z

    .line 161
    .line 162
    .line 163
    move-result v8

    .line 164
    if-nez v8, :cond_aa

    .line 165
    .line 166
    if-eqz v1, :cond_a8

    .line 167
    .line 168
    goto :goto_aa

    .line 169
    :cond_a8
    move v1, v2

    .line 170
    goto :goto_ab

    .line 171
    :cond_aa
    :goto_aa
    move v1, v9

    .line 172
    :goto_ab
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 173
    .line 174
    .line 175
    move-result-object v8

    .line 176
    new-instance v10, Lh01;

    .line 177
    .line 178
    invoke-direct {v10, v8}, Lh01;-><init>(Landroid/view/View;)V

    .line 179
    .line 180
    .line 181
    const/16 v8, 0x1a

    .line 182
    .line 183
    const/16 v11, 0x1e

    .line 184
    .line 185
    if-lt v7, v6, :cond_c0

    .line 186
    .line 187
    new-instance v7, Luc3;

    .line 188
    .line 189
    invoke-direct {v7, v0, v10}, Ltc3;-><init>(Landroid/view/Window;Lh01;)V

    .line 190
    .line 191
    .line 192
    goto :goto_d5

    .line 193
    :cond_c0
    if-lt v7, v11, :cond_c8

    .line 194
    .line 195
    new-instance v7, Ltc3;

    .line 196
    .line 197
    invoke-direct {v7, v0, v10}, Ltc3;-><init>(Landroid/view/Window;Lh01;)V

    .line 198
    .line 199
    .line 200
    goto :goto_d5

    .line 201
    :cond_c8
    if-lt v7, v8, :cond_d0

    .line 202
    .line 203
    new-instance v7, Lsc3;

    .line 204
    .line 205
    invoke-direct {v7, v0, v10}, Lrc3;-><init>(Landroid/view/Window;Lh01;)V

    .line 206
    .line 207
    .line 208
    goto :goto_d5

    .line 209
    :cond_d0
    new-instance v7, Lrc3;

    .line 210
    .line 211
    invoke-direct {v7, v0, v10}, Lrc3;-><init>(Landroid/view/Window;Lh01;)V

    .line 212
    .line 213
    .line 214
    :goto_d5
    invoke-virtual {v7, v1}, Lmw1;->D(Z)V

    .line 215
    .line 216
    .line 217
    invoke-static {v5}, Lmw0;->j(I)Z

    .line 218
    .line 219
    .line 220
    move-result v1

    .line 221
    invoke-static {v3}, Lmw0;->j(I)Z

    .line 222
    .line 223
    .line 224
    move-result v5

    .line 225
    if-nez v5, :cond_e6

    .line 226
    .line 227
    if-nez v3, :cond_e7

    .line 228
    .line 229
    if-eqz v1, :cond_e7

    .line 230
    .line 231
    :cond_e6
    move v2, v9

    .line 232
    :cond_e7
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 233
    .line 234
    .line 235
    move-result-object v1

    .line 236
    new-instance v3, Lh01;

    .line 237
    .line 238
    invoke-direct {v3, v1}, Lh01;-><init>(Landroid/view/View;)V

    .line 239
    .line 240
    .line 241
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 242
    .line 243
    if-lt v1, v6, :cond_fa

    .line 244
    .line 245
    new-instance v1, Luc3;

    .line 246
    .line 247
    invoke-direct {v1, v0, v3}, Ltc3;-><init>(Landroid/view/Window;Lh01;)V

    .line 248
    .line 249
    .line 250
    goto :goto_10f

    .line 251
    :cond_fa
    if-lt v1, v11, :cond_102

    .line 252
    .line 253
    new-instance v1, Ltc3;

    .line 254
    .line 255
    invoke-direct {v1, v0, v3}, Ltc3;-><init>(Landroid/view/Window;Lh01;)V

    .line 256
    .line 257
    .line 258
    goto :goto_10f

    .line 259
    :cond_102
    if-lt v1, v8, :cond_10a

    .line 260
    .line 261
    new-instance v1, Lsc3;

    .line 262
    .line 263
    invoke-direct {v1, v0, v3}, Lrc3;-><init>(Landroid/view/Window;Lh01;)V

    .line 264
    .line 265
    .line 266
    goto :goto_10f

    .line 267
    :cond_10a
    new-instance v1, Lrc3;

    .line 268
    .line 269
    invoke-direct {v1, v0, v3}, Lrc3;-><init>(Landroid/view/Window;Lh01;)V

    .line 270
    .line 271
    .line 272
    :goto_10f
    invoke-virtual {v1, v2}, Lmw1;->C(Z)V

    .line 273
    .line 274
    .line 275
    invoke-virtual {v4}, Landroid/view/View;->getPaddingTop()I

    .line 276
    .line 277
    .line 278
    move-result v7

    .line 279
    invoke-virtual {v4}, Landroid/view/View;->getPaddingLeft()I

    .line 280
    .line 281
    .line 282
    move-result v6

    .line 283
    invoke-virtual {v4}, Landroid/view/View;->getPaddingRight()I

    .line 284
    .line 285
    .line 286
    move-result v8

    .line 287
    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 288
    .line 289
    .line 290
    move-result-object v0

    .line 291
    iget v5, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 292
    .line 293
    new-instance v3, Lnq1;

    .line 294
    .line 295
    invoke-direct/range {v3 .. v8}, Lnq1;-><init>(Landroid/view/View;IIII)V

    .line 296
    .line 297
    .line 298
    sget-object v0, Ln83;->a:Ljava/util/WeakHashMap;

    .line 299
    .line 300
    invoke-static {v4, v3}, Lf83;->c(Landroid/view/View;Lbz1;)V

    .line 301
    .line 302
    .line 303
    iput-boolean v9, p0, Lpq1;->t0:Z

    .line 304
    .line 305
    goto :goto_162

    .line 306
    :cond_131
    const/4 v1, -0x2

    .line 307
    invoke-virtual {v0, v1, v1}, Landroid/view/Window;->setLayout(II)V

    .line 308
    .line 309
    .line 310
    invoke-virtual {p0}, Landroidx/fragment/app/m;->getResources()Landroid/content/res/Resources;

    .line 311
    .line 312
    .line 313
    move-result-object v1

    .line 314
    const v2, 0x7f0703be

    .line 315
    .line 316
    .line 317
    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    .line 318
    .line 319
    .line 320
    move-result v5

    .line 321
    new-instance v1, Landroid/graphics/Rect;

    .line 322
    .line 323
    invoke-direct {v1, v5, v5, v5, v5}, Landroid/graphics/Rect;-><init>(IIII)V

    .line 324
    .line 325
    .line 326
    new-instance v3, Landroid/graphics/drawable/InsetDrawable;

    .line 327
    .line 328
    iget-object v4, p0, Lpq1;->r0:Lyq1;

    .line 329
    .line 330
    move v6, v5

    .line 331
    move v7, v5

    .line 332
    move v8, v5

    .line 333
    invoke-direct/range {v3 .. v8}, Landroid/graphics/drawable/InsetDrawable;-><init>(Landroid/graphics/drawable/Drawable;IIII)V

    .line 334
    .line 335
    .line 336
    invoke-virtual {v0, v3}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 337
    .line 338
    .line 339
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 340
    .line 341
    .line 342
    move-result-object v0

    .line 343
    new-instance v2, Lu11;

    .line 344
    .line 345
    invoke-virtual {p0}, Landroidx/fragment/app/g;->requireDialog()Landroid/app/Dialog;

    .line 346
    .line 347
    .line 348
    move-result-object v3

    .line 349
    invoke-direct {v2, v3, v1}, Lu11;-><init>(Landroid/app/Dialog;Landroid/graphics/Rect;)V

    .line 350
    .line 351
    .line 352
    invoke-virtual {v0, v2}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 353
    .line 354
    .line 355
    :goto_162
    invoke-virtual {p0}, Lpq1;->s()V

    .line 356
    .line 357
    .line 358
    return-void
.end method

.method public final onStop()V
    .registers 2

    .line 1
    iget-object v0, p0, Lpq1;->l:Lq12;

    .line 2
    .line 3
    iget-object v0, v0, Lq12;->b:Ljava/util/LinkedHashSet;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/util/AbstractCollection;->clear()V

    .line 6
    .line 7
    .line 8
    invoke-super {p0}, Landroidx/fragment/app/g;->onStop()V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final p()Ljava/lang/String;
    .registers 3

    .line 1
    invoke-virtual {p0}, Lpq1;->o()Lro2;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {p0}, Landroidx/fragment/app/m;->getContext()Landroid/content/Context;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    iget-object v0, v0, Lro2;->a:Ljava/lang/Long;

    .line 17
    .line 18
    if-nez v0, :cond_1b

    .line 19
    .line 20
    const v0, 0x7f1200c4

    .line 21
    .line 22
    .line 23
    invoke-virtual {p0, v0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    return-object p0

    .line 28
    :cond_1b
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 29
    .line 30
    .line 31
    move-result-wide v0

    .line 32
    invoke-static {v0, v1}, Lkm2;->o(J)Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    const v1, 0x7f1200c2

    .line 37
    .line 38
    .line 39
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    invoke-virtual {p0, v1, v0}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object p0

    .line 47
    return-object p0
.end method

.method public final s()V
    .registers 11

    .line 1
    invoke-virtual {p0}, Landroidx/fragment/app/m;->requireContext()Landroid/content/Context;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget v1, p0, Lpq1;->f:I

    .line 6
    .line 7
    if-eqz v1, :cond_9

    .line 8
    .line 9
    goto :goto_1f

    .line 10
    :cond_9
    invoke-virtual {p0}, Lpq1;->o()Lro2;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    const-class v1, Lpq1;

    .line 18
    .line 19
    invoke-virtual {v1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    const v2, 0x7f040387

    .line 24
    .line 25
    .line 26
    invoke-static {v2, v0, v1}, Llw0;->m0(ILandroid/content/Context;Ljava/lang/String;)Landroid/util/TypedValue;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    iget v1, v0, Landroid/util/TypedValue;->data:I

    .line 31
    .line 32
    :goto_1f
    iget v0, p0, Lpq1;->s:I

    .line 33
    .line 34
    const/4 v2, 0x1

    .line 35
    if-ne v0, v2, :cond_27

    .line 36
    .line 37
    const-string v0, "TEXT_INPUT_FRAGMENT_TAG"

    .line 38
    .line 39
    goto :goto_29

    .line 40
    :cond_27
    const-string v0, "CALENDAR_FRAGMENT_TAG"

    .line 41
    .line 42
    :goto_29
    invoke-virtual {p0}, Landroidx/fragment/app/m;->getChildFragmentManager()Landroidx/fragment/app/u;

    .line 43
    .line 44
    .line 45
    move-result-object v3

    .line 46
    invoke-virtual {v3, v0}, Landroidx/fragment/app/u;->B(Ljava/lang/String;)Landroidx/fragment/app/m;

    .line 47
    .line 48
    .line 49
    move-result-object v3

    .line 50
    instance-of v4, v3, Lq12;

    .line 51
    .line 52
    const/4 v5, 0x0

    .line 53
    if-eqz v4, :cond_39

    .line 54
    .line 55
    check-cast v3, Lq12;

    .line 56
    .line 57
    goto :goto_3a

    .line 58
    :cond_39
    move-object v3, v5

    .line 59
    :goto_3a
    if-nez v3, :cond_91

    .line 60
    .line 61
    iget v3, p0, Lpq1;->s:I

    .line 62
    .line 63
    const-string v4, "CALENDAR_CONSTRAINTS_KEY"

    .line 64
    .line 65
    const-string v6, "THEME_RES_ID_KEY"

    .line 66
    .line 67
    if-ne v3, v2, :cond_64

    .line 68
    .line 69
    invoke-virtual {p0}, Lpq1;->o()Lro2;

    .line 70
    .line 71
    .line 72
    move-result-object v3

    .line 73
    iget-object v5, p0, Lpq1;->m:Lgo;

    .line 74
    .line 75
    new-instance v7, Lbr1;

    .line 76
    .line 77
    invoke-direct {v7}, Lbr1;-><init>()V

    .line 78
    .line 79
    .line 80
    new-instance v8, Landroid/os/Bundle;

    .line 81
    .line 82
    invoke-direct {v8}, Landroid/os/Bundle;-><init>()V

    .line 83
    .line 84
    .line 85
    invoke-virtual {v8, v6, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 86
    .line 87
    .line 88
    const-string v1, "DATE_SELECTOR_KEY"

    .line 89
    .line 90
    invoke-virtual {v8, v1, v3}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    .line 91
    .line 92
    .line 93
    invoke-virtual {v8, v4, v5}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    .line 94
    .line 95
    .line 96
    invoke-virtual {v7, v8}, Landroidx/fragment/app/m;->setArguments(Landroid/os/Bundle;)V

    .line 97
    .line 98
    .line 99
    move-object v3, v7

    .line 100
    goto :goto_91

    .line 101
    :cond_64
    invoke-virtual {p0}, Lpq1;->o()Lro2;

    .line 102
    .line 103
    .line 104
    move-result-object v3

    .line 105
    iget-object v7, p0, Lpq1;->m:Lgo;

    .line 106
    .line 107
    new-instance v8, Leq1;

    .line 108
    .line 109
    invoke-direct {v8}, Leq1;-><init>()V

    .line 110
    .line 111
    .line 112
    new-instance v9, Landroid/os/Bundle;

    .line 113
    .line 114
    invoke-direct {v9}, Landroid/os/Bundle;-><init>()V

    .line 115
    .line 116
    .line 117
    invoke-virtual {v9, v6, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 118
    .line 119
    .line 120
    const-string v1, "GRID_SELECTOR_KEY"

    .line 121
    .line 122
    invoke-virtual {v9, v1, v3}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    .line 123
    .line 124
    .line 125
    invoke-virtual {v9, v4, v7}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    .line 126
    .line 127
    .line 128
    const-string v1, "DAY_VIEW_DECORATOR_KEY"

    .line 129
    .line 130
    invoke-virtual {v9, v1, v5}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    .line 131
    .line 132
    .line 133
    const-string v1, "CURRENT_MONTH_KEY"

    .line 134
    .line 135
    iget-object v3, v7, Lgo;->d:Lcu1;

    .line 136
    .line 137
    invoke-virtual {v9, v1, v3}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    .line 138
    .line 139
    .line 140
    invoke-virtual {v8, v9}, Landroidx/fragment/app/m;->setArguments(Landroid/os/Bundle;)V

    .line 141
    .line 142
    .line 143
    iput-object v8, p0, Lpq1;->n:Leq1;

    .line 144
    .line 145
    move-object v3, v8

    .line 146
    :cond_91
    :goto_91
    iput-object v3, p0, Lpq1;->l:Lq12;

    .line 147
    .line 148
    new-instance v1, Loq1;

    .line 149
    .line 150
    const/4 v4, 0x0

    .line 151
    invoke-direct {v1, p0, v4}, Loq1;-><init>(Landroidx/fragment/app/m;I)V

    .line 152
    .line 153
    .line 154
    invoke-virtual {v3, v1}, Lq12;->n(Loq1;)V

    .line 155
    .line 156
    .line 157
    iget-object v1, p0, Lpq1;->Z:Landroid/widget/TextView;

    .line 158
    .line 159
    iget v3, p0, Lpq1;->s:I

    .line 160
    .line 161
    if-ne v3, v2, :cond_b2

    .line 162
    .line 163
    invoke-virtual {p0}, Landroidx/fragment/app/m;->getResources()Landroid/content/res/Resources;

    .line 164
    .line 165
    .line 166
    move-result-object v2

    .line 167
    invoke-virtual {v2}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 168
    .line 169
    .line 170
    move-result-object v2

    .line 171
    iget v2, v2, Landroid/content/res/Configuration;->orientation:I

    .line 172
    .line 173
    const/4 v3, 0x2

    .line 174
    if-ne v2, v3, :cond_b2

    .line 175
    .line 176
    iget-object v2, p0, Lpq1;->v0:Ljava/lang/CharSequence;

    .line 177
    .line 178
    goto :goto_b4

    .line 179
    :cond_b2
    iget-object v2, p0, Lpq1;->u0:Ljava/lang/CharSequence;

    .line 180
    .line 181
    :goto_b4
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 182
    .line 183
    .line 184
    invoke-virtual {p0}, Lpq1;->p()Ljava/lang/String;

    .line 185
    .line 186
    .line 187
    move-result-object v1

    .line 188
    invoke-virtual {p0, v1}, Lpq1;->t(Ljava/lang/String;)V

    .line 189
    .line 190
    .line 191
    invoke-virtual {p0}, Landroidx/fragment/app/m;->getChildFragmentManager()Landroidx/fragment/app/u;

    .line 192
    .line 193
    .line 194
    move-result-object v1

    .line 195
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 196
    .line 197
    .line 198
    new-instance v2, Landroidx/fragment/app/a;

    .line 199
    .line 200
    invoke-direct {v2, v1}, Landroidx/fragment/app/a;-><init>(Landroidx/fragment/app/u;)V

    .line 201
    .line 202
    .line 203
    const v1, 0x7f09016c

    .line 204
    .line 205
    .line 206
    iget-object p0, p0, Lpq1;->l:Lq12;

    .line 207
    .line 208
    invoke-virtual {v2, v1, p0, v0}, Lcs0;->d(ILandroidx/fragment/app/m;Ljava/lang/String;)V

    .line 209
    .line 210
    .line 211
    iget-boolean p0, v2, Lcs0;->g:Z

    .line 212
    .line 213
    if-nez p0, :cond_dc

    .line 214
    .line 215
    iget-object p0, v2, Landroidx/fragment/app/a;->p:Landroidx/fragment/app/u;

    .line 216
    .line 217
    invoke-virtual {p0, v2, v4}, Landroidx/fragment/app/u;->y(Landroidx/fragment/app/a;Z)V

    .line 218
    .line 219
    .line 220
    return-void

    .line 221
    :cond_dc
    const-string p0, "This transaction is already being added to the back stack"

    .line 222
    .line 223
    invoke-static {p0}, Ly0;->h(Ljava/lang/String;)V

    .line 224
    .line 225
    .line 226
    return-void
.end method

.method public final t(Ljava/lang/String;)V
    .registers 7

    .line 1
    iget-object v0, p0, Lpq1;->p0:Landroid/widget/TextView;

    .line 2
    .line 3
    invoke-virtual {p0}, Lpq1;->o()Lro2;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    invoke-virtual {p0}, Landroidx/fragment/app/m;->requireContext()Landroid/content/Context;

    .line 8
    .line 9
    .line 10
    move-result-object v2

    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 15
    .line 16
    .line 17
    move-result-object v2

    .line 18
    iget-object v1, v1, Lro2;->a:Ljava/lang/Long;

    .line 19
    .line 20
    if-nez v1, :cond_1d

    .line 21
    .line 22
    const v1, 0x7f1200bf

    .line 23
    .line 24
    .line 25
    invoke-virtual {v2, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    goto :goto_25

    .line 30
    :cond_1d
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 31
    .line 32
    .line 33
    move-result-wide v3

    .line 34
    invoke-static {v3, v4}, Lkm2;->o(J)Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v1

    .line 38
    :goto_25
    const v3, 0x7f1200be

    .line 39
    .line 40
    .line 41
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    invoke-virtual {v2, v3, v1}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    invoke-virtual {v0, v1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 50
    .line 51
    .line 52
    iget-object p0, p0, Lpq1;->p0:Landroid/widget/TextView;

    .line 53
    .line 54
    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 55
    .line 56
    .line 57
    return-void
.end method

.method public final u(Lcom/google/android/material/internal/CheckableImageButton;)V
    .registers 4

    .line 1
    iget v0, p0, Lpq1;->s:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-ne v0, v1, :cond_11

    .line 5
    .line 6
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    const v0, 0x7f1200e0

    .line 11
    .line 12
    .line 13
    invoke-virtual {p1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    goto :goto_1c

    .line 18
    :cond_11
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    const v0, 0x7f1200e3

    .line 23
    .line 24
    .line 25
    invoke-virtual {p1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    :goto_1c
    iget-object p0, p0, Lpq1;->q0:Lcom/google/android/material/internal/CheckableImageButton;

    .line 30
    .line 31
    invoke-virtual {p0, p1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 32
    .line 33
    .line 34
    return-void
.end method

.method public final v(Lcom/google/android/material/internal/CheckableImageButton;)V
    .registers 4

    .line 1
    iget v0, p0, Lpq1;->s:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-ne v0, v1, :cond_11

    .line 5
    .line 6
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    const v0, 0x7f1200e1

    .line 11
    .line 12
    .line 13
    invoke-virtual {p1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    goto :goto_1c

    .line 18
    :cond_11
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    const v0, 0x7f1200e4

    .line 23
    .line 24
    .line 25
    invoke-virtual {p1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    :goto_1c
    iget-object p0, p0, Lpq1;->q0:Lcom/google/android/material/internal/CheckableImageButton;

    .line 30
    .line 31
    invoke-static {p0, p1}, Liw0;->s(Landroid/view/View;Ljava/lang/CharSequence;)V

    .line 32
    .line 33
    .line 34
    return-void
.end method

###### Class defpackage.mq1 (mq1)
.class public final synthetic Lmq1;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lpq1;


# direct methods
.method public synthetic constructor <init>(Lpq1;I)V
    .registers 3

    .line 1
    iput p2, p0, Lmq1;->a:I

    .line 2
    .line 3
    iput-object p1, p0, Lmq1;->b:Lpq1;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 5

    .line 1
    iget v0, p0, Lmq1;->a:I

    .line 2
    .line 3
    iget-object p0, p0, Lmq1;->b:Lpq1;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_70

    .line 6
    .line 7
    .line 8
    iget-object p1, p0, Lpq1;->s0:Landroid/widget/Button;

    .line 9
    .line 10
    invoke-virtual {p0}, Lpq1;->o()Lro2;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iget-object v0, v0, Lro2;->a:Ljava/lang/Long;

    .line 15
    .line 16
    const/4 v1, 0x0

    .line 17
    const/4 v2, 0x1

    .line 18
    if-eqz v0, :cond_15

    .line 19
    .line 20
    move v0, v2

    .line 21
    goto :goto_16

    .line 22
    :cond_15
    move v0, v1

    .line 23
    :goto_16
    invoke-virtual {p1, v0}, Landroid/view/View;->setEnabled(Z)V

    .line 24
    .line 25
    .line 26
    iget-object p1, p0, Lpq1;->q0:Lcom/google/android/material/internal/CheckableImageButton;

    .line 27
    .line 28
    invoke-virtual {p1}, Lcom/google/android/material/internal/CheckableImageButton;->toggle()V

    .line 29
    .line 30
    .line 31
    iget p1, p0, Lpq1;->s:I

    .line 32
    .line 33
    if-ne p1, v2, :cond_23

    .line 34
    .line 35
    goto :goto_24

    .line 36
    :cond_23
    move v1, v2

    .line 37
    :goto_24
    iput v1, p0, Lpq1;->s:I

    .line 38
    .line 39
    iget-object p1, p0, Lpq1;->q0:Lcom/google/android/material/internal/CheckableImageButton;

    .line 40
    .line 41
    invoke-virtual {p0, p1}, Lpq1;->u(Lcom/google/android/material/internal/CheckableImageButton;)V

    .line 42
    .line 43
    .line 44
    iget-object p1, p0, Lpq1;->q0:Lcom/google/android/material/internal/CheckableImageButton;

    .line 45
    .line 46
    invoke-virtual {p0, p1}, Lpq1;->v(Lcom/google/android/material/internal/CheckableImageButton;)V

    .line 47
    .line 48
    .line 49
    invoke-virtual {p0}, Lpq1;->s()V

    .line 50
    .line 51
    .line 52
    return-void

    .line 53
    :pswitch_34
    iget-object v0, p0, Lpq1;->c:Ljava/util/LinkedHashSet;

    .line 54
    .line 55
    invoke-virtual {v0}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    :goto_3a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 60
    .line 61
    .line 62
    move-result v1

    .line 63
    if-eqz v1, :cond_4a

    .line 64
    .line 65
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object v1

    .line 69
    check-cast v1, Landroid/view/View$OnClickListener;

    .line 70
    .line 71
    invoke-interface {v1, p1}, Landroid/view/View$OnClickListener;->onClick(Landroid/view/View;)V

    .line 72
    .line 73
    .line 74
    goto :goto_3a

    .line 75
    :cond_4a
    invoke-virtual {p0}, Landroidx/fragment/app/g;->dismiss()V

    .line 76
    .line 77
    .line 78
    return-void

    .line 79
    :pswitch_4e
    iget-object p1, p0, Lpq1;->b:Ljava/util/LinkedHashSet;

    .line 80
    .line 81
    invoke-virtual {p1}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    .line 82
    .line 83
    .line 84
    move-result-object p1

    .line 85
    :goto_54
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 86
    .line 87
    .line 88
    move-result v0

    .line 89
    if-eqz v0, :cond_6c

    .line 90
    .line 91
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 92
    .line 93
    .line 94
    move-result-object v0

    .line 95
    check-cast v0, Lao1;

    .line 96
    .line 97
    invoke-virtual {p0}, Lpq1;->o()Lro2;

    .line 98
    .line 99
    .line 100
    move-result-object v1

    .line 101
    iget-object v1, v1, Lro2;->a:Ljava/lang/Long;

    .line 102
    .line 103
    iget-object v0, v0, Lao1;->a:Lzn1;

    .line 104
    .line 105
    invoke-static {v0, v1}, Lcc/bomber/ui/MainActivity;->X(Lzn1;Ljava/lang/Long;)V

    .line 106
    .line 107
    .line 108
    goto :goto_54

    .line 109
    :cond_6c
    invoke-virtual {p0}, Landroidx/fragment/app/g;->dismiss()V

    .line 110
    .line 111
    .line 112
    return-void

    .line 113
    :pswitch_data_70
    .packed-switch 0x0
        :pswitch_4e
        :pswitch_34
    .end packed-switch
.end method
