###### Class defpackage.q9 (q9)
.class public final Lq9;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 1
    iput p1, p0, Lq9;->a:I

    .line 2
    .line 3
    iput-object p2, p0, Lq9;->b:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .registers 15

    .line 1
    iget p1, p0, Lq9;->a:I

    .line 2
    .line 3
    iget-object p0, p0, Lq9;->b:Ljava/lang/Object;

    .line 4
    .line 5
    packed-switch p1, :pswitch_data_96

    .line 6
    .line 7
    .line 8
    check-cast p0, Lhp1;

    .line 9
    .line 10
    iget-object p1, p0, Lhp1;->e:Luk1;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    if-gez p3, :cond_1f

    .line 14
    .line 15
    iget-object v1, p1, Luk1;->C:Lh9;

    .line 16
    .line 17
    invoke-virtual {v1}, Landroid/widget/PopupWindow;->isShowing()Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-nez v1, :cond_18

    .line 22
    .line 23
    move-object v1, v0

    .line 24
    goto :goto_27

    .line 25
    :cond_18
    iget-object v1, p1, Luk1;->c:Lcf0;

    .line 26
    .line 27
    invoke-virtual {v1}, Landroid/widget/AdapterView;->getSelectedItem()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    goto :goto_27

    .line 32
    :cond_1f
    invoke-virtual {p0}, Landroid/widget/AutoCompleteTextView;->getAdapter()Landroid/widget/ListAdapter;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    invoke-interface {v1, p3}, Landroid/widget/Adapter;->getItem(I)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    :goto_27
    invoke-static {p0, v1}, Lhp1;->a(Lhp1;Ljava/lang/Object;)Ljava/lang/CharSequence;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    const/4 v2, 0x0

    .line 45
    invoke-virtual {p0, v1, v2}, Landroid/widget/AutoCompleteTextView;->setText(Ljava/lang/CharSequence;Z)V

    .line 46
    .line 47
    .line 48
    invoke-virtual {p0}, Landroid/widget/AutoCompleteTextView;->getOnItemClickListener()Landroid/widget/AdapterView$OnItemClickListener;

    .line 49
    .line 50
    .line 51
    move-result-object v3

    .line 52
    if-eqz v3, :cond_78

    .line 53
    .line 54
    if-eqz p2, :cond_3e

    .line 55
    .line 56
    if-gez p3, :cond_3a

    .line 57
    .line 58
    goto :goto_3e

    .line 59
    :cond_3a
    :goto_3a
    move-object v5, p2

    .line 60
    move v6, p3

    .line 61
    move-wide v7, p4

    .line 62
    goto :goto_73

    .line 63
    :cond_3e
    :goto_3e
    iget-object p0, p1, Luk1;->C:Lh9;

    .line 64
    .line 65
    invoke-virtual {p0}, Landroid/widget/PopupWindow;->isShowing()Z

    .line 66
    .line 67
    .line 68
    move-result p0

    .line 69
    if-nez p0, :cond_48

    .line 70
    .line 71
    move-object p2, v0

    .line 72
    goto :goto_4f

    .line 73
    :cond_48
    iget-object p0, p1, Luk1;->c:Lcf0;

    .line 74
    .line 75
    invoke-virtual {p0}, Landroid/widget/AdapterView;->getSelectedView()Landroid/view/View;

    .line 76
    .line 77
    .line 78
    move-result-object p0

    .line 79
    move-object p2, p0

    .line 80
    :goto_4f
    iget-object p0, p1, Luk1;->C:Lh9;

    .line 81
    .line 82
    invoke-virtual {p0}, Landroid/widget/PopupWindow;->isShowing()Z

    .line 83
    .line 84
    .line 85
    move-result p0

    .line 86
    if-nez p0, :cond_5a

    .line 87
    .line 88
    const/4 p0, -0x1

    .line 89
    :goto_58
    move p3, p0

    .line 90
    goto :goto_61

    .line 91
    :cond_5a
    iget-object p0, p1, Luk1;->c:Lcf0;

    .line 92
    .line 93
    invoke-virtual {p0}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    .line 94
    .line 95
    .line 96
    move-result p0

    .line 97
    goto :goto_58

    .line 98
    :goto_61
    iget-object p0, p1, Luk1;->C:Lh9;

    .line 99
    .line 100
    invoke-virtual {p0}, Landroid/widget/PopupWindow;->isShowing()Z

    .line 101
    .line 102
    .line 103
    move-result p0

    .line 104
    if-nez p0, :cond_6c

    .line 105
    .line 106
    const-wide/high16 p4, -0x8000000000000000L

    .line 107
    .line 108
    goto :goto_3a

    .line 109
    :cond_6c
    iget-object p0, p1, Luk1;->c:Lcf0;

    .line 110
    .line 111
    invoke-virtual {p0}, Landroid/widget/AdapterView;->getSelectedItemId()J

    .line 112
    .line 113
    .line 114
    move-result-wide p4

    .line 115
    goto :goto_3a

    .line 116
    :goto_73
    iget-object v4, p1, Luk1;->c:Lcf0;

    .line 117
    .line 118
    invoke-interface/range {v3 .. v8}, Landroid/widget/AdapterView$OnItemClickListener;->onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V

    .line 119
    .line 120
    .line 121
    :cond_78
    invoke-virtual {p1}, Luk1;->dismiss()V

    .line 122
    .line 123
    .line 124
    return-void

    .line 125
    :pswitch_7c
    check-cast p0, Ls9;

    .line 126
    .line 127
    iget-object p1, p0, Ls9;->J:Landroidx/appcompat/widget/AppCompatSpinner;

    .line 128
    .line 129
    invoke-virtual {p1, p3}, Landroid/widget/AdapterView;->setSelection(I)V

    .line 130
    .line 131
    .line 132
    invoke-virtual {p1}, Landroid/widget/AdapterView;->getOnItemClickListener()Landroid/widget/AdapterView$OnItemClickListener;

    .line 133
    .line 134
    .line 135
    move-result-object p4

    .line 136
    if-eqz p4, :cond_92

    .line 137
    .line 138
    iget-object p4, p0, Ls9;->G:Lp9;

    .line 139
    .line 140
    invoke-virtual {p4, p3}, Lp9;->getItemId(I)J

    .line 141
    .line 142
    .line 143
    move-result-wide p4

    .line 144
    invoke-virtual {p1, p2, p3, p4, p5}, Landroid/widget/AdapterView;->performItemClick(Landroid/view/View;IJ)Z

    .line 145
    .line 146
    .line 147
    :cond_92
    invoke-virtual {p0}, Luk1;->dismiss()V

    .line 148
    .line 149
    .line 150
    return-void

    .line 151
    :pswitch_data_96
    .packed-switch 0x0
        :pswitch_7c
    .end packed-switch
.end method
