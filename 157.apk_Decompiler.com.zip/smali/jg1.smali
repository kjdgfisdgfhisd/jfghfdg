###### Class defpackage.jg1 (jg1)
.class public final Ljg1;
.super Ljava/lang/Object;

# interfaces
.implements Lft0;


# instance fields
.field public final synthetic a:I

.field public final b:Lp13;


# direct methods
.method public constructor <init>(Lg13;Lp13;Ljava/util/List;Z)V
    .registers 5

    const/4 p1, 0x0

    iput p1, p0, Ljg1;->a:I

    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Ljg1;->b:Lp13;

    return-void
.end method

.method public constructor <init>(Lvr1;Lg13;Lp13;Ljava/util/List;Z)V
    .registers 6

    .line 1
    const/4 p1, 0x1

    .line 2
    iput p1, p0, Ljg1;->a:I

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p3, p0, Ljg1;->b:Lp13;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    iget v0, p0, Ljg1;->a:I

    .line 2
    .line 3
    check-cast p1, Llg1;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_1a

    .line 6
    .line 7
    .line 8
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    .line 10
    .line 11
    iget-object p0, p0, Ljg1;->b:Lp13;

    .line 12
    .line 13
    invoke-interface {p0}, Lp13;->c()Lau;

    .line 14
    .line 15
    .line 16
    :goto_f
    const/4 p0, 0x0

    .line 17
    return-object p0

    .line 18
    :pswitch_11
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    .line 20
    .line 21
    iget-object p0, p0, Ljg1;->b:Lp13;

    .line 22
    .line 23
    invoke-interface {p0}, Lp13;->c()Lau;

    .line 24
    .line 25
    .line 26
    goto :goto_f

    .line 27
    :pswitch_data_1a
    .packed-switch 0x0
        :pswitch_11
    .end packed-switch
.end method
