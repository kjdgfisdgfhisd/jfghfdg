###### Class defpackage.z81 (z81)
.class public final Lz81;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lwk2;


# static fields
.field public static final b:Lz81;

.field public static final c:Ljava/lang/String;


# instance fields
.field public final synthetic a:Lbk1;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Lz81;

    .line 2
    .line 3
    invoke-direct {v0}, Lz81;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lz81;->b:Lz81;

    .line 7
    .line 8
    const-string v0, "kotlinx.serialization.json.JsonObject"

    .line 9
    .line 10
    sput-object v0, Lz81;->c:Ljava/lang/String;

    .line 11
    .line 12
    return-void
.end method

.method public constructor <init>()V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lut2;->a:Lut2;

    .line 5
    .line 6
    sget-object v0, Lg71;->a:Lg71;

    .line 7
    .line 8
    sget-object v1, Lut2;->a:Lut2;

    .line 9
    .line 10
    new-instance v1, Lbk1;

    .line 11
    .line 12
    sget-object v2, Lut2;->b:Lc42;

    .line 13
    .line 14
    invoke-interface {v0}, Lif1;->getDescriptor()Lwk2;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    invoke-direct {v1, v2, v0}, Lbk1;-><init>(Lwk2;Lwk2;)V

    .line 19
    .line 20
    .line 21
    iput-object v1, p0, Lz81;->a:Lbk1;

    .line 22
    .line 23
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;)I
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lz81;->a:Lbk1;

    .line 5
    .line 6
    invoke-virtual {p0, p1}, Lbk1;->a(Ljava/lang/String;)I

    .line 7
    .line 8
    .line 9
    move-result p0

    .line 10
    return p0
.end method

.method public final b()Ljava/lang/String;
    .registers 1

    .line 1
    sget-object p0, Lz81;->c:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final c()I
    .registers 1

    .line 1
    const/4 p0, 0x2

    .line 2
    return p0
.end method

.method public final d(I)Ljava/lang/String;
    .registers 2

    .line 1
    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public final f()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final g(I)Ljava/util/List;
    .registers 2

    .line 1
    iget-object p0, p0, Lz81;->a:Lbk1;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lbk1;->g(I)Ljava/util/List;

    .line 4
    .line 5
    .line 6
    sget-object p0, Lth0;->a:Lth0;

    .line 7
    .line 8
    return-object p0
.end method

.method public final getAnnotations()Ljava/util/List;
    .registers 1

    .line 1
    sget-object p0, Lth0;->a:Lth0;

    .line 2
    .line 3
    return-object p0
.end method

.method public final h(I)Lwk2;
    .registers 2

    .line 1
    iget-object p0, p0, Lz81;->a:Lbk1;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lbk1;->h(I)Lwk2;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final i(I)Z
    .registers 2

    .line 1
    iget-object p0, p0, Lz81;->a:Lbk1;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lbk1;->i(I)Z

    .line 4
    .line 5
    .line 6
    const/4 p0, 0x0

    .line 7
    return p0
.end method

.method public final j()Lg70;
    .registers 1

    .line 1
    sget-object p0, Lhu2;->k:Lhu2;

    .line 2
    .line 3
    return-object p0
.end method

.method public final o()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method
