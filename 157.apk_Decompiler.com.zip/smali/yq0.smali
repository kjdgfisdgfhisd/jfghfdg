###### Class defpackage.yq0 (yq0)
.class public final Lyq0;
.super Lhy2;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public e:Lhy2;


# direct methods
.method public constructor <init>(Lhy2;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lyq0;->e:Lhy2;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final a()Lhy2;
    .registers 1

    .line 1
    iget-object p0, p0, Lyq0;->e:Lhy2;

    .line 2
    .line 3
    invoke-virtual {p0}, Lhy2;->a()Lhy2;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final b()Lhy2;
    .registers 1

    .line 1
    iget-object p0, p0, Lyq0;->e:Lhy2;

    .line 2
    .line 3
    invoke-virtual {p0}, Lhy2;->b()Lhy2;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final c()J
    .registers 3

    .line 1
    iget-object p0, p0, Lyq0;->e:Lhy2;

    .line 2
    .line 3
    invoke-virtual {p0}, Lhy2;->c()J

    .line 4
    .line 5
    .line 6
    move-result-wide v0

    .line 7
    return-wide v0
.end method

.method public final d(J)Lhy2;
    .registers 3

    .line 1
    iget-object p0, p0, Lyq0;->e:Lhy2;

    .line 2
    .line 3
    invoke-virtual {p0, p1, p2}, Lhy2;->d(J)Lhy2;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final e()Z
    .registers 1

    .line 1
    iget-object p0, p0, Lyq0;->e:Lhy2;

    .line 2
    .line 3
    invoke-virtual {p0}, Lhy2;->e()Z

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final f()V
    .registers 1

    .line 1
    iget-object p0, p0, Lyq0;->e:Lhy2;

    .line 2
    .line 3
    invoke-virtual {p0}, Lhy2;->f()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final g(J)Lhy2;
    .registers 4

    .line 1
    sget-object v0, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    iget-object p0, p0, Lyq0;->e:Lhy2;

    .line 7
    .line 8
    invoke-virtual {p0, p1, p2}, Lhy2;->g(J)Lhy2;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method
