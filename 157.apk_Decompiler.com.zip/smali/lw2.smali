###### Class defpackage.lw2 (lw2)
.class public interface abstract Llw2;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Laj1;


# virtual methods
.method public abstract a(Landroid/graphics/drawable/Drawable;)V
.end method

.method public abstract c(Ljp2;)V
.end method

.method public abstract d(Ljava/lang/Object;Lvz2;)V
.end method

.method public abstract e(Ljp2;)V
.end method

.method public abstract f(Lxe2;)V
.end method

.method public abstract g(Landroid/graphics/drawable/Drawable;)V
.end method

.method public abstract h()Lxe2;
.end method

.method public abstract i(Landroid/graphics/drawable/Drawable;)V
.end method
