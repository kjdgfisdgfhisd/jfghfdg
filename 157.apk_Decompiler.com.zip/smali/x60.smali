###### Class defpackage.x60 (x60)
.class public final Lx60;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lm50;
.implements Ljava/lang/Runnable;
.implements Ljava/lang/Comparable;
.implements Lxl0;


# static fields
.field public static final K:Lh02;


# instance fields
.field public A:Lqf1;

.field public B:Ljava/lang/Object;

.field public C:Lu50;

.field public D:Ll50;

.field public volatile E:Ln50;

.field public volatile F:Z

.field public volatile G:Z

.field public H:Z

.field public I:I

.field public J:I

.field public final a:Lv60;

.field public final b:Ljava/util/ArrayList;

.field public final c:Lis2;

.field public final d:Lfx0;

.field public final e:Lo22;

.field public final f:Lna;

.field public final g:Lw60;

.field public j:Lnw0;

.field public l:Lqf1;

.field public m:Lh42;

.field public n:Lri0;

.field public o:I

.field public p:I

.field public q:Lad0;

.field public r:Lm02;

.field public s:Lqi0;

.field public t:I

.field public u:J

.field public v:Ljava/lang/Object;

.field public w:Lf80;

.field public x:Ljava/util/function/Supplier;

.field public y:Ljava/lang/Thread;

.field public z:Lqf1;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lh02;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    sget-object v2, Lh02;->e:Le51;

    .line 5
    .line 6
    const-string v3, "glide_thread_priority_override"

    .line 7
    .line 8
    invoke-direct {v0, v3, v1, v2}, Lh02;-><init>(Ljava/lang/String;Ljava/lang/Object;Lg02;)V

    .line 9
    .line 10
    .line 11
    sput-object v0, Lx60;->K:Lh02;

    .line 12
    .line 13
    return-void
.end method

.method public constructor <init>(Lfx0;Lna;)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lv60;

    .line 5
    .line 6
    invoke-direct {v0}, Lv60;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Lx60;->a:Lv60;

    .line 10
    .line 11
    new-instance v0, Ljava/util/ArrayList;

    .line 12
    .line 13
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 14
    .line 15
    .line 16
    iput-object v0, p0, Lx60;->b:Ljava/util/ArrayList;

    .line 17
    .line 18
    new-instance v0, Lis2;

    .line 19
    .line 20
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 21
    .line 22
    .line 23
    iput-object v0, p0, Lx60;->c:Lis2;

    .line 24
    .line 25
    new-instance v0, Lna;

    .line 26
    .line 27
    const/16 v1, 0x10

    .line 28
    .line 29
    const/4 v2, 0x0

    .line 30
    invoke-direct {v0, v1, v2}, Lna;-><init>(IZ)V

    .line 31
    .line 32
    .line 33
    iput-object v0, p0, Lx60;->f:Lna;

    .line 34
    .line 35
    new-instance v0, Lw60;

    .line 36
    .line 37
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 38
    .line 39
    .line 40
    iput-object v0, p0, Lx60;->g:Lw60;

    .line 41
    .line 42
    iput-object p1, p0, Lx60;->d:Lfx0;

    .line 43
    .line 44
    iput-object p2, p0, Lx60;->e:Lo22;

    .line 45
    .line 46
    return-void
.end method


# virtual methods
.method public final a(Lqf1;Ljava/lang/Exception;Ll50;Lu50;)V
    .registers 7

    .line 1
    invoke-interface {p3}, Ll50;->b()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lpw0;

    .line 5
    .line 6
    const-string v1, "Fetching data failed"

    .line 7
    .line 8
    invoke-static {p2}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 9
    .line 10
    .line 11
    move-result-object p2

    .line 12
    invoke-direct {v0, v1, p2}, Lpw0;-><init>(Ljava/lang/String;Ljava/util/List;)V

    .line 13
    .line 14
    .line 15
    invoke-interface {p3}, Ll50;->a()Ljava/lang/Class;

    .line 16
    .line 17
    .line 18
    move-result-object p2

    .line 19
    iput-object p1, v0, Lpw0;->b:Lqf1;

    .line 20
    .line 21
    iput-object p4, v0, Lpw0;->c:Lu50;

    .line 22
    .line 23
    iput-object p2, v0, Lpw0;->d:Ljava/lang/Class;

    .line 24
    .line 25
    iget-object p1, p0, Lx60;->b:Ljava/util/ArrayList;

    .line 26
    .line 27
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    iget-object p2, p0, Lx60;->y:Ljava/lang/Thread;

    .line 35
    .line 36
    if-eq p1, p2, :cond_37

    .line 37
    .line 38
    const/4 p1, 0x2

    .line 39
    iput p1, p0, Lx60;->J:I

    .line 40
    .line 41
    iget-object p1, p0, Lx60;->s:Lqi0;

    .line 42
    .line 43
    iget-boolean p2, p1, Lqi0;->o:Z

    .line 44
    .line 45
    if-eqz p2, :cond_31

    .line 46
    .line 47
    iget-object p1, p1, Lqi0;->j:Lrw0;

    .line 48
    .line 49
    goto :goto_33

    .line 50
    :cond_31
    iget-object p1, p1, Lqi0;->g:Lrw0;

    .line 51
    .line 52
    :goto_33
    invoke-virtual {p1, p0}, Lrw0;->execute(Ljava/lang/Runnable;)V

    .line 53
    .line 54
    .line 55
    return-void

    .line 56
    :cond_37
    invoke-virtual {p0}, Lx60;->m()V

    .line 57
    .line 58
    .line 59
    return-void
.end method

.method public final b()Lis2;
    .registers 1

    .line 1
    iget-object p0, p0, Lx60;->c:Lis2;

    .line 2
    .line 3
    return-object p0
.end method

.method public final c(Lqf1;Ljava/lang/Object;Ll50;Lu50;Lqf1;)V
    .registers 6

    .line 1
    iput-object p1, p0, Lx60;->z:Lqf1;

    .line 2
    .line 3
    iput-object p2, p0, Lx60;->B:Ljava/lang/Object;

    .line 4
    .line 5
    iput-object p3, p0, Lx60;->D:Ll50;

    .line 6
    .line 7
    iput-object p4, p0, Lx60;->C:Lu50;

    .line 8
    .line 9
    iput-object p5, p0, Lx60;->A:Lqf1;

    .line 10
    .line 11
    iget-object p2, p0, Lx60;->a:Lv60;

    .line 12
    .line 13
    invoke-virtual {p2}, Lv60;->a()Ljava/util/ArrayList;

    .line 14
    .line 15
    .line 16
    move-result-object p2

    .line 17
    const/4 p3, 0x0

    .line 18
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p2

    .line 22
    if-eq p1, p2, :cond_18

    .line 23
    .line 24
    const/4 p3, 0x1

    .line 25
    :cond_18
    iput-boolean p3, p0, Lx60;->H:Z

    .line 26
    .line 27
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    iget-object p2, p0, Lx60;->y:Ljava/lang/Thread;

    .line 32
    .line 33
    if-eq p1, p2, :cond_34

    .line 34
    .line 35
    const/4 p1, 0x3

    .line 36
    iput p1, p0, Lx60;->J:I

    .line 37
    .line 38
    iget-object p1, p0, Lx60;->s:Lqi0;

    .line 39
    .line 40
    iget-boolean p2, p1, Lqi0;->o:Z

    .line 41
    .line 42
    if-eqz p2, :cond_2e

    .line 43
    .line 44
    iget-object p1, p1, Lqi0;->j:Lrw0;

    .line 45
    .line 46
    goto :goto_30

    .line 47
    :cond_2e
    iget-object p1, p1, Lqi0;->g:Lrw0;

    .line 48
    .line 49
    :goto_30
    invoke-virtual {p1, p0}, Lrw0;->execute(Ljava/lang/Runnable;)V

    .line 50
    .line 51
    .line 52
    return-void

    .line 53
    :cond_34
    invoke-virtual {p0}, Lx60;->f()V

    .line 54
    .line 55
    .line 56
    return-void
.end method

.method public final compareTo(Ljava/lang/Object;)I
    .registers 4

    .line 1
    check-cast p1, Lx60;

    .line 2
    .line 3
    iget-object v0, p0, Lx60;->m:Lh42;

    .line 4
    .line 5
    iget-object v1, p1, Lx60;->m:Lh42;

    .line 6
    .line 7
    invoke-virtual {v0, v1}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-nez v0, :cond_12

    .line 12
    .line 13
    iget p0, p0, Lx60;->t:I

    .line 14
    .line 15
    iget p1, p1, Lx60;->t:I

    .line 16
    .line 17
    sub-int/2addr p0, p1

    .line 18
    return p0

    .line 19
    :cond_12
    return v0
.end method

.method public final d(Ll50;Ljava/lang/Object;Lu50;)Lqf2;
    .registers 9

    .line 1
    const-string v0, "Decoded result "

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez p2, :cond_9

    .line 5
    .line 6
    invoke-interface {p1}, Ll50;->b()V

    .line 7
    .line 8
    .line 9
    return-object v1

    .line 10
    :cond_9
    :try_start_9
    sget v2, Lpm1;->b:I

    .line 11
    .line 12
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtimeNanos()J

    .line 13
    .line 14
    .line 15
    move-result-wide v2

    .line 16
    invoke-virtual {p0, p2, p3}, Lx60;->e(Ljava/lang/Object;Lu50;)Lqf2;

    .line 17
    .line 18
    .line 19
    move-result-object p2

    .line 20
    const-string p3, "DecodeJob"

    .line 21
    .line 22
    const/4 v4, 0x2

    .line 23
    invoke-static {p3, v4}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 24
    .line 25
    .line 26
    move-result p3

    .line 27
    if-eqz p3, :cond_2e

    .line 28
    .line 29
    new-instance p3, Ljava/lang/StringBuilder;

    .line 30
    .line 31
    invoke-direct {p3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 35
    .line 36
    .line 37
    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object p3

    .line 41
    invoke-virtual {p0, v2, v3, p3, v1}, Lx60;->i(JLjava/lang/String;Ljava/lang/String;)V
    :try_end_2b
    .catchall {:try_start_9 .. :try_end_2b} :catchall_2c

    .line 42
    .line 43
    .line 44
    goto :goto_2e

    .line 45
    :catchall_2c
    move-exception p0

    .line 46
    goto :goto_32

    .line 47
    :cond_2e
    :goto_2e
    invoke-interface {p1}, Ll50;->b()V

    .line 48
    .line 49
    .line 50
    return-object p2

    .line 51
    :goto_32
    invoke-interface {p1}, Ll50;->b()V

    .line 52
    .line 53
    .line 54
    throw p0
.end method

.method public final e(Ljava/lang/Object;Lu50;)Lqf2;
    .registers 11

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v1, p0, Lx60;->a:Lv60;

    .line 6
    .line 7
    invoke-virtual {v1, v0}, Lv60;->c(Ljava/lang/Class;)Lll1;

    .line 8
    .line 9
    .line 10
    move-result-object v2

    .line 11
    iget-object v0, p0, Lx60;->r:Lm02;

    .line 12
    .line 13
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 14
    .line 15
    const/4 v4, 0x0

    .line 16
    const/16 v5, 0x1a

    .line 17
    .line 18
    if-ge v3, v5, :cond_15

    .line 19
    .line 20
    :cond_13
    :goto_13
    move-object v6, v0

    .line 21
    goto :goto_4a

    .line 22
    :cond_15
    sget-object v3, Lu50;->d:Lu50;

    .line 23
    .line 24
    if-eq p2, v3, :cond_20

    .line 25
    .line 26
    iget-boolean v1, v1, Lv60;->r:Z

    .line 27
    .line 28
    if-eqz v1, :cond_1e

    .line 29
    .line 30
    goto :goto_20

    .line 31
    :cond_1e
    move v1, v4

    .line 32
    goto :goto_21

    .line 33
    :cond_20
    :goto_20
    const/4 v1, 0x1

    .line 34
    :goto_21
    sget-object v3, Lle0;->i:Lh02;

    .line 35
    .line 36
    invoke-virtual {v0, v3}, Lm02;->c(Lh02;)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v6

    .line 40
    check-cast v6, Ljava/lang/Boolean;

    .line 41
    .line 42
    if-eqz v6, :cond_34

    .line 43
    .line 44
    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    .line 45
    .line 46
    .line 47
    move-result v6

    .line 48
    if-eqz v6, :cond_13

    .line 49
    .line 50
    if-eqz v1, :cond_34

    .line 51
    .line 52
    goto :goto_13

    .line 53
    :cond_34
    new-instance v0, Lm02;

    .line 54
    .line 55
    invoke-direct {v0}, Lm02;-><init>()V

    .line 56
    .line 57
    .line 58
    iget-object v6, p0, Lx60;->r:Lm02;

    .line 59
    .line 60
    iget-object v6, v6, Lm02;->b:Lbo;

    .line 61
    .line 62
    iget-object v7, v0, Lm02;->b:Lbo;

    .line 63
    .line 64
    invoke-virtual {v7, v6}, Lbo;->h(Llb;)V

    .line 65
    .line 66
    .line 67
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 68
    .line 69
    .line 70
    move-result-object v1

    .line 71
    invoke-virtual {v7, v3, v1}, Lbo;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    goto :goto_13

    .line 75
    :goto_4a
    iget-object v0, p0, Lx60;->j:Lnw0;

    .line 76
    .line 77
    invoke-virtual {v0}, Lnw0;->a()Lce2;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    invoke-virtual {v0, p1}, Lce2;->g(Ljava/lang/Object;)Ls50;

    .line 82
    .line 83
    .line 84
    move-result-object p1

    .line 85
    :try_start_54
    iget v3, p0, Lx60;->o:I

    .line 86
    .line 87
    move v0, v4

    .line 88
    iget v4, p0, Lx60;->p:I

    .line 89
    .line 90
    new-instance v7, Ljt3;

    .line 91
    .line 92
    invoke-direct {v7, v5, p0, p2, v0}, Ljt3;-><init>(ILjava/lang/Object;Ljava/lang/Object;Z)V
    :try_end_5e
    .catchall {:try_start_54 .. :try_end_5e} :catchall_6a

    .line 93
    .line 94
    .line 95
    move-object v5, p1

    .line 96
    :try_start_5f
    invoke-virtual/range {v2 .. v7}, Lll1;->a(IILs50;Lm02;Ljt3;)Lqf2;

    .line 97
    .line 98
    .line 99
    move-result-object p0
    :try_end_63
    .catchall {:try_start_5f .. :try_end_63} :catchall_67

    .line 100
    invoke-interface {v5}, Ls50;->b()V

    .line 101
    .line 102
    .line 103
    return-object p0

    .line 104
    :catchall_67
    move-exception v0

    .line 105
    :goto_68
    move-object p0, v0

    .line 106
    goto :goto_6d

    .line 107
    :catchall_6a
    move-exception v0

    .line 108
    move-object v5, p1

    .line 109
    goto :goto_68

    .line 110
    :goto_6d
    invoke-interface {v5}, Ls50;->b()V

    .line 111
    .line 112
    .line 113
    throw p0
.end method

.method public final f()V
    .registers 13

    .line 1
    const-string v0, "DecodeJob"

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    invoke-static {v0, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_34

    .line 9
    .line 10
    const-string v0, "Retrieved data"

    .line 11
    .line 12
    iget-wide v2, p0, Lx60;->u:J

    .line 13
    .line 14
    new-instance v4, Ljava/lang/StringBuilder;

    .line 15
    .line 16
    const-string v5, "data: "

    .line 17
    .line 18
    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    iget-object v5, p0, Lx60;->B:Ljava/lang/Object;

    .line 22
    .line 23
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 24
    .line 25
    .line 26
    const-string v5, ", cache key: "

    .line 27
    .line 28
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 29
    .line 30
    .line 31
    iget-object v5, p0, Lx60;->z:Lqf1;

    .line 32
    .line 33
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 34
    .line 35
    .line 36
    const-string v5, ", fetcher: "

    .line 37
    .line 38
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 39
    .line 40
    .line 41
    iget-object v5, p0, Lx60;->D:Ll50;

    .line 42
    .line 43
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 44
    .line 45
    .line 46
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object v4

    .line 50
    invoke-virtual {p0, v2, v3, v0, v4}, Lx60;->i(JLjava/lang/String;Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    :cond_34
    iget-object v0, p0, Lx60;->w:Lf80;

    .line 54
    .line 55
    const-class v2, Lkw0;

    .line 56
    .line 57
    iget-object v0, v0, Lf80;->b:Ljava/lang/Object;

    .line 58
    .line 59
    check-cast v0, Ljava/util/Map;

    .line 60
    .line 61
    invoke-interface {v0, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    const/4 v2, 0x0

    .line 66
    if-eqz v0, :cond_75

    .line 67
    .line 68
    iget-object v0, p0, Lx60;->x:Ljava/util/function/Supplier;

    .line 69
    .line 70
    if-eqz v0, :cond_75

    .line 71
    .line 72
    invoke-interface {v0}, Ljava/util/function/Supplier;->get()Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    if-eqz v0, :cond_75

    .line 77
    .line 78
    :try_start_4d
    invoke-static {}, Landroid/os/Process;->myTid()I

    .line 79
    .line 80
    .line 81
    move-result v0

    .line 82
    iget-object v3, p0, Lx60;->x:Ljava/util/function/Supplier;

    .line 83
    .line 84
    invoke-interface {v3}, Ljava/util/function/Supplier;->get()Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object v3

    .line 88
    check-cast v3, Ljava/lang/Integer;

    .line 89
    .line 90
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 91
    .line 92
    .line 93
    move-result v3

    .line 94
    invoke-static {v0, v3}, Landroid/os/Process;->setThreadPriority(II)V
    :try_end_60
    .catch Ljava/lang/IllegalArgumentException; {:try_start_4d .. :try_end_60} :catch_63
    .catch Ljava/lang/SecurityException; {:try_start_4d .. :try_end_60} :catch_61

    .line 95
    .line 96
    .line 97
    goto :goto_75

    .line 98
    :catch_61
    move-exception v0

    .line 99
    goto :goto_64

    .line 100
    :catch_63
    move-exception v0

    .line 101
    :goto_64
    iput-object v2, p0, Lx60;->x:Ljava/util/function/Supplier;

    .line 102
    .line 103
    const-string v3, "DecodeJob"

    .line 104
    .line 105
    invoke-static {v3, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 106
    .line 107
    .line 108
    move-result v1

    .line 109
    if-eqz v1, :cond_75

    .line 110
    .line 111
    const-string v1, "DecodeJob"

    .line 112
    .line 113
    const-string v3, "Failed to set thread priority; using default priority for any subsequent jobs."

    .line 114
    .line 115
    invoke-static {v1, v3, v0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 116
    .line 117
    .line 118
    :cond_75
    :goto_75
    :try_start_75
    iget-object v0, p0, Lx60;->D:Ll50;

    .line 119
    .line 120
    iget-object v1, p0, Lx60;->B:Ljava/lang/Object;

    .line 121
    .line 122
    iget-object v3, p0, Lx60;->C:Lu50;

    .line 123
    .line 124
    invoke-virtual {p0, v0, v1, v3}, Lx60;->d(Ll50;Ljava/lang/Object;Lu50;)Lqf2;

    .line 125
    .line 126
    .line 127
    move-result-object v0
    :try_end_7f
    .catch Lpw0; {:try_start_75 .. :try_end_7f} :catch_80

    .line 128
    goto :goto_91

    .line 129
    :catch_80
    move-exception v0

    .line 130
    iget-object v1, p0, Lx60;->A:Lqf1;

    .line 131
    .line 132
    iget-object v3, p0, Lx60;->C:Lu50;

    .line 133
    .line 134
    iput-object v1, v0, Lpw0;->b:Lqf1;

    .line 135
    .line 136
    iput-object v3, v0, Lpw0;->c:Lu50;

    .line 137
    .line 138
    iput-object v2, v0, Lpw0;->d:Ljava/lang/Class;

    .line 139
    .line 140
    iget-object v1, p0, Lx60;->b:Ljava/util/ArrayList;

    .line 141
    .line 142
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 143
    .line 144
    .line 145
    move-object v0, v2

    .line 146
    :goto_91
    if-eqz v0, :cond_1c1

    .line 147
    .line 148
    iget-object v1, p0, Lx60;->C:Lu50;

    .line 149
    .line 150
    instance-of v3, v0, Lf11;

    .line 151
    .line 152
    if-eqz v3, :cond_9f

    .line 153
    .line 154
    move-object v3, v0

    .line 155
    check-cast v3, Lf11;

    .line 156
    .line 157
    invoke-interface {v3}, Lf11;->a()V

    .line 158
    .line 159
    .line 160
    :cond_9f
    iget-object v3, p0, Lx60;->f:Lna;

    .line 161
    .line 162
    iget-object v3, v3, Lna;->d:Ljava/lang/Object;

    .line 163
    .line 164
    check-cast v3, Lim1;

    .line 165
    .line 166
    const/4 v4, 0x0

    .line 167
    const/4 v5, 0x1

    .line 168
    if-eqz v3, :cond_b8

    .line 169
    .line 170
    sget-object v2, Lim1;->e:Lna;

    .line 171
    .line 172
    invoke-virtual {v2}, Lna;->g()Ljava/lang/Object;

    .line 173
    .line 174
    .line 175
    move-result-object v2

    .line 176
    check-cast v2, Lim1;

    .line 177
    .line 178
    iput-boolean v4, v2, Lim1;->d:Z

    .line 179
    .line 180
    iput-boolean v5, v2, Lim1;->c:Z

    .line 181
    .line 182
    iput-object v0, v2, Lim1;->b:Lqf2;

    .line 183
    .line 184
    move-object v0, v2

    .line 185
    :cond_b8
    iget-object v3, p0, Lx60;->w:Lf80;

    .line 186
    .line 187
    const-class v6, Lkw0;

    .line 188
    .line 189
    iget-object v3, v3, Lf80;->b:Ljava/lang/Object;

    .line 190
    .line 191
    check-cast v3, Ljava/util/Map;

    .line 192
    .line 193
    invoke-interface {v3, v6}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 194
    .line 195
    .line 196
    move-result v3

    .line 197
    if-eqz v3, :cond_c9

    .line 198
    .line 199
    invoke-virtual {p0}, Lx60;->l()V

    .line 200
    .line 201
    .line 202
    :cond_c9
    invoke-virtual {p0}, Lx60;->o()V

    .line 203
    .line 204
    .line 205
    iget-object v3, p0, Lx60;->s:Lqi0;

    .line 206
    .line 207
    monitor-enter v3

    .line 208
    :try_start_cf
    iput-object v0, v3, Lqi0;->p:Lqf2;

    .line 209
    .line 210
    iput-object v1, v3, Lqi0;->q:Lu50;

    .line 211
    .line 212
    monitor-exit v3
    :try_end_d4
    .catchall {:try_start_cf .. :try_end_d4} :catchall_1bd

    .line 213
    monitor-enter v3

    .line 214
    :try_start_d5
    iget-object v0, v3, Lqi0;->b:Lis2;

    .line 215
    .line 216
    invoke-virtual {v0}, Lis2;->a()V

    .line 217
    .line 218
    .line 219
    iget-boolean v0, v3, Lqi0;->w:Z

    .line 220
    .line 221
    if-eqz v0, :cond_ec

    .line 222
    .line 223
    iget-object v0, v3, Lqi0;->p:Lqf2;

    .line 224
    .line 225
    invoke-interface {v0}, Lqf2;->e()V

    .line 226
    .line 227
    .line 228
    invoke-virtual {v3}, Lqi0;->f()V

    .line 229
    .line 230
    .line 231
    monitor-exit v3

    .line 232
    goto :goto_14b

    .line 233
    :catchall_e8
    move-exception v0

    .line 234
    move-object p0, v0

    .line 235
    goto/16 :goto_1bb

    .line 236
    .line 237
    :cond_ec
    iget-object v0, v3, Lqi0;->a:Ll6;

    .line 238
    .line 239
    iget-object v0, v0, Ll6;->b:Ljava/lang/Object;

    .line 240
    .line 241
    check-cast v0, Ljava/util/ArrayList;

    .line 242
    .line 243
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 244
    .line 245
    .line 246
    move-result v0

    .line 247
    if-nez v0, :cond_1b3

    .line 248
    .line 249
    iget-boolean v0, v3, Lqi0;->r:Z

    .line 250
    .line 251
    if-nez v0, :cond_1ab

    .line 252
    .line 253
    iget-object v7, v3, Lqi0;->p:Lqf2;

    .line 254
    .line 255
    iget-boolean v8, v3, Lqi0;->n:Z

    .line 256
    .line 257
    iget-object v10, v3, Lqi0;->m:Lri0;

    .line 258
    .line 259
    iget-object v11, v3, Lqi0;->c:Lni0;

    .line 260
    .line 261
    new-instance v6, Lsi0;

    .line 262
    .line 263
    const/4 v9, 0x1

    .line 264
    invoke-direct/range {v6 .. v11}, Lsi0;-><init>(Lqf2;ZZLqf1;Lni0;)V

    .line 265
    .line 266
    .line 267
    iput-object v6, v3, Lqi0;->u:Lsi0;

    .line 268
    .line 269
    iput-boolean v5, v3, Lqi0;->r:Z

    .line 270
    .line 271
    iget-object v0, v3, Lqi0;->a:Ll6;

    .line 272
    .line 273
    new-instance v1, Ljava/util/ArrayList;

    .line 274
    .line 275
    iget-object v0, v0, Ll6;->b:Ljava/lang/Object;

    .line 276
    .line 277
    check-cast v0, Ljava/util/ArrayList;

    .line 278
    .line 279
    invoke-direct {v1, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 280
    .line 281
    .line 282
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 283
    .line 284
    .line 285
    move-result v0

    .line 286
    add-int/2addr v0, v5

    .line 287
    invoke-virtual {v3, v0}, Lqi0;->d(I)V

    .line 288
    .line 289
    .line 290
    iget-object v0, v3, Lqi0;->m:Lri0;

    .line 291
    .line 292
    iget-object v6, v3, Lqi0;->u:Lsi0;

    .line 293
    .line 294
    monitor-exit v3
    :try_end_126
    .catchall {:try_start_d5 .. :try_end_126} :catchall_e8

    .line 295
    iget-object v7, v3, Lqi0;->e:Lni0;

    .line 296
    .line 297
    invoke-virtual {v7, v3, v0, v6}, Lni0;->e(Lqi0;Lri0;Lsi0;)V

    .line 298
    .line 299
    .line 300
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 301
    .line 302
    .line 303
    move-result-object v0

    .line 304
    :goto_12f
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 305
    .line 306
    .line 307
    move-result v1

    .line 308
    if-eqz v1, :cond_148

    .line 309
    .line 310
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 311
    .line 312
    .line 313
    move-result-object v1

    .line 314
    check-cast v1, Lpi0;

    .line 315
    .line 316
    iget-object v6, v1, Lpi0;->b:Ljava/util/concurrent/Executor;

    .line 317
    .line 318
    new-instance v7, Loi0;

    .line 319
    .line 320
    iget-object v1, v1, Lpi0;->a:Ljp2;

    .line 321
    .line 322
    invoke-direct {v7, v3, v1, v5}, Loi0;-><init>(Lqi0;Ljp2;I)V

    .line 323
    .line 324
    .line 325
    invoke-interface {v6, v7}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 326
    .line 327
    .line 328
    goto :goto_12f

    .line 329
    :cond_148
    invoke-virtual {v3}, Lqi0;->c()V

    .line 330
    .line 331
    .line 332
    :goto_14b
    const/4 v0, 0x5

    .line 333
    iput v0, p0, Lx60;->I:I

    .line 334
    .line 335
    :try_start_14e
    iget-object v1, p0, Lx60;->f:Lna;

    .line 336
    .line 337
    iget-object v0, v1, Lna;->d:Ljava/lang/Object;

    .line 338
    .line 339
    check-cast v0, Lim1;

    .line 340
    .line 341
    if-eqz v0, :cond_157

    .line 342
    .line 343
    move v4, v5

    .line 344
    :cond_157
    if-eqz v4, :cond_18c

    .line 345
    .line 346
    iget-object v0, p0, Lx60;->d:Lfx0;

    .line 347
    .line 348
    iget-object v3, p0, Lx60;->r:Lm02;
    :try_end_15d
    .catchall {:try_start_14e .. :try_end_15d} :catchall_189

    .line 349
    .line 350
    :try_start_15d
    invoke-virtual {v0}, Lfx0;->a()Lzc0;

    .line 351
    .line 352
    .line 353
    move-result-object v0

    .line 354
    iget-object v4, v1, Lna;->b:Ljava/lang/Object;

    .line 355
    .line 356
    check-cast v4, Lqf1;

    .line 357
    .line 358
    new-instance v6, Lna;

    .line 359
    .line 360
    iget-object v7, v1, Lna;->c:Ljava/lang/Object;

    .line 361
    .line 362
    check-cast v7, Lwf2;

    .line 363
    .line 364
    iget-object v8, v1, Lna;->d:Ljava/lang/Object;

    .line 365
    .line 366
    check-cast v8, Lim1;

    .line 367
    .line 368
    const/16 v9, 0xf

    .line 369
    .line 370
    invoke-direct {v6, v7, v8, v3, v9}, Lna;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 371
    .line 372
    .line 373
    invoke-interface {v0, v4, v6}, Lzc0;->p(Lqf1;Lna;)V
    :try_end_177
    .catchall {:try_start_15d .. :try_end_177} :catchall_17f

    .line 374
    .line 375
    .line 376
    :try_start_177
    iget-object v0, v1, Lna;->d:Ljava/lang/Object;

    .line 377
    .line 378
    check-cast v0, Lim1;

    .line 379
    .line 380
    invoke-virtual {v0}, Lim1;->a()V

    .line 381
    .line 382
    .line 383
    goto :goto_18c

    .line 384
    :catchall_17f
    move-exception v0

    .line 385
    move-object p0, v0

    .line 386
    iget-object v0, v1, Lna;->d:Ljava/lang/Object;

    .line 387
    .line 388
    check-cast v0, Lim1;

    .line 389
    .line 390
    invoke-virtual {v0}, Lim1;->a()V

    .line 391
    .line 392
    .line 393
    throw p0
    :try_end_189
    .catchall {:try_start_177 .. :try_end_189} :catchall_189

    .line 394
    :catchall_189
    move-exception v0

    .line 395
    move-object p0, v0

    .line 396
    goto :goto_1a5

    .line 397
    :cond_18c
    :goto_18c
    if-eqz v2, :cond_191

    .line 398
    .line 399
    invoke-virtual {v2}, Lim1;->a()V

    .line 400
    .line 401
    .line 402
    :cond_191
    iget-object v1, p0, Lx60;->g:Lw60;

    .line 403
    .line 404
    monitor-enter v1

    .line 405
    :try_start_194
    iput-boolean v5, v1, Lw60;->b:Z

    .line 406
    .line 407
    invoke-virtual {v1}, Lw60;->a()Z

    .line 408
    .line 409
    .line 410
    move-result v0
    :try_end_19a
    .catchall {:try_start_194 .. :try_end_19a} :catchall_1a1

    .line 411
    monitor-exit v1

    .line 412
    if-eqz v0, :cond_1c4

    .line 413
    .line 414
    invoke-virtual {p0}, Lx60;->k()V

    .line 415
    .line 416
    .line 417
    goto :goto_1c4

    .line 418
    :catchall_1a1
    move-exception v0

    .line 419
    move-object p0, v0

    .line 420
    :try_start_1a3
    monitor-exit v1
    :try_end_1a4
    .catchall {:try_start_1a3 .. :try_end_1a4} :catchall_1a1

    .line 421
    throw p0

    .line 422
    :goto_1a5
    if-eqz v2, :cond_1aa

    .line 423
    .line 424
    invoke-virtual {v2}, Lim1;->a()V

    .line 425
    .line 426
    .line 427
    :cond_1aa
    throw p0

    .line 428
    :cond_1ab
    :try_start_1ab
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 429
    .line 430
    const-string v0, "Already have resource"

    .line 431
    .line 432
    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 433
    .line 434
    .line 435
    throw p0

    .line 436
    :cond_1b3
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 437
    .line 438
    const-string v0, "Received a resource without any callbacks to notify"

    .line 439
    .line 440
    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 441
    .line 442
    .line 443
    throw p0

    .line 444
    :goto_1bb
    monitor-exit v3
    :try_end_1bc
    .catchall {:try_start_1ab .. :try_end_1bc} :catchall_e8

    .line 445
    throw p0

    .line 446
    :catchall_1bd
    move-exception v0

    .line 447
    move-object p0, v0

    .line 448
    :try_start_1bf
    monitor-exit v3
    :try_end_1c0
    .catchall {:try_start_1bf .. :try_end_1c0} :catchall_1bd

    .line 449
    throw p0

    .line 450
    :cond_1c1
    invoke-virtual {p0}, Lx60;->m()V

    .line 451
    .line 452
    .line 453
    :cond_1c4
    :goto_1c4
    return-void
.end method

.method public final g()Ln50;
    .registers 4

    .line 1
    iget v0, p0, Lx60;->I:I

    .line 2
    .line 3
    invoke-static {v0}, Ln10;->u(I)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/4 v1, 0x1

    .line 8
    iget-object v2, p0, Lx60;->a:Lv60;

    .line 9
    .line 10
    if-eq v0, v1, :cond_36

    .line 11
    .line 12
    const/4 v1, 0x2

    .line 13
    if-eq v0, v1, :cond_2c

    .line 14
    .line 15
    const/4 v1, 0x3

    .line 16
    if-eq v0, v1, :cond_26

    .line 17
    .line 18
    const/4 v1, 0x5

    .line 19
    const/4 v2, 0x0

    .line 20
    if-ne v0, v1, :cond_16

    .line 21
    .line 22
    return-object v2

    .line 23
    :cond_16
    iget p0, p0, Lx60;->I:I

    .line 24
    .line 25
    invoke-static {p0}, Ln10;->w(I)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object p0

    .line 29
    const-string v0, "Unrecognized stage: "

    .line 30
    .line 31
    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object p0

    .line 35
    invoke-static {p0}, Ly0;->h(Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    return-object v2

    .line 39
    :cond_26
    new-instance v0, Lpq2;

    .line 40
    .line 41
    invoke-direct {v0, v2, p0}, Lpq2;-><init>(Lv60;Lx60;)V

    .line 42
    .line 43
    .line 44
    return-object v0

    .line 45
    :cond_2c
    new-instance v0, Le50;

    .line 46
    .line 47
    invoke-virtual {v2}, Lv60;->a()Ljava/util/ArrayList;

    .line 48
    .line 49
    .line 50
    move-result-object v1

    .line 51
    invoke-direct {v0, v1, v2, p0}, Le50;-><init>(Ljava/util/List;Lv60;Lm50;)V

    .line 52
    .line 53
    .line 54
    return-object v0

    .line 55
    :cond_36
    new-instance v0, Lrf2;

    .line 56
    .line 57
    invoke-direct {v0, v2, p0}, Lrf2;-><init>(Lv60;Lx60;)V

    .line 58
    .line 59
    .line 60
    return-object v0
.end method

.method public final h(I)I
    .registers 7

    .line 1
    invoke-static {p1}, Ln10;->u(I)I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    const/4 v2, 0x1

    .line 7
    const/4 v3, 0x2

    .line 8
    if-eqz v0, :cond_36

    .line 9
    .line 10
    const/4 v4, 0x3

    .line 11
    if-eq v0, v2, :cond_26

    .line 12
    .line 13
    if-eq v0, v3, :cond_24

    .line 14
    .line 15
    if-eq v0, v4, :cond_22

    .line 16
    .line 17
    const/4 p0, 0x5

    .line 18
    if-ne v0, p0, :cond_14

    .line 19
    .line 20
    goto :goto_22

    .line 21
    :cond_14
    invoke-static {p1}, Ln10;->w(I)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object p0

    .line 25
    const-string p1, "Unrecognized stage: "

    .line 26
    .line 27
    invoke-virtual {p1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    invoke-static {p0}, Lm03;->g(Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    return v1

    .line 35
    :cond_22
    :goto_22
    const/4 p0, 0x6

    .line 36
    return p0

    .line 37
    :cond_24
    const/4 p0, 0x4

    .line 38
    return p0

    .line 39
    :cond_26
    iget-object p1, p0, Lx60;->q:Lad0;

    .line 40
    .line 41
    iget p1, p1, Lad0;->a:I

    .line 42
    .line 43
    packed-switch p1, :pswitch_data_46

    .line 44
    .line 45
    .line 46
    :pswitch_2d
    move v1, v2

    .line 47
    :pswitch_2e
    if-eqz v1, :cond_31

    .line 48
    .line 49
    return v4

    .line 50
    :cond_31
    invoke-virtual {p0, v4}, Lx60;->h(I)I

    .line 51
    .line 52
    .line 53
    move-result p0

    .line 54
    return p0

    .line 55
    :cond_36
    iget-object p1, p0, Lx60;->q:Lad0;

    .line 56
    .line 57
    iget p1, p1, Lad0;->a:I

    .line 58
    .line 59
    packed-switch p1, :pswitch_data_50

    .line 60
    .line 61
    .line 62
    :pswitch_3d
    move v1, v2

    .line 63
    :pswitch_3e
    if-eqz v1, :cond_41

    .line 64
    .line 65
    return v3

    .line 66
    :cond_41
    invoke-virtual {p0, v3}, Lx60;->h(I)I

    .line 67
    .line 68
    .line 69
    move-result p0

    .line 70
    return p0

    .line 71
    :pswitch_data_46
    .packed-switch 0x0
        :pswitch_2d
        :pswitch_2e
        :pswitch_2d
    .end packed-switch

    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    :pswitch_data_50
    .packed-switch 0x0
        :pswitch_3d
        :pswitch_3e
        :pswitch_3e
    .end packed-switch
.end method

.method public final i(JLjava/lang/String;Ljava/lang/String;)V
    .registers 6

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    invoke-direct {v0, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string p3, " in "

    .line 7
    .line 8
    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 9
    .line 10
    .line 11
    invoke-static {p1, p2}, Lpm1;->a(J)D

    .line 12
    .line 13
    .line 14
    move-result-wide p1

    .line 15
    invoke-virtual {v0, p1, p2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    const-string p1, ", load key: "

    .line 19
    .line 20
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    iget-object p0, p0, Lx60;->n:Lri0;

    .line 24
    .line 25
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    if-eqz p4, :cond_24

    .line 29
    .line 30
    const-string p0, ", "

    .line 31
    .line 32
    invoke-virtual {p0, p4}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object p0

    .line 36
    goto :goto_26

    .line 37
    :cond_24
    const-string p0, ""

    .line 38
    .line 39
    :goto_26
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 40
    .line 41
    .line 42
    const-string p0, ", thread: "

    .line 43
    .line 44
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 45
    .line 46
    .line 47
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 48
    .line 49
    .line 50
    move-result-object p0

    .line 51
    invoke-virtual {p0}, Ljava/lang/Thread;->getName()Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object p0

    .line 55
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 56
    .line 57
    .line 58
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 59
    .line 60
    .line 61
    move-result-object p0

    .line 62
    const-string p1, "DecodeJob"

    .line 63
    .line 64
    invoke-static {p1, p0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 65
    .line 66
    .line 67
    return-void
.end method

.method public final j()V
    .registers 8

    .line 1
    iget-object v0, p0, Lx60;->w:Lf80;

    .line 2
    .line 3
    const-class v1, Lkw0;

    .line 4
    .line 5
    iget-object v0, v0, Lf80;->b:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v0, Ljava/util/Map;

    .line 8
    .line 9
    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_11

    .line 14
    .line 15
    invoke-virtual {p0}, Lx60;->l()V

    .line 16
    .line 17
    .line 18
    :cond_11
    invoke-virtual {p0}, Lx60;->o()V

    .line 19
    .line 20
    .line 21
    new-instance v0, Lpw0;

    .line 22
    .line 23
    const-string v1, "Failed to load resource"

    .line 24
    .line 25
    new-instance v2, Ljava/util/ArrayList;

    .line 26
    .line 27
    iget-object v3, p0, Lx60;->b:Ljava/util/ArrayList;

    .line 28
    .line 29
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 30
    .line 31
    .line 32
    invoke-direct {v0, v1, v2}, Lpw0;-><init>(Ljava/lang/String;Ljava/util/List;)V

    .line 33
    .line 34
    .line 35
    iget-object v1, p0, Lx60;->s:Lqi0;

    .line 36
    .line 37
    monitor-enter v1

    .line 38
    :try_start_25
    iput-object v0, v1, Lqi0;->s:Lpw0;

    .line 39
    .line 40
    monitor-exit v1
    :try_end_28
    .catchall {:try_start_25 .. :try_end_28} :catchall_ae

    .line 41
    monitor-enter v1

    .line 42
    :try_start_29
    iget-object v0, v1, Lqi0;->b:Lis2;

    .line 43
    .line 44
    invoke-virtual {v0}, Lis2;->a()V

    .line 45
    .line 46
    .line 47
    iget-boolean v0, v1, Lqi0;->w:Z

    .line 48
    .line 49
    const/4 v2, 0x1

    .line 50
    if-eqz v0, :cond_3a

    .line 51
    .line 52
    invoke-virtual {v1}, Lqi0;->f()V

    .line 53
    .line 54
    .line 55
    monitor-exit v1

    .line 56
    goto :goto_89

    .line 57
    :catchall_38
    move-exception p0

    .line 58
    goto :goto_ac

    .line 59
    :cond_3a
    iget-object v0, v1, Lqi0;->a:Ll6;

    .line 60
    .line 61
    iget-object v0, v0, Ll6;->b:Ljava/lang/Object;

    .line 62
    .line 63
    check-cast v0, Ljava/util/ArrayList;

    .line 64
    .line 65
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    if-nez v0, :cond_a4

    .line 70
    .line 71
    iget-boolean v0, v1, Lqi0;->t:Z

    .line 72
    .line 73
    if-nez v0, :cond_9c

    .line 74
    .line 75
    iput-boolean v2, v1, Lqi0;->t:Z

    .line 76
    .line 77
    iget-object v0, v1, Lqi0;->m:Lri0;

    .line 78
    .line 79
    iget-object v3, v1, Lqi0;->a:Ll6;

    .line 80
    .line 81
    new-instance v4, Ljava/util/ArrayList;

    .line 82
    .line 83
    iget-object v3, v3, Ll6;->b:Ljava/lang/Object;

    .line 84
    .line 85
    check-cast v3, Ljava/util/ArrayList;

    .line 86
    .line 87
    invoke-direct {v4, v3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 88
    .line 89
    .line 90
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 91
    .line 92
    .line 93
    move-result v3

    .line 94
    add-int/2addr v3, v2

    .line 95
    invoke-virtual {v1, v3}, Lqi0;->d(I)V

    .line 96
    .line 97
    .line 98
    monitor-exit v1
    :try_end_62
    .catchall {:try_start_29 .. :try_end_62} :catchall_38

    .line 99
    iget-object v3, v1, Lqi0;->e:Lni0;

    .line 100
    .line 101
    const/4 v5, 0x0

    .line 102
    invoke-virtual {v3, v1, v0, v5}, Lni0;->e(Lqi0;Lri0;Lsi0;)V

    .line 103
    .line 104
    .line 105
    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 106
    .line 107
    .line 108
    move-result-object v0

    .line 109
    :goto_6c
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 110
    .line 111
    .line 112
    move-result v3

    .line 113
    if-eqz v3, :cond_86

    .line 114
    .line 115
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 116
    .line 117
    .line 118
    move-result-object v3

    .line 119
    check-cast v3, Lpi0;

    .line 120
    .line 121
    iget-object v4, v3, Lpi0;->b:Ljava/util/concurrent/Executor;

    .line 122
    .line 123
    new-instance v5, Loi0;

    .line 124
    .line 125
    iget-object v3, v3, Lpi0;->a:Ljp2;

    .line 126
    .line 127
    const/4 v6, 0x0

    .line 128
    invoke-direct {v5, v1, v3, v6}, Loi0;-><init>(Lqi0;Ljp2;I)V

    .line 129
    .line 130
    .line 131
    invoke-interface {v4, v5}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 132
    .line 133
    .line 134
    goto :goto_6c

    .line 135
    :cond_86
    invoke-virtual {v1}, Lqi0;->c()V

    .line 136
    .line 137
    .line 138
    :goto_89
    iget-object v0, p0, Lx60;->g:Lw60;

    .line 139
    .line 140
    monitor-enter v0

    .line 141
    :try_start_8c
    iput-boolean v2, v0, Lw60;->c:Z

    .line 142
    .line 143
    invoke-virtual {v0}, Lw60;->a()Z

    .line 144
    .line 145
    .line 146
    move-result v1
    :try_end_92
    .catchall {:try_start_8c .. :try_end_92} :catchall_99

    .line 147
    monitor-exit v0

    .line 148
    if-eqz v1, :cond_98

    .line 149
    .line 150
    invoke-virtual {p0}, Lx60;->k()V

    .line 151
    .line 152
    .line 153
    :cond_98
    return-void

    .line 154
    :catchall_99
    move-exception p0

    .line 155
    :try_start_9a
    monitor-exit v0
    :try_end_9b
    .catchall {:try_start_9a .. :try_end_9b} :catchall_99

    .line 156
    throw p0

    .line 157
    :cond_9c
    :try_start_9c
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 158
    .line 159
    const-string v0, "Already failed once"

    .line 160
    .line 161
    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 162
    .line 163
    .line 164
    throw p0

    .line 165
    :cond_a4
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 166
    .line 167
    const-string v0, "Received an exception without any callbacks to notify"

    .line 168
    .line 169
    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 170
    .line 171
    .line 172
    throw p0

    .line 173
    :goto_ac
    monitor-exit v1
    :try_end_ad
    .catchall {:try_start_9c .. :try_end_ad} :catchall_38

    .line 174
    throw p0

    .line 175
    :catchall_ae
    move-exception p0

    .line 176
    :try_start_af
    monitor-exit v1
    :try_end_b0
    .catchall {:try_start_af .. :try_end_b0} :catchall_ae

    .line 177
    throw p0
.end method

.method public final k()V
    .registers 6

    .line 1
    iget-object v0, p0, Lx60;->g:Lw60;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    const/4 v1, 0x0

    .line 5
    :try_start_4
    iput-boolean v1, v0, Lw60;->b:Z

    .line 6
    .line 7
    iput-boolean v1, v0, Lw60;->a:Z

    .line 8
    .line 9
    iput-boolean v1, v0, Lw60;->c:Z
    :try_end_a
    .catchall {:try_start_4 .. :try_end_a} :catchall_65

    .line 10
    .line 11
    monitor-exit v0

    .line 12
    iget-object v0, p0, Lx60;->f:Lna;

    .line 13
    .line 14
    const/4 v2, 0x0

    .line 15
    iput-object v2, v0, Lna;->b:Ljava/lang/Object;

    .line 16
    .line 17
    iput-object v2, v0, Lna;->c:Ljava/lang/Object;

    .line 18
    .line 19
    iput-object v2, v0, Lna;->d:Ljava/lang/Object;

    .line 20
    .line 21
    iget-object v0, p0, Lx60;->a:Lv60;

    .line 22
    .line 23
    iput-object v2, v0, Lv60;->c:Lnw0;

    .line 24
    .line 25
    iput-object v2, v0, Lv60;->d:Ljava/lang/Object;

    .line 26
    .line 27
    iput-object v2, v0, Lv60;->n:Lqf1;

    .line 28
    .line 29
    iput-object v2, v0, Lv60;->g:Ljava/lang/Class;

    .line 30
    .line 31
    iput-object v2, v0, Lv60;->k:Ljava/lang/Class;

    .line 32
    .line 33
    iput-object v2, v0, Lv60;->i:Lm02;

    .line 34
    .line 35
    iput-object v2, v0, Lv60;->o:Lh42;

    .line 36
    .line 37
    iput-object v2, v0, Lv60;->j:Lbo;

    .line 38
    .line 39
    iput-object v2, v0, Lv60;->p:Lad0;

    .line 40
    .line 41
    iget-object v3, v0, Lv60;->a:Ljava/util/ArrayList;

    .line 42
    .line 43
    invoke-virtual {v3}, Ljava/util/ArrayList;->clear()V

    .line 44
    .line 45
    .line 46
    iput-boolean v1, v0, Lv60;->l:Z

    .line 47
    .line 48
    iget-object v3, v0, Lv60;->b:Ljava/util/ArrayList;

    .line 49
    .line 50
    invoke-virtual {v3}, Ljava/util/ArrayList;->clear()V

    .line 51
    .line 52
    .line 53
    iput-boolean v1, v0, Lv60;->m:Z

    .line 54
    .line 55
    iput-boolean v1, p0, Lx60;->F:Z

    .line 56
    .line 57
    iput-object v2, p0, Lx60;->j:Lnw0;

    .line 58
    .line 59
    iput-object v2, p0, Lx60;->l:Lqf1;

    .line 60
    .line 61
    iput-object v2, p0, Lx60;->r:Lm02;

    .line 62
    .line 63
    iput-object v2, p0, Lx60;->m:Lh42;

    .line 64
    .line 65
    iput-object v2, p0, Lx60;->n:Lri0;

    .line 66
    .line 67
    iput-object v2, p0, Lx60;->s:Lqi0;

    .line 68
    .line 69
    iput v1, p0, Lx60;->I:I

    .line 70
    .line 71
    iput-object v2, p0, Lx60;->E:Ln50;

    .line 72
    .line 73
    iput-object v2, p0, Lx60;->y:Ljava/lang/Thread;

    .line 74
    .line 75
    iput-object v2, p0, Lx60;->z:Lqf1;

    .line 76
    .line 77
    iput-object v2, p0, Lx60;->B:Ljava/lang/Object;

    .line 78
    .line 79
    iput-object v2, p0, Lx60;->C:Lu50;

    .line 80
    .line 81
    iput-object v2, p0, Lx60;->D:Ll50;

    .line 82
    .line 83
    const-wide/16 v3, 0x0

    .line 84
    .line 85
    iput-wide v3, p0, Lx60;->u:J

    .line 86
    .line 87
    iput-boolean v1, p0, Lx60;->G:Z

    .line 88
    .line 89
    iput-object v2, p0, Lx60;->v:Ljava/lang/Object;

    .line 90
    .line 91
    iget-object v0, p0, Lx60;->b:Ljava/util/ArrayList;

    .line 92
    .line 93
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 94
    .line 95
    .line 96
    iget-object v0, p0, Lx60;->e:Lo22;

    .line 97
    .line 98
    invoke-interface {v0, p0}, Lo22;->a(Ljava/lang/Object;)Z

    .line 99
    .line 100
    .line 101
    return-void

    .line 102
    :catchall_65
    move-exception p0

    .line 103
    :try_start_66
    monitor-exit v0
    :try_end_67
    .catchall {:try_start_66 .. :try_end_67} :catchall_65

    .line 104
    throw p0
.end method

.method public final l()V
    .registers 3

    .line 1
    iget-object v0, p0, Lx60;->w:Lf80;

    .line 2
    .line 3
    iget-object v0, v0, Lf80;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Ljava/util/Map;

    .line 6
    .line 7
    const-class v1, Lkw0;

    .line 8
    .line 9
    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_37

    .line 14
    .line 15
    iget-object v0, p0, Lx60;->x:Ljava/util/function/Supplier;

    .line 16
    .line 17
    if-eqz v0, :cond_36

    .line 18
    .line 19
    invoke-interface {v0}, Ljava/util/function/Supplier;->get()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    if-eqz v0, :cond_36

    .line 24
    .line 25
    :try_start_18
    invoke-static {}, Landroid/os/Process;->myTid()I

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    const/16 v1, 0x9

    .line 30
    .line 31
    invoke-static {v0, v1}, Landroid/os/Process;->setThreadPriority(II)V
    :try_end_21
    .catch Ljava/lang/IllegalArgumentException; {:try_start_18 .. :try_end_21} :catch_24
    .catch Ljava/lang/SecurityException; {:try_start_18 .. :try_end_21} :catch_22

    .line 32
    .line 33
    .line 34
    return-void

    .line 35
    :catch_22
    move-exception v0

    .line 36
    goto :goto_25

    .line 37
    :catch_24
    move-exception v0

    .line 38
    :goto_25
    const/4 v1, 0x0

    .line 39
    iput-object v1, p0, Lx60;->x:Ljava/util/function/Supplier;

    .line 40
    .line 41
    const/4 p0, 0x2

    .line 42
    const-string v1, "DecodeJob"

    .line 43
    .line 44
    invoke-static {v1, p0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 45
    .line 46
    .line 47
    move-result p0

    .line 48
    if-eqz p0, :cond_36

    .line 49
    .line 50
    const-string p0, "Failed to set thread priority; using default priority for any subsequent jobs."

    .line 51
    .line 52
    invoke-static {v1, p0, v0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 53
    .line 54
    .line 55
    :cond_36
    return-void

    .line 56
    :cond_37
    const-string p0, "OverrideGlideThreadPriority experiment is not enabled."

    .line 57
    .line 58
    invoke-static {p0}, Ly0;->h(Ljava/lang/String;)V

    .line 59
    .line 60
    .line 61
    return-void
.end method

.method public final m()V
    .registers 4

    .line 1
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iput-object v0, p0, Lx60;->y:Ljava/lang/Thread;

    .line 6
    .line 7
    sget v0, Lpm1;->b:I

    .line 8
    .line 9
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtimeNanos()J

    .line 10
    .line 11
    .line 12
    move-result-wide v0

    .line 13
    iput-wide v0, p0, Lx60;->u:J

    .line 14
    .line 15
    const/4 v0, 0x0

    .line 16
    :cond_f
    iget-boolean v1, p0, Lx60;->G:Z

    .line 17
    .line 18
    if-nez v1, :cond_44

    .line 19
    .line 20
    iget-object v1, p0, Lx60;->E:Ln50;

    .line 21
    .line 22
    if-eqz v1, :cond_44

    .line 23
    .line 24
    iget-object v0, p0, Lx60;->E:Ln50;

    .line 25
    .line 26
    invoke-interface {v0}, Ln50;->b()Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    if-nez v0, :cond_44

    .line 31
    .line 32
    iget v1, p0, Lx60;->I:I

    .line 33
    .line 34
    invoke-virtual {p0, v1}, Lx60;->h(I)I

    .line 35
    .line 36
    .line 37
    move-result v1

    .line 38
    iput v1, p0, Lx60;->I:I

    .line 39
    .line 40
    invoke-virtual {p0}, Lx60;->g()Ln50;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    iput-object v1, p0, Lx60;->E:Ln50;

    .line 45
    .line 46
    iget v1, p0, Lx60;->I:I

    .line 47
    .line 48
    const/4 v2, 0x4

    .line 49
    if-ne v1, v2, :cond_f

    .line 50
    .line 51
    const/4 v0, 0x2

    .line 52
    iput v0, p0, Lx60;->J:I

    .line 53
    .line 54
    iget-object v0, p0, Lx60;->s:Lqi0;

    .line 55
    .line 56
    iget-boolean v1, v0, Lqi0;->o:Z

    .line 57
    .line 58
    if-eqz v1, :cond_3e

    .line 59
    .line 60
    iget-object v0, v0, Lqi0;->j:Lrw0;

    .line 61
    .line 62
    goto :goto_40

    .line 63
    :cond_3e
    iget-object v0, v0, Lqi0;->g:Lrw0;

    .line 64
    .line 65
    :goto_40
    invoke-virtual {v0, p0}, Lrw0;->execute(Ljava/lang/Runnable;)V

    .line 66
    .line 67
    .line 68
    return-void

    .line 69
    :cond_44
    iget v1, p0, Lx60;->I:I

    .line 70
    .line 71
    const/4 v2, 0x6

    .line 72
    if-eq v1, v2, :cond_4d

    .line 73
    .line 74
    iget-boolean v1, p0, Lx60;->G:Z

    .line 75
    .line 76
    if-eqz v1, :cond_52

    .line 77
    .line 78
    :cond_4d
    if-nez v0, :cond_52

    .line 79
    .line 80
    invoke-virtual {p0}, Lx60;->j()V

    .line 81
    .line 82
    .line 83
    :cond_52
    return-void
.end method

.method public final n()V
    .registers 3

    .line 1
    iget v0, p0, Lx60;->J:I

    .line 2
    .line 3
    invoke-static {v0}, Ln10;->u(I)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/4 v1, 0x1

    .line 8
    if-eqz v0, :cond_36

    .line 9
    .line 10
    if-eq v0, v1, :cond_32

    .line 11
    .line 12
    const/4 v1, 0x2

    .line 13
    if-ne v0, v1, :cond_12

    .line 14
    .line 15
    invoke-virtual {p0}, Lx60;->f()V

    .line 16
    .line 17
    .line 18
    return-void

    .line 19
    :cond_12
    iget p0, p0, Lx60;->J:I

    .line 20
    .line 21
    const/4 v0, 0x1

    .line 22
    if-eq p0, v0, :cond_26

    .line 23
    .line 24
    const/4 v0, 0x2

    .line 25
    if-eq p0, v0, :cond_23

    .line 26
    .line 27
    const/4 v0, 0x3

    .line 28
    if-eq p0, v0, :cond_20

    .line 29
    .line 30
    const-string p0, "null"

    .line 31
    .line 32
    goto :goto_28

    .line 33
    :cond_20
    const-string p0, "DECODE_DATA"

    .line 34
    .line 35
    goto :goto_28

    .line 36
    :cond_23
    const-string p0, "SWITCH_TO_SOURCE_SERVICE"

    .line 37
    .line 38
    goto :goto_28

    .line 39
    :cond_26
    const-string p0, "INITIALIZE"

    .line 40
    .line 41
    :goto_28
    const-string v0, "Unrecognized run reason: "

    .line 42
    .line 43
    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object p0

    .line 47
    invoke-static {p0}, Ly0;->h(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    return-void

    .line 51
    :cond_32
    invoke-virtual {p0}, Lx60;->m()V

    .line 52
    .line 53
    .line 54
    return-void

    .line 55
    :cond_36
    invoke-virtual {p0, v1}, Lx60;->h(I)I

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    iput v0, p0, Lx60;->I:I

    .line 60
    .line 61
    invoke-virtual {p0}, Lx60;->g()Ln50;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    iput-object v0, p0, Lx60;->E:Ln50;

    .line 66
    .line 67
    invoke-virtual {p0}, Lx60;->m()V

    .line 68
    .line 69
    .line 70
    return-void
.end method

.method public final o()V
    .registers 3

    .line 1
    iget-object v0, p0, Lx60;->c:Lis2;

    .line 2
    .line 3
    invoke-virtual {v0}, Lis2;->a()V

    .line 4
    .line 5
    .line 6
    iget-boolean v0, p0, Lx60;->F:Z

    .line 7
    .line 8
    const/4 v1, 0x1

    .line 9
    if-eqz v0, :cond_29

    .line 10
    .line 11
    iget-object v0, p0, Lx60;->b:Ljava/util/ArrayList;

    .line 12
    .line 13
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_14

    .line 18
    .line 19
    const/4 p0, 0x0

    .line 20
    goto :goto_21

    .line 21
    :cond_14
    iget-object p0, p0, Lx60;->b:Ljava/util/ArrayList;

    .line 22
    .line 23
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    sub-int/2addr v0, v1

    .line 28
    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object p0

    .line 32
    check-cast p0, Ljava/lang/Throwable;

    .line 33
    .line 34
    :goto_21
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 35
    .line 36
    const-string v1, "Already notified"

    .line 37
    .line 38
    invoke-direct {v0, v1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 39
    .line 40
    .line 41
    throw v0

    .line 42
    :cond_29
    iput-boolean v1, p0, Lx60;->F:Z

    .line 43
    .line 44
    return-void
.end method

.method public final run()V
    .registers 6

    .line 1
    const-string v0, "DecodeJob"

    .line 2
    .line 3
    const-string v1, "DecodeJob threw unexpectedly, isCancelled: "

    .line 4
    .line 5
    iget-object v2, p0, Lx60;->D:Ll50;

    .line 6
    .line 7
    :try_start_6
    iget-boolean v3, p0, Lx60;->G:Z

    .line 8
    .line 9
    if-eqz v3, :cond_17

    .line 10
    .line 11
    invoke-virtual {p0}, Lx60;->j()V
    :try_end_d
    .catch Lro; {:try_start_6 .. :try_end_d} :catch_15
    .catchall {:try_start_6 .. :try_end_d} :catchall_13

    .line 12
    .line 13
    .line 14
    if-eqz v2, :cond_1f

    .line 15
    .line 16
    invoke-interface {v2}, Ll50;->b()V

    .line 17
    .line 18
    .line 19
    return-void

    .line 20
    :catchall_13
    move-exception v3

    .line 21
    goto :goto_20

    .line 22
    :catch_15
    move-exception p0

    .line 23
    goto :goto_5c

    .line 24
    :cond_17
    :try_start_17
    invoke-virtual {p0}, Lx60;->n()V
    :try_end_1a
    .catch Lro; {:try_start_17 .. :try_end_1a} :catch_15
    .catchall {:try_start_17 .. :try_end_1a} :catchall_13

    .line 25
    .line 26
    .line 27
    if-eqz v2, :cond_1f

    .line 28
    .line 29
    invoke-interface {v2}, Ll50;->b()V

    .line 30
    .line 31
    .line 32
    :cond_1f
    return-void

    .line 33
    :goto_20
    const/4 v4, 0x3

    .line 34
    :try_start_21
    invoke-static {v0, v4}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 35
    .line 36
    .line 37
    move-result v4

    .line 38
    if-eqz v4, :cond_49

    .line 39
    .line 40
    new-instance v4, Ljava/lang/StringBuilder;

    .line 41
    .line 42
    invoke-direct {v4, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    iget-boolean v1, p0, Lx60;->G:Z

    .line 46
    .line 47
    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 48
    .line 49
    .line 50
    const-string v1, ", stage: "

    .line 51
    .line 52
    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 53
    .line 54
    .line 55
    iget v1, p0, Lx60;->I:I

    .line 56
    .line 57
    invoke-static {v1}, Ln10;->w(I)Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v1

    .line 61
    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 62
    .line 63
    .line 64
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object v1

    .line 68
    invoke-static {v0, v1, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 69
    .line 70
    .line 71
    goto :goto_49

    .line 72
    :catchall_47
    move-exception p0

    .line 73
    goto :goto_5d

    .line 74
    :cond_49
    :goto_49
    iget v0, p0, Lx60;->I:I

    .line 75
    .line 76
    const/4 v1, 0x5

    .line 77
    if-eq v0, v1, :cond_56

    .line 78
    .line 79
    iget-object v0, p0, Lx60;->b:Ljava/util/ArrayList;

    .line 80
    .line 81
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 82
    .line 83
    .line 84
    invoke-virtual {p0}, Lx60;->j()V

    .line 85
    .line 86
    .line 87
    :cond_56
    iget-boolean p0, p0, Lx60;->G:Z

    .line 88
    .line 89
    if-nez p0, :cond_5b

    .line 90
    .line 91
    throw v3

    .line 92
    :cond_5b
    throw v3

    .line 93
    :goto_5c
    throw p0
    :try_end_5d
    .catchall {:try_start_21 .. :try_end_5d} :catchall_47

    .line 94
    :goto_5d
    if-eqz v2, :cond_62

    .line 95
    .line 96
    invoke-interface {v2}, Ll50;->b()V

    .line 97
    .line 98
    .line 99
    :cond_62
    throw p0
.end method
