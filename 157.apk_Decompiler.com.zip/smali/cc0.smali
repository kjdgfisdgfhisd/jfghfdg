###### Class defpackage.cc0 (cc0)
.class public final Lcc0;
.super Lp60;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lsb0;
.implements Lbu;


# instance fields
.field public final g:Lcm1;

.field public final j:Lya0;

.field public l:Ljava/util/List;

.field public final m:Lx0;

.field public final n:Lu72;

.field public final o:Lev1;

.field public final p:Lkd0;

.field public final q:Lih2;

.field public final r:Lpb0;

.field public s:Lko2;

.field public t:Lko2;

.field public u:Ljava/util/List;

.field public v:Lko2;


# direct methods
.method static constructor <clinit>()V
    .registers 5

    .line 1
    new-instance v0, Lt52;

    .line 2
    .line 3
    sget-object v1, Ltd2;->a:Lud2;

    .line 4
    .line 5
    const-class v2, Lcc0;

    .line 6
    .line 7
    invoke-virtual {v1, v2}, Lud2;->b(Ljava/lang/Class;)Lwc1;

    .line 8
    .line 9
    .line 10
    move-result-object v2

    .line 11
    const-string v3, "constructors"

    .line 12
    .line 13
    const-string v4, "getConstructors()Ljava/util/Collection;"

    .line 14
    .line 15
    invoke-direct {v0, v2, v3, v4}, Lt52;-><init>(Lkd1;Ljava/lang/String;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {v1, v0}, Lud2;->f(Ls52;)Lse1;

    .line 19
    .line 20
    .line 21
    return-void
.end method

.method public constructor <init>(Lcm1;Lm60;Ll7;Ldv1;Lya0;Lu72;Lev1;Lkd0;Lih2;Lpb0;)V
    .registers 12

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    invoke-virtual {p7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    invoke-virtual {p8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    invoke-virtual {p9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    .line 24
    .line 25
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 26
    .line 27
    .line 28
    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 29
    .line 30
    .line 31
    sget-object v0, Loq2;->e0:Ll01;

    .line 32
    .line 33
    invoke-direct {p0, p2, p3, p4, v0}, Lp60;-><init>(Lm60;Ll7;Ldv1;Loq2;)V

    .line 34
    .line 35
    .line 36
    iput-object p1, p0, Lcc0;->g:Lcm1;

    .line 37
    .line 38
    iput-object p5, p0, Lcc0;->j:Lya0;

    .line 39
    .line 40
    new-instance p2, Lw0;

    .line 41
    .line 42
    const/4 p3, 0x0

    .line 43
    invoke-direct {p2, p3, p0}, Lw0;-><init>(ILjava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    invoke-virtual {p1, p2}, Lcm1;->a(Ldt0;)Lzl1;

    .line 47
    .line 48
    .line 49
    new-instance p1, Lx0;

    .line 50
    .line 51
    invoke-direct {p1, p0}, Lx0;-><init>(Lcc0;)V

    .line 52
    .line 53
    .line 54
    iput-object p1, p0, Lcc0;->m:Lx0;

    .line 55
    .line 56
    iput-object p6, p0, Lcc0;->n:Lu72;

    .line 57
    .line 58
    iput-object p7, p0, Lcc0;->o:Lev1;

    .line 59
    .line 60
    iput-object p8, p0, Lcc0;->p:Lkd0;

    .line 61
    .line 62
    iput-object p9, p0, Lcc0;->q:Lih2;

    .line 63
    .line 64
    iput-object p10, p0, Lcc0;->r:Lpb0;

    .line 65
    .line 66
    return-void
.end method


# virtual methods
.method public final C()Lp13;
    .registers 1

    .line 1
    iget-object p0, p0, Lcc0;->m:Lx0;

    .line 2
    .line 3
    return-object p0
.end method

.method public final J0()Lo60;
    .registers 1

    .line 1
    return-object p0
.end method

.method public final K0()Lxt1;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lcc0;->L0()Lko2;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0}, Lfw;->z(Lgg1;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_b

    .line 10
    .line 11
    goto :goto_1e

    .line 12
    :cond_b
    invoke-virtual {p0}, Lcc0;->L0()Lko2;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    invoke-virtual {p0}, Lgg1;->y()Lp13;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    invoke-interface {p0}, Lp13;->c()Lau;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    instance-of v0, p0, Lxt1;

    .line 25
    .line 26
    if-eqz v0, :cond_1e

    .line 27
    .line 28
    check-cast p0, Lxt1;

    .line 29
    .line 30
    return-object p0

    .line 31
    :cond_1e
    :goto_1e
    const/4 p0, 0x0

    .line 32
    return-object p0
.end method

.method public final L0()Lko2;
    .registers 1

    .line 1
    iget-object p0, p0, Lcc0;->t:Lko2;

    .line 2
    .line 3
    if-eqz p0, :cond_5

    .line 4
    .line 5
    return-object p0

    .line 6
    :cond_5
    const-string p0, "expandedType"

    .line 7
    .line 8
    invoke-static {p0}, Ld31;->A(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const/4 p0, 0x0

    .line 12
    throw p0
.end method

.method public final M()Le0;
    .registers 1

    .line 1
    iget-object p0, p0, Lcc0;->n:Lu72;

    .line 2
    .line 3
    return-object p0
.end method

.method public final M0()Lko2;
    .registers 1

    .line 1
    iget-object p0, p0, Lcc0;->s:Lko2;

    .line 2
    .line 3
    if-eqz p0, :cond_5

    .line 4
    .line 5
    return-object p0

    .line 6
    :cond_5
    const-string p0, "underlyingType"

    .line 7
    .line 8
    invoke-static {p0}, Ld31;->A(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const/4 p0, 0x0

    .line 12
    throw p0
.end method

.method public final N0(Ljava/util/List;Lko2;Lko2;)V
    .registers 10

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcc0;->l:Ljava/util/List;

    .line 8
    .line 9
    iput-object p2, p0, Lcc0;->s:Lko2;

    .line 10
    .line 11
    iput-object p3, p0, Lcc0;->t:Lko2;

    .line 12
    .line 13
    invoke-static {p0}, Ld31;->g(Lbu;)Ljava/util/List;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    iput-object p1, p0, Lcc0;->u:Ljava/util/List;

    .line 18
    .line 19
    invoke-virtual {p0}, Lcc0;->K0()Lxt1;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    if-eqz p1, :cond_21

    .line 24
    .line 25
    invoke-virtual {p1}, Lxt1;->q0()Lvr1;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    if-nez p1, :cond_1f

    .line 30
    .line 31
    goto :goto_21

    .line 32
    :cond_1f
    :goto_1f
    move-object v4, p1

    .line 33
    goto :goto_24

    .line 34
    :cond_21
    :goto_21
    sget-object p1, Lur1;->b:Lur1;

    .line 35
    .line 36
    goto :goto_1f

    .line 37
    :goto_24
    new-instance v5, Lp23;

    .line 38
    .line 39
    const/4 p1, 0x3

    .line 40
    invoke-direct {v5, p1, p0}, Lp23;-><init>(ILjava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    sget-object p1, La33;->a:Lwj0;

    .line 44
    .line 45
    invoke-static {p0}, Lzj0;->f(Lm60;)Z

    .line 46
    .line 47
    .line 48
    move-result p1

    .line 49
    if-eqz p1, :cond_41

    .line 50
    .line 51
    invoke-virtual {p0}, Lcc0;->toString()Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    filled-new-array {p1}, [Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    sget-object p2, Lyj0;->n:Lyj0;

    .line 60
    .line 61
    invoke-static {p2, p1}, Lzj0;->c(Lyj0;[Ljava/lang/String;)Lwj0;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    goto :goto_5e

    .line 66
    :cond_41
    invoke-virtual {p0}, Lcc0;->C()Lp13;

    .line 67
    .line 68
    .line 69
    move-result-object v1

    .line 70
    if-eqz v1, :cond_61

    .line 71
    .line 72
    move-object p1, v1

    .line 73
    check-cast p1, Lx0;

    .line 74
    .line 75
    invoke-virtual {p1}, Lx0;->e()Ljava/util/List;

    .line 76
    .line 77
    .line 78
    move-result-object p1

    .line 79
    invoke-static {p1}, La33;->d(Ljava/util/List;)Ljava/util/List;

    .line 80
    .line 81
    .line 82
    move-result-object v2

    .line 83
    sget-object p1, Lg13;->b:Lm92;

    .line 84
    .line 85
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 86
    .line 87
    .line 88
    sget-object v0, Lg13;->c:Lg13;

    .line 89
    .line 90
    const/4 v3, 0x0

    .line 91
    invoke-static/range {v0 .. v5}, Lkv3;->y(Lg13;Lp13;Ljava/util/List;ZLvr1;Lft0;)Lko2;

    .line 92
    .line 93
    .line 94
    move-result-object p1

    .line 95
    :goto_5e
    iput-object p1, p0, Lcc0;->v:Lko2;

    .line 96
    .line 97
    return-void

    .line 98
    :cond_61
    const/16 p0, 0xc

    .line 99
    .line 100
    invoke-static {p0}, La33;->a(I)V

    .line 101
    .line 102
    .line 103
    const/4 p0, 0x0

    .line 104
    throw p0
.end method

.method public final T()Lko2;
    .registers 1

    .line 1
    iget-object p0, p0, Lcc0;->v:Lko2;

    .line 2
    .line 3
    if-eqz p0, :cond_5

    .line 4
    .line 5
    return-object p0

    .line 6
    :cond_5
    const-string p0, "defaultTypeImpl"

    .line 7
    .line 8
    invoke-static {p0}, Ld31;->A(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const/4 p0, 0x0

    .line 12
    throw p0
.end method

.method public final Y()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final Z()Z
    .registers 4

    .line 1
    invoke-virtual {p0}, Lcc0;->M0()Lko2;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    new-instance v1, Lk;

    .line 6
    .line 7
    const/4 v2, 0x4

    .line 8
    invoke-direct {v1, v2, p0}, Lk;-><init>(ILjava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    const/4 p0, 0x0

    .line 12
    invoke-static {v0, v1, p0}, La33;->c(Lgg1;Lft0;Lcq2;)Z

    .line 13
    .line 14
    .line 15
    move-result p0

    .line 16
    return p0
.end method

.method public final b()Lau;
    .registers 1

    .line 1
    return-object p0
.end method

.method public final b()Lm60;
    .registers 1

    .line 2
    return-object p0
.end method

.method public final e(Lx23;)Lo60;
    .registers 14

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object v0, p1, Lx23;->a:Lv23;

    .line 5
    .line 6
    invoke-virtual {v0}, Lv23;->e()Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-eqz v0, :cond_c

    .line 11
    .line 12
    return-object p0

    .line 13
    :cond_c
    new-instance v1, Lcc0;

    .line 14
    .line 15
    invoke-virtual {p0}, Lp60;->p()Lm60;

    .line 16
    .line 17
    .line 18
    move-result-object v3

    .line 19
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    invoke-virtual {p0}, Lov;->getAnnotations()Ll7;

    .line 23
    .line 24
    .line 25
    move-result-object v4

    .line 26
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 27
    .line 28
    .line 29
    invoke-virtual {p0}, Ln60;->getName()Ldv1;

    .line 30
    .line 31
    .line 32
    move-result-object v5

    .line 33
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 34
    .line 35
    .line 36
    iget-object v10, p0, Lcc0;->q:Lih2;

    .line 37
    .line 38
    iget-object v11, p0, Lcc0;->r:Lpb0;

    .line 39
    .line 40
    iget-object v2, p0, Lcc0;->g:Lcm1;

    .line 41
    .line 42
    iget-object v6, p0, Lcc0;->j:Lya0;

    .line 43
    .line 44
    iget-object v7, p0, Lcc0;->n:Lu72;

    .line 45
    .line 46
    iget-object v8, p0, Lcc0;->o:Lev1;

    .line 47
    .line 48
    iget-object v9, p0, Lcc0;->p:Lkd0;

    .line 49
    .line 50
    invoke-direct/range {v1 .. v11}, Lcc0;-><init>(Lcm1;Lm60;Ll7;Ldv1;Lya0;Lu72;Lev1;Lkd0;Lih2;Lpb0;)V

    .line 51
    .line 52
    .line 53
    invoke-virtual {p0}, Lcc0;->s0()Ljava/util/List;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    invoke-virtual {p0}, Lcc0;->M0()Lko2;

    .line 58
    .line 59
    .line 60
    move-result-object v2

    .line 61
    sget-object v3, Lf73;->c:Lf73;

    .line 62
    .line 63
    invoke-virtual {p1, v2, v3}, Lx23;->f(Lgg1;Lf73;)Lgg1;

    .line 64
    .line 65
    .line 66
    move-result-object v2

    .line 67
    invoke-static {v2}, Lmw1;->c(Lgg1;)Lko2;

    .line 68
    .line 69
    .line 70
    move-result-object v2

    .line 71
    invoke-virtual {p0}, Lcc0;->L0()Lko2;

    .line 72
    .line 73
    .line 74
    move-result-object p0

    .line 75
    invoke-virtual {p1, p0, v3}, Lx23;->f(Lgg1;Lf73;)Lgg1;

    .line 76
    .line 77
    .line 78
    move-result-object p0

    .line 79
    invoke-static {p0}, Lmw1;->c(Lgg1;)Lko2;

    .line 80
    .line 81
    .line 82
    move-result-object p0

    .line 83
    invoke-virtual {v1, v0, v2, p0}, Lcc0;->N0(Ljava/util/List;Lko2;Lko2;)V

    .line 84
    .line 85
    .line 86
    return-object v1
.end method

.method public final g()Lya0;
    .registers 1

    .line 1
    iget-object p0, p0, Lcc0;->j:Lya0;

    .line 2
    .line 3
    return-object p0
.end method

.method public final i0()Lkd0;
    .registers 1

    .line 1
    iget-object p0, p0, Lcc0;->p:Lkd0;

    .line 2
    .line 3
    return-object p0
.end method

.method public final n0(Lq60;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    invoke-interface {p1, p0, p2}, Lq60;->a(Lcc0;Ljava/lang/Object;)Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public final o0()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final s0()Ljava/util/List;
    .registers 1

    .line 1
    iget-object p0, p0, Lcc0;->l:Ljava/util/List;

    .line 2
    .line 3
    if-eqz p0, :cond_5

    .line 4
    .line 5
    return-object p0

    .line 6
    :cond_5
    const-string p0, "declaredTypeParametersImpl"

    .line 7
    .line 8
    invoke-static {p0}, Ld31;->A(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const/4 p0, 0x0

    .line 12
    throw p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "typealias "

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0}, Ln60;->getName()Ldv1;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    invoke-virtual {p0}, Ldv1;->b()Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 17
    .line 18
    .line 19
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    return-object p0
.end method

.method public final v()Lpb0;
    .registers 1

    .line 1
    iget-object p0, p0, Lcc0;->r:Lpb0;

    .line 2
    .line 3
    return-object p0
.end method

.method public final v0()Lev1;
    .registers 1

    .line 1
    iget-object p0, p0, Lcc0;->o:Lev1;

    .line 2
    .line 3
    return-object p0
.end method

.method public final z()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method
