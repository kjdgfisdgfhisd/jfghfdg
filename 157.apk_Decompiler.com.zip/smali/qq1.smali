###### Class defpackage.qq1 (qq1)
.class public final synthetic Lqq1;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Ljava/util/function/Function;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    .line 1
    iput p1, p0, Lqq1;->a:I

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public synthetic constructor <init>(Ly11;I)V
    .registers 3

    .line 7
    iput p2, p0, Lqq1;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final apply(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 29

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v0, v0, Lqq1;->a:I

    .line 4
    .line 5
    const-wide/high16 v1, 0x4044000000000000L    # 40.0

    .line 6
    .line 7
    const-wide v3, 0x4058800000000000L    # 98.0

    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    const-wide/high16 v5, 0x4018000000000000L    # 6.0

    .line 13
    .line 14
    const-wide/high16 v7, 0x3fe0000000000000L    # 0.5

    .line 15
    .line 16
    const-wide v9, 0x4056800000000000L    # 90.0

    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    const-wide/high16 v11, 0x3ff0000000000000L    # 1.0

    .line 22
    .line 23
    const-wide/16 v13, 0x0

    .line 24
    .line 25
    const-wide/high16 v15, -0x4010000000000000L    # -1.0

    .line 26
    .line 27
    const-wide/high16 v17, 0x4054000000000000L    # 80.0

    .line 28
    .line 29
    const-wide/high16 v19, 0x403e000000000000L    # 30.0

    .line 30
    .line 31
    packed-switch v0, :pswitch_data_304

    .line 32
    .line 33
    .line 34
    move-object/from16 v0, p1

    .line 35
    .line 36
    check-cast v0, Ltj2;

    .line 37
    .line 38
    iget-boolean v0, v0, Ltj2;->b:Z

    .line 39
    .line 40
    if-eqz v0, :cond_2b

    .line 41
    .line 42
    move-wide/from16 v17, v19

    .line 43
    .line 44
    :cond_2b
    invoke-static/range {v17 .. v18}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    return-object v0

    .line 49
    :pswitch_30
    move-object/from16 v0, p1

    .line 50
    .line 51
    check-cast v0, Ltj2;

    .line 52
    .line 53
    iget-object v0, v0, Ltj2;->h:Lqy2;

    .line 54
    .line 55
    return-object v0

    .line 56
    :pswitch_37
    move-object/from16 v0, p1

    .line 57
    .line 58
    check-cast v0, Ltj2;

    .line 59
    .line 60
    new-instance v1, Lqf0;

    .line 61
    .line 62
    new-instance v3, Lqq1;

    .line 63
    .line 64
    const/16 v0, 0x14

    .line 65
    .line 66
    invoke-direct {v3, v0}, Lqq1;-><init>(I)V

    .line 67
    .line 68
    .line 69
    new-instance v4, Lqq1;

    .line 70
    .line 71
    const/16 v0, 0x15

    .line 72
    .line 73
    invoke-direct {v4, v0}, Lqq1;-><init>(I)V

    .line 74
    .line 75
    .line 76
    const/4 v7, 0x0

    .line 77
    const/4 v8, 0x0

    .line 78
    const-string v2, "background"

    .line 79
    .line 80
    const/4 v5, 0x1

    .line 81
    const/4 v6, 0x0

    .line 82
    invoke-direct/range {v1 .. v8}, Lqf0;-><init>(Ljava/lang/String;Ljava/util/function/Function;Ljava/util/function/Function;ZLjava/util/function/Function;Lb10;Ljava/util/function/Function;)V

    .line 83
    .line 84
    .line 85
    return-object v1

    .line 86
    :pswitch_55
    move-object/from16 v0, p1

    .line 87
    .line 88
    check-cast v0, Ltj2;

    .line 89
    .line 90
    iget-boolean v0, v0, Ltj2;->b:Z

    .line 91
    .line 92
    if-eqz v0, :cond_5e

    .line 93
    .line 94
    goto :goto_60

    .line 95
    :cond_5e
    const-wide/high16 v9, 0x4024000000000000L    # 10.0

    .line 96
    .line 97
    :goto_60
    invoke-static {v9, v10}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 98
    .line 99
    .line 100
    move-result-object v0

    .line 101
    return-object v0

    .line 102
    :pswitch_65
    move-object/from16 v0, p1

    .line 103
    .line 104
    check-cast v0, Ltj2;

    .line 105
    .line 106
    iget-object v0, v0, Ltj2;->g:Lqy2;

    .line 107
    .line 108
    return-object v0

    .line 109
    :pswitch_6c
    move-object/from16 v0, p1

    .line 110
    .line 111
    check-cast v0, Ltj2;

    .line 112
    .line 113
    iget-boolean v1, v0, Ltj2;->b:Z

    .line 114
    .line 115
    iget-wide v2, v0, Ltj2;->c:D

    .line 116
    .line 117
    if-eqz v1, :cond_aa

    .line 118
    .line 119
    cmpg-double v0, v2, v15

    .line 120
    .line 121
    const-wide/high16 v17, 0x4031000000000000L    # 17.0

    .line 122
    .line 123
    if-gtz v0, :cond_7d

    .line 124
    .line 125
    goto :goto_e0

    .line 126
    :cond_7d
    cmpg-double v0, v2, v13

    .line 127
    .line 128
    const-wide/high16 v19, 0x4031000000000000L    # 17.0

    .line 129
    .line 130
    if-gez v0, :cond_8b

    .line 131
    .line 132
    sub-double/2addr v2, v15

    .line 133
    div-double v21, v2, v11

    .line 134
    .line 135
    invoke-static/range {v17 .. v22}, Lmw1;->t(DDD)D

    .line 136
    .line 137
    .line 138
    move-result-wide v17

    .line 139
    goto :goto_e0

    .line 140
    :cond_8b
    cmpg-double v0, v2, v7

    .line 141
    .line 142
    const-wide/high16 v21, 0x4035000000000000L    # 21.0

    .line 143
    .line 144
    if-gez v0, :cond_99

    .line 145
    .line 146
    sub-double/2addr v2, v13

    .line 147
    div-double v23, v2, v7

    .line 148
    .line 149
    invoke-static/range {v19 .. v24}, Lmw1;->t(DDD)D

    .line 150
    .line 151
    .line 152
    move-result-wide v17

    .line 153
    goto :goto_e0

    .line 154
    :cond_99
    cmpg-double v0, v2, v11

    .line 155
    .line 156
    const-wide/high16 v23, 0x4039000000000000L    # 25.0

    .line 157
    .line 158
    if-gez v0, :cond_a7

    .line 159
    .line 160
    sub-double/2addr v2, v7

    .line 161
    div-double v25, v2, v7

    .line 162
    .line 163
    invoke-static/range {v21 .. v26}, Lmw1;->t(DDD)D

    .line 164
    .line 165
    .line 166
    move-result-wide v17

    .line 167
    goto :goto_e0

    .line 168
    :cond_a7
    move-wide/from16 v17, v23

    .line 169
    .line 170
    goto :goto_e0

    .line 171
    :cond_aa
    cmpg-double v0, v2, v15

    .line 172
    .line 173
    const-wide/high16 v17, 0x4057000000000000L    # 92.0

    .line 174
    .line 175
    if-gtz v0, :cond_b1

    .line 176
    .line 177
    goto :goto_e0

    .line 178
    :cond_b1
    cmpg-double v0, v2, v13

    .line 179
    .line 180
    const-wide/high16 v19, 0x4057000000000000L    # 92.0

    .line 181
    .line 182
    if-gez v0, :cond_c1

    .line 183
    .line 184
    sub-double/2addr v2, v15

    .line 185
    div-double v21, v2, v11

    .line 186
    .line 187
    invoke-static/range {v17 .. v22}, Lmw1;->t(DDD)D

    .line 188
    .line 189
    .line 190
    move-result-wide v0

    .line 191
    :goto_be
    move-wide/from16 v17, v0

    .line 192
    .line 193
    goto :goto_e0

    .line 194
    :cond_c1
    cmpg-double v0, v2, v7

    .line 195
    .line 196
    const-wide/high16 v21, 0x4056000000000000L    # 88.0

    .line 197
    .line 198
    if-gez v0, :cond_cf

    .line 199
    .line 200
    sub-double/2addr v2, v13

    .line 201
    div-double v23, v2, v7

    .line 202
    .line 203
    invoke-static/range {v19 .. v24}, Lmw1;->t(DDD)D

    .line 204
    .line 205
    .line 206
    move-result-wide v0

    .line 207
    goto :goto_be

    .line 208
    :cond_cf
    cmpg-double v0, v2, v11

    .line 209
    .line 210
    const-wide v23, 0x4055400000000000L    # 85.0

    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    if-gez v0, :cond_a7

    .line 216
    .line 217
    sub-double/2addr v2, v7

    .line 218
    div-double v25, v2, v7

    .line 219
    .line 220
    invoke-static/range {v21 .. v26}, Lmw1;->t(DDD)D

    .line 221
    .line 222
    .line 223
    move-result-wide v0

    .line 224
    goto :goto_be

    .line 225
    :goto_e0
    invoke-static/range {v17 .. v18}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 226
    .line 227
    .line 228
    move-result-object v0

    .line 229
    return-object v0

    .line 230
    :pswitch_e5
    move-object/from16 v0, p1

    .line 231
    .line 232
    check-cast v0, Ltj2;

    .line 233
    .line 234
    iget-object v0, v0, Ltj2;->g:Lqy2;

    .line 235
    .line 236
    return-object v0

    .line 237
    :pswitch_ec
    move-object/from16 v0, p1

    .line 238
    .line 239
    check-cast v0, Ltj2;

    .line 240
    .line 241
    iget-object v0, v0, Ltj2;->g:Lqy2;

    .line 242
    .line 243
    return-object v0

    .line 244
    :pswitch_f3
    move-object/from16 v0, p1

    .line 245
    .line 246
    check-cast v0, Ltj2;

    .line 247
    .line 248
    iget-boolean v0, v0, Ltj2;->b:Z

    .line 249
    .line 250
    if-eqz v0, :cond_fc

    .line 251
    .line 252
    move-wide v3, v5

    .line 253
    :cond_fc
    invoke-static {v3, v4}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 254
    .line 255
    .line 256
    move-result-object v0

    .line 257
    return-object v0

    .line 258
    :pswitch_101
    move-object/from16 v0, p1

    .line 259
    .line 260
    check-cast v0, Ltj2;

    .line 261
    .line 262
    iget-object v0, v0, Ltj2;->g:Lqy2;

    .line 263
    .line 264
    return-object v0

    .line 265
    :pswitch_108
    move-object/from16 v0, p1

    .line 266
    .line 267
    check-cast v0, Ltj2;

    .line 268
    .line 269
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 270
    .line 271
    .line 272
    iget-object v0, v0, Ltj2;->a:Lux0;

    .line 273
    .line 274
    iget-wide v0, v0, Lux0;->c:D

    .line 275
    .line 276
    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 277
    .line 278
    .line 279
    move-result-object v0

    .line 280
    return-object v0

    .line 281
    :pswitch_118
    move-object/from16 v0, p1

    .line 282
    .line 283
    check-cast v0, Ltj2;

    .line 284
    .line 285
    iget-object v0, v0, Ltj2;->d:Lqy2;

    .line 286
    .line 287
    return-object v0

    .line 288
    :pswitch_11f
    move-object/from16 v0, p1

    .line 289
    .line 290
    check-cast v0, Ltj2;

    .line 291
    .line 292
    iget-boolean v0, v0, Ltj2;->b:Z

    .line 293
    .line 294
    if-eqz v0, :cond_12d

    .line 295
    .line 296
    const-wide v0, 0x3fc999999999999aL    # 0.2

    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    goto :goto_132

    .line 302
    :cond_12d
    const-wide v0, 0x3fbeb851eb851eb8L    # 0.12

    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    :goto_132
    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 308
    .line 309
    .line 310
    move-result-object v0

    .line 311
    return-object v0

    .line 312
    :pswitch_137
    move-object/from16 v0, p1

    .line 313
    .line 314
    check-cast v0, Ltj2;

    .line 315
    .line 316
    iget-boolean v0, v0, Ltj2;->b:Z

    .line 317
    .line 318
    if-eqz v0, :cond_141

    .line 319
    .line 320
    const-wide/high16 v13, 0x4059000000000000L    # 100.0

    .line 321
    .line 322
    :cond_141
    invoke-static {v13, v14}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 323
    .line 324
    .line 325
    move-result-object v0

    .line 326
    return-object v0

    .line 327
    :pswitch_146
    move-object/from16 v0, p1

    .line 328
    .line 329
    check-cast v0, Ltj2;

    .line 330
    .line 331
    iget-object v0, v0, Ltj2;->g:Lqy2;

    .line 332
    .line 333
    return-object v0

    .line 334
    :pswitch_14d
    move-object/from16 v0, p1

    .line 335
    .line 336
    check-cast v0, Ltj2;

    .line 337
    .line 338
    iget-boolean v0, v0, Ltj2;->b:Z

    .line 339
    .line 340
    if-eqz v0, :cond_156

    .line 341
    .line 342
    move-wide v3, v5

    .line 343
    :cond_156
    invoke-static {v3, v4}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 344
    .line 345
    .line 346
    move-result-object v0

    .line 347
    return-object v0

    .line 348
    :pswitch_15b
    move-object/from16 v0, p1

    .line 349
    .line 350
    check-cast v0, Ltj2;

    .line 351
    .line 352
    iget-boolean v1, v0, Ltj2;->b:Z

    .line 353
    .line 354
    if-eqz v1, :cond_166

    .line 355
    .line 356
    move-wide/from16 v6, v19

    .line 357
    .line 358
    goto :goto_167

    .line 359
    :cond_166
    move-wide v6, v9

    .line 360
    :goto_167
    iget-object v0, v0, Ltj2;->e:Lqy2;

    .line 361
    .line 362
    iget-wide v2, v0, Lqy2;->a:D

    .line 363
    .line 364
    iget-wide v4, v0, Lqy2;->b:D

    .line 365
    .line 366
    invoke-static/range {v2 .. v7}, Lux0;->a(DDD)Lux0;

    .line 367
    .line 368
    .line 369
    move-result-object v0

    .line 370
    move-wide/from16 v17, v2

    .line 371
    .line 372
    move-wide/from16 v19, v4

    .line 373
    .line 374
    iget-wide v2, v0, Lux0;->b:D

    .line 375
    .line 376
    cmpg-double v4, v2, v19

    .line 377
    .line 378
    if-gez v4, :cond_1c3

    .line 379
    .line 380
    :goto_17b
    iget-wide v4, v0, Lux0;->b:D

    .line 381
    .line 382
    cmpg-double v4, v4, v19

    .line 383
    .line 384
    if-gez v4, :cond_1c3

    .line 385
    .line 386
    if-nez v1, :cond_185

    .line 387
    .line 388
    move-wide v4, v15

    .line 389
    goto :goto_186

    .line 390
    :cond_185
    move-wide v4, v11

    .line 391
    :goto_186
    add-double v21, v6, v4

    .line 392
    .line 393
    invoke-static/range {v17 .. v22}, Lux0;->a(DDD)Lux0;

    .line 394
    .line 395
    .line 396
    move-result-object v4

    .line 397
    iget-wide v5, v4, Lux0;->b:D

    .line 398
    .line 399
    cmpl-double v7, v2, v5

    .line 400
    .line 401
    if-lez v7, :cond_193

    .line 402
    .line 403
    goto :goto_1a2

    .line 404
    :cond_193
    sub-double v5, v5, v19

    .line 405
    .line 406
    invoke-static {v5, v6}, Ljava/lang/Math;->abs(D)D

    .line 407
    .line 408
    .line 409
    move-result-wide v5

    .line 410
    const-wide v7, 0x3fd999999999999aL    # 0.4

    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    cmpg-double v5, v5, v7

    .line 416
    .line 417
    if-gez v5, :cond_1a5

    .line 418
    .line 419
    :goto_1a2
    move-wide/from16 v6, v21

    .line 420
    .line 421
    goto :goto_1c3

    .line 422
    :cond_1a5
    iget-wide v5, v4, Lux0;->b:D

    .line 423
    .line 424
    sub-double v5, v5, v19

    .line 425
    .line 426
    invoke-static {v5, v6}, Ljava/lang/Math;->abs(D)D

    .line 427
    .line 428
    .line 429
    move-result-wide v5

    .line 430
    iget-wide v7, v0, Lux0;->b:D

    .line 431
    .line 432
    sub-double v7, v7, v19

    .line 433
    .line 434
    invoke-static {v7, v8}, Ljava/lang/Math;->abs(D)D

    .line 435
    .line 436
    .line 437
    move-result-wide v7

    .line 438
    cmpg-double v5, v5, v7

    .line 439
    .line 440
    if-gez v5, :cond_1ba

    .line 441
    .line 442
    move-object v0, v4

    .line 443
    :cond_1ba
    iget-wide v4, v4, Lux0;->b:D

    .line 444
    .line 445
    invoke-static {v2, v3, v4, v5}, Ljava/lang/Math;->max(DD)D

    .line 446
    .line 447
    .line 448
    move-result-wide v2

    .line 449
    move-wide/from16 v6, v21

    .line 450
    .line 451
    goto :goto_17b

    .line 452
    :cond_1c3
    :goto_1c3
    invoke-static {v6, v7}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 453
    .line 454
    .line 455
    move-result-object v0

    .line 456
    return-object v0

    .line 457
    :pswitch_1c8
    move-object/from16 v0, p1

    .line 458
    .line 459
    check-cast v0, Ltj2;

    .line 460
    .line 461
    iget-object v0, v0, Ltj2;->e:Lqy2;

    .line 462
    .line 463
    return-object v0

    .line 464
    :pswitch_1cf
    move-object/from16 v0, p1

    .line 465
    .line 466
    check-cast v0, Ltj2;

    .line 467
    .line 468
    iget-boolean v1, v0, Ltj2;->b:Z

    .line 469
    .line 470
    iget-wide v2, v0, Ltj2;->c:D

    .line 471
    .line 472
    if-eqz v1, :cond_20d

    .line 473
    .line 474
    cmpg-double v0, v2, v15

    .line 475
    .line 476
    const-wide/high16 v17, 0x4024000000000000L    # 10.0

    .line 477
    .line 478
    if-gtz v0, :cond_1e0

    .line 479
    .line 480
    goto :goto_243

    .line 481
    :cond_1e0
    cmpg-double v0, v2, v13

    .line 482
    .line 483
    const-wide/high16 v19, 0x4024000000000000L    # 10.0

    .line 484
    .line 485
    if-gez v0, :cond_1ee

    .line 486
    .line 487
    sub-double/2addr v2, v15

    .line 488
    div-double v21, v2, v11

    .line 489
    .line 490
    invoke-static/range {v17 .. v22}, Lmw1;->t(DDD)D

    .line 491
    .line 492
    .line 493
    move-result-wide v17

    .line 494
    goto :goto_243

    .line 495
    :cond_1ee
    cmpg-double v0, v2, v7

    .line 496
    .line 497
    const-wide/high16 v21, 0x4026000000000000L    # 11.0

    .line 498
    .line 499
    if-gez v0, :cond_1fc

    .line 500
    .line 501
    sub-double/2addr v2, v13

    .line 502
    div-double v23, v2, v7

    .line 503
    .line 504
    invoke-static/range {v19 .. v24}, Lmw1;->t(DDD)D

    .line 505
    .line 506
    .line 507
    move-result-wide v17

    .line 508
    goto :goto_243

    .line 509
    :cond_1fc
    cmpg-double v0, v2, v11

    .line 510
    .line 511
    const-wide/high16 v23, 0x4028000000000000L    # 12.0

    .line 512
    .line 513
    if-gez v0, :cond_20a

    .line 514
    .line 515
    sub-double/2addr v2, v7

    .line 516
    div-double v25, v2, v7

    .line 517
    .line 518
    invoke-static/range {v21 .. v26}, Lmw1;->t(DDD)D

    .line 519
    .line 520
    .line 521
    move-result-wide v17

    .line 522
    goto :goto_243

    .line 523
    :cond_20a
    move-wide/from16 v17, v23

    .line 524
    .line 525
    goto :goto_243

    .line 526
    :cond_20d
    cmpg-double v0, v2, v15

    .line 527
    .line 528
    const-wide/high16 v17, 0x4058000000000000L    # 96.0

    .line 529
    .line 530
    if-gtz v0, :cond_214

    .line 531
    .line 532
    goto :goto_243

    .line 533
    :cond_214
    cmpg-double v0, v2, v13

    .line 534
    .line 535
    const-wide/high16 v19, 0x4058000000000000L    # 96.0

    .line 536
    .line 537
    if-gez v0, :cond_224

    .line 538
    .line 539
    sub-double/2addr v2, v15

    .line 540
    div-double v21, v2, v11

    .line 541
    .line 542
    invoke-static/range {v17 .. v22}, Lmw1;->t(DDD)D

    .line 543
    .line 544
    .line 545
    move-result-wide v0

    .line 546
    :goto_221
    move-wide/from16 v17, v0

    .line 547
    .line 548
    goto :goto_243

    .line 549
    :cond_224
    cmpg-double v0, v2, v7

    .line 550
    .line 551
    const-wide/high16 v21, 0x4058000000000000L    # 96.0

    .line 552
    .line 553
    if-gez v0, :cond_232

    .line 554
    .line 555
    sub-double/2addr v2, v13

    .line 556
    div-double v23, v2, v7

    .line 557
    .line 558
    invoke-static/range {v19 .. v24}, Lmw1;->t(DDD)D

    .line 559
    .line 560
    .line 561
    move-result-wide v0

    .line 562
    goto :goto_221

    .line 563
    :cond_232
    cmpg-double v0, v2, v11

    .line 564
    .line 565
    const-wide v23, 0x4057c00000000000L    # 95.0

    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    if-gez v0, :cond_20a

    .line 571
    .line 572
    sub-double/2addr v2, v7

    .line 573
    div-double v25, v2, v7

    .line 574
    .line 575
    invoke-static/range {v21 .. v26}, Lmw1;->t(DDD)D

    .line 576
    .line 577
    .line 578
    move-result-wide v0

    .line 579
    goto :goto_221

    .line 580
    :goto_243
    invoke-static/range {v17 .. v18}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 581
    .line 582
    .line 583
    move-result-object v0

    .line 584
    return-object v0

    .line 585
    :pswitch_248
    move-object/from16 v0, p1

    .line 586
    .line 587
    check-cast v0, Ltj2;

    .line 588
    .line 589
    iget-object v0, v0, Ltj2;->g:Lqy2;

    .line 590
    .line 591
    return-object v0

    .line 592
    :pswitch_24f
    move-object/from16 v0, p1

    .line 593
    .line 594
    check-cast v0, Ltj2;

    .line 595
    .line 596
    iget-boolean v0, v0, Ltj2;->b:Z

    .line 597
    .line 598
    if-eqz v0, :cond_259

    .line 599
    .line 600
    move-wide/from16 v9, v19

    .line 601
    .line 602
    :cond_259
    invoke-static {v9, v10}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 603
    .line 604
    .line 605
    move-result-object v0

    .line 606
    return-object v0

    .line 607
    :pswitch_25e
    move-object/from16 v0, p1

    .line 608
    .line 609
    check-cast v0, Ltj2;

    .line 610
    .line 611
    iget-object v0, v0, Ltj2;->d:Lqy2;

    .line 612
    .line 613
    return-object v0

    .line 614
    :pswitch_265
    move-object/from16 v0, p1

    .line 615
    .line 616
    check-cast v0, Ltj2;

    .line 617
    .line 618
    iget-boolean v0, v0, Ltj2;->b:Z

    .line 619
    .line 620
    if-eqz v0, :cond_26e

    .line 621
    .line 622
    goto :goto_270

    .line 623
    :cond_26e
    move-wide/from16 v17, v19

    .line 624
    .line 625
    :goto_270
    invoke-static/range {v17 .. v18}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 626
    .line 627
    .line 628
    move-result-object v0

    .line 629
    return-object v0

    .line 630
    :pswitch_275
    move-object/from16 v0, p1

    .line 631
    .line 632
    check-cast v0, Ltj2;

    .line 633
    .line 634
    iget-object v0, v0, Ltj2;->h:Lqy2;

    .line 635
    .line 636
    return-object v0

    .line 637
    :pswitch_27c
    move-object/from16 v0, p1

    .line 638
    .line 639
    check-cast v0, Ltj2;

    .line 640
    .line 641
    iget-boolean v1, v0, Ltj2;->b:Z

    .line 642
    .line 643
    if-eqz v1, :cond_285

    .line 644
    .line 645
    goto :goto_2c6

    .line 646
    :cond_285
    iget-wide v0, v0, Ltj2;->c:D

    .line 647
    .line 648
    cmpg-double v2, v0, v15

    .line 649
    .line 650
    const-wide v17, 0x4055c00000000000L    # 87.0

    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    if-gtz v2, :cond_293

    .line 656
    .line 657
    move-wide/from16 v5, v17

    .line 658
    .line 659
    goto :goto_2c6

    .line 660
    :cond_293
    cmpg-double v2, v0, v13

    .line 661
    .line 662
    const-wide v19, 0x4055c00000000000L    # 87.0

    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    if-gez v2, :cond_2a5

    .line 668
    .line 669
    sub-double/2addr v0, v15

    .line 670
    div-double v21, v0, v11

    .line 671
    .line 672
    invoke-static/range {v17 .. v22}, Lmw1;->t(DDD)D

    .line 673
    .line 674
    .line 675
    move-result-wide v0

    .line 676
    :goto_2a3
    move-wide v5, v0

    .line 677
    goto :goto_2c6

    .line 678
    :cond_2a5
    cmpg-double v2, v0, v7

    .line 679
    .line 680
    const-wide/high16 v21, 0x4054000000000000L    # 80.0

    .line 681
    .line 682
    if-gez v2, :cond_2b3

    .line 683
    .line 684
    sub-double/2addr v0, v13

    .line 685
    div-double v23, v0, v7

    .line 686
    .line 687
    invoke-static/range {v19 .. v24}, Lmw1;->t(DDD)D

    .line 688
    .line 689
    .line 690
    move-result-wide v0

    .line 691
    goto :goto_2a3

    .line 692
    :cond_2b3
    cmpg-double v2, v0, v11

    .line 693
    .line 694
    const-wide v23, 0x4052c00000000000L    # 75.0

    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    if-gez v2, :cond_2c4

    .line 700
    .line 701
    sub-double/2addr v0, v7

    .line 702
    div-double v25, v0, v7

    .line 703
    .line 704
    invoke-static/range {v21 .. v26}, Lmw1;->t(DDD)D

    .line 705
    .line 706
    .line 707
    move-result-wide v0

    .line 708
    goto :goto_2a3

    .line 709
    :cond_2c4
    move-wide/from16 v5, v23

    .line 710
    .line 711
    :goto_2c6
    invoke-static {v5, v6}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 712
    .line 713
    .line 714
    move-result-object v0

    .line 715
    return-object v0

    .line 716
    :pswitch_2cb
    move-object/from16 v0, p1

    .line 717
    .line 718
    check-cast v0, Ltj2;

    .line 719
    .line 720
    iget-object v0, v0, Ltj2;->g:Lqy2;

    .line 721
    .line 722
    return-object v0

    .line 723
    :pswitch_2d2
    move-object/from16 v0, p1

    .line 724
    .line 725
    check-cast v0, Ltj2;

    .line 726
    .line 727
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 728
    .line 729
    .line 730
    iget-boolean v0, v0, Ltj2;->b:Z

    .line 731
    .line 732
    if-eqz v0, :cond_2df

    .line 733
    .line 734
    move-wide/from16 v1, v17

    .line 735
    .line 736
    :cond_2df
    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 737
    .line 738
    .line 739
    move-result-object v0

    .line 740
    return-object v0

    .line 741
    :pswitch_2e4
    move-object/from16 v0, p1

    .line 742
    .line 743
    check-cast v0, Ltj2;

    .line 744
    .line 745
    iget-object v0, v0, Ltj2;->f:Lqy2;

    .line 746
    .line 747
    return-object v0

    .line 748
    :pswitch_2eb
    move-object/from16 v0, p1

    .line 749
    .line 750
    check-cast v0, Ltj2;

    .line 751
    .line 752
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 753
    .line 754
    .line 755
    iget-boolean v0, v0, Ltj2;->b:Z

    .line 756
    .line 757
    if-eqz v0, :cond_2f8

    .line 758
    .line 759
    move-wide/from16 v1, v17

    .line 760
    .line 761
    :cond_2f8
    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 762
    .line 763
    .line 764
    move-result-object v0

    .line 765
    return-object v0

    .line 766
    :pswitch_2fd
    move-object/from16 v0, p1

    .line 767
    .line 768
    check-cast v0, Ltj2;

    .line 769
    .line 770
    iget-object v0, v0, Ltj2;->g:Lqy2;

    .line 771
    .line 772
    return-object v0

    .line 773
    :pswitch_data_304
    .packed-switch 0x0
        :pswitch_2fd
        :pswitch_2eb
        :pswitch_2e4
        :pswitch_2d2
        :pswitch_2cb
        :pswitch_27c
        :pswitch_275
        :pswitch_265
        :pswitch_25e
        :pswitch_24f
        :pswitch_248
        :pswitch_1cf
        :pswitch_1c8
        :pswitch_15b
        :pswitch_14d
        :pswitch_146
        :pswitch_137
        :pswitch_11f
        :pswitch_118
        :pswitch_108
        :pswitch_101
        :pswitch_f3
        :pswitch_ec
        :pswitch_e5
        :pswitch_6c
        :pswitch_65
        :pswitch_55
        :pswitch_37
        :pswitch_30
    .end packed-switch
.end method
