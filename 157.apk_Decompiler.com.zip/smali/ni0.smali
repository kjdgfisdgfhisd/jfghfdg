###### Class defpackage.ni0 (ni0)
.class public final Lni0;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field public static final h:Z


# instance fields
.field public final a:Lt50;

.field public final b:Lby0;

.field public final c:Lkn1;

.field public final d:Lfz2;

.field public final e:Lel;

.field public final f:Le9;

.field public final g:Lyx2;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    const-string v0, "Engine"

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    invoke-static {v0, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    sput-boolean v0, Lni0;->h:Z

    .line 9
    .line 10
    return-void
.end method

.method public constructor <init>(Lkn1;Lf80;Lrw0;Lrw0;Lrw0;Lrw0;)V
    .registers 16

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lni0;->c:Lkn1;

    .line 5
    .line 6
    new-instance v0, Lfx0;

    .line 7
    .line 8
    invoke-direct {v0, p2}, Lfx0;-><init>(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    new-instance p2, Lyx2;

    .line 12
    .line 13
    const/4 v1, 0x2

    .line 14
    invoke-direct {p2, v1}, Lyx2;-><init>(I)V

    .line 15
    .line 16
    .line 17
    iput-object p2, p0, Lni0;->g:Lyx2;

    .line 18
    .line 19
    monitor-enter p0

    .line 20
    :try_start_13
    monitor-enter p2
    :try_end_14
    .catchall {:try_start_13 .. :try_end_14} :catchall_45

    .line 21
    :try_start_14
    iput-object p0, p2, Lyx2;->b:Ljava/lang/Object;

    .line 22
    .line 23
    monitor-exit p2
    :try_end_17
    .catchall {:try_start_14 .. :try_end_17} :catchall_49

    .line 24
    :try_start_17
    monitor-exit p0
    :try_end_18
    .catchall {:try_start_17 .. :try_end_18} :catchall_45

    .line 25
    new-instance p2, Lby0;

    .line 26
    .line 27
    invoke-direct {p2}, Ljava/lang/Object;-><init>()V

    .line 28
    .line 29
    .line 30
    iput-object p2, p0, Lni0;->b:Lby0;

    .line 31
    .line 32
    new-instance p2, Lt50;

    .line 33
    .line 34
    const/4 v1, 0x3

    .line 35
    invoke-direct {p2, v1}, Lt50;-><init>(I)V

    .line 36
    .line 37
    .line 38
    iput-object p2, p0, Lni0;->a:Lt50;

    .line 39
    .line 40
    new-instance v2, Lfz2;

    .line 41
    .line 42
    move-object v8, p0

    .line 43
    move-object v7, p0

    .line 44
    move-object v3, p3

    .line 45
    move-object v4, p4

    .line 46
    move-object v5, p5

    .line 47
    move-object v6, p6

    .line 48
    invoke-direct/range {v2 .. v8}, Lfz2;-><init>(Lrw0;Lrw0;Lrw0;Lrw0;Lni0;Lni0;)V

    .line 49
    .line 50
    .line 51
    iput-object v2, v7, Lni0;->d:Lfz2;

    .line 52
    .line 53
    new-instance p0, Le9;

    .line 54
    .line 55
    invoke-direct {p0, v0}, Le9;-><init>(Lfx0;)V

    .line 56
    .line 57
    .line 58
    iput-object p0, v7, Lni0;->f:Le9;

    .line 59
    .line 60
    new-instance p0, Lel;

    .line 61
    .line 62
    invoke-direct {p0}, Lel;-><init>()V

    .line 63
    .line 64
    .line 65
    iput-object p0, v7, Lni0;->e:Lel;

    .line 66
    .line 67
    iput-object v7, p1, Lkn1;->d:Lni0;

    .line 68
    .line 69
    return-void

    .line 70
    :catchall_45
    move-exception v0

    .line 71
    move-object v7, p0

    .line 72
    :goto_47
    move-object p0, v0

    .line 73
    goto :goto_52

    .line 74
    :catchall_49
    move-exception v0

    .line 75
    move-object v7, p0

    .line 76
    :goto_4b
    move-object p0, v0

    .line 77
    :try_start_4c
    monitor-exit p2
    :try_end_4d
    .catchall {:try_start_4c .. :try_end_4d} :catchall_50

    .line 78
    :try_start_4d
    throw p0

    .line 79
    :catchall_4e
    move-exception v0

    .line 80
    goto :goto_47

    .line 81
    :catchall_50
    move-exception v0

    .line 82
    goto :goto_4b

    .line 83
    :goto_52
    monitor-exit v7
    :try_end_53
    .catchall {:try_start_4d .. :try_end_53} :catchall_4e

    .line 84
    throw p0
.end method

.method public static c(Ljava/lang/String;Lsi0;)V
    .registers 6

    .line 1
    const/4 v0, 0x3

    .line 2
    const-string v1, "GlideMemoryTracking"

    .line 3
    .line 4
    invoke-static {v1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-nez v0, :cond_a

    .line 9
    .line 10
    goto :goto_25

    .line 11
    :cond_a
    iget-object p1, p1, Lsi0;->c:Lqf2;

    .line 12
    .line 13
    invoke-interface {p1}, Lqf2;->get()Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    instance-of v0, p1, Landroid/graphics/Bitmap;

    .line 18
    .line 19
    if-eqz v0, :cond_17

    .line 20
    .line 21
    check-cast p1, Landroid/graphics/Bitmap;

    .line 22
    .line 23
    goto :goto_23

    .line 24
    :cond_17
    instance-of v0, p1, Landroid/graphics/drawable/BitmapDrawable;

    .line 25
    .line 26
    if-eqz v0, :cond_22

    .line 27
    .line 28
    check-cast p1, Landroid/graphics/drawable/BitmapDrawable;

    .line 29
    .line 30
    invoke-virtual {p1}, Landroid/graphics/drawable/BitmapDrawable;->getBitmap()Landroid/graphics/Bitmap;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    goto :goto_23

    .line 35
    :cond_22
    const/4 p1, 0x0

    .line 36
    :goto_23
    if-nez p1, :cond_26

    .line 37
    .line 38
    :goto_25
    return-void

    .line 39
    :cond_26
    invoke-static {p1}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    new-instance v2, Ljava/lang/StringBuilder;

    .line 44
    .line 45
    const-string v3, "Engine [Device: "

    .line 46
    .line 47
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    sget-object v3, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    .line 51
    .line 52
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 53
    .line 54
    .line 55
    const-string v3, "]: Loaded bitmap [ID: "

    .line 56
    .line 57
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 58
    .line 59
    .line 60
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 61
    .line 62
    .line 63
    const-string v0, "] from memory cache ("

    .line 64
    .line 65
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 66
    .line 67
    .line 68
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 69
    .line 70
    .line 71
    const-string p0, "). Size: ["

    .line 72
    .line 73
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 74
    .line 75
    .line 76
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getWidth()I

    .line 77
    .line 78
    .line 79
    move-result p0

    .line 80
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 81
    .line 82
    .line 83
    const-string p0, "x"

    .line 84
    .line 85
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 86
    .line 87
    .line 88
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getHeight()I

    .line 89
    .line 90
    .line 91
    move-result p0

    .line 92
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 93
    .line 94
    .line 95
    const-string p0, "] ("

    .line 96
    .line 97
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 98
    .line 99
    .line 100
    invoke-static {p1}, Lk63;->j(Landroid/graphics/Bitmap;)I

    .line 101
    .line 102
    .line 103
    move-result p0

    .line 104
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 105
    .line 106
    .line 107
    const-string p0, " bytes)"

    .line 108
    .line 109
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 110
    .line 111
    .line 112
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 113
    .line 114
    .line 115
    move-result-object p0

    .line 116
    invoke-static {v1, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 117
    .line 118
    .line 119
    return-void
.end method

.method public static d(Ljava/lang/String;JLri0;)V
    .registers 5

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string p0, " in "

    .line 7
    .line 8
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 9
    .line 10
    .line 11
    invoke-static {p1, p2}, Lpm1;->a(J)D

    .line 12
    .line 13
    .line 14
    move-result-wide p0

    .line 15
    invoke-virtual {v0, p0, p1}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    const-string p0, "ms, key: "

    .line 19
    .line 20
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 24
    .line 25
    .line 26
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    const-string p1, "Engine"

    .line 31
    .line 32
    invoke-static {p1, p0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 33
    .line 34
    .line 35
    return-void
.end method

.method public static g(Lqf2;)V
    .registers 2

    .line 1
    instance-of v0, p0, Lsi0;

    .line 2
    .line 3
    if-eqz v0, :cond_a

    .line 4
    .line 5
    check-cast p0, Lsi0;

    .line 6
    .line 7
    invoke-virtual {p0}, Lsi0;->b()V

    .line 8
    .line 9
    .line 10
    return-void

    .line 11
    :cond_a
    const-string p0, "Cannot release anything but an EngineResource"

    .line 12
    .line 13
    invoke-static {p0}, Lm03;->g(Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final a(Lnw0;Ljava/lang/Object;Lqf1;IILjava/lang/Class;Ljava/lang/Class;Lh42;Lad0;Lbo;ZZLm02;ZZLjp2;Luc0;)Lna;
    .registers 41

    .line 1
    move-object/from16 v2, p0

    .line 2
    .line 3
    sget-boolean v0, Lni0;->h:Z

    .line 4
    .line 5
    if-eqz v0, :cond_d

    .line 6
    .line 7
    sget v0, Lpm1;->b:I

    .line 8
    .line 9
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtimeNanos()J

    .line 10
    .line 11
    .line 12
    move-result-wide v0

    .line 13
    goto :goto_f

    .line 14
    :cond_d
    const-wide/16 v0, 0x0

    .line 15
    .line 16
    :goto_f
    iget-object v3, v2, Lni0;->b:Lby0;

    .line 17
    .line 18
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    .line 20
    .line 21
    new-instance v4, Lri0;

    .line 22
    .line 23
    move-object/from16 v5, p2

    .line 24
    .line 25
    move-object/from16 v6, p3

    .line 26
    .line 27
    move/from16 v7, p4

    .line 28
    .line 29
    move/from16 v8, p5

    .line 30
    .line 31
    move-object/from16 v10, p6

    .line 32
    .line 33
    move-object/from16 v11, p7

    .line 34
    .line 35
    move-object/from16 v9, p10

    .line 36
    .line 37
    move-object/from16 v12, p13

    .line 38
    .line 39
    invoke-direct/range {v4 .. v12}, Lri0;-><init>(Ljava/lang/Object;Lqf1;IILbo;Ljava/lang/Class;Ljava/lang/Class;Lm02;)V

    .line 40
    .line 41
    .line 42
    monitor-enter p0

    .line 43
    move/from16 v3, p14

    .line 44
    .line 45
    :try_start_2c
    invoke-virtual {v2, v4, v3, v0, v1}, Lni0;->b(Lri0;ZJ)Lsi0;

    .line 46
    .line 47
    .line 48
    move-result-object v5

    .line 49
    if-nez v5, :cond_60

    .line 50
    .line 51
    move-object/from16 v5, p3

    .line 52
    .line 53
    move/from16 v6, p4

    .line 54
    .line 55
    move/from16 v7, p5

    .line 56
    .line 57
    move-object/from16 v8, p6

    .line 58
    .line 59
    move-object/from16 v9, p7

    .line 60
    .line 61
    move-object/from16 v10, p8

    .line 62
    .line 63
    move-object/from16 v11, p9

    .line 64
    .line 65
    move-object/from16 v12, p10

    .line 66
    .line 67
    move/from16 v13, p11

    .line 68
    .line 69
    move/from16 v14, p12

    .line 70
    .line 71
    move-object/from16 v15, p13

    .line 72
    .line 73
    move/from16 v17, p15

    .line 74
    .line 75
    move-object/from16 v18, p16

    .line 76
    .line 77
    move-object/from16 v19, p17

    .line 78
    .line 79
    move-wide/from16 v21, v0

    .line 80
    .line 81
    move/from16 v16, v3

    .line 82
    .line 83
    move-object/from16 v20, v4

    .line 84
    .line 85
    move-object/from16 v3, p1

    .line 86
    .line 87
    move-object/from16 v4, p2

    .line 88
    .line 89
    invoke-virtual/range {v2 .. v22}, Lni0;->h(Lnw0;Ljava/lang/Object;Lqf1;IILjava/lang/Class;Ljava/lang/Class;Lh42;Lad0;Lbo;ZZLm02;ZZLjp2;Ljava/util/concurrent/Executor;Lri0;J)Lna;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    monitor-exit p0

    .line 94
    return-object v0

    .line 95
    :catchall_5e
    move-exception v0

    .line 96
    goto :goto_6b

    .line 97
    :cond_60
    move-object v0, v5

    .line 98
    monitor-exit p0
    :try_end_62
    .catchall {:try_start_2c .. :try_end_62} :catchall_5e

    .line 99
    sget-object v1, Lu50;->e:Lu50;

    .line 100
    .line 101
    move-object/from16 v2, p16

    .line 102
    .line 103
    invoke-virtual {v2, v0, v1}, Ljp2;->g(Lqf2;Lu50;)V

    .line 104
    .line 105
    .line 106
    const/4 v0, 0x0

    .line 107
    return-object v0

    .line 108
    :goto_6b
    :try_start_6b
    monitor-exit p0
    :try_end_6c
    .catchall {:try_start_6b .. :try_end_6c} :catchall_5e

    .line 109
    throw v0
.end method

.method public final b(Lri0;ZJ)Lsi0;
    .registers 14

    .line 1
    const/4 v0, 0x0

    .line 2
    if-nez p2, :cond_5

    .line 3
    .line 4
    goto/16 :goto_a1

    .line 5
    .line 6
    :cond_5
    iget-object p2, p0, Lni0;->g:Lyx2;

    .line 7
    .line 8
    monitor-enter p2

    .line 9
    :try_start_8
    iget-object v1, p2, Lyx2;->d:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v1, Ljava/util/HashMap;

    .line 12
    .line 13
    invoke-virtual {v1, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    check-cast v1, Le3;
    :try_end_12
    .catchall {:try_start_8 .. :try_end_12} :catchall_23

    .line 18
    .line 19
    if-nez v1, :cond_17

    .line 20
    .line 21
    monitor-exit p2

    .line 22
    move-object v2, v0

    .line 23
    goto :goto_28

    .line 24
    :cond_17
    :try_start_17
    invoke-virtual {v1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    check-cast v2, Lsi0;

    .line 29
    .line 30
    if-nez v2, :cond_27

    .line 31
    .line 32
    invoke-virtual {p2, v1}, Lyx2;->r(Le3;)V
    :try_end_22
    .catchall {:try_start_17 .. :try_end_22} :catchall_23

    .line 33
    .line 34
    .line 35
    goto :goto_27

    .line 36
    :catchall_23
    move-exception v0

    .line 37
    move-object p0, v0

    .line 38
    goto/16 :goto_a6

    .line 39
    .line 40
    :cond_27
    :goto_27
    monitor-exit p2

    .line 41
    :goto_28
    if-eqz v2, :cond_2d

    .line 42
    .line 43
    invoke-virtual {v2}, Lsi0;->a()V

    .line 44
    .line 45
    .line 46
    :cond_2d
    const/4 p2, 0x3

    .line 47
    if-eqz v2, :cond_47

    .line 48
    .line 49
    sget-boolean p0, Lni0;->h:Z

    .line 50
    .line 51
    if-eqz p0, :cond_39

    .line 52
    .line 53
    const-string p0, "Loaded resource from active resources"

    .line 54
    .line 55
    invoke-static {p0, p3, p4, p1}, Lni0;->d(Ljava/lang/String;JLri0;)V

    .line 56
    .line 57
    .line 58
    :cond_39
    const-string p0, "GlideMemoryTracking"

    .line 59
    .line 60
    invoke-static {p0, p2}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 61
    .line 62
    .line 63
    move-result p0

    .line 64
    if-eqz p0, :cond_46

    .line 65
    .line 66
    const-string p0, "active"

    .line 67
    .line 68
    invoke-static {p0, v2}, Lni0;->c(Ljava/lang/String;Lsi0;)V

    .line 69
    .line 70
    .line 71
    :cond_46
    return-object v2

    .line 72
    :cond_47
    iget-object v1, p0, Lni0;->c:Lkn1;

    .line 73
    .line 74
    monitor-enter v1

    .line 75
    :try_start_4a
    iget-object v2, v1, Lin1;->a:Ljava/util/LinkedHashMap;

    .line 76
    .line 77
    invoke-interface {v2, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v2

    .line 81
    check-cast v2, Lhn1;
    :try_end_52
    .catchall {:try_start_4a .. :try_end_52} :catchall_a2

    .line 82
    .line 83
    if-nez v2, :cond_57

    .line 84
    .line 85
    monitor-exit v1

    .line 86
    move-object v2, v0

    .line 87
    goto :goto_62

    .line 88
    :cond_57
    :try_start_57
    iget-wide v3, v1, Lin1;->c:J

    .line 89
    .line 90
    iget v5, v2, Lhn1;->b:I

    .line 91
    .line 92
    int-to-long v5, v5

    .line 93
    sub-long/2addr v3, v5

    .line 94
    iput-wide v3, v1, Lin1;->c:J

    .line 95
    .line 96
    iget-object v2, v2, Lhn1;->a:Ljava/lang/Object;
    :try_end_61
    .catchall {:try_start_57 .. :try_end_61} :catchall_a2

    .line 97
    .line 98
    monitor-exit v1

    .line 99
    :goto_62
    move-object v4, v2

    .line 100
    check-cast v4, Lqf2;

    .line 101
    .line 102
    if-nez v4, :cond_6b

    .line 103
    .line 104
    move-object v8, p0

    .line 105
    move-object v7, p1

    .line 106
    move-object v4, v0

    .line 107
    goto :goto_7e

    .line 108
    :cond_6b
    instance-of v1, v4, Lsi0;

    .line 109
    .line 110
    if-eqz v1, :cond_74

    .line 111
    .line 112
    check-cast v4, Lsi0;

    .line 113
    .line 114
    move-object v8, p0

    .line 115
    move-object v7, p1

    .line 116
    goto :goto_7e

    .line 117
    :cond_74
    new-instance v3, Lsi0;

    .line 118
    .line 119
    const/4 v5, 0x1

    .line 120
    const/4 v6, 0x1

    .line 121
    move-object v8, p0

    .line 122
    move-object v7, p1

    .line 123
    invoke-direct/range {v3 .. v8}, Lsi0;-><init>(Lqf2;ZZLqf1;Lni0;)V

    .line 124
    .line 125
    .line 126
    move-object v4, v3

    .line 127
    :goto_7e
    if-eqz v4, :cond_88

    .line 128
    .line 129
    invoke-virtual {v4}, Lsi0;->a()V

    .line 130
    .line 131
    .line 132
    iget-object p0, v8, Lni0;->g:Lyx2;

    .line 133
    .line 134
    invoke-virtual {p0, v7, v4}, Lyx2;->f(Lqf1;Lsi0;)V

    .line 135
    .line 136
    .line 137
    :cond_88
    if-eqz v4, :cond_a1

    .line 138
    .line 139
    sget-boolean p0, Lni0;->h:Z

    .line 140
    .line 141
    if-eqz p0, :cond_93

    .line 142
    .line 143
    const-string p0, "Loaded resource from cache"

    .line 144
    .line 145
    invoke-static {p0, p3, p4, v7}, Lni0;->d(Ljava/lang/String;JLri0;)V

    .line 146
    .line 147
    .line 148
    :cond_93
    const-string p0, "GlideMemoryTracking"

    .line 149
    .line 150
    invoke-static {p0, p2}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 151
    .line 152
    .line 153
    move-result p0

    .line 154
    if-eqz p0, :cond_a0

    .line 155
    .line 156
    const-string p0, "cache"

    .line 157
    .line 158
    invoke-static {p0, v4}, Lni0;->c(Ljava/lang/String;Lsi0;)V

    .line 159
    .line 160
    .line 161
    :cond_a0
    return-object v4

    .line 162
    :cond_a1
    :goto_a1
    return-object v0

    .line 163
    :catchall_a2
    move-exception v0

    .line 164
    move-object p0, v0

    .line 165
    :try_start_a4
    monitor-exit v1
    :try_end_a5
    .catchall {:try_start_a4 .. :try_end_a5} :catchall_a2

    .line 166
    throw p0

    .line 167
    :goto_a6
    :try_start_a6
    monitor-exit p2
    :try_end_a7
    .catchall {:try_start_a6 .. :try_end_a7} :catchall_23

    .line 168
    throw p0
.end method

.method public final declared-synchronized e(Lqi0;Lri0;Lsi0;)V
    .registers 5

    .line 1
    monitor-enter p0

    .line 2
    if-eqz p3, :cond_f

    .line 3
    .line 4
    :try_start_3
    iget-boolean v0, p3, Lsi0;->a:Z

    .line 5
    .line 6
    if-eqz v0, :cond_f

    .line 7
    .line 8
    iget-object v0, p0, Lni0;->g:Lyx2;

    .line 9
    .line 10
    invoke-virtual {v0, p2, p3}, Lyx2;->f(Lqf1;Lsi0;)V

    .line 11
    .line 12
    .line 13
    goto :goto_f

    .line 14
    :catchall_d
    move-exception p1

    .line 15
    goto :goto_25

    .line 16
    :cond_f
    :goto_f
    iget-object p3, p0, Lni0;->a:Lt50;

    .line 17
    .line 18
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    .line 20
    .line 21
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    .line 23
    .line 24
    iget-object p3, p3, Lt50;->b:Ljava/util/HashMap;

    .line 25
    .line 26
    invoke-virtual {p3, p2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    if-eq p1, v0, :cond_20

    .line 31
    .line 32
    goto :goto_23

    .line 33
    :cond_20
    invoke-virtual {p3, p2}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_23
    .catchall {:try_start_3 .. :try_end_23} :catchall_d

    .line 34
    .line 35
    .line 36
    :goto_23
    monitor-exit p0

    .line 37
    return-void

    .line 38
    :goto_25
    :try_start_25
    monitor-exit p0
    :try_end_26
    .catchall {:try_start_25 .. :try_end_26} :catchall_d

    .line 39
    throw p1
.end method

.method public final f(Lqf1;Lsi0;)V
    .registers 6

    .line 1
    iget-object v0, p0, Lni0;->g:Lyx2;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    iget-object v1, v0, Lyx2;->d:Ljava/lang/Object;

    .line 5
    .line 6
    check-cast v1, Ljava/util/HashMap;

    .line 7
    .line 8
    invoke-virtual {v1, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    check-cast v1, Le3;

    .line 13
    .line 14
    if-eqz v1, :cond_15

    .line 15
    .line 16
    const/4 v2, 0x0

    .line 17
    iput-object v2, v1, Le3;->c:Lqf2;

    .line 18
    .line 19
    invoke-virtual {v1}, Ljava/lang/ref/Reference;->clear()V
    :try_end_15
    .catchall {:try_start_3 .. :try_end_15} :catchall_2a

    .line 20
    .line 21
    .line 22
    :cond_15
    monitor-exit v0

    .line 23
    iget-boolean v0, p2, Lsi0;->a:Z

    .line 24
    .line 25
    if-eqz v0, :cond_23

    .line 26
    .line 27
    iget-object p0, p0, Lni0;->c:Lkn1;

    .line 28
    .line 29
    invoke-virtual {p0, p1, p2}, Lin1;->d(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    check-cast p0, Lqf2;

    .line 34
    .line 35
    return-void

    .line 36
    :cond_23
    iget-object p0, p0, Lni0;->e:Lel;

    .line 37
    .line 38
    const/4 p1, 0x0

    .line 39
    invoke-virtual {p0, p2, p1}, Lel;->l(Lqf2;Z)V

    .line 40
    .line 41
    .line 42
    return-void

    .line 43
    :catchall_2a
    move-exception p0

    .line 44
    :try_start_2b
    monitor-exit v0
    :try_end_2c
    .catchall {:try_start_2b .. :try_end_2c} :catchall_2a

    .line 45
    throw p0
.end method

.method public final h(Lnw0;Ljava/lang/Object;Lqf1;IILjava/lang/Class;Ljava/lang/Class;Lh42;Lad0;Lbo;ZZLm02;ZZLjp2;Ljava/util/concurrent/Executor;Lri0;J)Lna;
    .registers 37

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move/from16 v4, p4

    move/from16 v5, p5

    move-object/from16 v6, p8

    move-object/from16 v7, p9

    move-object/from16 v8, p13

    move-object/from16 v9, p16

    move-object/from16 v10, p17

    move-object/from16 v11, p18

    move-wide/from16 v12, p19

    .line 1
    iget-object v14, v0, Lni0;->a:Lt50;

    .line 2
    iget-object v14, v14, Lt50;->b:Ljava/util/HashMap;

    .line 3
    invoke-virtual {v14, v11}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Lqi0;

    if-eqz v14, :cond_38

    .line 4
    invoke-virtual {v14, v9, v10}, Lqi0;->a(Ljp2;Ljava/util/concurrent/Executor;)V

    .line 5
    sget-boolean v1, Lni0;->h:Z

    if-eqz v1, :cond_32

    .line 6
    const-string v1, "Added to existing load"

    invoke-static {v1, v12, v13, v11}, Lni0;->d(Ljava/lang/String;JLri0;)V

    .line 7
    :cond_32
    new-instance v1, Lna;

    invoke-direct {v1, v0, v9, v14}, Lna;-><init>(Lni0;Ljp2;Lqi0;)V

    return-object v1

    .line 8
    :cond_38
    iget-object v14, v0, Lni0;->d:Lfz2;

    .line 9
    iget-object v14, v14, Lfz2;->g:Ljava/lang/Object;

    check-cast v14, Lna;

    invoke-virtual {v14}, Lna;->g()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Lqi0;

    .line 10
    monitor-enter v14

    .line 11
    :try_start_45
    iput-object v11, v14, Lqi0;->m:Lri0;

    move/from16 v15, p14

    .line 12
    iput-boolean v15, v14, Lqi0;->n:Z

    move/from16 v15, p15

    .line 13
    iput-boolean v15, v14, Lqi0;->o:Z
    :try_end_4f
    .catchall {:try_start_45 .. :try_end_4f} :catchall_f6

    .line 14
    monitor-exit v14

    .line 15
    iget-object v15, v0, Lni0;->f:Le9;

    .line 16
    iget-object v12, v15, Le9;->d:Ljava/lang/Object;

    check-cast v12, Lna;

    invoke-virtual {v12}, Lna;->g()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lx60;

    .line 17
    iget v13, v15, Le9;->b:I

    add-int/lit8 v9, v13, 0x1

    iput v9, v15, Le9;->b:I

    .line 18
    iget-object v9, v12, Lx60;->a:Lv60;

    iget-object v15, v12, Lx60;->d:Lfx0;

    .line 19
    iput-object v1, v9, Lv60;->c:Lnw0;

    .line 20
    iput-object v2, v9, Lv60;->d:Ljava/lang/Object;

    .line 21
    iput-object v3, v9, Lv60;->n:Lqf1;

    .line 22
    iput v4, v9, Lv60;->e:I

    .line 23
    iput v5, v9, Lv60;->f:I

    .line 24
    iput-object v7, v9, Lv60;->p:Lad0;

    move-object/from16 v10, p6

    .line 25
    iput-object v10, v9, Lv60;->g:Ljava/lang/Class;

    .line 26
    iput-object v15, v9, Lv60;->h:Lfx0;

    move-object/from16 v10, p7

    .line 27
    iput-object v10, v9, Lv60;->k:Ljava/lang/Class;

    .line 28
    iput-object v6, v9, Lv60;->o:Lh42;

    .line 29
    iput-object v8, v9, Lv60;->i:Lm02;

    move-object/from16 v10, p10

    .line 30
    iput-object v10, v9, Lv60;->j:Lbo;

    move/from16 v10, p11

    .line 31
    iput-boolean v10, v9, Lv60;->q:Z

    move/from16 v10, p12

    .line 32
    iput-boolean v10, v9, Lv60;->r:Z

    .line 33
    iput-object v1, v12, Lx60;->j:Lnw0;

    .line 34
    iput-object v3, v12, Lx60;->l:Lqf1;

    .line 35
    iput-object v6, v12, Lx60;->m:Lh42;

    .line 36
    iput-object v11, v12, Lx60;->n:Lri0;

    .line 37
    iput v4, v12, Lx60;->o:I

    .line 38
    iput v5, v12, Lx60;->p:I

    .line 39
    iput-object v7, v12, Lx60;->q:Lad0;

    .line 40
    iput-object v8, v12, Lx60;->r:Lm02;

    .line 41
    iput-object v14, v12, Lx60;->s:Lqi0;

    .line 42
    iput v13, v12, Lx60;->t:I

    const/4 v3, 0x1

    .line 43
    iput v3, v12, Lx60;->J:I

    .line 44
    iput-object v2, v12, Lx60;->v:Ljava/lang/Object;

    .line 45
    iget-object v1, v1, Lnw0;->g:Lf80;

    .line 46
    iput-object v1, v12, Lx60;->w:Lf80;

    .line 47
    sget-object v1, Lx60;->K:Lh02;

    invoke-virtual {v8, v1}, Lm02;->c(Lh02;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/function/Supplier;

    iput-object v1, v12, Lx60;->x:Ljava/util/function/Supplier;

    .line 48
    iget-object v1, v0, Lni0;->a:Lt50;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 49
    iget-object v1, v1, Lt50;->b:Ljava/util/HashMap;

    .line 50
    invoke-virtual {v1, v11, v14}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-object/from16 v9, p16

    move-object/from16 v10, p17

    .line 51
    invoke-virtual {v14, v9, v10}, Lqi0;->a(Ljp2;Ljava/util/concurrent/Executor;)V

    .line 52
    monitor-enter v14

    .line 53
    :try_start_c5
    iput-object v12, v14, Lqi0;->v:Lx60;

    .line 54
    invoke-virtual {v12, v3}, Lx60;->h(I)I

    move-result v1

    const/4 v2, 0x2

    if-eq v1, v2, :cond_dc

    const/4 v2, 0x3

    if-ne v1, v2, :cond_d2

    goto :goto_dc

    .line 55
    :cond_d2
    iget-boolean v1, v14, Lqi0;->o:Z

    if-eqz v1, :cond_d9

    iget-object v1, v14, Lqi0;->j:Lrw0;

    goto :goto_de

    :cond_d9
    iget-object v1, v14, Lqi0;->g:Lrw0;

    goto :goto_de

    .line 56
    :cond_dc
    :goto_dc
    iget-object v1, v14, Lqi0;->f:Lrw0;

    .line 57
    :goto_de
    invoke-virtual {v1, v12}, Lrw0;->execute(Ljava/lang/Runnable;)V
    :try_end_e1
    .catchall {:try_start_c5 .. :try_end_e1} :catchall_f3

    .line 58
    monitor-exit v14

    .line 59
    sget-boolean v1, Lni0;->h:Z

    if-eqz v1, :cond_ed

    .line 60
    const-string v1, "Started new load"

    move-wide/from16 v12, p19

    invoke-static {v1, v12, v13, v11}, Lni0;->d(Ljava/lang/String;JLri0;)V

    .line 61
    :cond_ed
    new-instance v1, Lna;

    invoke-direct {v1, v0, v9, v14}, Lna;-><init>(Lni0;Ljp2;Lqi0;)V

    return-object v1

    :catchall_f3
    move-exception v0

    .line 62
    :try_start_f4
    monitor-exit v14
    :try_end_f5
    .catchall {:try_start_f4 .. :try_end_f5} :catchall_f3

    throw v0

    :catchall_f6
    move-exception v0

    .line 63
    :try_start_f7
    monitor-exit v14
    :try_end_f8
    .catchall {:try_start_f7 .. :try_end_f8} :catchall_f6

    throw v0
.end method
