###### Class defpackage.zx3 (zx3)
.class public interface abstract Lzx3;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# virtual methods
.method public abstract a(Landroid/content/Intent;)V
.end method

.method public abstract b(Landroid/app/job/JobParameters;)V
.end method

.method public abstract e(I)Z
.end method
