###### Class defpackage.z60 (z60)
.class public interface abstract Lz60;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# virtual methods
.method public abstract A()F
.end method

.method public abstract C(Lwk2;)I
.end method

.method public abstract D()D
.end method

.method public abstract b(Lwk2;)Lnx;
.end method

.method public c(Lif1;)Ljava/lang/Object;
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-interface {p1, p0}, Lif1;->deserialize(Lz60;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    return-object p0
.end method

.method public abstract d()J
.end method

.method public abstract f()Z
.end method

.method public abstract g()Z
.end method

.method public abstract h()C
.end method

.method public abstract r()I
.end method

.method public abstract u()B
.end method

.method public abstract v(Lwk2;)Lz60;
.end method

.method public abstract y()S
.end method

.method public abstract z()Ljava/lang/String;
.end method
