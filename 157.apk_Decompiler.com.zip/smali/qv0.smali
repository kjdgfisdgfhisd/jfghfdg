###### Class defpackage.qv0 (qv0)
.class public final Lqv0;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lhs2;


# instance fields
.field public final a:Lo63;

.field public final b:Lpw2;


# direct methods
.method public constructor <init>(Lo63;Lpw2;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lqv0;->a:Lo63;

    .line 5
    .line 6
    iput-object p2, p0, Lqv0;->b:Lpw2;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Exception;)Z
    .registers 2

    .line 1
    iget-object p0, p0, Lqv0;->b:Lpw2;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lpw2;->a(Ljava/lang/Exception;)V

    .line 4
    .line 5
    .line 6
    const/4 p0, 0x1

    .line 7
    return p0
.end method

.method public final b(Lah;)Z
    .registers 11

    .line 1
    iget v0, p1, Lah;->b:I

    .line 2
    .line 3
    const/4 v1, 0x4

    .line 4
    const/4 v2, 0x0

    .line 5
    if-ne v0, v1, :cond_29

    .line 6
    .line 7
    iget-object v0, p0, Lqv0;->a:Lo63;

    .line 8
    .line 9
    invoke-virtual {v0, p1}, Lo63;->a(Lah;)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-nez v0, :cond_29

    .line 14
    .line 15
    iget-object v4, p1, Lah;->c:Ljava/lang/String;

    .line 16
    .line 17
    if-eqz v4, :cond_24

    .line 18
    .line 19
    iget-wide v5, p1, Lah;->e:J

    .line 20
    .line 21
    iget-wide v7, p1, Lah;->f:J

    .line 22
    .line 23
    new-instance v3, Lrg;

    .line 24
    .line 25
    invoke-direct/range {v3 .. v8}, Lrg;-><init>(Ljava/lang/String;JJ)V

    .line 26
    .line 27
    .line 28
    iget-object p0, p0, Lqv0;->b:Lpw2;

    .line 29
    .line 30
    iget-object p0, p0, Lpw2;->a:Lo14;

    .line 31
    .line 32
    invoke-virtual {p0, v3}, Lo14;->j(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    const/4 p0, 0x1

    .line 36
    return p0

    .line 37
    :cond_24
    const-string p0, "Null token"

    .line 38
    .line 39
    invoke-static {p0}, Lm03;->i(Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    :cond_29
    return v2
.end method
