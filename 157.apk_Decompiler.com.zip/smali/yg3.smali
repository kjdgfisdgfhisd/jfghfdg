###### Class defpackage.yg3 (yg3)
.class public final synthetic Lyg3;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lft0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc71;


# direct methods
.method public synthetic constructor <init>(Lc71;I)V
    .registers 3

    .line 1
    iput p2, p0, Lyg3;->a:I

    .line 2
    .line 3
    iput-object p1, p0, Lyg3;->b:Lc71;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    iget v0, p0, Lyg3;->a:I

    .line 2
    .line 3
    iget-object p0, p0, Lyg3;->b:Lc71;

    .line 4
    .line 5
    check-cast p1, Lyx0;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_14

    .line 8
    .line 9
    .line 10
    invoke-static {p0, p1}, Lcc/bomber/x/i/c;->w1(Lc71;Lyx0;)Lw43;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    return-object p0

    .line 15
    :pswitch_e
    invoke-static {p0, p1}, Lcc/bomber/x/i/b;->I5(Lc71;Lyx0;)Lw43;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    return-object p0

    .line 20
    nop

    .line 21
    :pswitch_data_14
    .packed-switch 0x0
        :pswitch_e
    .end packed-switch
.end method
