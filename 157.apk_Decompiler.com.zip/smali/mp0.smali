###### Class defpackage.mp0 (mp0)
.class public final Lmp0;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lfp0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lfp0;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lfp0;Ljava/lang/Object;I)V
    .registers 4

    .line 1
    iput p3, p0, Lmp0;->a:I

    .line 2
    .line 3
    iput-object p1, p0, Lmp0;->b:Lfp0;

    .line 4
    .line 5
    iput-object p2, p0, Lmp0;->c:Ljava/lang/Object;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final b(Lhp0;Lw00;)Ljava/lang/Object;
    .registers 21

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    iget v3, v0, Lmp0;->a:I

    .line 8
    .line 9
    const-string v4, "call to \'resume\' before \'invoke\' with coroutine"

    .line 10
    .line 11
    const/4 v5, 0x1

    .line 12
    const/high16 v6, -0x80000000

    .line 13
    .line 14
    const/4 v7, 0x2

    .line 15
    const/4 v8, 0x0

    .line 16
    iget-object v9, v0, Lmp0;->c:Ljava/lang/Object;

    .line 17
    .line 18
    iget-object v10, v0, Lmp0;->b:Lfp0;

    .line 19
    .line 20
    const/4 v11, 0x0

    .line 21
    sget-object v12, Lb20;->a:Lb20;

    .line 22
    .line 23
    sget-object v13, Lw43;->a:Lw43;

    .line 24
    .line 25
    packed-switch v3, :pswitch_data_142

    .line 26
    .line 27
    .line 28
    check-cast v10, Lmp0;

    .line 29
    .line 30
    new-instance v0, Lsz;

    .line 31
    .line 32
    check-cast v9, Lol2;

    .line 33
    .line 34
    invoke-direct {v0, v1, v9}, Lsz;-><init>(Lhp0;Lol2;)V

    .line 35
    .line 36
    .line 37
    invoke-virtual {v10, v0, v2}, Lmp0;->b(Lhp0;Lw00;)Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    if-ne v0, v12, :cond_2b

    .line 42
    .line 43
    move-object v13, v0

    .line 44
    :cond_2b
    return-object v13

    .line 45
    :pswitch_2c
    new-instance v0, Lvp0;

    .line 46
    .line 47
    check-cast v9, Ltt0;

    .line 48
    .line 49
    invoke-direct {v0, v1, v8, v9}, Lvp0;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    invoke-interface {v10, v0, v2}, Lfp0;->b(Lhp0;Lw00;)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    if-ne v0, v12, :cond_3a

    .line 57
    .line 58
    move-object v13, v0

    .line 59
    :cond_3a
    return-object v13

    .line 60
    :pswitch_3b
    instance-of v3, v2, Lpp0;

    .line 61
    .line 62
    if-eqz v3, :cond_4c

    .line 63
    .line 64
    move-object v3, v2

    .line 65
    check-cast v3, Lpp0;

    .line 66
    .line 67
    iget v9, v3, Lpp0;->l:I

    .line 68
    .line 69
    and-int v10, v9, v6

    .line 70
    .line 71
    if-eqz v10, :cond_4c

    .line 72
    .line 73
    sub-int/2addr v9, v6

    .line 74
    iput v9, v3, Lpp0;->l:I

    .line 75
    .line 76
    goto :goto_51

    .line 77
    :cond_4c
    new-instance v3, Lpp0;

    .line 78
    .line 79
    invoke-direct {v3, v0, v2}, Lpp0;-><init>(Lmp0;Lw00;)V

    .line 80
    .line 81
    .line 82
    :goto_51
    iget-object v2, v3, Lpp0;->j:Ljava/lang/Object;

    .line 83
    .line 84
    iget v6, v3, Lpp0;->l:I

    .line 85
    .line 86
    if-eqz v6, :cond_78

    .line 87
    .line 88
    if-eq v6, v5, :cond_6c

    .line 89
    .line 90
    if-ne v6, v7, :cond_67

    .line 91
    .line 92
    iget-wide v0, v3, Lpp0;->q:J

    .line 93
    .line 94
    iget-object v4, v3, Lpp0;->p:Ljava/lang/Throwable;

    .line 95
    .line 96
    iget-object v6, v3, Lpp0;->o:Lhp0;

    .line 97
    .line 98
    iget-object v9, v3, Lpp0;->n:Lmp0;

    .line 99
    .line 100
    invoke-static {v2}, Lh23;->t(Ljava/lang/Object;)V

    .line 101
    .line 102
    .line 103
    goto :goto_c9

    .line 104
    :cond_67
    invoke-static {v4}, Ly0;->h(Ljava/lang/String;)V

    .line 105
    .line 106
    .line 107
    goto/16 :goto_e2

    .line 108
    .line 109
    :cond_6c
    iget-wide v0, v3, Lpp0;->q:J

    .line 110
    .line 111
    iget-object v4, v3, Lpp0;->o:Lhp0;

    .line 112
    .line 113
    iget-object v6, v3, Lpp0;->n:Lmp0;

    .line 114
    .line 115
    invoke-static {v2}, Lh23;->t(Ljava/lang/Object;)V

    .line 116
    .line 117
    .line 118
    move-object v9, v6

    .line 119
    move-object v6, v4

    .line 120
    goto :goto_98

    .line 121
    :cond_78
    invoke-static {v2}, Lh23;->t(Ljava/lang/Object;)V

    .line 122
    .line 123
    .line 124
    const-wide/16 v9, 0x0

    .line 125
    .line 126
    :goto_7d
    iget-object v2, v0, Lmp0;->b:Lfp0;

    .line 127
    .line 128
    check-cast v2, Lxp0;

    .line 129
    .line 130
    iput-object v0, v3, Lpp0;->n:Lmp0;

    .line 131
    .line 132
    iput-object v1, v3, Lpp0;->o:Lhp0;

    .line 133
    .line 134
    iput-object v11, v3, Lpp0;->p:Ljava/lang/Throwable;

    .line 135
    .line 136
    iput-wide v9, v3, Lpp0;->q:J

    .line 137
    .line 138
    iput v5, v3, Lpp0;->l:I

    .line 139
    .line 140
    invoke-static {v2, v1, v3}, Lb21;->c(Lfp0;Lhp0;Ly00;)Ljava/io/Serializable;

    .line 141
    .line 142
    .line 143
    move-result-object v2

    .line 144
    if-ne v2, v12, :cond_92

    .line 145
    .line 146
    goto :goto_c7

    .line 147
    :cond_92
    move-object v6, v1

    .line 148
    move-wide/from16 v16, v9

    .line 149
    .line 150
    move-object v9, v0

    .line 151
    move-wide/from16 v0, v16

    .line 152
    .line 153
    :goto_98
    move-object v4, v2

    .line 154
    check-cast v4, Ljava/lang/Throwable;

    .line 155
    .line 156
    if-eqz v4, :cond_dd

    .line 157
    .line 158
    iget-object v2, v9, Lmp0;->c:Ljava/lang/Object;

    .line 159
    .line 160
    new-instance v2, Ljava/lang/Long;

    .line 161
    .line 162
    invoke-direct {v2, v0, v1}, Ljava/lang/Long;-><init>(J)V

    .line 163
    .line 164
    .line 165
    iput-object v9, v3, Lpp0;->n:Lmp0;

    .line 166
    .line 167
    iput-object v6, v3, Lpp0;->o:Lhp0;

    .line 168
    .line 169
    iput-object v4, v3, Lpp0;->p:Ljava/lang/Throwable;

    .line 170
    .line 171
    iput-wide v0, v3, Lpp0;->q:J

    .line 172
    .line 173
    iput v7, v3, Lpp0;->l:I

    .line 174
    .line 175
    check-cast v2, Ljava/lang/Number;

    .line 176
    .line 177
    invoke-virtual {v2}, Ljava/lang/Number;->longValue()J

    .line 178
    .line 179
    .line 180
    move-result-wide v14

    .line 181
    move-object v2, v3

    .line 182
    check-cast v2, Lw00;

    .line 183
    .line 184
    new-instance v10, Lt43;

    .line 185
    .line 186
    const/4 v8, 0x4

    .line 187
    invoke-direct {v10, v8, v2}, Lnv2;-><init>(ILw00;)V

    .line 188
    .line 189
    .line 190
    iput-object v4, v10, Lt43;->l:Ljava/lang/Throwable;

    .line 191
    .line 192
    iput-wide v14, v10, Lt43;->m:J

    .line 193
    .line 194
    invoke-virtual {v10, v13}, Lt43;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 195
    .line 196
    .line 197
    move-result-object v2

    .line 198
    if-ne v2, v12, :cond_c9

    .line 199
    .line 200
    :goto_c7
    move-object v11, v12

    .line 201
    goto :goto_e2

    .line 202
    :cond_c9
    :goto_c9
    check-cast v2, Ljava/lang/Boolean;

    .line 203
    .line 204
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 205
    .line 206
    .line 207
    move-result v2

    .line 208
    if-eqz v2, :cond_dc

    .line 209
    .line 210
    const-wide/16 v14, 0x1

    .line 211
    .line 212
    add-long/2addr v0, v14

    .line 213
    move v2, v5

    .line 214
    :goto_d5
    move-wide/from16 v16, v0

    .line 215
    .line 216
    move-object v0, v9

    .line 217
    move-wide/from16 v9, v16

    .line 218
    .line 219
    move-object v1, v6

    .line 220
    goto :goto_df

    .line 221
    :cond_dc
    throw v4

    .line 222
    :cond_dd
    const/4 v2, 0x0

    .line 223
    goto :goto_d5

    .line 224
    :goto_df
    if-nez v2, :cond_e3

    .line 225
    .line 226
    move-object v11, v13

    .line 227
    :goto_e2
    return-object v11

    .line 228
    :cond_e3
    const/4 v8, 0x0

    .line 229
    goto :goto_7d

    .line 230
    :pswitch_e5
    instance-of v3, v2, Llp0;

    .line 231
    .line 232
    if-eqz v3, :cond_f6

    .line 233
    .line 234
    move-object v3, v2

    .line 235
    check-cast v3, Llp0;

    .line 236
    .line 237
    iget v8, v3, Llp0;->l:I

    .line 238
    .line 239
    and-int v9, v8, v6

    .line 240
    .line 241
    if-eqz v9, :cond_f6

    .line 242
    .line 243
    sub-int/2addr v8, v6

    .line 244
    iput v8, v3, Llp0;->l:I

    .line 245
    .line 246
    goto :goto_fb

    .line 247
    :cond_f6
    new-instance v3, Llp0;

    .line 248
    .line 249
    invoke-direct {v3, v0, v2}, Llp0;-><init>(Lmp0;Lw00;)V

    .line 250
    .line 251
    .line 252
    :goto_fb
    iget-object v2, v3, Llp0;->j:Ljava/lang/Object;

    .line 253
    .line 254
    iget v6, v3, Llp0;->l:I

    .line 255
    .line 256
    if-eqz v6, :cond_11a

    .line 257
    .line 258
    if-eq v6, v5, :cond_10d

    .line 259
    .line 260
    if-ne v6, v7, :cond_109

    .line 261
    .line 262
    invoke-static {v2}, Lh23;->t(Ljava/lang/Object;)V

    .line 263
    .line 264
    .line 265
    goto :goto_140

    .line 266
    :cond_109
    invoke-static {v4}, Ly0;->h(Ljava/lang/String;)V

    .line 267
    .line 268
    .line 269
    goto :goto_141

    .line 270
    :cond_10d
    iget-object v0, v3, Llp0;->o:Lhp0;

    .line 271
    .line 272
    iget-object v1, v3, Llp0;->n:Lmp0;

    .line 273
    .line 274
    invoke-static {v2}, Lh23;->t(Ljava/lang/Object;)V

    .line 275
    .line 276
    .line 277
    move-object/from16 v16, v1

    .line 278
    .line 279
    move-object v1, v0

    .line 280
    move-object/from16 v0, v16

    .line 281
    .line 282
    goto :goto_12a

    .line 283
    :cond_11a
    invoke-static {v2}, Lh23;->t(Ljava/lang/Object;)V

    .line 284
    .line 285
    .line 286
    iput-object v0, v3, Llp0;->n:Lmp0;

    .line 287
    .line 288
    iput-object v1, v3, Llp0;->o:Lhp0;

    .line 289
    .line 290
    iput v5, v3, Llp0;->l:I

    .line 291
    .line 292
    invoke-static {v10, v1, v3}, Lb21;->c(Lfp0;Lhp0;Ly00;)Ljava/io/Serializable;

    .line 293
    .line 294
    .line 295
    move-result-object v2

    .line 296
    if-ne v2, v12, :cond_12a

    .line 297
    .line 298
    goto :goto_13e

    .line 299
    :cond_12a
    :goto_12a
    check-cast v2, Ljava/lang/Throwable;

    .line 300
    .line 301
    if-eqz v2, :cond_140

    .line 302
    .line 303
    iget-object v0, v0, Lmp0;->c:Ljava/lang/Object;

    .line 304
    .line 305
    check-cast v0, Lml2;

    .line 306
    .line 307
    iput-object v11, v3, Llp0;->n:Lmp0;

    .line 308
    .line 309
    iput-object v11, v3, Llp0;->o:Lhp0;

    .line 310
    .line 311
    iput v7, v3, Llp0;->l:I

    .line 312
    .line 313
    invoke-virtual {v0, v1, v2, v3}, Lml2;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 314
    .line 315
    .line 316
    move-result-object v0

    .line 317
    if-ne v0, v12, :cond_140

    .line 318
    .line 319
    :goto_13e
    move-object v11, v12

    .line 320
    goto :goto_141

    .line 321
    :cond_140
    :goto_140
    move-object v11, v13

    .line 322
    :goto_141
    return-object v11

    .line 323
    :pswitch_data_142
    .packed-switch 0x0
        :pswitch_e5
        :pswitch_3b
        :pswitch_2c
    .end packed-switch
.end method
