###### Class defpackage.v62 (v62)
.class public final Lv62;
.super Lgv0;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field public static final g:Lv62;

.field public static final j:Lac1;


# instance fields
.field public final b:Lun;

.field public c:I

.field public d:I

.field public e:B

.field public f:I


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lac1;

    .line 2
    .line 3
    const/16 v1, 0xc

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lac1;-><init>(I)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lv62;->j:Lac1;

    .line 9
    .line 10
    new-instance v0, Lv62;

    .line 11
    .line 12
    invoke-direct {v0}, Lv62;-><init>()V

    .line 13
    .line 14
    .line 15
    sput-object v0, Lv62;->g:Lv62;

    .line 16
    .line 17
    const/4 v1, 0x0

    .line 18
    iput v1, v0, Lv62;->d:I

    .line 19
    .line 20
    return-void
.end method

.method public constructor <init>()V
    .registers 2

    .line 119
    invoke-direct {p0}, Lgv0;-><init>()V

    const/4 v0, -0x1

    .line 120
    iput-byte v0, p0, Lv62;->e:B

    .line 121
    iput v0, p0, Lv62;->f:I

    .line 122
    sget-object v0, Lun;->a:Lfl1;

    iput-object v0, p0, Lv62;->b:Lun;

    return-void
.end method

.method public constructor <init>(Lu62;)V
    .registers 3

    .line 123
    invoke-direct {p0, p1}, Lgv0;-><init>(Lfv0;)V

    const/4 v0, -0x1

    .line 124
    iput-byte v0, p0, Lv62;->e:B

    .line 125
    iput v0, p0, Lv62;->f:I

    .line 126
    iget-object p1, p1, Lcv0;->a:Lun;

    .line 127
    iput-object p1, p0, Lv62;->b:Lun;

    return-void
.end method

.method public constructor <init>(Lwu;Lpl0;)V
    .registers 9

    .line 1
    invoke-direct {p0}, Lgv0;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, -0x1

    .line 5
    iput-byte v0, p0, Lv62;->e:B

    .line 6
    .line 7
    iput v0, p0, Lv62;->f:I

    .line 8
    .line 9
    const/4 v0, 0x0

    .line 10
    iput v0, p0, Lv62;->d:I

    .line 11
    .line 12
    new-instance v1, Ltn;

    .line 13
    .line 14
    invoke-direct {v1}, Ltn;-><init>()V

    .line 15
    .line 16
    .line 17
    const/4 v2, 0x1

    .line 18
    invoke-static {v1, v2}, Lzu;->j(Ljava/io/OutputStream;I)Lzu;

    .line 19
    .line 20
    .line 21
    move-result-object v3

    .line 22
    :cond_15
    :goto_15
    if-nez v0, :cond_60

    .line 23
    .line 24
    :try_start_17
    invoke-virtual {p1}, Lwu;->m()I

    .line 25
    .line 26
    .line 27
    move-result v4

    .line 28
    if-eqz v4, :cond_27

    .line 29
    .line 30
    const/16 v5, 0x8

    .line 31
    .line 32
    if-eq v4, v5, :cond_2f

    .line 33
    .line 34
    invoke-virtual {p0, p1, v3, p2, v4}, Lgv0;->n(Lwu;Lzu;Lpl0;I)Z

    .line 35
    .line 36
    .line 37
    move-result v4

    .line 38
    if-nez v4, :cond_15

    .line 39
    .line 40
    :cond_27
    move v0, v2

    .line 41
    goto :goto_15

    .line 42
    :catchall_29
    move-exception p1

    .line 43
    goto :goto_4a

    .line 44
    :catch_2b
    move-exception p1

    .line 45
    goto :goto_3b

    .line 46
    :catch_2d
    move-exception p1

    .line 47
    goto :goto_47

    .line 48
    :cond_2f
    iget v4, p0, Lv62;->c:I

    .line 49
    .line 50
    or-int/2addr v4, v2

    .line 51
    iput v4, p0, Lv62;->c:I

    .line 52
    .line 53
    invoke-virtual {p1}, Lwu;->j()I

    .line 54
    .line 55
    .line 56
    move-result v4

    .line 57
    iput v4, p0, Lv62;->d:I
    :try_end_3a
    .catch Lg31; {:try_start_17 .. :try_end_3a} :catch_2d
    .catch Ljava/io/IOException; {:try_start_17 .. :try_end_3a} :catch_2b
    .catchall {:try_start_17 .. :try_end_3a} :catchall_29

    .line 58
    .line 59
    goto :goto_15

    .line 60
    :goto_3b
    :try_start_3b
    new-instance p2, Lg31;

    .line 61
    .line 62
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object p1

    .line 66
    invoke-direct {p2, p1}, Lg31;-><init>(Ljava/lang/String;)V

    .line 67
    .line 68
    .line 69
    iput-object p0, p2, Lg31;->a:Le0;

    .line 70
    .line 71
    throw p2

    .line 72
    :goto_47
    iput-object p0, p1, Lg31;->a:Le0;

    .line 73
    .line 74
    throw p1
    :try_end_4a
    .catchall {:try_start_3b .. :try_end_4a} :catchall_29

    .line 75
    :goto_4a
    :try_start_4a
    invoke-virtual {v3}, Lzu;->k()V
    :try_end_4d
    .catch Ljava/io/IOException; {:try_start_4a .. :try_end_4d} :catch_4d
    .catchall {:try_start_4a .. :try_end_4d} :catchall_54

    .line 76
    .line 77
    .line 78
    :catch_4d
    invoke-virtual {v1}, Ltn;->j()Lun;

    .line 79
    .line 80
    .line 81
    move-result-object p2

    .line 82
    iput-object p2, p0, Lv62;->b:Lun;

    .line 83
    .line 84
    goto :goto_5c

    .line 85
    :catchall_54
    move-exception p1

    .line 86
    invoke-virtual {v1}, Ltn;->j()Lun;

    .line 87
    .line 88
    .line 89
    move-result-object p2

    .line 90
    iput-object p2, p0, Lv62;->b:Lun;

    .line 91
    .line 92
    throw p1

    .line 93
    :goto_5c
    invoke-virtual {p0}, Lgv0;->m()V

    .line 94
    .line 95
    .line 96
    throw p1

    .line 97
    :cond_60
    :try_start_60
    invoke-virtual {v3}, Lzu;->k()V
    :try_end_63
    .catch Ljava/io/IOException; {:try_start_60 .. :try_end_63} :catch_63
    .catchall {:try_start_60 .. :try_end_63} :catchall_6a

    .line 98
    .line 99
    .line 100
    :catch_63
    invoke-virtual {v1}, Ltn;->j()Lun;

    .line 101
    .line 102
    .line 103
    move-result-object p1

    .line 104
    iput-object p1, p0, Lv62;->b:Lun;

    .line 105
    .line 106
    goto :goto_72

    .line 107
    :catchall_6a
    move-exception p1

    .line 108
    invoke-virtual {v1}, Ltn;->j()Lun;

    .line 109
    .line 110
    .line 111
    move-result-object p2

    .line 112
    iput-object p2, p0, Lv62;->b:Lun;

    .line 113
    .line 114
    throw p1

    .line 115
    :goto_72
    invoke-virtual {p0}, Lgv0;->m()V

    .line 116
    .line 117
    .line 118
    return-void
.end method


# virtual methods
.method public final a()Le0;
    .registers 1

    .line 1
    sget-object p0, Lv62;->g:Lv62;

    .line 2
    .line 3
    return-object p0
.end method

.method public final b()Z
    .registers 4

    .line 1
    iget-byte v0, p0, Lv62;->e:B

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-ne v0, v1, :cond_6

    .line 5
    .line 6
    return v1

    .line 7
    :cond_6
    const/4 v2, 0x0

    .line 8
    if-nez v0, :cond_a

    .line 9
    .line 10
    return v2

    .line 11
    :cond_a
    invoke-virtual {p0}, Lgv0;->i()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-nez v0, :cond_13

    .line 16
    .line 17
    iput-byte v2, p0, Lv62;->e:B

    .line 18
    .line 19
    return v2

    .line 20
    :cond_13
    iput-byte v1, p0, Lv62;->e:B

    .line 21
    .line 22
    return v1
.end method

.method public final c()I
    .registers 3

    .line 1
    iget v0, p0, Lv62;->f:I

    .line 2
    .line 3
    const/4 v1, -0x1

    .line 4
    if-eq v0, v1, :cond_6

    .line 5
    .line 6
    return v0

    .line 7
    :cond_6
    iget v0, p0, Lv62;->c:I

    .line 8
    .line 9
    const/4 v1, 0x1

    .line 10
    and-int/2addr v0, v1

    .line 11
    if-ne v0, v1, :cond_13

    .line 12
    .line 13
    iget v0, p0, Lv62;->d:I

    .line 14
    .line 15
    invoke-static {v1, v0}, Lzu;->b(II)I

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    goto :goto_14

    .line 20
    :cond_13
    const/4 v0, 0x0

    .line 21
    :goto_14
    invoke-virtual {p0}, Lgv0;->j()I

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    add-int/2addr v1, v0

    .line 26
    iget-object v0, p0, Lv62;->b:Lun;

    .line 27
    .line 28
    invoke-virtual {v0}, Lun;->size()I

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    add-int/2addr v0, v1

    .line 33
    iput v0, p0, Lv62;->f:I

    .line 34
    .line 35
    return v0
.end method

.method public final d()Lcv0;
    .registers 1

    .line 1
    new-instance p0, Lu62;

    .line 2
    .line 3
    invoke-direct {p0}, Lfv0;-><init>()V

    .line 4
    .line 5
    .line 6
    return-object p0
.end method

.method public final e()Lcv0;
    .registers 2

    .line 1
    new-instance v0, Lu62;

    .line 2
    .line 3
    invoke-direct {v0}, Lfv0;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {v0, p0}, Lu62;->g(Lv62;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public final f(Lzu;)V
    .registers 5

    .line 1
    invoke-virtual {p0}, Lv62;->c()I

    .line 2
    .line 3
    .line 4
    new-instance v0, Leh0;

    .line 5
    .line 6
    invoke-direct {v0, p0}, Leh0;-><init>(Lgv0;)V

    .line 7
    .line 8
    .line 9
    iget v1, p0, Lv62;->c:I

    .line 10
    .line 11
    const/4 v2, 0x1

    .line 12
    and-int/2addr v1, v2

    .line 13
    if-ne v1, v2, :cond_13

    .line 14
    .line 15
    iget v1, p0, Lv62;->d:I

    .line 16
    .line 17
    invoke-virtual {p1, v2, v1}, Lzu;->m(II)V

    .line 18
    .line 19
    .line 20
    :cond_13
    const/16 v1, 0xc8

    .line 21
    .line 22
    invoke-virtual {v0, v1, p1}, Leh0;->V0(ILzu;)V

    .line 23
    .line 24
    .line 25
    iget-object p0, p0, Lv62;->b:Lun;

    .line 26
    .line 27
    invoke-virtual {p1, p0}, Lzu;->r(Lun;)V

    .line 28
    .line 29
    .line 30
    return-void
.end method
