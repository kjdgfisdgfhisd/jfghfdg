###### Class defpackage.ri2 (ri2)
.class public abstract Lri2;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# virtual methods
.method public abstract a(Lpi2;)V
.end method
