###### Class defpackage.ic0 (ic0)
.class public final synthetic Lic0;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:I

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lcc/bomber/x/k/e;Lcc/bomber/x/b/o;I)V
    .registers 5

    .line 14
    const/4 v0, 0x1

    iput v0, p0, Lic0;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lic0;->c:Ljava/lang/Object;

    iput-object p2, p0, Lic0;->d:Ljava/lang/Object;

    iput p3, p0, Lic0;->b:I

    return-void
.end method

.method public synthetic constructor <init>(Ljc0;ILjava/lang/Object;)V
    .registers 5

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lic0;->a:I

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lic0;->c:Ljava/lang/Object;

    .line 8
    .line 9
    iput p2, p0, Lic0;->b:I

    .line 10
    .line 11
    iput-object p3, p0, Lic0;->d:Ljava/lang/Object;

    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    .line 1
    iget v0, p0, Lic0;->a:I

    .line 2
    .line 3
    iget v1, p0, Lic0;->b:I

    .line 4
    .line 5
    iget-object v2, p0, Lic0;->d:Ljava/lang/Object;

    .line 6
    .line 7
    iget-object p0, p0, Lic0;->c:Ljava/lang/Object;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_1c

    .line 10
    .line 11
    .line 12
    check-cast p0, Lcc/bomber/x/k/e;

    .line 13
    .line 14
    check-cast v2, Lcc/bomber/x/b/o;

    .line 15
    .line 16
    invoke-static {p0, v2, v1}, Lcc/bomber/x/k/e;->c(Lcc/bomber/x/k/e;Lcc/bomber/x/b/o;I)V

    .line 17
    .line 18
    .line 19
    return-void

    .line 20
    :pswitch_13
    check-cast p0, Ljc0;

    .line 21
    .line 22
    iget-object p0, p0, Ljc0;->b:Lf52;

    .line 23
    .line 24
    invoke-interface {p0, v1, v2}, Lf52;->k(ILjava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    return-void

    .line 28
    nop

    .line 29
    :pswitch_data_1c
    .packed-switch 0x0
        :pswitch_13
    .end packed-switch
.end method
