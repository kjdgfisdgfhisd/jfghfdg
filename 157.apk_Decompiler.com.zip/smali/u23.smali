###### Class defpackage.u23 (u23)
.class public final Lu23;
.super Lv23;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# virtual methods
.method public final d(Lgg1;)Lq23;
    .registers 2

    .line 1
    const/4 p0, 0x0

    .line 2
    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 1

    .line 1
    const-string p0, "Empty TypeSubstitution"

    .line 2
    .line 3
    return-object p0
.end method
