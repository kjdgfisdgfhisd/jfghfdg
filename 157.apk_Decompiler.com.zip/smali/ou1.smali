###### Class defpackage.ou1 (ou1)
.class public final Lou1;
.super Lxq0;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# virtual methods
.method public final close()V
    .registers 1

    .line 1
    return-void
.end method
