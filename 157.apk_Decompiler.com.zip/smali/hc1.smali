###### Class defpackage.hc1 (hc1)
.class public final Lhc1;
.super Lcv0;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lat1;


# instance fields
.field public b:I

.field public c:I

.field public d:I

.field public e:Ljava/lang/Object;

.field public f:Lic1;

.field public g:Ljava/util/List;

.field public j:Ljava/util/List;


# direct methods
.method public static g()Lhc1;
    .registers 2

    .line 1
    new-instance v0, Lhc1;

    .line 2
    .line 3
    invoke-direct {v0}, Lcv0;-><init>()V

    .line 4
    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    iput v1, v0, Lhc1;->c:I

    .line 8
    .line 9
    const-string v1, ""

    .line 10
    .line 11
    iput-object v1, v0, Lhc1;->e:Ljava/lang/Object;

    .line 12
    .line 13
    sget-object v1, Lic1;->b:Lic1;

    .line 14
    .line 15
    iput-object v1, v0, Lhc1;->f:Lic1;

    .line 16
    .line 17
    sget-object v1, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 18
    .line 19
    iput-object v1, v0, Lhc1;->g:Ljava/util/List;

    .line 20
    .line 21
    iput-object v1, v0, Lhc1;->j:Ljava/util/List;

    .line 22
    .line 23
    return-object v0
.end method


# virtual methods
.method public final c()Le0;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lhc1;->f()Ljc1;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0}, Ljc1;->b()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_b

    .line 10
    .line 11
    return-object p0

    .line 12
    :cond_b
    new-instance p0, Llw;

    .line 13
    .line 14
    invoke-direct {p0}, Llw;-><init>()V

    .line 15
    .line 16
    .line 17
    throw p0
.end method

.method public final clone()Ljava/lang/Object;
    .registers 2

    .line 1
    invoke-static {}, Lhc1;->g()Lhc1;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {p0}, Lhc1;->f()Ljc1;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    invoke-virtual {v0, p0}, Lhc1;->h(Ljc1;)V

    .line 10
    .line 11
    .line 12
    return-object v0
.end method

.method public final d(Lwu;Lpl0;)Lcv0;
    .registers 4

    .line 1
    const/4 p2, 0x0

    .line 2
    :try_start_1
    sget-object v0, Ljc1;->q:Lac1;

    .line 3
    .line 4
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    new-instance v0, Ljc1;

    .line 8
    .line 9
    invoke-direct {v0, p1}, Ljc1;-><init>(Lwu;)V
    :try_end_b
    .catch Lg31; {:try_start_1 .. :try_end_b} :catch_11
    .catchall {:try_start_1 .. :try_end_b} :catchall_f

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0, v0}, Lhc1;->h(Ljc1;)V

    .line 13
    .line 14
    .line 15
    return-object p0

    .line 16
    :catchall_f
    move-exception p1

    .line 17
    goto :goto_19

    .line 18
    :catch_11
    move-exception p1

    .line 19
    :try_start_12
    iget-object v0, p1, Lg31;->a:Le0;

    .line 20
    .line 21
    check-cast v0, Ljc1;
    :try_end_16
    .catchall {:try_start_12 .. :try_end_16} :catchall_f

    .line 22
    .line 23
    :try_start_16
    throw p1
    :try_end_17
    .catchall {:try_start_16 .. :try_end_17} :catchall_17

    .line 24
    :catchall_17
    move-exception p1

    .line 25
    move-object p2, v0

    .line 26
    :goto_19
    if-eqz p2, :cond_1e

    .line 27
    .line 28
    invoke-virtual {p0, p2}, Lhc1;->h(Ljc1;)V

    .line 29
    .line 30
    .line 31
    :cond_1e
    throw p1
.end method

.method public final bridge synthetic e(Ljv0;)Lcv0;
    .registers 2

    .line 1
    check-cast p1, Ljc1;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lhc1;->h(Ljc1;)V

    .line 4
    .line 5
    .line 6
    return-object p0
.end method

.method public final f()Ljc1;
    .registers 6

    .line 1
    new-instance v0, Ljc1;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Ljc1;-><init>(Lhc1;)V

    .line 4
    .line 5
    .line 6
    iget v1, p0, Lhc1;->b:I

    .line 7
    .line 8
    and-int/lit8 v2, v1, 0x1

    .line 9
    .line 10
    const/4 v3, 0x1

    .line 11
    if-ne v2, v3, :cond_d

    .line 12
    .line 13
    goto :goto_e

    .line 14
    :cond_d
    const/4 v3, 0x0

    .line 15
    :goto_e
    iget v2, p0, Lhc1;->c:I

    .line 16
    .line 17
    iput v2, v0, Ljc1;->c:I

    .line 18
    .line 19
    and-int/lit8 v2, v1, 0x2

    .line 20
    .line 21
    const/4 v4, 0x2

    .line 22
    if-ne v2, v4, :cond_19

    .line 23
    .line 24
    or-int/lit8 v3, v3, 0x2

    .line 25
    .line 26
    :cond_19
    iget v2, p0, Lhc1;->d:I

    .line 27
    .line 28
    iput v2, v0, Ljc1;->d:I

    .line 29
    .line 30
    and-int/lit8 v2, v1, 0x4

    .line 31
    .line 32
    const/4 v4, 0x4

    .line 33
    if-ne v2, v4, :cond_24

    .line 34
    .line 35
    or-int/lit8 v3, v3, 0x4

    .line 36
    .line 37
    :cond_24
    iget-object v2, p0, Lhc1;->e:Ljava/lang/Object;

    .line 38
    .line 39
    iput-object v2, v0, Ljc1;->e:Ljava/lang/Object;

    .line 40
    .line 41
    and-int/lit8 v2, v1, 0x8

    .line 42
    .line 43
    const/16 v4, 0x8

    .line 44
    .line 45
    if-ne v2, v4, :cond_30

    .line 46
    .line 47
    or-int/lit8 v3, v3, 0x8

    .line 48
    .line 49
    :cond_30
    iget-object v2, p0, Lhc1;->f:Lic1;

    .line 50
    .line 51
    iput-object v2, v0, Ljc1;->f:Lic1;

    .line 52
    .line 53
    and-int/lit8 v2, v1, 0x10

    .line 54
    .line 55
    const/16 v4, 0x10

    .line 56
    .line 57
    if-ne v2, v4, :cond_48

    .line 58
    .line 59
    iget-object v1, p0, Lhc1;->g:Ljava/util/List;

    .line 60
    .line 61
    invoke-static {v1}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 62
    .line 63
    .line 64
    move-result-object v1

    .line 65
    iput-object v1, p0, Lhc1;->g:Ljava/util/List;

    .line 66
    .line 67
    iget v1, p0, Lhc1;->b:I

    .line 68
    .line 69
    and-int/lit8 v1, v1, -0x11

    .line 70
    .line 71
    iput v1, p0, Lhc1;->b:I

    .line 72
    .line 73
    :cond_48
    iget-object v2, p0, Lhc1;->g:Ljava/util/List;

    .line 74
    .line 75
    iput-object v2, v0, Ljc1;->g:Ljava/util/List;

    .line 76
    .line 77
    const/16 v2, 0x20

    .line 78
    .line 79
    and-int/2addr v1, v2

    .line 80
    if-ne v1, v2, :cond_5f

    .line 81
    .line 82
    iget-object v1, p0, Lhc1;->j:Ljava/util/List;

    .line 83
    .line 84
    invoke-static {v1}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 85
    .line 86
    .line 87
    move-result-object v1

    .line 88
    iput-object v1, p0, Lhc1;->j:Ljava/util/List;

    .line 89
    .line 90
    iget v1, p0, Lhc1;->b:I

    .line 91
    .line 92
    and-int/lit8 v1, v1, -0x21

    .line 93
    .line 94
    iput v1, p0, Lhc1;->b:I

    .line 95
    .line 96
    :cond_5f
    iget-object p0, p0, Lhc1;->j:Ljava/util/List;

    .line 97
    .line 98
    iput-object p0, v0, Ljc1;->l:Ljava/util/List;

    .line 99
    .line 100
    iput v3, v0, Ljc1;->b:I

    .line 101
    .line 102
    return-object v0
.end method

.method public final h(Ljc1;)V
    .registers 6

    .line 1
    sget-object v0, Ljc1;->p:Ljc1;

    .line 2
    .line 3
    if-ne p1, v0, :cond_5

    .line 4
    .line 5
    return-void

    .line 6
    :cond_5
    iget v0, p1, Ljc1;->b:I

    .line 7
    .line 8
    and-int/lit8 v1, v0, 0x1

    .line 9
    .line 10
    const/4 v2, 0x1

    .line 11
    if-ne v1, v2, :cond_15

    .line 12
    .line 13
    iget v1, p1, Ljc1;->c:I

    .line 14
    .line 15
    iget v3, p0, Lhc1;->b:I

    .line 16
    .line 17
    or-int/2addr v2, v3

    .line 18
    iput v2, p0, Lhc1;->b:I

    .line 19
    .line 20
    iput v1, p0, Lhc1;->c:I

    .line 21
    .line 22
    :cond_15
    and-int/lit8 v1, v0, 0x2

    .line 23
    .line 24
    const/4 v2, 0x2

    .line 25
    if-ne v1, v2, :cond_23

    .line 26
    .line 27
    iget v1, p1, Ljc1;->d:I

    .line 28
    .line 29
    iget v3, p0, Lhc1;->b:I

    .line 30
    .line 31
    or-int/2addr v2, v3

    .line 32
    iput v2, p0, Lhc1;->b:I

    .line 33
    .line 34
    iput v1, p0, Lhc1;->d:I

    .line 35
    .line 36
    :cond_23
    and-int/lit8 v1, v0, 0x4

    .line 37
    .line 38
    const/4 v2, 0x4

    .line 39
    if-ne v1, v2, :cond_31

    .line 40
    .line 41
    iget v1, p0, Lhc1;->b:I

    .line 42
    .line 43
    or-int/2addr v1, v2

    .line 44
    iput v1, p0, Lhc1;->b:I

    .line 45
    .line 46
    iget-object v1, p1, Ljc1;->e:Ljava/lang/Object;

    .line 47
    .line 48
    iput-object v1, p0, Lhc1;->e:Ljava/lang/Object;

    .line 49
    .line 50
    :cond_31
    const/16 v1, 0x8

    .line 51
    .line 52
    and-int/2addr v0, v1

    .line 53
    if-ne v0, v1, :cond_42

    .line 54
    .line 55
    iget-object v0, p1, Ljc1;->f:Lic1;

    .line 56
    .line 57
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 58
    .line 59
    .line 60
    iget v2, p0, Lhc1;->b:I

    .line 61
    .line 62
    or-int/2addr v1, v2

    .line 63
    iput v1, p0, Lhc1;->b:I

    .line 64
    .line 65
    iput-object v0, p0, Lhc1;->f:Lic1;

    .line 66
    .line 67
    :cond_42
    iget-object v0, p1, Ljc1;->g:Ljava/util/List;

    .line 68
    .line 69
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 70
    .line 71
    .line 72
    move-result v0

    .line 73
    if-nez v0, :cond_79

    .line 74
    .line 75
    iget-object v0, p0, Lhc1;->g:Ljava/util/List;

    .line 76
    .line 77
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    if-eqz v0, :cond_5d

    .line 82
    .line 83
    iget-object v0, p1, Ljc1;->g:Ljava/util/List;

    .line 84
    .line 85
    iput-object v0, p0, Lhc1;->g:Ljava/util/List;

    .line 86
    .line 87
    iget v0, p0, Lhc1;->b:I

    .line 88
    .line 89
    and-int/lit8 v0, v0, -0x11

    .line 90
    .line 91
    iput v0, p0, Lhc1;->b:I

    .line 92
    .line 93
    goto :goto_79

    .line 94
    :cond_5d
    iget v0, p0, Lhc1;->b:I

    .line 95
    .line 96
    const/16 v1, 0x10

    .line 97
    .line 98
    and-int/2addr v0, v1

    .line 99
    if-eq v0, v1, :cond_72

    .line 100
    .line 101
    new-instance v0, Ljava/util/ArrayList;

    .line 102
    .line 103
    iget-object v2, p0, Lhc1;->g:Ljava/util/List;

    .line 104
    .line 105
    invoke-direct {v0, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 106
    .line 107
    .line 108
    iput-object v0, p0, Lhc1;->g:Ljava/util/List;

    .line 109
    .line 110
    iget v0, p0, Lhc1;->b:I

    .line 111
    .line 112
    or-int/2addr v0, v1

    .line 113
    iput v0, p0, Lhc1;->b:I

    .line 114
    .line 115
    :cond_72
    iget-object v0, p0, Lhc1;->g:Ljava/util/List;

    .line 116
    .line 117
    iget-object v1, p1, Ljc1;->g:Ljava/util/List;

    .line 118
    .line 119
    invoke-interface {v0, v1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 120
    .line 121
    .line 122
    :cond_79
    :goto_79
    iget-object v0, p1, Ljc1;->l:Ljava/util/List;

    .line 123
    .line 124
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 125
    .line 126
    .line 127
    move-result v0

    .line 128
    if-nez v0, :cond_b0

    .line 129
    .line 130
    iget-object v0, p0, Lhc1;->j:Ljava/util/List;

    .line 131
    .line 132
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 133
    .line 134
    .line 135
    move-result v0

    .line 136
    if-eqz v0, :cond_94

    .line 137
    .line 138
    iget-object v0, p1, Ljc1;->l:Ljava/util/List;

    .line 139
    .line 140
    iput-object v0, p0, Lhc1;->j:Ljava/util/List;

    .line 141
    .line 142
    iget v0, p0, Lhc1;->b:I

    .line 143
    .line 144
    and-int/lit8 v0, v0, -0x21

    .line 145
    .line 146
    iput v0, p0, Lhc1;->b:I

    .line 147
    .line 148
    goto :goto_b0

    .line 149
    :cond_94
    iget v0, p0, Lhc1;->b:I

    .line 150
    .line 151
    const/16 v1, 0x20

    .line 152
    .line 153
    and-int/2addr v0, v1

    .line 154
    if-eq v0, v1, :cond_a9

    .line 155
    .line 156
    new-instance v0, Ljava/util/ArrayList;

    .line 157
    .line 158
    iget-object v2, p0, Lhc1;->j:Ljava/util/List;

    .line 159
    .line 160
    invoke-direct {v0, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 161
    .line 162
    .line 163
    iput-object v0, p0, Lhc1;->j:Ljava/util/List;

    .line 164
    .line 165
    iget v0, p0, Lhc1;->b:I

    .line 166
    .line 167
    or-int/2addr v0, v1

    .line 168
    iput v0, p0, Lhc1;->b:I

    .line 169
    .line 170
    :cond_a9
    iget-object v0, p0, Lhc1;->j:Ljava/util/List;

    .line 171
    .line 172
    iget-object v1, p1, Ljc1;->l:Ljava/util/List;

    .line 173
    .line 174
    invoke-interface {v0, v1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 175
    .line 176
    .line 177
    :cond_b0
    :goto_b0
    iget-object v0, p0, Lcv0;->a:Lun;

    .line 178
    .line 179
    iget-object p1, p1, Ljc1;->a:Lun;

    .line 180
    .line 181
    invoke-virtual {v0, p1}, Lun;->c(Lun;)Lun;

    .line 182
    .line 183
    .line 184
    move-result-object p1

    .line 185
    iput-object p1, p0, Lcv0;->a:Lun;

    .line 186
    .line 187
    return-void
.end method
