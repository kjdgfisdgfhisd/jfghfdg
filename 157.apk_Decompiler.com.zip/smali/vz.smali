###### Class defpackage.vz (vz)
.class public final Lvz;
.super Lnv2;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Ltt0;


# instance fields
.field public final synthetic j:I

.field public synthetic l:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILw00;)V
    .registers 4

    .line 11
    const/4 v0, 0x1

    iput v0, p0, Lvz;->j:I

    invoke-direct {p0, p1, p2}, Lnv2;-><init>(ILw00;)V

    return-void
.end method

.method public constructor <init>(Lje3;Lw00;)V
    .registers 4

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lvz;->j:I

    .line 3
    .line 4
    iput-object p1, p0, Lvz;->l:Ljava/lang/Object;

    .line 5
    .line 6
    const/4 p1, 0x2

    .line 7
    invoke-direct {p0, p1, p2}, Lnv2;-><init>(ILw00;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lw00;)Lw00;
    .registers 4

    .line 1
    iget v0, p0, Lvz;->j:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_18

    .line 4
    .line 5
    .line 6
    new-instance p0, Lvz;

    .line 7
    .line 8
    const/4 v0, 0x2

    .line 9
    invoke-direct {p0, v0, p2}, Lvz;-><init>(ILw00;)V

    .line 10
    .line 11
    .line 12
    iput-object p1, p0, Lvz;->l:Ljava/lang/Object;

    .line 13
    .line 14
    return-object p0

    .line 15
    :pswitch_e
    new-instance p1, Lvz;

    .line 16
    .line 17
    iget-object p0, p0, Lvz;->l:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast p0, Lje3;

    .line 20
    .line 21
    invoke-direct {p1, p0, p2}, Lvz;-><init>(Lje3;Lw00;)V

    .line 22
    .line 23
    .line 24
    return-object p1

    .line 25
    :pswitch_data_18
    .packed-switch 0x0
        :pswitch_e
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 1
    iget v0, p0, Lvz;->j:I

    .line 2
    .line 3
    sget-object v1, Lw43;->a:Lw43;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_24

    .line 6
    .line 7
    .line 8
    check-cast p1, Ljava/lang/String;

    .line 9
    .line 10
    check-cast p2, Lw00;

    .line 11
    .line 12
    invoke-virtual {p0, p1, p2}, Lvz;->create(Ljava/lang/Object;Lw00;)Lw00;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Lvz;

    .line 17
    .line 18
    invoke-virtual {p0, v1}, Lvz;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    return-object v1

    .line 22
    :pswitch_15
    check-cast p1, Le00;

    .line 23
    .line 24
    check-cast p2, Lw00;

    .line 25
    .line 26
    invoke-virtual {p0, p1, p2}, Lvz;->create(Ljava/lang/Object;Lw00;)Lw00;

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    check-cast p0, Lvz;

    .line 31
    .line 32
    invoke-virtual {p0, v1}, Lvz;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    return-object v1

    .line 36
    nop

    .line 37
    :pswitch_data_24
    .packed-switch 0x0
        :pswitch_15
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 1
    iget v0, p0, Lvz;->j:I

    .line 2
    .line 3
    sget-object v1, Lw43;->a:Lw43;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_42

    .line 6
    .line 7
    .line 8
    invoke-static {p1}, Lh23;->t(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    iget-object p0, p0, Lvz;->l:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast p0, Ljava/lang/String;

    .line 14
    .line 15
    new-instance p1, Ljava/lang/StringBuilder;

    .line 16
    .line 17
    const-string v0, "Error failing to fetch the remote configs: "

    .line 18
    .line 19
    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 23
    .line 24
    .line 25
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object p0

    .line 29
    const-string p1, "SessionConfigFetcher"

    .line 30
    .line 31
    invoke-static {p1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 32
    .line 33
    .line 34
    return-object v1

    .line 35
    :pswitch_22
    invoke-static {p1}, Lh23;->t(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    sget-object p1, Lwz;->a:Ljava/lang/String;

    .line 39
    .line 40
    iget-object p0, p0, Lvz;->l:Ljava/lang/Object;

    .line 41
    .line 42
    check-cast p0, Lje3;

    .line 43
    .line 44
    invoke-static {}, Lrm1;->h()Lrm1;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    new-instance v2, Ljava/lang/StringBuilder;

    .line 49
    .line 50
    const-string v3, "Constraints changed for "

    .line 51
    .line 52
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 53
    .line 54
    .line 55
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 56
    .line 57
    .line 58
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 59
    .line 60
    .line 61
    move-result-object p0

    .line 62
    invoke-virtual {v0, p1, p0}, Lrm1;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 63
    .line 64
    .line 65
    return-object v1

    .line 66
    nop

    .line 67
    :pswitch_data_42
    .packed-switch 0x0
        :pswitch_22
    .end packed-switch
.end method
