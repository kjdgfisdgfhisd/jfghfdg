###### Class defpackage.et3 (et3)
.class public abstract Let3;
.super Lgp3;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public d:Z


# direct methods
.method public constructor <init>(Lzt3;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lov;-><init>(Lzt3;)V

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lov;->a:Ljava/lang/Object;

    .line 5
    .line 6
    check-cast p0, Lzt3;

    .line 7
    .line 8
    iget p1, p0, Lzt3;->H:I

    .line 9
    .line 10
    add-int/lit8 p1, p1, 0x1

    .line 11
    .line 12
    iput p1, p0, Lzt3;->H:I

    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final L0()V
    .registers 1

    .line 1
    iget-boolean p0, p0, Let3;->d:Z

    .line 2
    .line 3
    if-eqz p0, :cond_5

    .line 4
    .line 5
    return-void

    .line 6
    :cond_5
    const-string p0, "Not initialized"

    .line 7
    .line 8
    invoke-static {p0}, Ly0;->h(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final M0()V
    .registers 2

    .line 1
    iget-boolean v0, p0, Let3;->d:Z

    .line 2
    .line 3
    if-nez v0, :cond_17

    .line 4
    .line 5
    invoke-virtual {p0}, Let3;->N0()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-nez v0, :cond_16

    .line 10
    .line 11
    iget-object v0, p0, Lov;->a:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v0, Lzt3;

    .line 14
    .line 15
    iget-object v0, v0, Lzt3;->J:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 16
    .line 17
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I

    .line 18
    .line 19
    .line 20
    const/4 v0, 0x1

    .line 21
    iput-boolean v0, p0, Let3;->d:Z

    .line 22
    .line 23
    :cond_16
    return-void

    .line 24
    :cond_17
    const-string p0, "Can\'t initialize twice"

    .line 25
    .line 26
    invoke-static {p0}, Ly0;->h(Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    return-void
.end method

.method public abstract N0()Z
.end method
