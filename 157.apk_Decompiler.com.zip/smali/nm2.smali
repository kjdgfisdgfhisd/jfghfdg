###### Class defpackage.nm2 (nm2)
.class public final Lnm2;
.super Ly00;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public synthetic j:Ljava/lang/Object;

.field public final synthetic l:Lpm2;

.field public m:I


# direct methods
.method public constructor <init>(Lpm2;Ly00;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lnm2;->l:Lpm2;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Ly00;-><init>(Lw00;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    iput-object p1, p0, Lnm2;->j:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lnm2;->m:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lnm2;->m:I

    .line 9
    .line 10
    iget-object p1, p0, Lnm2;->l:Lpm2;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-virtual {p1, v0, v0, p0}, Lpm2;->b(Lk32;Ljava/lang/Object;Ly00;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method
