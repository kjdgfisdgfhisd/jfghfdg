###### Class defpackage.kf0 (kf0)
.class public final Lkf0;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Ljava/lang/Comparable;


# static fields
.field public static final b:Lih2;

.field public static final c:J

.field public static final d:J

.field public static final e:J


# instance fields
.field public final a:J


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lih2;

    .line 2
    .line 3
    const/16 v1, 0x17

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lih2;-><init>(I)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lkf0;->b:Lih2;

    .line 9
    .line 10
    const-wide v0, 0x3fffffffffffffffL    # 1.9999999999999998

    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    invoke-static {v0, v1}, Lns3;->e(J)J

    .line 16
    .line 17
    .line 18
    move-result-wide v0

    .line 19
    sput-wide v0, Lkf0;->c:J

    .line 20
    .line 21
    const-wide v0, -0x3fffffffffffffffL    # -2.0000000000000004

    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    invoke-static {v0, v1}, Lns3;->e(J)J

    .line 27
    .line 28
    .line 29
    move-result-wide v0

    .line 30
    sput-wide v0, Lkf0;->d:J

    .line 31
    .line 32
    const-wide v0, 0x7fffffffffffc0deL

    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    sput-wide v0, Lkf0;->e:J

    .line 38
    .line 39
    return-void
.end method

.method public synthetic constructor <init>(J)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-wide p1, p0, Lkf0;->a:J

    .line 5
    .line 6
    return-void
.end method

.method public static final a(JJ)J
    .registers 10

    .line 1
    const-wide/32 v0, 0xf4240

    .line 2
    .line 3
    .line 4
    div-long v2, p2, v0

    .line 5
    .line 6
    invoke-static {p0, p1, v2, v3}, Lns3;->a(JJ)J

    .line 7
    .line 8
    .line 9
    move-result-wide p0

    .line 10
    const-wide v4, -0x431bde82d7aL

    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    cmp-long v4, v4, p0

    .line 16
    .line 17
    if-gtz v4, :cond_24

    .line 18
    .line 19
    const-wide v4, 0x431bde82d7bL

    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    cmp-long v4, p0, v4

    .line 25
    .line 26
    if-gez v4, :cond_24

    .line 27
    .line 28
    mul-long/2addr v2, v0

    .line 29
    sub-long/2addr p2, v2

    .line 30
    mul-long/2addr p0, v0

    .line 31
    add-long/2addr p0, p2

    .line 32
    const/4 p2, 0x1

    .line 33
    shl-long/2addr p0, p2

    .line 34
    sget p2, Llf0;->a:I

    .line 35
    .line 36
    return-wide p0

    .line 37
    :cond_24
    invoke-static {p0, p1}, Lns3;->e(J)J

    .line 38
    .line 39
    .line 40
    move-result-wide p0

    .line 41
    return-wide p0
.end method

.method public static final b(Ljava/lang/StringBuilder;IIILjava/lang/String;Z)V
    .registers 9

    .line 1
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 2
    .line 3
    .line 4
    if-eqz p2, :cond_3d

    .line 5
    .line 6
    const/16 p1, 0x2e

    .line 7
    .line 8
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 9
    .line 10
    .line 11
    invoke-static {p2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    invoke-static {p3, p1}, Lxt2;->X(ILjava/lang/String;)Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 20
    .line 21
    .line 22
    move-result p2

    .line 23
    const/4 p3, -0x1

    .line 24
    add-int/2addr p2, p3

    .line 25
    if-ltz p2, :cond_2b

    .line 26
    .line 27
    :goto_1a
    add-int/lit8 v0, p2, -0x1

    .line 28
    .line 29
    invoke-virtual {p1, p2}, Ljava/lang/String;->charAt(I)C

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    const/16 v2, 0x30

    .line 34
    .line 35
    if-eq v1, v2, :cond_26

    .line 36
    .line 37
    move p3, p2

    .line 38
    goto :goto_2b

    .line 39
    :cond_26
    if-gez v0, :cond_29

    .line 40
    .line 41
    goto :goto_2b

    .line 42
    :cond_29
    move p2, v0

    .line 43
    goto :goto_1a

    .line 44
    :cond_2b
    :goto_2b
    add-int/lit8 p2, p3, 0x1

    .line 45
    .line 46
    const/4 v0, 0x0

    .line 47
    const/4 v1, 0x3

    .line 48
    if-nez p5, :cond_37

    .line 49
    .line 50
    if-ge p2, v1, :cond_37

    .line 51
    .line 52
    invoke-virtual {p0, p1, v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    .line 53
    .line 54
    .line 55
    goto :goto_3d

    .line 56
    :cond_37
    add-int/2addr p3, v1

    .line 57
    div-int/2addr p3, v1

    .line 58
    mul-int/2addr p3, v1

    .line 59
    invoke-virtual {p0, p1, v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    .line 60
    .line 61
    .line 62
    :cond_3d
    :goto_3d
    invoke-virtual {p0, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 63
    .line 64
    .line 65
    return-void
.end method

.method public static final c(J)I
    .registers 4

    .line 1
    invoke-static {p0, p1}, Lkf0;->d(J)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_8

    .line 6
    .line 7
    const/4 p0, 0x0

    .line 8
    return p0

    .line 9
    :cond_8
    long-to-int v0, p0

    .line 10
    const/4 v1, 0x1

    .line 11
    and-int/2addr v0, v1

    .line 12
    if-ne v0, v1, :cond_17

    .line 13
    .line 14
    shr-long/2addr p0, v1

    .line 15
    const-wide/16 v0, 0x3e8

    .line 16
    .line 17
    rem-long/2addr p0, v0

    .line 18
    const-wide/32 v0, 0xf4240

    .line 19
    .line 20
    .line 21
    mul-long/2addr p0, v0

    .line 22
    :goto_15
    long-to-int p0, p0

    .line 23
    return p0

    .line 24
    :cond_17
    shr-long/2addr p0, v1

    .line 25
    const-wide/32 v0, 0x3b9aca00

    .line 26
    .line 27
    .line 28
    rem-long/2addr p0, v0

    .line 29
    goto :goto_15
.end method

.method public static final d(J)Z
    .registers 4

    .line 1
    sget-wide v0, Lkf0;->c:J

    .line 2
    .line 3
    cmp-long v0, p0, v0

    .line 4
    .line 5
    if-eqz v0, :cond_f

    .line 6
    .line 7
    sget-wide v0, Lkf0;->d:J

    .line 8
    .line 9
    cmp-long p0, p0, v0

    .line 10
    .line 11
    if-nez p0, :cond_d

    .line 12
    .line 13
    goto :goto_f

    .line 14
    :cond_d
    const/4 p0, 0x0

    .line 15
    return p0

    .line 16
    :cond_f
    :goto_f
    const/4 p0, 0x1

    .line 17
    return p0
.end method

.method public static final e(JJ)J
    .registers 8

    .line 1
    long-to-int v0, p0

    .line 2
    const/4 v1, 0x1

    .line 3
    and-int/2addr v0, v1

    .line 4
    long-to-int v2, p2

    .line 5
    and-int/2addr v2, v1

    .line 6
    if-ne v0, v2, :cond_7a

    .line 7
    .line 8
    const-wide/32 v2, 0xf4240

    .line 9
    .line 10
    .line 11
    if-nez v0, :cond_2b

    .line 12
    .line 13
    shr-long/2addr p0, v1

    .line 14
    shr-long/2addr p2, v1

    .line 15
    add-long/2addr p0, p2

    .line 16
    const-wide p2, -0x3ffffffffffa14bfL    # -2.0000000001722644

    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    cmp-long p2, p2, p0

    .line 22
    .line 23
    if-gtz p2, :cond_25

    .line 24
    .line 25
    const-wide p2, 0x3ffffffffffa14c0L    # 1.999999999913868

    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    cmp-long p2, p0, p2

    .line 31
    .line 32
    if-gez p2, :cond_25

    .line 33
    .line 34
    shl-long/2addr p0, v1

    .line 35
    sget p2, Llf0;->a:I

    .line 36
    .line 37
    return-wide p0

    .line 38
    :cond_25
    div-long/2addr p0, v2

    .line 39
    invoke-static {p0, p1}, Lns3;->e(J)J

    .line 40
    .line 41
    .line 42
    move-result-wide p0

    .line 43
    return-wide p0

    .line 44
    :cond_2b
    shr-long/2addr p0, v1

    .line 45
    shr-long/2addr p2, v1

    .line 46
    invoke-static {p0, p1, p2, p3}, Lns3;->a(JJ)J

    .line 47
    .line 48
    .line 49
    move-result-wide p0

    .line 50
    const-wide p2, 0x7fffffffffffc0deL

    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    cmp-long p2, p0, p2

    .line 56
    .line 57
    if-eqz p2, :cond_72

    .line 58
    .line 59
    const-wide p2, 0x3fffffffffffffffL    # 1.9999999999999998

    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    cmp-long p2, p0, p2

    .line 65
    .line 66
    if-eqz p2, :cond_6d

    .line 67
    .line 68
    const-wide p2, -0x3fffffffffffffffL    # -2.0000000000000004

    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    cmp-long p2, p0, p2

    .line 74
    .line 75
    if-nez p2, :cond_4d

    .line 76
    .line 77
    goto :goto_6d

    .line 78
    :cond_4d
    const-wide p2, -0x431bde82d7aL

    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    cmp-long p2, p2, p0

    .line 84
    .line 85
    if-gtz p2, :cond_64

    .line 86
    .line 87
    const-wide p2, 0x431bde82d7bL

    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    cmp-long p2, p0, p2

    .line 93
    .line 94
    if-gez p2, :cond_64

    .line 95
    .line 96
    mul-long/2addr p0, v2

    .line 97
    shl-long/2addr p0, v1

    .line 98
    sget p2, Llf0;->a:I

    .line 99
    .line 100
    return-wide p0

    .line 101
    :cond_64
    invoke-static {p0, p1}, Ll60;->k(J)J

    .line 102
    .line 103
    .line 104
    move-result-wide p0

    .line 105
    invoke-static {p0, p1}, Lns3;->e(J)J

    .line 106
    .line 107
    .line 108
    move-result-wide p0

    .line 109
    return-wide p0

    .line 110
    :cond_6d
    :goto_6d
    invoke-static {p0, p1}, Lns3;->e(J)J

    .line 111
    .line 112
    .line 113
    move-result-wide p0

    .line 114
    return-wide p0

    .line 115
    :cond_72
    const-string p0, "Summing infinite durations of different signs yields an undefined result."

    .line 116
    .line 117
    invoke-static {p0}, Lm03;->g(Ljava/lang/String;)V

    .line 118
    .line 119
    .line 120
    const-wide/16 p0, 0x0

    .line 121
    .line 122
    return-wide p0

    .line 123
    :cond_7a
    if-ne v0, v1, :cond_83

    .line 124
    .line 125
    shr-long/2addr p0, v1

    .line 126
    shr-long/2addr p2, v1

    .line 127
    invoke-static {p0, p1, p2, p3}, Lkf0;->a(JJ)J

    .line 128
    .line 129
    .line 130
    move-result-wide p0

    .line 131
    return-wide p0

    .line 132
    :cond_83
    shr-long/2addr p2, v1

    .line 133
    shr-long/2addr p0, v1

    .line 134
    invoke-static {p2, p3, p0, p1}, Lkf0;->a(JJ)J

    .line 135
    .line 136
    .line 137
    move-result-wide p0

    .line 138
    return-wide p0
.end method

.method public static final f(JLnf0;)J
    .registers 6

    .line 1
    sget-wide v0, Lkf0;->c:J

    .line 2
    .line 3
    cmp-long v0, p0, v0

    .line 4
    .line 5
    if-nez v0, :cond_c

    .line 6
    .line 7
    const-wide p0, 0x7fffffffffffffffL

    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    return-wide p0

    .line 13
    :cond_c
    sget-wide v0, Lkf0;->d:J

    .line 14
    .line 15
    cmp-long v0, p0, v0

    .line 16
    .line 17
    if-nez v0, :cond_15

    .line 18
    .line 19
    const-wide/high16 p0, -0x8000000000000000L

    .line 20
    .line 21
    return-wide p0

    .line 22
    :cond_15
    const/4 v0, 0x1

    .line 23
    shr-long v1, p0, v0

    .line 24
    .line 25
    long-to-int p0, p0

    .line 26
    and-int/2addr p0, v0

    .line 27
    if-nez p0, :cond_1f

    .line 28
    .line 29
    sget-object p0, Lnf0;->b:Lnf0;

    .line 30
    .line 31
    goto :goto_21

    .line 32
    :cond_1f
    sget-object p0, Lnf0;->c:Lnf0;

    .line 33
    .line 34
    :goto_21
    iget-object p1, p2, Lnf0;->a:Ljava/util/concurrent/TimeUnit;

    .line 35
    .line 36
    iget-object p0, p0, Lnf0;->a:Ljava/util/concurrent/TimeUnit;

    .line 37
    .line 38
    invoke-virtual {p1, v1, v2, p0}, Ljava/util/concurrent/TimeUnit;->convert(JLjava/util/concurrent/TimeUnit;)J

    .line 39
    .line 40
    .line 41
    move-result-wide p0

    .line 42
    return-wide p0
.end method


# virtual methods
.method public final compareTo(Ljava/lang/Object;)I
    .registers 9

    .line 1
    check-cast p1, Lkf0;

    .line 2
    .line 3
    iget-wide v0, p1, Lkf0;->a:J

    .line 4
    .line 5
    iget-wide p0, p0, Lkf0;->a:J

    .line 6
    .line 7
    xor-long v2, p0, v0

    .line 8
    .line 9
    const-wide/16 v4, 0x0

    .line 10
    .line 11
    cmp-long v6, v2, v4

    .line 12
    .line 13
    if-ltz v6, :cond_22

    .line 14
    .line 15
    long-to-int v2, v2

    .line 16
    and-int/lit8 v2, v2, 0x1

    .line 17
    .line 18
    if-nez v2, :cond_14

    .line 19
    .line 20
    goto :goto_22

    .line 21
    :cond_14
    long-to-int v2, p0

    .line 22
    and-int/lit8 v2, v2, 0x1

    .line 23
    .line 24
    long-to-int v0, v0

    .line 25
    and-int/lit8 v0, v0, 0x1

    .line 26
    .line 27
    sub-int/2addr v2, v0

    .line 28
    cmp-long p0, p0, v4

    .line 29
    .line 30
    if-gez p0, :cond_21

    .line 31
    .line 32
    neg-int p0, v2

    .line 33
    return p0

    .line 34
    :cond_21
    return v2

    .line 35
    :cond_22
    :goto_22
    invoke-static {p0, p1, v0, v1}, Ld31;->f(JJ)I

    .line 36
    .line 37
    .line 38
    move-result p0

    .line 39
    return p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    .line 1
    instance-of v0, p1, Lkf0;

    .line 2
    .line 3
    if-nez v0, :cond_5

    .line 4
    .line 5
    goto :goto_f

    .line 6
    :cond_5
    check-cast p1, Lkf0;

    .line 7
    .line 8
    iget-wide v0, p1, Lkf0;->a:J

    .line 9
    .line 10
    iget-wide p0, p0, Lkf0;->a:J

    .line 11
    .line 12
    cmp-long p0, p0, v0

    .line 13
    .line 14
    if-eqz p0, :cond_11

    .line 15
    .line 16
    :goto_f
    const/4 p0, 0x0

    .line 17
    return p0

    .line 18
    :cond_11
    const/4 p0, 0x1

    .line 19
    return p0
.end method

.method public final hashCode()I
    .registers 3

    .line 1
    iget-wide v0, p0, Lkf0;->a:J

    .line 2
    .line 3
    invoke-static {v0, v1}, Ljava/lang/Long;->hashCode(J)I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 16

    .line 1
    iget-wide v0, p0, Lkf0;->a:J

    .line 2
    .line 3
    const-wide/16 v2, 0x0

    .line 4
    .line 5
    cmp-long p0, v0, v2

    .line 6
    .line 7
    if-nez p0, :cond_b

    .line 8
    .line 9
    const-string p0, "0s"

    .line 10
    .line 11
    return-object p0

    .line 12
    :cond_b
    sget-wide v4, Lkf0;->c:J

    .line 13
    .line 14
    cmp-long v4, v0, v4

    .line 15
    .line 16
    if-nez v4, :cond_14

    .line 17
    .line 18
    const-string p0, "Infinity"

    .line 19
    .line 20
    return-object p0

    .line 21
    :cond_14
    sget-wide v4, Lkf0;->d:J

    .line 22
    .line 23
    cmp-long v4, v0, v4

    .line 24
    .line 25
    if-nez v4, :cond_1d

    .line 26
    .line 27
    const-string p0, "-Infinity"

    .line 28
    .line 29
    return-object p0

    .line 30
    :cond_1d
    const/4 v4, 0x0

    .line 31
    const/4 v5, 0x1

    .line 32
    if-gez p0, :cond_23

    .line 33
    .line 34
    move v6, v5

    .line 35
    goto :goto_24

    .line 36
    :cond_23
    move v6, v4

    .line 37
    :goto_24
    new-instance v7, Ljava/lang/StringBuilder;

    .line 38
    .line 39
    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    .line 40
    .line 41
    .line 42
    if-eqz v6, :cond_30

    .line 43
    .line 44
    const/16 v8, 0x2d

    .line 45
    .line 46
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 47
    .line 48
    .line 49
    :cond_30
    if-gez p0, :cond_3d

    .line 50
    .line 51
    shr-long v8, v0, v5

    .line 52
    .line 53
    neg-long v8, v8

    .line 54
    long-to-int p0, v0

    .line 55
    and-int/2addr p0, v5

    .line 56
    shl-long v0, v8, v5

    .line 57
    .line 58
    int-to-long v8, p0

    .line 59
    add-long/2addr v0, v8

    .line 60
    sget p0, Llf0;->a:I

    .line 61
    .line 62
    :cond_3d
    sget-object p0, Lnf0;->g:Lnf0;

    .line 63
    .line 64
    invoke-static {v0, v1, p0}, Lkf0;->f(JLnf0;)J

    .line 65
    .line 66
    .line 67
    move-result-wide v8

    .line 68
    invoke-static {v0, v1}, Lkf0;->d(J)Z

    .line 69
    .line 70
    .line 71
    move-result p0

    .line 72
    if-eqz p0, :cond_4b

    .line 73
    .line 74
    move p0, v4

    .line 75
    goto :goto_55

    .line 76
    :cond_4b
    sget-object p0, Lnf0;->f:Lnf0;

    .line 77
    .line 78
    invoke-static {v0, v1, p0}, Lkf0;->f(JLnf0;)J

    .line 79
    .line 80
    .line 81
    move-result-wide v10

    .line 82
    const-wide/16 v12, 0x18

    .line 83
    .line 84
    rem-long/2addr v10, v12

    .line 85
    long-to-int p0, v10

    .line 86
    :goto_55
    invoke-static {v0, v1}, Lkf0;->d(J)Z

    .line 87
    .line 88
    .line 89
    move-result v10

    .line 90
    const-wide/16 v11, 0x3c

    .line 91
    .line 92
    if-eqz v10, :cond_5f

    .line 93
    .line 94
    move v10, v4

    .line 95
    goto :goto_67

    .line 96
    :cond_5f
    sget-object v10, Lnf0;->e:Lnf0;

    .line 97
    .line 98
    invoke-static {v0, v1, v10}, Lkf0;->f(JLnf0;)J

    .line 99
    .line 100
    .line 101
    move-result-wide v13

    .line 102
    rem-long/2addr v13, v11

    .line 103
    long-to-int v10, v13

    .line 104
    :goto_67
    invoke-static {v0, v1}, Lkf0;->d(J)Z

    .line 105
    .line 106
    .line 107
    move-result v13

    .line 108
    if-eqz v13, :cond_6f

    .line 109
    .line 110
    move v11, v4

    .line 111
    goto :goto_77

    .line 112
    :cond_6f
    sget-object v13, Lnf0;->d:Lnf0;

    .line 113
    .line 114
    invoke-static {v0, v1, v13}, Lkf0;->f(JLnf0;)J

    .line 115
    .line 116
    .line 117
    move-result-wide v13

    .line 118
    rem-long/2addr v13, v11

    .line 119
    long-to-int v11, v13

    .line 120
    :goto_77
    invoke-static {v0, v1}, Lkf0;->c(J)I

    .line 121
    .line 122
    .line 123
    move-result v0

    .line 124
    cmp-long v1, v8, v2

    .line 125
    .line 126
    if-eqz v1, :cond_81

    .line 127
    .line 128
    move v1, v5

    .line 129
    goto :goto_82

    .line 130
    :cond_81
    move v1, v4

    .line 131
    :goto_82
    if-eqz p0, :cond_86

    .line 132
    .line 133
    move v2, v5

    .line 134
    goto :goto_87

    .line 135
    :cond_86
    move v2, v4

    .line 136
    :goto_87
    if-eqz v10, :cond_8b

    .line 137
    .line 138
    move v3, v5

    .line 139
    goto :goto_8c

    .line 140
    :cond_8b
    move v3, v4

    .line 141
    :goto_8c
    if-nez v11, :cond_93

    .line 142
    .line 143
    if-eqz v0, :cond_91

    .line 144
    .line 145
    goto :goto_93

    .line 146
    :cond_91
    move v12, v4

    .line 147
    goto :goto_94

    .line 148
    :cond_93
    :goto_93
    move v12, v5

    .line 149
    :goto_94
    if-eqz v1, :cond_9f

    .line 150
    .line 151
    invoke-virtual {v7, v8, v9}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 152
    .line 153
    .line 154
    const/16 v4, 0x64

    .line 155
    .line 156
    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 157
    .line 158
    .line 159
    move v4, v5

    .line 160
    :cond_9f
    const/16 v8, 0x20

    .line 161
    .line 162
    if-nez v2, :cond_a9

    .line 163
    .line 164
    if-eqz v1, :cond_b9

    .line 165
    .line 166
    if-nez v3, :cond_a9

    .line 167
    .line 168
    if-eqz v12, :cond_b9

    .line 169
    .line 170
    :cond_a9
    add-int/lit8 v9, v4, 0x1

    .line 171
    .line 172
    if-lez v4, :cond_b0

    .line 173
    .line 174
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 175
    .line 176
    .line 177
    :cond_b0
    invoke-virtual {v7, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 178
    .line 179
    .line 180
    const/16 p0, 0x68

    .line 181
    .line 182
    invoke-virtual {v7, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 183
    .line 184
    .line 185
    move v4, v9

    .line 186
    :cond_b9
    if-nez v3, :cond_c1

    .line 187
    .line 188
    if-eqz v12, :cond_d1

    .line 189
    .line 190
    if-nez v2, :cond_c1

    .line 191
    .line 192
    if-eqz v1, :cond_d1

    .line 193
    .line 194
    :cond_c1
    add-int/lit8 p0, v4, 0x1

    .line 195
    .line 196
    if-lez v4, :cond_c8

    .line 197
    .line 198
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 199
    .line 200
    .line 201
    :cond_c8
    invoke-virtual {v7, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 202
    .line 203
    .line 204
    const/16 v4, 0x6d

    .line 205
    .line 206
    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 207
    .line 208
    .line 209
    move v4, p0

    .line 210
    :cond_d1
    if-eqz v12, :cond_118

    .line 211
    .line 212
    add-int/lit8 p0, v4, 0x1

    .line 213
    .line 214
    if-lez v4, :cond_da

    .line 215
    .line 216
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 217
    .line 218
    .line 219
    :cond_da
    if-nez v11, :cond_e2

    .line 220
    .line 221
    if-nez v1, :cond_e2

    .line 222
    .line 223
    if-nez v2, :cond_e2

    .line 224
    .line 225
    if-eqz v3, :cond_e4

    .line 226
    .line 227
    :cond_e2
    move v8, v11

    .line 228
    goto :goto_10e

    .line 229
    :cond_e4
    const v1, 0xf4240

    .line 230
    .line 231
    .line 232
    if-lt v0, v1, :cond_f5

    .line 233
    .line 234
    div-int v8, v0, v1

    .line 235
    .line 236
    rem-int v9, v0, v1

    .line 237
    .line 238
    const-string v11, "ms"

    .line 239
    .line 240
    const/4 v12, 0x0

    .line 241
    const/4 v10, 0x6

    .line 242
    invoke-static/range {v7 .. v12}, Lkf0;->b(Ljava/lang/StringBuilder;IIILjava/lang/String;Z)V

    .line 243
    .line 244
    .line 245
    goto :goto_117

    .line 246
    :cond_f5
    const/16 v1, 0x3e8

    .line 247
    .line 248
    if-lt v0, v1, :cond_105

    .line 249
    .line 250
    div-int/lit16 v8, v0, 0x3e8

    .line 251
    .line 252
    rem-int/lit16 v9, v0, 0x3e8

    .line 253
    .line 254
    const-string v11, "us"

    .line 255
    .line 256
    const/4 v12, 0x0

    .line 257
    const/4 v10, 0x3

    .line 258
    invoke-static/range {v7 .. v12}, Lkf0;->b(Ljava/lang/StringBuilder;IIILjava/lang/String;Z)V

    .line 259
    .line 260
    .line 261
    goto :goto_117

    .line 262
    :cond_105
    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 263
    .line 264
    .line 265
    const-string v0, "ns"

    .line 266
    .line 267
    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 268
    .line 269
    .line 270
    goto :goto_117

    .line 271
    :goto_10e
    const-string v11, "s"

    .line 272
    .line 273
    const/4 v12, 0x0

    .line 274
    const/16 v10, 0x9

    .line 275
    .line 276
    move v9, v0

    .line 277
    invoke-static/range {v7 .. v12}, Lkf0;->b(Ljava/lang/StringBuilder;IIILjava/lang/String;Z)V

    .line 278
    .line 279
    .line 280
    :goto_117
    move v4, p0

    .line 281
    :cond_118
    if-eqz v6, :cond_127

    .line 282
    .line 283
    if-le v4, v5, :cond_127

    .line 284
    .line 285
    const/16 p0, 0x28

    .line 286
    .line 287
    invoke-virtual {v7, v5, p0}, Ljava/lang/StringBuilder;->insert(IC)Ljava/lang/StringBuilder;

    .line 288
    .line 289
    .line 290
    move-result-object p0

    .line 291
    const/16 v0, 0x29

    .line 292
    .line 293
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 294
    .line 295
    .line 296
    :cond_127
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 297
    .line 298
    .line 299
    move-result-object p0

    .line 300
    return-object p0
.end method
