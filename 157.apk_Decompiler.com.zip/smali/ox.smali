###### Class defpackage.ox (ox)
.class public interface abstract Lox;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# virtual methods
.method public abstract a(Lwk2;)V
.end method

.method public abstract d(Lwk2;)Z
.end method

.method public abstract m(Lwk2;ILif1;Ljava/lang/Object;)V
.end method
