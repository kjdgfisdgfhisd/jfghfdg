###### Class defpackage.v12 (v12)
.class public interface abstract Lv12;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# virtual methods
.method public abstract m(Lxt1;Lbc0;)Z
.end method
