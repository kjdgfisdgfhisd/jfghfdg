###### Class defpackage.ys2 (ys2)
.class public final Lys2;
.super Lbt2;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final c:I


# direct methods
.method public constructor <init>(ILjava/lang/Class;)V
    .registers 4

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, v0, p2}, Lbt2;-><init>(ILjava/lang/Class;)V

    .line 3
    .line 4
    .line 5
    iput p1, p0, Lys2;->c:I

    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Lt71;Lfl2;)V
    .registers 14

    .line 1
    iget p0, p0, Lys2;->c:I

    .line 2
    .line 3
    packed-switch p0, :pswitch_data_158

    .line 4
    .line 5
    .line 6
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    invoke-virtual {p2, p0}, Lt71;->D(Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :pswitch_d
    iget-object p0, p3, Lfl2;->a:Lbl2;

    .line 15
    .line 16
    iget-object p0, p0, Lvo1;->b:Lpi;

    .line 17
    .line 18
    iget-object p0, p0, Lpi;->g:Lxh;

    .line 19
    .line 20
    check-cast p1, [B

    .line 21
    .line 22
    iget-object p3, p0, Lxh;->b:[C

    .line 23
    .line 24
    iget v0, p0, Lxh;->f:I

    .line 25
    .line 26
    array-length v1, p1

    .line 27
    new-instance v2, Ljava/lang/StringBuilder;

    .line 28
    .line 29
    shr-int/lit8 v3, v1, 0x2

    .line 30
    .line 31
    add-int/2addr v3, v1

    .line 32
    shr-int/lit8 v4, v1, 0x3

    .line 33
    .line 34
    add-int/2addr v3, v4

    .line 35
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 36
    .line 37
    .line 38
    const/4 v3, 0x2

    .line 39
    shr-int/2addr v0, v3

    .line 40
    add-int/lit8 v4, v1, -0x3

    .line 41
    .line 42
    const/4 v5, 0x0

    .line 43
    :goto_2a
    move v6, v0

    .line 44
    :cond_2b
    if-gt v5, v4, :cond_6f

    .line 45
    .line 46
    add-int/lit8 v7, v5, 0x1

    .line 47
    .line 48
    aget-byte v8, p1, v5

    .line 49
    .line 50
    shl-int/lit8 v8, v8, 0x8

    .line 51
    .line 52
    add-int/lit8 v9, v5, 0x2

    .line 53
    .line 54
    aget-byte v7, p1, v7

    .line 55
    .line 56
    and-int/lit16 v7, v7, 0xff

    .line 57
    .line 58
    or-int/2addr v7, v8

    .line 59
    shl-int/lit8 v7, v7, 0x8

    .line 60
    .line 61
    add-int/lit8 v5, v5, 0x3

    .line 62
    .line 63
    aget-byte v8, p1, v9

    .line 64
    .line 65
    and-int/lit16 v8, v8, 0xff

    .line 66
    .line 67
    or-int/2addr v7, v8

    .line 68
    shr-int/lit8 v8, v7, 0x12

    .line 69
    .line 70
    and-int/lit8 v8, v8, 0x3f

    .line 71
    .line 72
    aget-char v8, p3, v8

    .line 73
    .line 74
    invoke-virtual {v2, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 75
    .line 76
    .line 77
    shr-int/lit8 v8, v7, 0xc

    .line 78
    .line 79
    and-int/lit8 v8, v8, 0x3f

    .line 80
    .line 81
    aget-char v8, p3, v8

    .line 82
    .line 83
    invoke-virtual {v2, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 84
    .line 85
    .line 86
    shr-int/lit8 v8, v7, 0x6

    .line 87
    .line 88
    and-int/lit8 v8, v8, 0x3f

    .line 89
    .line 90
    aget-char v8, p3, v8

    .line 91
    .line 92
    invoke-virtual {v2, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 93
    .line 94
    .line 95
    and-int/lit8 v7, v7, 0x3f

    .line 96
    .line 97
    aget-char v7, p3, v7

    .line 98
    .line 99
    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 100
    .line 101
    .line 102
    add-int/lit8 v6, v6, -0x1

    .line 103
    .line 104
    if-gtz v6, :cond_2b

    .line 105
    .line 106
    const-string v6, "\\n"

    .line 107
    .line 108
    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 109
    .line 110
    .line 111
    goto :goto_2a

    .line 112
    :cond_6f
    sub-int/2addr v1, v5

    .line 113
    if-lez v1, :cond_b5

    .line 114
    .line 115
    add-int/lit8 v0, v5, 0x1

    .line 116
    .line 117
    aget-byte v4, p1, v5

    .line 118
    .line 119
    shl-int/lit8 v4, v4, 0x10

    .line 120
    .line 121
    if-ne v1, v3, :cond_81

    .line 122
    .line 123
    aget-byte p1, p1, v0

    .line 124
    .line 125
    and-int/lit16 p1, p1, 0xff

    .line 126
    .line 127
    shl-int/lit8 p1, p1, 0x8

    .line 128
    .line 129
    or-int/2addr v4, p1

    .line 130
    :cond_81
    iget-char p1, p0, Lxh;->e:C

    .line 131
    .line 132
    shr-int/lit8 v0, v4, 0x12

    .line 133
    .line 134
    and-int/lit8 v0, v0, 0x3f

    .line 135
    .line 136
    aget-char v0, p3, v0

    .line 137
    .line 138
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 139
    .line 140
    .line 141
    shr-int/lit8 v0, v4, 0xc

    .line 142
    .line 143
    and-int/lit8 v0, v0, 0x3f

    .line 144
    .line 145
    aget-char v0, p3, v0

    .line 146
    .line 147
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 148
    .line 149
    .line 150
    iget-boolean p0, p0, Lxh;->g:Z

    .line 151
    .line 152
    if-eqz p0, :cond_aa

    .line 153
    .line 154
    if-ne v1, v3, :cond_a2

    .line 155
    .line 156
    shr-int/lit8 p0, v4, 0x6

    .line 157
    .line 158
    and-int/lit8 p0, p0, 0x3f

    .line 159
    .line 160
    aget-char p0, p3, p0

    .line 161
    .line 162
    goto :goto_a3

    .line 163
    :cond_a2
    move p0, p1

    .line 164
    :goto_a3
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 165
    .line 166
    .line 167
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 168
    .line 169
    .line 170
    goto :goto_b5

    .line 171
    :cond_aa
    if-ne v1, v3, :cond_b5

    .line 172
    .line 173
    shr-int/lit8 p0, v4, 0x6

    .line 174
    .line 175
    and-int/lit8 p0, p0, 0x3f

    .line 176
    .line 177
    aget-char p0, p3, p0

    .line 178
    .line 179
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 180
    .line 181
    .line 182
    :cond_b5
    :goto_b5
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 183
    .line 184
    .line 185
    move-result-object p0

    .line 186
    invoke-virtual {p2, p0}, Lt71;->D(Ljava/lang/String;)V

    .line 187
    .line 188
    .line 189
    return-void

    .line 190
    :pswitch_bd
    check-cast p1, Ljava/lang/Number;

    .line 191
    .line 192
    invoke-virtual {p1}, Ljava/lang/Number;->longValue()J

    .line 193
    .line 194
    .line 195
    move-result-wide p0

    .line 196
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 197
    .line 198
    .line 199
    invoke-static {p0, p1}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    .line 200
    .line 201
    .line 202
    move-result-object p0

    .line 203
    invoke-virtual {p2, p0}, Lt71;->D(Ljava/lang/String;)V

    .line 204
    .line 205
    .line 206
    return-void

    .line 207
    :pswitch_ce
    sget-object p0, Lcl2;->r:Lcl2;

    .line 208
    .line 209
    iget-object v0, p3, Lfl2;->a:Lbl2;

    .line 210
    .line 211
    invoke-virtual {v0, p0}, Lbl2;->i(Lcl2;)Z

    .line 212
    .line 213
    .line 214
    move-result p0

    .line 215
    if-eqz p0, :cond_dd

    .line 216
    .line 217
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 218
    .line 219
    .line 220
    move-result-object p0

    .line 221
    goto :goto_f6

    .line 222
    :cond_dd
    check-cast p1, Ljava/lang/Enum;

    .line 223
    .line 224
    sget-object p0, Lcl2;->t:Lcl2;

    .line 225
    .line 226
    iget-object p3, p3, Lfl2;->a:Lbl2;

    .line 227
    .line 228
    invoke-virtual {p3, p0}, Lbl2;->i(Lcl2;)Z

    .line 229
    .line 230
    .line 231
    move-result p0

    .line 232
    if-eqz p0, :cond_f2

    .line 233
    .line 234
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 235
    .line 236
    .line 237
    move-result p0

    .line 238
    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 239
    .line 240
    .line 241
    move-result-object p0

    .line 242
    goto :goto_f6

    .line 243
    :cond_f2
    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 244
    .line 245
    .line 246
    move-result-object p0

    .line 247
    :goto_f6
    invoke-virtual {p2, p0}, Lt71;->D(Ljava/lang/String;)V

    .line 248
    .line 249
    .line 250
    return-void

    .line 251
    :pswitch_fa
    check-cast p1, Ljava/lang/Class;

    .line 252
    .line 253
    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 254
    .line 255
    .line 256
    move-result-object p0

    .line 257
    invoke-virtual {p2, p0}, Lt71;->D(Ljava/lang/String;)V

    .line 258
    .line 259
    .line 260
    return-void

    .line 261
    :pswitch_104
    check-cast p1, Ljava/util/Calendar;

    .line 262
    .line 263
    invoke-virtual {p1}, Ljava/util/Calendar;->getTimeInMillis()J

    .line 264
    .line 265
    .line 266
    move-result-wide p0

    .line 267
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 268
    .line 269
    .line 270
    sget-object v0, Lcl2;->p:Lcl2;

    .line 271
    .line 272
    iget-object v1, p3, Lfl2;->a:Lbl2;

    .line 273
    .line 274
    invoke-virtual {v1, v0}, Lbl2;->i(Lcl2;)Z

    .line 275
    .line 276
    .line 277
    move-result v0

    .line 278
    if-eqz v0, :cond_11f

    .line 279
    .line 280
    invoke-static {p0, p1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 281
    .line 282
    .line 283
    move-result-object p0

    .line 284
    invoke-virtual {p2, p0}, Lt71;->D(Ljava/lang/String;)V

    .line 285
    .line 286
    .line 287
    return-void

    .line 288
    :cond_11f
    invoke-virtual {p3}, Lfl2;->d()Ljava/text/DateFormat;

    .line 289
    .line 290
    .line 291
    move-result-object p3

    .line 292
    new-instance v0, Ljava/util/Date;

    .line 293
    .line 294
    invoke-direct {v0, p0, p1}, Ljava/util/Date;-><init>(J)V

    .line 295
    .line 296
    .line 297
    invoke-virtual {p3, v0}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    .line 298
    .line 299
    .line 300
    move-result-object p0

    .line 301
    invoke-virtual {p2, p0}, Lt71;->D(Ljava/lang/String;)V

    .line 302
    .line 303
    .line 304
    return-void

    .line 305
    :pswitch_130
    check-cast p1, Ljava/util/Date;

    .line 306
    .line 307
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 308
    .line 309
    .line 310
    sget-object p0, Lcl2;->p:Lcl2;

    .line 311
    .line 312
    iget-object v0, p3, Lfl2;->a:Lbl2;

    .line 313
    .line 314
    invoke-virtual {v0, p0}, Lbl2;->i(Lcl2;)Z

    .line 315
    .line 316
    .line 317
    move-result p0

    .line 318
    if-eqz p0, :cond_14b

    .line 319
    .line 320
    invoke-virtual {p1}, Ljava/util/Date;->getTime()J

    .line 321
    .line 322
    .line 323
    move-result-wide p0

    .line 324
    invoke-static {p0, p1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 325
    .line 326
    .line 327
    move-result-object p0

    .line 328
    invoke-virtual {p2, p0}, Lt71;->D(Ljava/lang/String;)V

    .line 329
    .line 330
    .line 331
    return-void

    .line 332
    :cond_14b
    invoke-virtual {p3}, Lfl2;->d()Ljava/text/DateFormat;

    .line 333
    .line 334
    .line 335
    move-result-object p0

    .line 336
    invoke-virtual {p0, p1}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    .line 337
    .line 338
    .line 339
    move-result-object p0

    .line 340
    invoke-virtual {p2, p0}, Lt71;->D(Ljava/lang/String;)V

    .line 341
    .line 342
    .line 343
    return-void

    .line 344
    nop

    .line 345
    :pswitch_data_158
    .packed-switch 0x1
        :pswitch_130
        :pswitch_104
        :pswitch_fa
        :pswitch_ce
        :pswitch_bd
        :pswitch_bd
        :pswitch_d
    .end packed-switch
.end method
