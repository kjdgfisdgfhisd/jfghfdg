###### Class defpackage.dr3 (dr3)
.class public final Ldr3;
.super Lov3;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field private static final zzc:Ldr3;

.field private static volatile zzd:Lvw3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lvw3;"
        }
    .end annotation
.end field


# instance fields
.field private zze:I

.field private zzf:I

.field private zzg:Lsr3;

.field private zzh:Lsr3;

.field private zzi:Z


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Ldr3;

    .line 2
    .line 3
    invoke-direct {v0}, Lov3;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Ldr3;->zzc:Ldr3;

    .line 7
    .line 8
    const-class v1, Ldr3;

    .line 9
    .line 10
    invoke-static {v1, v0}, Lov3;->f(Ljava/lang/Class;Lov3;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public static synthetic n(Ldr3;I)V
    .registers 3

    .line 1
    iget v0, p0, Ldr3;->zze:I

    .line 2
    .line 3
    or-int/lit8 v0, v0, 0x1

    .line 4
    .line 5
    iput v0, p0, Ldr3;->zze:I

    .line 6
    .line 7
    iput p1, p0, Ldr3;->zzf:I

    .line 8
    .line 9
    return-void
.end method

.method public static synthetic o(Ldr3;Lsr3;)V
    .registers 2

    .line 1
    iput-object p1, p0, Ldr3;->zzg:Lsr3;

    .line 2
    .line 3
    iget p1, p0, Ldr3;->zze:I

    .line 4
    .line 5
    or-int/lit8 p1, p1, 0x2

    .line 6
    .line 7
    iput p1, p0, Ldr3;->zze:I

    .line 8
    .line 9
    return-void
.end method

.method public static synthetic p(Ldr3;Z)V
    .registers 3

    .line 1
    iget v0, p0, Ldr3;->zze:I

    .line 2
    .line 3
    or-int/lit8 v0, v0, 0x8

    .line 4
    .line 5
    iput v0, p0, Ldr3;->zze:I

    .line 6
    .line 7
    iput-boolean p1, p0, Ldr3;->zzi:Z

    .line 8
    .line 9
    return-void
.end method

.method public static q()Lcr3;
    .registers 1

    .line 1
    sget-object v0, Ldr3;->zzc:Ldr3;

    .line 2
    .line 3
    invoke-virtual {v0}, Lov3;->h()Lmv3;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lcr3;

    .line 8
    .line 9
    return-object v0
.end method

.method public static synthetic r(Ldr3;Lsr3;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Ldr3;->zzh:Lsr3;

    .line 5
    .line 6
    iget p1, p0, Ldr3;->zze:I

    .line 7
    .line 8
    or-int/lit8 p1, p1, 0x4

    .line 9
    .line 10
    iput p1, p0, Ldr3;->zze:I

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final c(I)Ljava/lang/Object;
    .registers 5

    .line 1
    sget-object p0, Lwq3;->a:[I

    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    sub-int/2addr p1, v0

    .line 5
    aget p0, p0, p1

    .line 6
    .line 7
    const/4 p1, 0x0

    .line 8
    packed-switch p0, :pswitch_data_58

    .line 9
    .line 10
    .line 11
    invoke-static {}, Lvn0;->n()V

    .line 12
    .line 13
    .line 14
    :pswitch_d
    return-object p1

    .line 15
    :pswitch_e
    invoke-static {v0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    return-object p0

    .line 20
    :pswitch_13
    sget-object p0, Ldr3;->zzd:Lvw3;

    .line 21
    .line 22
    if-nez p0, :cond_2e

    .line 23
    .line 24
    const-class p1, Ldr3;

    .line 25
    .line 26
    monitor-enter p1

    .line 27
    :try_start_1a
    sget-object p0, Ldr3;->zzd:Lvw3;

    .line 28
    .line 29
    if-nez p0, :cond_2a

    .line 30
    .line 31
    new-instance p0, Lap3;

    .line 32
    .line 33
    const/16 v0, 0xc

    .line 34
    .line 35
    invoke-direct {p0, v0}, Lap3;-><init>(I)V

    .line 36
    .line 37
    .line 38
    sput-object p0, Ldr3;->zzd:Lvw3;

    .line 39
    .line 40
    goto :goto_2a

    .line 41
    :catchall_28
    move-exception p0

    .line 42
    goto :goto_2c

    .line 43
    :cond_2a
    :goto_2a
    monitor-exit p1

    .line 44
    return-object p0

    .line 45
    :goto_2c
    monitor-exit p1
    :try_end_2d
    .catchall {:try_start_1a .. :try_end_2d} :catchall_28

    .line 46
    throw p0

    .line 47
    :cond_2e
    return-object p0

    .line 48
    :pswitch_2f
    sget-object p0, Ldr3;->zzc:Ldr3;

    .line 49
    .line 50
    return-object p0

    .line 51
    :pswitch_32
    const-string p0, "zze"

    .line 52
    .line 53
    const-string p1, "zzf"

    .line 54
    .line 55
    const-string v0, "zzg"

    .line 56
    .line 57
    const-string v1, "zzh"

    .line 58
    .line 59
    const-string v2, "zzi"

    .line 60
    .line 61
    filled-new-array {p0, p1, v0, v1, v2}, [Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object p0

    .line 65
    const-string p1, "\u0004\u0004\u0000\u0001\u0001\u0004\u0004\u0000\u0000\u0000\u0001\u1004\u0000\u0002\u1009\u0001\u0003\u1009\u0002\u0004\u1007\u0003"

    .line 66
    .line 67
    sget-object v0, Ldr3;->zzc:Ldr3;

    .line 68
    .line 69
    new-instance v1, Lcx3;

    .line 70
    .line 71
    invoke-direct {v1, v0, p1, p0}, Lcx3;-><init>(Leu3;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 72
    .line 73
    .line 74
    return-object v1

    .line 75
    :pswitch_4a
    new-instance p0, Lcr3;

    .line 76
    .line 77
    sget-object p1, Ldr3;->zzc:Ldr3;

    .line 78
    .line 79
    invoke-direct {p0, p1}, Lmv3;-><init>(Lov3;)V

    .line 80
    .line 81
    .line 82
    return-object p0

    .line 83
    :pswitch_52
    new-instance p0, Ldr3;

    .line 84
    .line 85
    invoke-direct {p0}, Lov3;-><init>()V

    .line 86
    .line 87
    .line 88
    return-object p0

    .line 89
    :pswitch_data_58
    .packed-switch 0x1
        :pswitch_52
        :pswitch_4a
        :pswitch_32
        :pswitch_2f
        :pswitch_13
        :pswitch_e
        :pswitch_d
    .end packed-switch
.end method

.method public final m()I
    .registers 1

    .line 1
    iget p0, p0, Ldr3;->zzf:I

    .line 2
    .line 3
    return p0
.end method

.method public final s()Lsr3;
    .registers 1

    .line 1
    iget-object p0, p0, Ldr3;->zzg:Lsr3;

    .line 2
    .line 3
    if-nez p0, :cond_8

    .line 4
    .line 5
    invoke-static {}, Lsr3;->z()Lsr3;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    :cond_8
    return-object p0
.end method

.method public final t()Lsr3;
    .registers 1

    .line 1
    iget-object p0, p0, Ldr3;->zzh:Lsr3;

    .line 2
    .line 3
    if-nez p0, :cond_8

    .line 4
    .line 5
    invoke-static {}, Lsr3;->z()Lsr3;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    :cond_8
    return-object p0
.end method

.method public final u()Z
    .registers 1

    .line 1
    iget-boolean p0, p0, Ldr3;->zzi:Z

    .line 2
    .line 3
    return p0
.end method

.method public final v()Z
    .registers 2

    .line 1
    iget p0, p0, Ldr3;->zze:I

    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    and-int/2addr p0, v0

    .line 5
    if-eqz p0, :cond_7

    .line 6
    .line 7
    return v0

    .line 8
    :cond_7
    const/4 p0, 0x0

    .line 9
    return p0
.end method

.method public final w()Z
    .registers 1

    .line 1
    iget p0, p0, Ldr3;->zze:I

    .line 2
    .line 3
    and-int/lit8 p0, p0, 0x8

    .line 4
    .line 5
    if-eqz p0, :cond_8

    .line 6
    .line 7
    const/4 p0, 0x1

    .line 8
    return p0

    .line 9
    :cond_8
    const/4 p0, 0x0

    .line 10
    return p0
.end method

.method public final x()Z
    .registers 1

    .line 1
    iget p0, p0, Ldr3;->zze:I

    .line 2
    .line 3
    and-int/lit8 p0, p0, 0x4

    .line 4
    .line 5
    if-eqz p0, :cond_8

    .line 6
    .line 7
    const/4 p0, 0x1

    .line 8
    return p0

    .line 9
    :cond_8
    const/4 p0, 0x0

    .line 10
    return p0
.end method
