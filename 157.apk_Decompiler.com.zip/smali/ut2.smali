###### Class defpackage.ut2 (ut2)
.class public final Lut2;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lif1;


# static fields
.field public static final a:Lut2;

.field public static final b:Lc42;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    new-instance v0, Lut2;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lut2;->a:Lut2;

    .line 7
    .line 8
    new-instance v0, Lc42;

    .line 9
    .line 10
    const-string v1, "kotlin.String"

    .line 11
    .line 12
    sget-object v2, La42;->q:La42;

    .line 13
    .line 14
    invoke-direct {v0, v1, v2}, Lc42;-><init>(Ljava/lang/String;La42;)V

    .line 15
    .line 16
    .line 17
    sput-object v0, Lut2;->b:Lc42;

    .line 18
    .line 19
    return-void
.end method


# virtual methods
.method public final deserialize(Lz60;)Ljava/lang/Object;
    .registers 2

    .line 1
    invoke-interface {p1}, Lz60;->z()Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public final getDescriptor()Lwk2;
    .registers 1

    .line 1
    sget-object p0, Lut2;->b:Lc42;

    .line 2
    .line 3
    return-object p0
.end method

.method public final serialize(Lbi0;Ljava/lang/Object;)V
    .registers 3

    .line 1
    check-cast p2, Ljava/lang/String;

    .line 2
    .line 3
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-interface {p1, p2}, Lbi0;->p(Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method
