###### Class defpackage.dh2 (dh2)
.class public final Ldh2;
.super Ljl1;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final l:Landroidx/work/impl/WorkDatabase_Impl;

.field public final m:Leh0;

.field public final n:Lgh2;

.field public final o:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public final p:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public final q:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public final r:Lr10;

.field public final s:Lja2;


# direct methods
.method public constructor <init>(Landroidx/work/impl/WorkDatabase_Impl;Leh0;[Ljava/lang/String;Lja2;)V
    .registers 5

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljl1;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Ldh2;->l:Landroidx/work/impl/WorkDatabase_Impl;

    .line 8
    .line 9
    iput-object p2, p0, Ldh2;->m:Leh0;

    .line 10
    .line 11
    new-instance p2, Lgh2;

    .line 12
    .line 13
    invoke-direct {p2, p3, p0}, Lgh2;-><init>([Ljava/lang/String;Ldh2;)V

    .line 14
    .line 15
    .line 16
    iput-object p2, p0, Ldh2;->n:Lgh2;

    .line 17
    .line 18
    new-instance p2, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 19
    .line 20
    const/4 p3, 0x1

    .line 21
    invoke-direct {p2, p3}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 22
    .line 23
    .line 24
    iput-object p2, p0, Ldh2;->o:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 25
    .line 26
    new-instance p2, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 27
    .line 28
    const/4 p3, 0x0

    .line 29
    invoke-direct {p2, p3}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 30
    .line 31
    .line 32
    iput-object p2, p0, Ldh2;->p:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 33
    .line 34
    new-instance p2, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 35
    .line 36
    invoke-direct {p2, p3}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 37
    .line 38
    .line 39
    iput-object p2, p0, Ldh2;->q:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 40
    .line 41
    invoke-virtual {p1}, Lch2;->k()Z

    .line 42
    .line 43
    .line 44
    move-result p2

    .line 45
    if-eqz p2, :cond_3c

    .line 46
    .line 47
    iget-object p1, p1, Lch2;->a:Lt00;

    .line 48
    .line 49
    if-eqz p1, :cond_35

    .line 50
    .line 51
    iget-object p1, p1, Lt00;->a:Lr10;

    .line 52
    .line 53
    goto :goto_3e

    .line 54
    :cond_35
    const-string p0, "coroutineScope"

    .line 55
    .line 56
    invoke-static {p0}, Ld31;->A(Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    const/4 p0, 0x0

    .line 60
    throw p0

    .line 61
    :cond_3c
    sget-object p1, Lrh0;->a:Lrh0;

    .line 62
    .line 63
    :goto_3e
    iput-object p1, p0, Ldh2;->r:Lr10;

    .line 64
    .line 65
    iput-object p4, p0, Ldh2;->s:Lja2;

    .line 66
    .line 67
    return-void
.end method


# virtual methods
.method public final g()V
    .registers 5

    .line 1
    iget-object v0, p0, Ldh2;->m:Leh0;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    iget-object v0, v0, Leh0;->c:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Ljava/util/Set;

    .line 9
    .line 10
    invoke-interface {v0, p0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 11
    .line 12
    .line 13
    iget-object v0, p0, Ldh2;->l:Landroidx/work/impl/WorkDatabase_Impl;

    .line 14
    .line 15
    invoke-virtual {v0}, Lch2;->f()La20;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    new-instance v1, Lfh2;

    .line 20
    .line 21
    const/4 v2, 0x1

    .line 22
    const/4 v3, 0x0

    .line 23
    invoke-direct {v1, p0, v3, v2}, Lfh2;-><init>(Ldh2;Lw00;I)V

    .line 24
    .line 25
    .line 26
    const/4 v2, 0x2

    .line 27
    iget-object p0, p0, Ldh2;->r:Lr10;

    .line 28
    .line 29
    invoke-static {v0, p0, v3, v1, v2}, Lia1;->t(La20;Lr10;Ld20;Ltt0;I)Llr2;

    .line 30
    .line 31
    .line 32
    return-void
.end method

.method public final h()V
    .registers 2

    .line 1
    iget-object v0, p0, Ldh2;->m:Leh0;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    iget-object v0, v0, Leh0;->c:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Ljava/util/Set;

    .line 9
    .line 10
    invoke-interface {v0, p0}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public final l(Ly00;)Ljava/lang/Object;
    .registers 13

    .line 1
    instance-of v0, p1, Lhh2;

    .line 2
    .line 3
    if-eqz v0, :cond_13

    .line 4
    .line 5
    move-object v0, p1

    .line 6
    check-cast v0, Lhh2;

    .line 7
    .line 8
    iget v1, v0, Lhh2;->o:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_13

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lhh2;->o:I

    .line 18
    .line 19
    goto :goto_18

    .line 20
    :cond_13
    new-instance v0, Lhh2;

    .line 21
    .line 22
    invoke-direct {v0, p0, p1}, Lhh2;-><init>(Ldh2;Ly00;)V

    .line 23
    .line 24
    .line 25
    :goto_18
    iget-object p1, v0, Lhh2;->m:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, Lhh2;->o:I

    .line 28
    .line 29
    const/4 v2, 0x0

    .line 30
    const/4 v3, 0x0

    .line 31
    const/4 v4, 0x1

    .line 32
    if-eqz v1, :cond_38

    .line 33
    .line 34
    if-ne v1, v4, :cond_32

    .line 35
    .line 36
    iget p0, v0, Lhh2;->l:I

    .line 37
    .line 38
    iget-object v1, v0, Lhh2;->j:Ldh2;

    .line 39
    .line 40
    :try_start_27
    invoke-static {p1}, Lh23;->t(Ljava/lang/Object;)V
    :try_end_2a
    .catch Ljava/lang/Exception; {:try_start_27 .. :try_end_2a} :catch_2f
    .catchall {:try_start_27 .. :try_end_2a} :catchall_2c

    .line 41
    .line 42
    .line 43
    goto/16 :goto_ae

    .line 44
    .line 45
    :catchall_2c
    move-exception p0

    .line 46
    goto/16 :goto_de

    .line 47
    .line 48
    :catch_2f
    move-exception p0

    .line 49
    goto/16 :goto_cb

    .line 50
    .line 51
    :cond_32
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 52
    .line 53
    invoke-static {p0}, Ly0;->h(Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    return-object v2

    .line 57
    :cond_38
    invoke-static {p1}, Lh23;->t(Ljava/lang/Object;)V

    .line 58
    .line 59
    .line 60
    iget-object p1, p0, Ldh2;->q:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 61
    .line 62
    invoke-virtual {p1, v3, v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    .line 63
    .line 64
    .line 65
    move-result p1

    .line 66
    if-eqz p1, :cond_a3

    .line 67
    .line 68
    iget-object p1, p0, Ldh2;->l:Landroidx/work/impl/WorkDatabase_Impl;

    .line 69
    .line 70
    invoke-virtual {p1}, Lch2;->g()Lm31;

    .line 71
    .line 72
    .line 73
    move-result-object p1

    .line 74
    iget-object v1, p0, Ldh2;->n:Lgh2;

    .line 75
    .line 76
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 77
    .line 78
    .line 79
    new-instance v5, Lcb3;

    .line 80
    .line 81
    invoke-direct {v5, p1, v1}, Lcb3;-><init>(Lm31;Lgh2;)V

    .line 82
    .line 83
    .line 84
    iget-object v1, p1, Lm31;->c:Ljava/util/LinkedHashMap;

    .line 85
    .line 86
    iget-object v6, p1, Lm31;->b:Ly03;

    .line 87
    .line 88
    iget-object v7, v5, Lj31;->a:[Ljava/lang/String;

    .line 89
    .line 90
    invoke-virtual {v6, v7}, Ly03;->g([Ljava/lang/String;)Lg12;

    .line 91
    .line 92
    .line 93
    move-result-object v7

    .line 94
    iget-object v8, v7, Lg12;->a:Ljava/lang/Object;

    .line 95
    .line 96
    check-cast v8, [Ljava/lang/String;

    .line 97
    .line 98
    iget-object v7, v7, Lg12;->b:Ljava/lang/Object;

    .line 99
    .line 100
    check-cast v7, [I

    .line 101
    .line 102
    new-instance v9, Lvy1;

    .line 103
    .line 104
    invoke-direct {v9, v5, v7, v8}, Lvy1;-><init>(Lj31;[I[Ljava/lang/String;)V

    .line 105
    .line 106
    .line 107
    iget-object v8, p1, Lm31;->d:Ljava/util/concurrent/locks/ReentrantLock;

    .line 108
    .line 109
    invoke-virtual {v8}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    .line 110
    .line 111
    .line 112
    :try_start_6f
    invoke-interface {v1, v5}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 113
    .line 114
    .line 115
    move-result v10

    .line 116
    if-eqz v10, :cond_7e

    .line 117
    .line 118
    invoke-static {v1, v5}, Lyo1;->w(Ljava/util/Map;Ljava/lang/Object;)Ljava/lang/Object;

    .line 119
    .line 120
    .line 121
    move-result-object v1

    .line 122
    check-cast v1, Lvy1;

    .line 123
    .line 124
    goto :goto_84

    .line 125
    :catchall_7c
    move-exception p0

    .line 126
    goto :goto_9f

    .line 127
    :cond_7e
    invoke-interface {v1, v5, v9}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 128
    .line 129
    .line 130
    move-result-object v1

    .line 131
    check-cast v1, Lvy1;
    :try_end_84
    .catchall {:try_start_6f .. :try_end_84} :catchall_7c

    .line 132
    .line 133
    :goto_84
    invoke-virtual {v8}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 134
    .line 135
    .line 136
    if-nez v1, :cond_93

    .line 137
    .line 138
    iget-object v1, v6, Ly03;->h:Led0;

    .line 139
    .line 140
    invoke-virtual {v1, v7}, Led0;->e([I)Z

    .line 141
    .line 142
    .line 143
    move-result v1

    .line 144
    if-eqz v1, :cond_93

    .line 145
    .line 146
    move v1, v4

    .line 147
    goto :goto_94

    .line 148
    :cond_93
    move v1, v3

    .line 149
    :goto_94
    if-eqz v1, :cond_a3

    .line 150
    .line 151
    new-instance v1, Lk31;

    .line 152
    .line 153
    invoke-direct {v1, p1, v2, v3}, Lk31;-><init>(Lm31;Lw00;I)V

    .line 154
    .line 155
    .line 156
    invoke-static {v1}, Lq33;->F(Ltt0;)Ljava/lang/Object;

    .line 157
    .line 158
    .line 159
    goto :goto_a3

    .line 160
    :goto_9f
    invoke-virtual {v8}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 161
    .line 162
    .line 163
    throw p0

    .line 164
    :cond_a3
    :goto_a3
    iget-object p1, p0, Ldh2;->p:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 165
    .line 166
    invoke-virtual {p1, v3, v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    .line 167
    .line 168
    .line 169
    move-result p1

    .line 170
    move-object v1, p0

    .line 171
    if-eqz p1, :cond_e4

    .line 172
    .line 173
    move-object p1, v2

    .line 174
    move p0, v3

    .line 175
    :goto_ae
    :try_start_ae
    iget-object v5, v1, Ldh2;->o:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 176
    .line 177
    invoke-virtual {v5, v4, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    .line 178
    .line 179
    .line 180
    move-result v5
    :try_end_b4
    .catchall {:try_start_ae .. :try_end_b4} :catchall_2c

    .line 181
    if-eqz v5, :cond_d3

    .line 182
    .line 183
    :try_start_b6
    iput-object v1, v0, Lhh2;->j:Ldh2;

    .line 184
    .line 185
    iput v4, v0, Lhh2;->l:I

    .line 186
    .line 187
    iput v4, v0, Lhh2;->o:I

    .line 188
    .line 189
    iget-object p0, v1, Ldh2;->l:Landroidx/work/impl/WorkDatabase_Impl;

    .line 190
    .line 191
    iget-object p1, v1, Ldh2;->s:Lja2;

    .line 192
    .line 193
    invoke-static {p0, v4, p1, v0}, Lh50;->l(Lch2;ZLft0;Ly00;)Ljava/lang/Object;

    .line 194
    .line 195
    .line 196
    move-result-object p1
    :try_end_c4
    .catch Ljava/lang/Exception; {:try_start_b6 .. :try_end_c4} :catch_2f
    .catchall {:try_start_b6 .. :try_end_c4} :catchall_2c

    .line 197
    sget-object p0, Lb20;->a:Lb20;

    .line 198
    .line 199
    if-ne p1, p0, :cond_c9

    .line 200
    .line 201
    return-object p0

    .line 202
    :cond_c9
    move p0, v4

    .line 203
    goto :goto_ae

    .line 204
    :goto_cb
    :try_start_cb
    new-instance p1, Ljava/lang/RuntimeException;

    .line 205
    .line 206
    const-string v0, "Exception while computing database live data."

    .line 207
    .line 208
    invoke-direct {p1, v0, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 209
    .line 210
    .line 211
    throw p1

    .line 212
    :cond_d3
    if-eqz p0, :cond_d8

    .line 213
    .line 214
    invoke-virtual {v1, p1}, Ljl1;->i(Ljava/lang/Object;)V
    :try_end_d8
    .catchall {:try_start_cb .. :try_end_d8} :catchall_2c

    .line 215
    .line 216
    .line 217
    :cond_d8
    iget-object p1, v1, Ldh2;->p:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 218
    .line 219
    invoke-virtual {p1, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 220
    .line 221
    .line 222
    goto :goto_e5

    .line 223
    :goto_de
    iget-object p1, v1, Ldh2;->p:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 224
    .line 225
    invoke-virtual {p1, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 226
    .line 227
    .line 228
    throw p0

    .line 229
    :cond_e4
    move p0, v3

    .line 230
    :goto_e5
    if-eqz p0, :cond_f2

    .line 231
    .line 232
    iget-object p0, v1, Ldh2;->o:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 233
    .line 234
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 235
    .line 236
    .line 237
    move-result p0

    .line 238
    if-nez p0, :cond_f0

    .line 239
    .line 240
    goto :goto_f2

    .line 241
    :cond_f0
    move-object p0, v1

    .line 242
    goto :goto_a3

    .line 243
    :cond_f2
    :goto_f2
    sget-object p0, Lw43;->a:Lw43;

    .line 244
    .line 245
    return-object p0
.end method
