###### Class defpackage.u83 (u83)
.class public final Lu83;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field public static final d:Lp22;


# instance fields
.field public a:I

.field public b:Li92;

.field public c:Li92;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lp22;

    .line 2
    .line 3
    const/16 v1, 0x14

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lp22;-><init>(I)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lu83;->d:Lp22;

    .line 9
    .line 10
    return-void
.end method

.method public static a()Lu83;
    .registers 1

    .line 1
    sget-object v0, Lu83;->d:Lp22;

    .line 2
    .line 3
    invoke-virtual {v0}, Lp22;->g()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lu83;

    .line 8
    .line 9
    if-nez v0, :cond_f

    .line 10
    .line 11
    new-instance v0, Lu83;

    .line 12
    .line 13
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 14
    .line 15
    .line 16
    :cond_f
    return-object v0
.end method
