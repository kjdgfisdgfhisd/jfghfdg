###### Class defpackage.w9 (w9)
.class public final Lw9;
.super Lsn2;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final synthetic i:I

.field public final synthetic j:I

.field public final synthetic k:Ljava/lang/ref/WeakReference;

.field public final synthetic l:Lca;


# direct methods
.method public constructor <init>(Lca;IILjava/lang/ref/WeakReference;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lw9;->l:Lca;

    .line 5
    .line 6
    iput p2, p0, Lw9;->i:I

    .line 7
    .line 8
    iput p3, p0, Lw9;->j:I

    .line 9
    .line 10
    iput-object p4, p0, Lw9;->k:Ljava/lang/ref/WeakReference;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final v(I)V
    .registers 2

    .line 1
    return-void
.end method

.method public final w(Landroid/graphics/Typeface;)V
    .registers 4

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/16 v1, 0x1c

    .line 4
    .line 5
    if-lt v0, v1, :cond_18

    .line 6
    .line 7
    const/4 v0, -0x1

    .line 8
    iget v1, p0, Lw9;->i:I

    .line 9
    .line 10
    if-eq v1, v0, :cond_18

    .line 11
    .line 12
    iget v0, p0, Lw9;->j:I

    .line 13
    .line 14
    and-int/lit8 v0, v0, 0x2

    .line 15
    .line 16
    if-eqz v0, :cond_13

    .line 17
    .line 18
    const/4 v0, 0x1

    .line 19
    goto :goto_14

    .line 20
    :cond_13
    const/4 v0, 0x0

    .line 21
    :goto_14
    invoke-static {p1, v1, v0}, Ls7;->a(Landroid/graphics/Typeface;IZ)Landroid/graphics/Typeface;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    :cond_18
    iget-object v0, p0, Lw9;->l:Lca;

    .line 26
    .line 27
    iget-boolean v1, v0, Lca;->n:Z

    .line 28
    .line 29
    if-eqz v1, :cond_3e

    .line 30
    .line 31
    iput-object p1, v0, Lca;->l:Landroid/graphics/Typeface;

    .line 32
    .line 33
    iget-object p0, p0, Lw9;->k:Ljava/lang/ref/WeakReference;

    .line 34
    .line 35
    invoke-virtual {p0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object p0

    .line 39
    check-cast p0, Landroid/widget/TextView;

    .line 40
    .line 41
    if-eqz p0, :cond_3e

    .line 42
    .line 43
    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    .line 44
    .line 45
    .line 46
    move-result v1

    .line 47
    iget v0, v0, Lca;->j:I

    .line 48
    .line 49
    if-eqz v1, :cond_3b

    .line 50
    .line 51
    new-instance v1, Lx9;

    .line 52
    .line 53
    invoke-direct {v1, p0, p1, v0}, Lx9;-><init>(Landroid/widget/TextView;Landroid/graphics/Typeface;I)V

    .line 54
    .line 55
    .line 56
    invoke-virtual {p0, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 57
    .line 58
    .line 59
    return-void

    .line 60
    :cond_3b
    invoke-static {p0, p1, v0}, Lca;->d(Landroid/widget/TextView;Landroid/graphics/Typeface;I)V

    .line 61
    .line 62
    .line 63
    :cond_3e
    return-void
.end method
