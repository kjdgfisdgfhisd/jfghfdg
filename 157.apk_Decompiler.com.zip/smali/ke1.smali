###### Class defpackage.ke1 (ke1)
.class public final Lke1;
.super Ljava/lang/Object;

# interfaces
.implements Ldt0;


# instance fields
.field public final synthetic a:I

.field public final b:Lme1;


# direct methods
.method public synthetic constructor <init>(Lme1;I)V
    .registers 3

    .line 1
    iput p2, p0, Lke1;->a:I

    .line 2
    .line 3
    iput-object p1, p0, Lke1;->b:Lme1;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 8

    .line 1
    iget v0, p0, Lke1;->a:I

    .line 2
    .line 3
    iget-object p0, p0, Lke1;->b:Lme1;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_102

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0}, Lme1;->a()Lh12;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    iget v1, p0, Lme1;->b:I

    .line 13
    .line 14
    iget-object p0, p0, Lme1;->a:Lvc1;

    .line 15
    .line 16
    instance-of v2, v0, Ltg1;

    .line 17
    .line 18
    if-eqz v2, :cond_49

    .line 19
    .line 20
    invoke-virtual {p0}, Lvc1;->h()Lno;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    invoke-static {v2}, Ln63;->g(Llo;)Ltg1;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    invoke-static {v2, v0}, Ld31;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result v2

    .line 32
    if-eqz v2, :cond_49

    .line 33
    .line 34
    invoke-virtual {p0}, Lvc1;->h()Lno;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    invoke-interface {v2}, Lno;->j()I

    .line 39
    .line 40
    .line 41
    move-result v2

    .line 42
    const/4 v3, 0x2

    .line 43
    if-ne v2, v3, :cond_49

    .line 44
    .line 45
    invoke-virtual {p0}, Lvc1;->h()Lno;

    .line 46
    .line 47
    .line 48
    move-result-object p0

    .line 49
    invoke-interface {p0}, Lm60;->p()Lm60;

    .line 50
    .line 51
    .line 52
    move-result-object p0

    .line 53
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 54
    .line 55
    .line 56
    check-cast p0, Lxt1;

    .line 57
    .line 58
    invoke-static {p0}, Ln63;->j(Lxt1;)Ljava/lang/Class;

    .line 59
    .line 60
    .line 61
    move-result-object p0

    .line 62
    if-eqz p0, :cond_41

    .line 63
    .line 64
    goto/16 :goto_f8

    .line 65
    .line 66
    :cond_41
    const-string p0, "Cannot determine receiver Java type of inherited declaration: "

    .line 67
    .line 68
    invoke-static {v0, p0}, Lvn0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    .line 69
    .line 70
    .line 71
    const/4 p0, 0x0

    .line 72
    goto/16 :goto_f8

    .line 73
    .line 74
    :cond_49
    invoke-virtual {p0}, Lvc1;->d()Lyo;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    instance-of v2, v0, Lt63;

    .line 79
    .line 80
    const-string v3, "Expected at least 1 type for compound type"

    .line 81
    .line 82
    const/4 v4, 0x0

    .line 83
    const/4 v5, 0x1

    .line 84
    if-eqz v2, :cond_b9

    .line 85
    .line 86
    invoke-virtual {p0}, Lvc1;->j()Z

    .line 87
    .line 88
    .line 89
    move-result p0

    .line 90
    if-eqz p0, :cond_7f

    .line 91
    .line 92
    check-cast v0, Lt63;

    .line 93
    .line 94
    add-int/2addr v1, v5

    .line 95
    invoke-virtual {v0, v1}, Lt63;->d(I)Ll21;

    .line 96
    .line 97
    .line 98
    move-result-object p0

    .line 99
    invoke-virtual {v0, v4}, Lt63;->d(I)Ll21;

    .line 100
    .line 101
    .line 102
    move-result-object v1

    .line 103
    iget v1, v1, Lj21;->b:I

    .line 104
    .line 105
    add-int/2addr v1, v5

    .line 106
    iget-object v0, v0, Lt63;->b:Lyo;

    .line 107
    .line 108
    invoke-interface {v0}, Lyo;->a()Ljava/util/List;

    .line 109
    .line 110
    .line 111
    move-result-object v0

    .line 112
    new-instance v2, Ll21;

    .line 113
    .line 114
    iget v6, p0, Lj21;->a:I

    .line 115
    .line 116
    sub-int/2addr v6, v1

    .line 117
    iget p0, p0, Lj21;->b:I

    .line 118
    .line 119
    sub-int/2addr p0, v1

    .line 120
    invoke-direct {v2, v6, p0, v5}, Lj21;-><init>(III)V

    .line 121
    .line 122
    .line 123
    invoke-static {v0, v2}, Lgv;->s0(Ljava/util/List;Ll21;)Ljava/util/List;

    .line 124
    .line 125
    .line 126
    move-result-object p0

    .line 127
    goto :goto_8f

    .line 128
    :cond_7f
    check-cast v0, Lt63;

    .line 129
    .line 130
    invoke-virtual {v0, v1}, Lt63;->d(I)Ll21;

    .line 131
    .line 132
    .line 133
    move-result-object p0

    .line 134
    iget-object v0, v0, Lt63;->b:Lyo;

    .line 135
    .line 136
    invoke-interface {v0}, Lyo;->a()Ljava/util/List;

    .line 137
    .line 138
    .line 139
    move-result-object v0

    .line 140
    invoke-static {v0, p0}, Lgv;->s0(Ljava/util/List;Ll21;)Ljava/util/List;

    .line 141
    .line 142
    .line 143
    move-result-object p0

    .line 144
    :goto_8f
    check-cast p0, Ljava/util/Collection;

    .line 145
    .line 146
    new-array v0, v4, [Ljava/lang/reflect/Type;

    .line 147
    .line 148
    invoke-interface {p0, v0}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 149
    .line 150
    .line 151
    move-result-object p0

    .line 152
    check-cast p0, [Ljava/lang/reflect/Type;

    .line 153
    .line 154
    array-length v0, p0

    .line 155
    invoke-static {p0, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 156
    .line 157
    .line 158
    move-result-object p0

    .line 159
    check-cast p0, [Ljava/lang/reflect/Type;

    .line 160
    .line 161
    array-length v0, p0

    .line 162
    if-eqz v0, :cond_b3

    .line 163
    .line 164
    if-eq v0, v5, :cond_ac

    .line 165
    .line 166
    new-instance v0, Lle1;

    .line 167
    .line 168
    invoke-direct {v0, p0}, Lle1;-><init>([Ljava/lang/reflect/Type;)V

    .line 169
    .line 170
    .line 171
    :goto_aa
    move-object p0, v0

    .line 172
    goto :goto_f8

    .line 173
    :cond_ac
    invoke-static {p0}, Lub;->R([Ljava/lang/Object;)Ljava/lang/Object;

    .line 174
    .line 175
    .line 176
    move-result-object p0

    .line 177
    check-cast p0, Ljava/lang/reflect/Type;

    .line 178
    .line 179
    goto :goto_f8

    .line 180
    :cond_b3
    new-instance p0, Lg20;

    .line 181
    .line 182
    invoke-direct {p0, v3}, Ljava/lang/Error;-><init>(Ljava/lang/String;)V

    .line 183
    .line 184
    .line 185
    throw p0

    .line 186
    :cond_b9
    instance-of p0, v0, Ls63;

    .line 187
    .line 188
    if-eqz p0, :cond_ee

    .line 189
    .line 190
    check-cast v0, Ls63;

    .line 191
    .line 192
    iget-object p0, v0, Ls63;->d:Ljava/util/ArrayList;

    .line 193
    .line 194
    invoke-virtual {p0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 195
    .line 196
    .line 197
    move-result-object p0

    .line 198
    check-cast p0, Ljava/util/Collection;

    .line 199
    .line 200
    new-array v0, v4, [Ljava/lang/Class;

    .line 201
    .line 202
    invoke-interface {p0, v0}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 203
    .line 204
    .line 205
    move-result-object p0

    .line 206
    check-cast p0, [Ljava/lang/Class;

    .line 207
    .line 208
    array-length v0, p0

    .line 209
    invoke-static {p0, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 210
    .line 211
    .line 212
    move-result-object p0

    .line 213
    check-cast p0, [Ljava/lang/reflect/Type;

    .line 214
    .line 215
    array-length v0, p0

    .line 216
    if-eqz v0, :cond_e8

    .line 217
    .line 218
    if-eq v0, v5, :cond_e1

    .line 219
    .line 220
    new-instance v0, Lle1;

    .line 221
    .line 222
    invoke-direct {v0, p0}, Lle1;-><init>([Ljava/lang/reflect/Type;)V

    .line 223
    .line 224
    .line 225
    goto :goto_aa

    .line 226
    :cond_e1
    invoke-static {p0}, Lub;->R([Ljava/lang/Object;)Ljava/lang/Object;

    .line 227
    .line 228
    .line 229
    move-result-object p0

    .line 230
    check-cast p0, Ljava/lang/reflect/Type;

    .line 231
    .line 232
    goto :goto_f8

    .line 233
    :cond_e8
    new-instance p0, Lg20;

    .line 234
    .line 235
    invoke-direct {p0, v3}, Ljava/lang/Error;-><init>(Ljava/lang/String;)V

    .line 236
    .line 237
    .line 238
    throw p0

    .line 239
    :cond_ee
    invoke-interface {v0}, Lyo;->a()Ljava/util/List;

    .line 240
    .line 241
    .line 242
    move-result-object p0

    .line 243
    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 244
    .line 245
    .line 246
    move-result-object p0

    .line 247
    check-cast p0, Ljava/lang/reflect/Type;

    .line 248
    .line 249
    :goto_f8
    return-object p0

    .line 250
    :pswitch_f9
    invoke-virtual {p0}, Lme1;->a()Lh12;

    .line 251
    .line 252
    .line 253
    move-result-object p0

    .line 254
    invoke-static {p0}, Ln63;->d(La6;)Ljava/util/ArrayList;

    .line 255
    .line 256
    .line 257
    move-result-object p0

    .line 258
    return-object p0

    .line 259
    :pswitch_data_102
    .packed-switch 0x0
        :pswitch_f9
    .end packed-switch
.end method
