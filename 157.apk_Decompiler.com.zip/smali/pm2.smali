###### Class defpackage.pm2 (pm2)
.class public final Lpm2;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field public static final c:Lk32;

.field public static final d:Lk32;

.field public static final e:Lk32;

.field public static final f:Lk32;

.field public static final g:Lk32;


# instance fields
.field public final a:Lv50;

.field public b:Lil2;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lk32;

    .line 2
    .line 3
    const-string v1, "firebase_sessions_enabled"

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lk32;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lpm2;->c:Lk32;

    .line 9
    .line 10
    new-instance v0, Lk32;

    .line 11
    .line 12
    const-string v1, "firebase_sessions_sampling_rate"

    .line 13
    .line 14
    invoke-direct {v0, v1}, Lk32;-><init>(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    sput-object v0, Lpm2;->d:Lk32;

    .line 18
    .line 19
    new-instance v0, Lk32;

    .line 20
    .line 21
    const-string v1, "firebase_sessions_restart_timeout"

    .line 22
    .line 23
    invoke-direct {v0, v1}, Lk32;-><init>(Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    sput-object v0, Lpm2;->e:Lk32;

    .line 27
    .line 28
    new-instance v0, Lk32;

    .line 29
    .line 30
    const-string v1, "firebase_sessions_cache_duration"

    .line 31
    .line 32
    invoke-direct {v0, v1}, Lk32;-><init>(Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    sput-object v0, Lpm2;->f:Lk32;

    .line 36
    .line 37
    new-instance v0, Lk32;

    .line 38
    .line 39
    const-string v1, "firebase_sessions_cache_updated_time"

    .line 40
    .line 41
    invoke-direct {v0, v1}, Lk32;-><init>(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    sput-object v0, Lpm2;->g:Lk32;

    .line 45
    .line 46
    return-void
.end method

.method public constructor <init>(Lv50;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lpm2;->a:Lv50;

    .line 5
    .line 6
    new-instance p1, Lbi;

    .line 7
    .line 8
    const/16 v0, 0xa

    .line 9
    .line 10
    const/4 v1, 0x0

    .line 11
    invoke-direct {p1, p0, v1, v0}, Lbi;-><init>(Ljava/lang/Object;Lw00;I)V

    .line 12
    .line 13
    .line 14
    sget-object p0, Lrh0;->a:Lrh0;

    .line 15
    .line 16
    invoke-static {p0, p1}, Ld31;->t(Lr10;Ltt0;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    return-void
.end method


# virtual methods
.method public final a()Z
    .registers 5

    .line 1
    iget-object p0, p0, Lpm2;->b:Lil2;

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    const-string v1, "sessionConfigs"

    .line 5
    .line 6
    if-eqz p0, :cond_2e

    .line 7
    .line 8
    iget-object v2, p0, Lil2;->e:Ljava/lang/Long;

    .line 9
    .line 10
    if-eqz p0, :cond_2a

    .line 11
    .line 12
    iget-object p0, p0, Lil2;->d:Ljava/lang/Integer;

    .line 13
    .line 14
    if-eqz v2, :cond_28

    .line 15
    .line 16
    if-eqz p0, :cond_28

    .line 17
    .line 18
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 19
    .line 20
    .line 21
    move-result-wide v0

    .line 22
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 23
    .line 24
    .line 25
    move-result-wide v2

    .line 26
    sub-long/2addr v0, v2

    .line 27
    const-wide/16 v2, 0x3e8

    .line 28
    .line 29
    div-long/2addr v0, v2

    .line 30
    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    .line 31
    .line 32
    .line 33
    move-result p0

    .line 34
    int-to-long v2, p0

    .line 35
    cmp-long p0, v0, v2

    .line 36
    .line 37
    if-gez p0, :cond_28

    .line 38
    .line 39
    const/4 p0, 0x0

    .line 40
    return p0

    .line 41
    :cond_28
    const/4 p0, 0x1

    .line 42
    return p0

    .line 43
    :cond_2a
    invoke-static {v1}, Ld31;->A(Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    throw v0

    .line 47
    :cond_2e
    invoke-static {v1}, Ld31;->A(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    throw v0
.end method

.method public final b(Lk32;Ljava/lang/Object;Ly00;)Ljava/lang/Object;
    .registers 8

    .line 1
    instance-of v0, p3, Lnm2;

    .line 2
    .line 3
    if-eqz v0, :cond_13

    .line 4
    .line 5
    move-object v0, p3

    .line 6
    check-cast v0, Lnm2;

    .line 7
    .line 8
    iget v1, v0, Lnm2;->m:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_13

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lnm2;->m:I

    .line 18
    .line 19
    goto :goto_18

    .line 20
    :cond_13
    new-instance v0, Lnm2;

    .line 21
    .line 22
    invoke-direct {v0, p0, p3}, Lnm2;-><init>(Lpm2;Ly00;)V

    .line 23
    .line 24
    .line 25
    :goto_18
    iget-object p3, v0, Lnm2;->j:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, Lnm2;->m:I

    .line 28
    .line 29
    const/4 v2, 0x0

    .line 30
    const/4 v3, 0x1

    .line 31
    if-eqz v1, :cond_2c

    .line 32
    .line 33
    if-ne v1, v3, :cond_26

    .line 34
    .line 35
    :try_start_22
    invoke-static {p3}, Lh23;->t(Ljava/lang/Object;)V
    :try_end_25
    .catch Ljava/io/IOException; {:try_start_22 .. :try_end_25} :catch_46

    .line 36
    .line 37
    .line 38
    goto :goto_5a

    .line 39
    :cond_26
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 40
    .line 41
    invoke-static {p0}, Ly0;->h(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    return-object v2

    .line 45
    :cond_2c
    invoke-static {p3}, Lh23;->t(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    :try_start_2f
    iget-object p3, p0, Lpm2;->a:Lv50;

    .line 49
    .line 50
    new-instance v1, Lom2;

    .line 51
    .line 52
    invoke-direct {v1, p2, p1, p0, v2}, Lom2;-><init>(Ljava/lang/Object;Lk32;Lpm2;Lw00;)V

    .line 53
    .line 54
    .line 55
    iput v3, v0, Lnm2;->m:I

    .line 56
    .line 57
    new-instance p0, Lg32;

    .line 58
    .line 59
    invoke-direct {p0, v1, v2, v3}, Lg32;-><init>(Ltt0;Lw00;I)V

    .line 60
    .line 61
    .line 62
    invoke-interface {p3, p0, v0}, Lv50;->l(Ltt0;Ly00;)Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object p0
    :try_end_41
    .catch Ljava/io/IOException; {:try_start_2f .. :try_end_41} :catch_46

    .line 66
    sget-object p1, Lb20;->a:Lb20;

    .line 67
    .line 68
    if-ne p0, p1, :cond_5a

    .line 69
    .line 70
    return-object p1

    .line 71
    :catch_46
    move-exception p0

    .line 72
    new-instance p1, Ljava/lang/StringBuilder;

    .line 73
    .line 74
    const-string p2, "Failed to update cache config value: "

    .line 75
    .line 76
    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 77
    .line 78
    .line 79
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 80
    .line 81
    .line 82
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object p0

    .line 86
    const-string p1, "SettingsCache"

    .line 87
    .line 88
    invoke-static {p1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 89
    .line 90
    .line 91
    :cond_5a
    :goto_5a
    sget-object p0, Lw43;->a:Lw43;

    .line 92
    .line 93
    return-object p0
.end method

.method public final c(Lxu1;)V
    .registers 8

    .line 1
    new-instance v0, Lil2;

    .line 2
    .line 3
    sget-object v1, Lpm2;->c:Lk32;

    .line 4
    .line 5
    invoke-virtual {p1, v1}, Lxu1;->a(Lk32;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    check-cast v1, Ljava/lang/Boolean;

    .line 10
    .line 11
    sget-object v2, Lpm2;->d:Lk32;

    .line 12
    .line 13
    invoke-virtual {p1, v2}, Lxu1;->a(Lk32;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    check-cast v2, Ljava/lang/Double;

    .line 18
    .line 19
    sget-object v3, Lpm2;->e:Lk32;

    .line 20
    .line 21
    invoke-virtual {p1, v3}, Lxu1;->a(Lk32;)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v3

    .line 25
    check-cast v3, Ljava/lang/Integer;

    .line 26
    .line 27
    sget-object v4, Lpm2;->f:Lk32;

    .line 28
    .line 29
    invoke-virtual {p1, v4}, Lxu1;->a(Lk32;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v4

    .line 33
    check-cast v4, Ljava/lang/Integer;

    .line 34
    .line 35
    sget-object v5, Lpm2;->g:Lk32;

    .line 36
    .line 37
    invoke-virtual {p1, v5}, Lxu1;->a(Lk32;)Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    move-object v5, p1

    .line 42
    check-cast v5, Ljava/lang/Long;

    .line 43
    .line 44
    invoke-direct/range {v0 .. v5}, Lil2;-><init>(Ljava/lang/Boolean;Ljava/lang/Double;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Long;)V

    .line 45
    .line 46
    .line 47
    iput-object v0, p0, Lpm2;->b:Lil2;

    .line 48
    .line 49
    return-void
.end method
