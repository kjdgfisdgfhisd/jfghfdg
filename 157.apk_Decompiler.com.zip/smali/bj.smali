###### Class defpackage.bj (bj)
.class public final Lbj;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lbz1;


# instance fields
.field public final synthetic a:Lgj;


# direct methods
.method public synthetic constructor <init>(Lgj;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lbj;->a:Lgj;

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public a(Landroid/view/View;)V
    .registers 3

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    if-eqz v0, :cond_b

    .line 6
    .line 7
    const/16 v0, 0x8

    .line 8
    .line 9
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 10
    .line 11
    .line 12
    :cond_b
    iget-object p0, p0, Lbj;->a:Lgj;

    .line 13
    .line 14
    const/4 p1, 0x0

    .line 15
    invoke-virtual {p0, p1}, Lgj;->a(I)V

    .line 16
    .line 17
    .line 18
    return-void
.end method

.method public p(Landroid/view/View;Lqc3;)Lqc3;
    .registers 3

    .line 1
    invoke-virtual {p2}, Lqc3;->a()I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    iget-object p0, p0, Lbj;->a:Lgj;

    .line 6
    .line 7
    iput p1, p0, Lgj;->m:I

    .line 8
    .line 9
    invoke-virtual {p2}, Lqc3;->b()I

    .line 10
    .line 11
    .line 12
    move-result p1

    .line 13
    iput p1, p0, Lgj;->n:I

    .line 14
    .line 15
    invoke-virtual {p2}, Lqc3;->c()I

    .line 16
    .line 17
    .line 18
    move-result p1

    .line 19
    iput p1, p0, Lgj;->o:I

    .line 20
    .line 21
    invoke-virtual {p0}, Lgj;->e()V

    .line 22
    .line 23
    .line 24
    return-object p2
.end method
