###### Class defpackage.oi0 (oi0)
.class public final Loi0;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final b:Ljp2;

.field public final synthetic c:Lqi0;


# direct methods
.method public synthetic constructor <init>(Lqi0;Ljp2;I)V
    .registers 4

    .line 1
    iput p3, p0, Loi0;->a:I

    .line 2
    .line 3
    iput-object p1, p0, Loi0;->c:Lqi0;

    .line 4
    .line 5
    iput-object p2, p0, Loi0;->b:Ljp2;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final run()V
    .registers 7

    .line 1
    iget v0, p0, Loi0;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_a6

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Loi0;->b:Ljp2;

    .line 7
    .line 8
    iget-object v1, v0, Ljp2;->b:Lis2;

    .line 9
    .line 10
    invoke-virtual {v1}, Lis2;->a()V

    .line 11
    .line 12
    .line 13
    iget-object v0, v0, Ljp2;->c:Ljava/lang/Object;

    .line 14
    .line 15
    monitor-enter v0

    .line 16
    :try_start_f
    iget-object v1, p0, Loi0;->c:Lqi0;

    .line 17
    .line 18
    monitor-enter v1
    :try_end_12
    .catchall {:try_start_f .. :try_end_12} :catchall_57

    .line 19
    :try_start_12
    iget-object v2, p0, Loi0;->c:Lqi0;

    .line 20
    .line 21
    iget-object v2, v2, Lqi0;->a:Ll6;

    .line 22
    .line 23
    iget-object v3, p0, Loi0;->b:Ljp2;

    .line 24
    .line 25
    iget-object v2, v2, Ll6;->b:Ljava/lang/Object;

    .line 26
    .line 27
    check-cast v2, Ljava/util/ArrayList;

    .line 28
    .line 29
    new-instance v4, Lpi0;

    .line 30
    .line 31
    sget-object v5, Lpf3;->b:Luc0;

    .line 32
    .line 33
    invoke-direct {v4, v3, v5}, Lpi0;-><init>(Ljp2;Ljava/util/concurrent/Executor;)V

    .line 34
    .line 35
    .line 36
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    .line 37
    .line 38
    .line 39
    move-result v2

    .line 40
    if-eqz v2, :cond_4f

    .line 41
    .line 42
    iget-object v2, p0, Loi0;->c:Lqi0;

    .line 43
    .line 44
    iget-object v2, v2, Lqi0;->u:Lsi0;

    .line 45
    .line 46
    invoke-virtual {v2}, Lsi0;->a()V

    .line 47
    .line 48
    .line 49
    iget-object v2, p0, Loi0;->c:Lqi0;

    .line 50
    .line 51
    iget-object v3, p0, Loi0;->b:Ljp2;

    .line 52
    .line 53
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_37
    .catchall {:try_start_12 .. :try_end_37} :catchall_46

    .line 54
    .line 55
    .line 56
    :try_start_37
    iget-object v4, v2, Lqi0;->u:Lsi0;

    .line 57
    .line 58
    iget-object v2, v2, Lqi0;->q:Lu50;

    .line 59
    .line 60
    invoke-virtual {v3, v4, v2}, Ljp2;->g(Lqf2;Lu50;)V
    :try_end_3e
    .catchall {:try_start_37 .. :try_end_3e} :catchall_48

    .line 61
    .line 62
    .line 63
    :try_start_3e
    iget-object v2, p0, Loi0;->c:Lqi0;

    .line 64
    .line 65
    iget-object v3, p0, Loi0;->b:Ljp2;

    .line 66
    .line 67
    invoke-virtual {v2, v3}, Lqi0;->g(Ljp2;)V

    .line 68
    .line 69
    .line 70
    goto :goto_4f

    .line 71
    :catchall_46
    move-exception p0

    .line 72
    goto :goto_59

    .line 73
    :catchall_48
    move-exception p0

    .line 74
    new-instance v2, Lro;

    .line 75
    .line 76
    invoke-direct {v2, p0}, Lro;-><init>(Ljava/lang/Throwable;)V

    .line 77
    .line 78
    .line 79
    throw v2

    .line 80
    :cond_4f
    :goto_4f
    iget-object p0, p0, Loi0;->c:Lqi0;

    .line 81
    .line 82
    invoke-virtual {p0}, Lqi0;->c()V

    .line 83
    .line 84
    .line 85
    monitor-exit v1
    :try_end_55
    .catchall {:try_start_3e .. :try_end_55} :catchall_46

    .line 86
    :try_start_55
    monitor-exit v0
    :try_end_56
    .catchall {:try_start_55 .. :try_end_56} :catchall_57

    .line 87
    return-void

    .line 88
    :catchall_57
    move-exception p0

    .line 89
    goto :goto_5b

    .line 90
    :goto_59
    :try_start_59
    monitor-exit v1
    :try_end_5a
    .catchall {:try_start_59 .. :try_end_5a} :catchall_46

    .line 91
    :try_start_5a
    throw p0

    .line 92
    :goto_5b
    monitor-exit v0
    :try_end_5c
    .catchall {:try_start_5a .. :try_end_5c} :catchall_57

    .line 93
    throw p0

    .line 94
    :pswitch_5d
    iget-object v0, p0, Loi0;->b:Ljp2;

    .line 95
    .line 96
    iget-object v1, v0, Ljp2;->b:Lis2;

    .line 97
    .line 98
    invoke-virtual {v1}, Lis2;->a()V

    .line 99
    .line 100
    .line 101
    iget-object v0, v0, Ljp2;->c:Ljava/lang/Object;

    .line 102
    .line 103
    monitor-enter v0

    .line 104
    :try_start_67
    iget-object v1, p0, Loi0;->c:Lqi0;

    .line 105
    .line 106
    monitor-enter v1
    :try_end_6a
    .catchall {:try_start_67 .. :try_end_6a} :catchall_a0

    .line 107
    :try_start_6a
    iget-object v2, p0, Loi0;->c:Lqi0;

    .line 108
    .line 109
    iget-object v2, v2, Lqi0;->a:Ll6;

    .line 110
    .line 111
    iget-object v3, p0, Loi0;->b:Ljp2;

    .line 112
    .line 113
    iget-object v2, v2, Ll6;->b:Ljava/lang/Object;

    .line 114
    .line 115
    check-cast v2, Ljava/util/ArrayList;

    .line 116
    .line 117
    new-instance v4, Lpi0;

    .line 118
    .line 119
    sget-object v5, Lpf3;->b:Luc0;

    .line 120
    .line 121
    invoke-direct {v4, v3, v5}, Lpi0;-><init>(Ljp2;Ljava/util/concurrent/Executor;)V

    .line 122
    .line 123
    .line 124
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    .line 125
    .line 126
    .line 127
    move-result v2

    .line 128
    if-eqz v2, :cond_98

    .line 129
    .line 130
    iget-object v2, p0, Loi0;->c:Lqi0;

    .line 131
    .line 132
    iget-object v3, p0, Loi0;->b:Ljp2;

    .line 133
    .line 134
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_88
    .catchall {:try_start_6a .. :try_end_88} :catchall_96

    .line 135
    .line 136
    .line 137
    :try_start_88
    iget-object v2, v2, Lqi0;->s:Lpw0;

    .line 138
    .line 139
    const/4 v4, 0x5

    .line 140
    invoke-virtual {v3, v2, v4}, Ljp2;->f(Lpw0;I)V
    :try_end_8e
    .catchall {:try_start_88 .. :try_end_8e} :catchall_8f

    .line 141
    .line 142
    .line 143
    goto :goto_98

    .line 144
    :catchall_8f
    move-exception p0

    .line 145
    :try_start_90
    new-instance v2, Lro;

    .line 146
    .line 147
    invoke-direct {v2, p0}, Lro;-><init>(Ljava/lang/Throwable;)V

    .line 148
    .line 149
    .line 150
    throw v2

    .line 151
    :catchall_96
    move-exception p0

    .line 152
    goto :goto_a2

    .line 153
    :cond_98
    :goto_98
    iget-object p0, p0, Loi0;->c:Lqi0;

    .line 154
    .line 155
    invoke-virtual {p0}, Lqi0;->c()V

    .line 156
    .line 157
    .line 158
    monitor-exit v1
    :try_end_9e
    .catchall {:try_start_90 .. :try_end_9e} :catchall_96

    .line 159
    :try_start_9e
    monitor-exit v0
    :try_end_9f
    .catchall {:try_start_9e .. :try_end_9f} :catchall_a0

    .line 160
    return-void

    .line 161
    :catchall_a0
    move-exception p0

    .line 162
    goto :goto_a4

    .line 163
    :goto_a2
    :try_start_a2
    monitor-exit v1
    :try_end_a3
    .catchall {:try_start_a2 .. :try_end_a3} :catchall_96

    .line 164
    :try_start_a3
    throw p0

    .line 165
    :goto_a4
    monitor-exit v0
    :try_end_a5
    .catchall {:try_start_a3 .. :try_end_a5} :catchall_a0

    .line 166
    throw p0

    .line 167
    :pswitch_data_a6
    .packed-switch 0x0
        :pswitch_5d
    .end packed-switch
.end method
