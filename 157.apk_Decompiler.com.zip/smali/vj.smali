###### Class defpackage.vj (vj)
.class public final Lvj;
.super Llj;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field public static final synthetic l:I


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Loo;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-direct {v0, v1}, Loo;-><init>(I)V

    .line 5
    .line 6
    .line 7
    return-void
.end method
