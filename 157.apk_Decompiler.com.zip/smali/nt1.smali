###### Class defpackage.nt1 (nt1)
.class public final Lnt1;
.super Lc21;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final a:Ljava/util/ArrayList;

.field public final b:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lnt1;Ljava/util/ArrayList;Ljava/lang/String;)V
    .registers 5

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 2
    .line 3
    .line 4
    iput-object p3, p0, Lnt1;->a:Ljava/util/ArrayList;

    .line 5
    .line 6
    iput-object p4, p0, Lnt1;->b:Ljava/lang/String;

    .line 7
    .line 8
    return-void
.end method
