###### Class defpackage.do2 (do2)
.class public final Ldo2;
.super Lxj;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final b:Lfa3;

.field public final c:Lp52;

.field public final d:Lq52;

.field public final e:Lf81;


# direct methods
.method public constructor <init>(Lry1;Lfa3;Lq52;Lp52;Lf81;)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, Ldo2;->b:Lfa3;

    .line 5
    .line 6
    iput-object p3, p0, Ldo2;->d:Lq52;

    .line 7
    .line 8
    if-nez p4, :cond_b

    .line 9
    .line 10
    sget-object p4, Lp52;->g:Lp52;

    .line 11
    .line 12
    :cond_b
    iput-object p4, p0, Ldo2;->c:Lp52;

    .line 13
    .line 14
    iput-object p5, p0, Ldo2;->e:Lf81;

    .line 15
    .line 16
    return-void
.end method

.method public static p(Lvo1;Lfa3;Lq52;Lp52;Le81;)Ldo2;
    .registers 12

    .line 1
    if-eqz p4, :cond_16

    .line 2
    .line 3
    sget-object v0, Le81;->e:Le81;

    .line 4
    .line 5
    if-ne p4, v0, :cond_7

    .line 6
    .line 7
    goto :goto_16

    .line 8
    :cond_7
    sget-object v1, Lf81;->e:Lf81;

    .line 9
    .line 10
    if-eq p4, v0, :cond_12

    .line 11
    .line 12
    new-instance v0, Lf81;

    .line 13
    .line 14
    const/4 v1, 0x0

    .line 15
    invoke-direct {v0, p4, v1, v1, v1}, Lf81;-><init>(Le81;Le81;Ljava/lang/Class;Ljava/lang/Class;)V

    .line 16
    .line 17
    .line 18
    goto :goto_14

    .line 19
    :cond_12
    sget-object v0, Lf81;->e:Lf81;

    .line 20
    .line 21
    :goto_14
    move-object v6, v0

    .line 22
    goto :goto_19

    .line 23
    :cond_16
    :goto_16
    sget-object v0, Lxj;->a:Lf81;

    .line 24
    .line 25
    goto :goto_14

    .line 26
    :goto_19
    new-instance v1, Ldo2;

    .line 27
    .line 28
    invoke-virtual {p0}, Lvo1;->d()Lry1;

    .line 29
    .line 30
    .line 31
    move-result-object v2

    .line 32
    move-object v3, p1

    .line 33
    move-object v4, p2

    .line 34
    move-object v5, p3

    .line 35
    invoke-direct/range {v1 .. v6}, Ldo2;-><init>(Lry1;Lfa3;Lq52;Lp52;Lf81;)V

    .line 36
    .line 37
    .line 38
    return-object v1
.end method


# virtual methods
.method public final b()Lf81;
    .registers 1

    .line 1
    iget-object p0, p0, Ldo2;->e:Lf81;

    .line 2
    .line 3
    return-object p0
.end method

.method public final f()Lm6;
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return-object p0
.end method

.method public final g()Lf6;
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return-object p0
.end method

.method public final h()Li6;
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return-object p0
.end method

.method public final i()Lp52;
    .registers 1

    .line 1
    iget-object p0, p0, Ldo2;->c:Lp52;

    .line 2
    .line 3
    return-object p0
.end method

.method public final j()Ljava/lang/String;
    .registers 1

    .line 1
    iget-object p0, p0, Ldo2;->d:Lq52;

    .line 2
    .line 3
    iget-object p0, p0, Lq52;->a:Ljava/lang/String;

    .line 4
    .line 5
    return-object p0
.end method

.method public final k()Ljava/lang/Class;
    .registers 1

    .line 1
    iget-object p0, p0, Ldo2;->b:Lfa3;

    .line 2
    .line 3
    iget-object p0, p0, Lfa3;->j:Lh13;

    .line 4
    .line 5
    iget-object p0, p0, Lh13;->d:Ljava/lang/Class;

    .line 6
    .line 7
    return-object p0
.end method

.method public final l()Li6;
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return-object p0
.end method

.method public final m()V
    .registers 1

    .line 1
    return-void
.end method

.method public final n()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method
