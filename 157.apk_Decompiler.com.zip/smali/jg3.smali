###### Class defpackage.jg3 (jg3)
.class public final synthetic Ljg3;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lft0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcc/bomber/x/g/c;


# direct methods
.method public synthetic constructor <init>(Lcc/bomber/x/g/c;I)V
    .registers 3

    .line 1
    iput p2, p0, Ljg3;->a:I

    .line 2
    .line 3
    iput-object p1, p0, Ljg3;->b:Lcc/bomber/x/g/c;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    iget v0, p0, Ljg3;->a:I

    .line 2
    .line 3
    iget-object p0, p0, Ljg3;->b:Lcc/bomber/x/g/c;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_da

    .line 6
    .line 7
    .line 8
    check-cast p1, Ltq0;

    .line 9
    .line 10
    invoke-static {p0, p1}, Lcc/bomber/x/i/b;->H7(Lcc/bomber/x/g/c;Ltq0;)Lw43;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    return-object p0

    .line 15
    :pswitch_e
    check-cast p1, Ltq0;

    .line 16
    .line 17
    invoke-static {p0, p1}, Lcc/bomber/x/i/b;->W1(Lcc/bomber/x/g/c;Ltq0;)Lw43;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    return-object p0

    .line 22
    :pswitch_15
    check-cast p1, Ltq0;

    .line 23
    .line 24
    invoke-static {p0, p1}, Lcc/bomber/x/i/b;->e5(Lcc/bomber/x/g/c;Ltq0;)Lw43;

    .line 25
    .line 26
    .line 27
    move-result-object p0

    .line 28
    return-object p0

    .line 29
    :pswitch_1c
    check-cast p1, Lsz0;

    .line 30
    .line 31
    invoke-static {p0, p1}, Lcc/bomber/x/i/b;->D0(Lcc/bomber/x/g/c;Lsz0;)Lw43;

    .line 32
    .line 33
    .line 34
    move-result-object p0

    .line 35
    return-object p0

    .line 36
    :pswitch_23
    check-cast p1, Ltq0;

    .line 37
    .line 38
    invoke-static {p0, p1}, Lcc/bomber/x/i/b;->g5(Lcc/bomber/x/g/c;Ltq0;)Lw43;

    .line 39
    .line 40
    .line 41
    move-result-object p0

    .line 42
    return-object p0

    .line 43
    :pswitch_2a
    check-cast p1, Ltq0;

    .line 44
    .line 45
    invoke-static {p0, p1}, Lcc/bomber/x/i/b;->L2(Lcc/bomber/x/g/c;Ltq0;)Lw43;

    .line 46
    .line 47
    .line 48
    move-result-object p0

    .line 49
    return-object p0

    .line 50
    :pswitch_31
    check-cast p1, Ltq0;

    .line 51
    .line 52
    invoke-static {p0, p1}, Lcc/bomber/x/i/b;->y6(Lcc/bomber/x/g/c;Ltq0;)Lw43;

    .line 53
    .line 54
    .line 55
    move-result-object p0

    .line 56
    return-object p0

    .line 57
    :pswitch_38
    check-cast p1, Lorg/json/JSONObject;

    .line 58
    .line 59
    invoke-static {p0, p1}, Lcc/bomber/x/i/b;->l7(Lcc/bomber/x/g/c;Lorg/json/JSONObject;)Lw43;

    .line 60
    .line 61
    .line 62
    move-result-object p0

    .line 63
    return-object p0

    .line 64
    :pswitch_3f
    check-cast p1, Ltq0;

    .line 65
    .line 66
    invoke-static {p0, p1}, Lcc/bomber/x/i/b;->W0(Lcc/bomber/x/g/c;Ltq0;)Lw43;

    .line 67
    .line 68
    .line 69
    move-result-object p0

    .line 70
    return-object p0

    .line 71
    :pswitch_46
    check-cast p1, Ltq0;

    .line 72
    .line 73
    invoke-static {p0, p1}, Lcc/bomber/x/i/b;->s2(Lcc/bomber/x/g/c;Ltq0;)Lw43;

    .line 74
    .line 75
    .line 76
    move-result-object p0

    .line 77
    return-object p0

    .line 78
    :pswitch_4d
    check-cast p1, Ltq0;

    .line 79
    .line 80
    invoke-static {p0, p1}, Lcc/bomber/x/i/b;->D7(Lcc/bomber/x/g/c;Ltq0;)Lw43;

    .line 81
    .line 82
    .line 83
    move-result-object p0

    .line 84
    return-object p0

    .line 85
    :pswitch_54
    check-cast p1, Ltq0;

    .line 86
    .line 87
    invoke-static {p0, p1}, Lcc/bomber/x/i/b;->i0(Lcc/bomber/x/g/c;Ltq0;)Lw43;

    .line 88
    .line 89
    .line 90
    move-result-object p0

    .line 91
    return-object p0

    .line 92
    :pswitch_5b
    check-cast p1, Ltq0;

    .line 93
    .line 94
    invoke-static {p0, p1}, Lcc/bomber/x/i/b;->w7(Lcc/bomber/x/g/c;Ltq0;)Lw43;

    .line 95
    .line 96
    .line 97
    move-result-object p0

    .line 98
    return-object p0

    .line 99
    :pswitch_62
    check-cast p1, Ltq0;

    .line 100
    .line 101
    invoke-static {p0, p1}, Lcc/bomber/x/i/b;->k4(Lcc/bomber/x/g/c;Ltq0;)Lw43;

    .line 102
    .line 103
    .line 104
    move-result-object p0

    .line 105
    return-object p0

    .line 106
    :pswitch_69
    check-cast p1, Ltq0;

    .line 107
    .line 108
    invoke-static {p0, p1}, Lcc/bomber/x/i/b;->C3(Lcc/bomber/x/g/c;Ltq0;)Lw43;

    .line 109
    .line 110
    .line 111
    move-result-object p0

    .line 112
    return-object p0

    .line 113
    :pswitch_70
    check-cast p1, Ltq0;

    .line 114
    .line 115
    invoke-static {p0, p1}, Lcc/bomber/x/i/b;->l6(Lcc/bomber/x/g/c;Ltq0;)Lw43;

    .line 116
    .line 117
    .line 118
    move-result-object p0

    .line 119
    return-object p0

    .line 120
    :pswitch_77
    check-cast p1, Ltq0;

    .line 121
    .line 122
    invoke-static {p0, p1}, Lcc/bomber/x/i/b;->e3(Lcc/bomber/x/g/c;Ltq0;)Lw43;

    .line 123
    .line 124
    .line 125
    move-result-object p0

    .line 126
    return-object p0

    .line 127
    :pswitch_7e
    check-cast p1, Lsz0;

    .line 128
    .line 129
    invoke-static {p0, p1}, Lcc/bomber/x/i/b;->j5(Lcc/bomber/x/g/c;Lsz0;)Lw43;

    .line 130
    .line 131
    .line 132
    move-result-object p0

    .line 133
    return-object p0

    .line 134
    :pswitch_85
    check-cast p1, Lnu1;

    .line 135
    .line 136
    invoke-static {p0, p1}, Lcc/bomber/x/i/b;->w5(Lcc/bomber/x/g/c;Lnu1;)Lw43;

    .line 137
    .line 138
    .line 139
    move-result-object p0

    .line 140
    return-object p0

    .line 141
    :pswitch_8c
    check-cast p1, Lnu1;

    .line 142
    .line 143
    invoke-static {p0, p1}, Lcc/bomber/x/i/b;->Z6(Lcc/bomber/x/g/c;Lnu1;)Lw43;

    .line 144
    .line 145
    .line 146
    move-result-object p0

    .line 147
    return-object p0

    .line 148
    :pswitch_93
    check-cast p1, Ltq0;

    .line 149
    .line 150
    invoke-static {p0, p1}, Lcc/bomber/x/i/b;->b6(Lcc/bomber/x/g/c;Ltq0;)Lw43;

    .line 151
    .line 152
    .line 153
    move-result-object p0

    .line 154
    return-object p0

    .line 155
    :pswitch_9a
    check-cast p1, Lnu1;

    .line 156
    .line 157
    invoke-static {p0, p1}, Lcc/bomber/x/i/b;->W6(Lcc/bomber/x/g/c;Lnu1;)Lw43;

    .line 158
    .line 159
    .line 160
    move-result-object p0

    .line 161
    return-object p0

    .line 162
    :pswitch_a1
    check-cast p1, Ltq0;

    .line 163
    .line 164
    invoke-static {p0, p1}, Lcc/bomber/x/i/b;->H4(Lcc/bomber/x/g/c;Ltq0;)Lw43;

    .line 165
    .line 166
    .line 167
    move-result-object p0

    .line 168
    return-object p0

    .line 169
    :pswitch_a8
    check-cast p1, Ltq0;

    .line 170
    .line 171
    invoke-static {p0, p1}, Lcc/bomber/x/i/b;->Y1(Lcc/bomber/x/g/c;Ltq0;)Lw43;

    .line 172
    .line 173
    .line 174
    move-result-object p0

    .line 175
    return-object p0

    .line 176
    :pswitch_af
    check-cast p1, Ltq0;

    .line 177
    .line 178
    invoke-static {p0, p1}, Lcc/bomber/x/i/b;->Q3(Lcc/bomber/x/g/c;Ltq0;)Lw43;

    .line 179
    .line 180
    .line 181
    move-result-object p0

    .line 182
    return-object p0

    .line 183
    :pswitch_b6
    check-cast p1, Ltq0;

    .line 184
    .line 185
    invoke-static {p0, p1}, Lcc/bomber/x/i/b;->e8(Lcc/bomber/x/g/c;Ltq0;)Lw43;

    .line 186
    .line 187
    .line 188
    move-result-object p0

    .line 189
    return-object p0

    .line 190
    :pswitch_bd
    check-cast p1, Ltq0;

    .line 191
    .line 192
    invoke-static {p0, p1}, Lcc/bomber/x/i/b;->A7(Lcc/bomber/x/g/c;Ltq0;)Lw43;

    .line 193
    .line 194
    .line 195
    move-result-object p0

    .line 196
    return-object p0

    .line 197
    :pswitch_c4
    check-cast p1, Lsz0;

    .line 198
    .line 199
    invoke-static {p0, p1}, Lcc/bomber/x/i/a;->o(Lcc/bomber/x/g/c;Lsz0;)Lw43;

    .line 200
    .line 201
    .line 202
    move-result-object p0

    .line 203
    return-object p0

    .line 204
    :pswitch_cb
    check-cast p1, Lsz0;

    .line 205
    .line 206
    invoke-static {p0, p1}, Lcc/bomber/x/h/a;->M(Lcc/bomber/x/g/c;Lsz0;)Lw43;

    .line 207
    .line 208
    .line 209
    move-result-object p0

    .line 210
    return-object p0

    .line 211
    :pswitch_d2
    check-cast p1, Ltq0;

    .line 212
    .line 213
    invoke-static {p0, p1}, Lcc/bomber/x/h/a;->H(Lcc/bomber/x/g/c;Ltq0;)Lw43;

    .line 214
    .line 215
    .line 216
    move-result-object p0

    .line 217
    return-object p0

    .line 218
    nop

    .line 219
    :pswitch_data_da
    .packed-switch 0x0
        :pswitch_d2
        :pswitch_cb
        :pswitch_c4
        :pswitch_bd
        :pswitch_b6
        :pswitch_af
        :pswitch_a8
        :pswitch_a1
        :pswitch_9a
        :pswitch_93
        :pswitch_8c
        :pswitch_85
        :pswitch_7e
        :pswitch_77
        :pswitch_70
        :pswitch_69
        :pswitch_62
        :pswitch_5b
        :pswitch_54
        :pswitch_4d
        :pswitch_46
        :pswitch_3f
        :pswitch_38
        :pswitch_31
        :pswitch_2a
        :pswitch_23
        :pswitch_1c
        :pswitch_15
        :pswitch_e
    .end packed-switch
.end method
