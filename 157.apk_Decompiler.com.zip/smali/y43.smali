###### Class defpackage.y43 (y43)
.class public final Ly43;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lif1;


# static fields
.field public static final b:Ly43;


# instance fields
.field public final synthetic a:Lpy1;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Ly43;

    .line 2
    .line 3
    invoke-direct {v0}, Ly43;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Ly43;->b:Ly43;

    .line 7
    .line 8
    return-void
.end method

.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lpy1;

    .line 5
    .line 6
    invoke-direct {v0}, Lpy1;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Ly43;->a:Lpy1;

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final deserialize(Lz60;)Ljava/lang/Object;
    .registers 2

    .line 1
    iget-object p0, p0, Ly43;->a:Lpy1;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lpy1;->deserialize(Lz60;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    sget-object p0, Lw43;->a:Lw43;

    .line 7
    .line 8
    return-object p0
.end method

.method public final getDescriptor()Lwk2;
    .registers 1

    .line 1
    iget-object p0, p0, Ly43;->a:Lpy1;

    .line 2
    .line 3
    invoke-virtual {p0}, Lpy1;->getDescriptor()Lwk2;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final serialize(Lbi0;Ljava/lang/Object;)V
    .registers 3

    .line 1
    check-cast p2, Lw43;

    .line 2
    .line 3
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    iget-object p0, p0, Ly43;->a:Lpy1;

    .line 7
    .line 8
    invoke-virtual {p0, p1, p2}, Lpy1;->serialize(Lbi0;Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method
