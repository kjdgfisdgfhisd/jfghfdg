###### Class defpackage.p4 (p4)
.class public final Lp4;
.super Lw8;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Landroid/content/DialogInterface;


# instance fields
.field public final f:Ln4;


# direct methods
.method public constructor <init>(Landroid/view/ContextThemeWrapper;I)V
    .registers 4

    .line 1
    invoke-static {p1, p2}, Lp4;->e(Landroid/content/Context;I)I

    .line 2
    .line 3
    .line 4
    move-result p2

    .line 5
    invoke-direct {p0, p1, p2}, Lw8;-><init>(Landroid/content/Context;I)V

    .line 6
    .line 7
    .line 8
    new-instance p1, Ln4;

    .line 9
    .line 10
    invoke-virtual {p0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    .line 11
    .line 12
    .line 13
    move-result-object p2

    .line 14
    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    invoke-direct {p1, p2, p0, v0}, Ln4;-><init>(Landroid/content/Context;Lp4;Landroid/view/Window;)V

    .line 19
    .line 20
    .line 21
    iput-object p1, p0, Lp4;->f:Ln4;

    .line 22
    .line 23
    return-void
.end method

.method public static e(Landroid/content/Context;I)I
    .registers 4

    .line 1
    ushr-int/lit8 v0, p1, 0x18

    .line 2
    .line 3
    and-int/lit16 v0, v0, 0xff

    .line 4
    .line 5
    const/4 v1, 0x1

    .line 6
    if-lt v0, v1, :cond_8

    .line 7
    .line 8
    return p1

    .line 9
    :cond_8
    new-instance p1, Landroid/util/TypedValue;

    .line 10
    .line 11
    invoke-direct {p1}, Landroid/util/TypedValue;-><init>()V

    .line 12
    .line 13
    .line 14
    invoke-virtual {p0}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    const v0, 0x7f040030

    .line 19
    .line 20
    .line 21
    invoke-virtual {p0, v0, p1, v1}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    .line 22
    .line 23
    .line 24
    iget p0, p1, Landroid/util/TypedValue;->resourceId:I

    .line 25
    .line 26
    return p0
.end method


# virtual methods
.method public final onCreate(Landroid/os/Bundle;)V
    .registers 18

    .line 1
    invoke-super/range {p0 .. p1}, Lw8;->onCreate(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    move-object/from16 v0, p0

    .line 5
    .line 6
    iget-object v0, v0, Lp4;->f:Ln4;

    .line 7
    .line 8
    iget v1, v0, Ln4;->v:I

    .line 9
    .line 10
    iget-object v2, v0, Ln4;->b:Lp4;

    .line 11
    .line 12
    invoke-virtual {v2, v1}, Lw8;->setContentView(I)V

    .line 13
    .line 14
    .line 15
    iget-object v1, v0, Ln4;->a:Landroid/content/Context;

    .line 16
    .line 17
    iget-object v2, v0, Ln4;->c:Landroid/view/Window;

    .line 18
    .line 19
    const v3, 0x7f0901b6

    .line 20
    .line 21
    .line 22
    invoke-virtual {v2, v3}, Landroid/view/Window;->findViewById(I)Landroid/view/View;

    .line 23
    .line 24
    .line 25
    move-result-object v3

    .line 26
    const v4, 0x7f090282

    .line 27
    .line 28
    .line 29
    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 30
    .line 31
    .line 32
    move-result-object v5

    .line 33
    const v6, 0x7f0900ac

    .line 34
    .line 35
    .line 36
    invoke-virtual {v3, v6}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 37
    .line 38
    .line 39
    move-result-object v7

    .line 40
    const v8, 0x7f090080

    .line 41
    .line 42
    .line 43
    invoke-virtual {v3, v8}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 44
    .line 45
    .line 46
    move-result-object v9

    .line 47
    const v10, 0x7f0900b7

    .line 48
    .line 49
    .line 50
    invoke-virtual {v3, v10}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 51
    .line 52
    .line 53
    move-result-object v3

    .line 54
    check-cast v3, Landroid/view/ViewGroup;

    .line 55
    .line 56
    iget-object v10, v0, Ln4;->g:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 57
    .line 58
    if-eqz v10, :cond_3c

    .line 59
    .line 60
    goto :goto_3d

    .line 61
    :cond_3c
    const/4 v10, 0x0

    .line 62
    :goto_3d
    const/4 v13, 0x0

    .line 63
    if-eqz v10, :cond_42

    .line 64
    .line 65
    const/4 v14, 0x1

    .line 66
    goto :goto_43

    .line 67
    :cond_42
    move v14, v13

    .line 68
    :goto_43
    if-eqz v14, :cond_4b

    .line 69
    .line 70
    invoke-static {v10}, Ln4;->a(Landroid/view/View;)Z

    .line 71
    .line 72
    .line 73
    move-result v15

    .line 74
    if-nez v15, :cond_50

    .line 75
    .line 76
    :cond_4b
    const/high16 v15, 0x20000

    .line 77
    .line 78
    invoke-virtual {v2, v15, v15}, Landroid/view/Window;->setFlags(II)V

    .line 79
    .line 80
    .line 81
    :cond_50
    const/16 v15, 0x8

    .line 82
    .line 83
    const/4 v12, -0x1

    .line 84
    if-eqz v14, :cond_7d

    .line 85
    .line 86
    const v14, 0x7f0900b6

    .line 87
    .line 88
    .line 89
    invoke-virtual {v2, v14}, Landroid/view/Window;->findViewById(I)Landroid/view/View;

    .line 90
    .line 91
    .line 92
    move-result-object v14

    .line 93
    check-cast v14, Landroid/widget/FrameLayout;

    .line 94
    .line 95
    const/16 p1, 0x0

    .line 96
    .line 97
    new-instance v11, Landroid/view/ViewGroup$LayoutParams;

    .line 98
    .line 99
    invoke-direct {v11, v12, v12}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    .line 100
    .line 101
    .line 102
    invoke-virtual {v14, v10, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 103
    .line 104
    .line 105
    iget-boolean v10, v0, Ln4;->h:Z

    .line 106
    .line 107
    if-eqz v10, :cond_6f

    .line 108
    .line 109
    invoke-virtual {v14, v13, v13, v13, v13}, Landroid/view/View;->setPadding(IIII)V

    .line 110
    .line 111
    .line 112
    :cond_6f
    iget-object v10, v0, Ln4;->f:Landroidx/appcompat/app/AlertController$RecycleListView;

    .line 113
    .line 114
    if-eqz v10, :cond_82

    .line 115
    .line 116
    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 117
    .line 118
    .line 119
    move-result-object v10

    .line 120
    check-cast v10, Loj1;

    .line 121
    .line 122
    const/4 v11, 0x0

    .line 123
    iput v11, v10, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    .line 124
    .line 125
    goto :goto_82

    .line 126
    :cond_7d
    const/16 p1, 0x0

    .line 127
    .line 128
    invoke-virtual {v3, v15}, Landroid/view/View;->setVisibility(I)V

    .line 129
    .line 130
    .line 131
    :cond_82
    :goto_82
    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 132
    .line 133
    .line 134
    move-result-object v4

    .line 135
    invoke-virtual {v3, v6}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 136
    .line 137
    .line 138
    move-result-object v6

    .line 139
    invoke-virtual {v3, v8}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 140
    .line 141
    .line 142
    move-result-object v8

    .line 143
    invoke-static {v4, v5}, Ln4;->b(Landroid/view/View;Landroid/view/View;)Landroid/view/ViewGroup;

    .line 144
    .line 145
    .line 146
    move-result-object v4

    .line 147
    invoke-static {v6, v7}, Ln4;->b(Landroid/view/View;Landroid/view/View;)Landroid/view/ViewGroup;

    .line 148
    .line 149
    .line 150
    move-result-object v5

    .line 151
    invoke-static {v8, v9}, Ln4;->b(Landroid/view/View;Landroid/view/View;)Landroid/view/ViewGroup;

    .line 152
    .line 153
    .line 154
    move-result-object v6

    .line 155
    const v7, 0x7f0901ff

    .line 156
    .line 157
    .line 158
    invoke-virtual {v2, v7}, Landroid/view/Window;->findViewById(I)Landroid/view/View;

    .line 159
    .line 160
    .line 161
    move-result-object v7

    .line 162
    check-cast v7, Landroidx/core/widget/NestedScrollView;

    .line 163
    .line 164
    iput-object v7, v0, Ln4;->n:Landroidx/core/widget/NestedScrollView;

    .line 165
    .line 166
    invoke-virtual {v7, v13}, Landroid/view/View;->setFocusable(Z)V

    .line 167
    .line 168
    .line 169
    iget-object v7, v0, Ln4;->n:Landroidx/core/widget/NestedScrollView;

    .line 170
    .line 171
    invoke-virtual {v7, v13}, Landroidx/core/widget/NestedScrollView;->setNestedScrollingEnabled(Z)V

    .line 172
    .line 173
    .line 174
    const v7, 0x102000b

    .line 175
    .line 176
    .line 177
    invoke-virtual {v5, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 178
    .line 179
    .line 180
    move-result-object v7

    .line 181
    check-cast v7, Landroid/widget/TextView;

    .line 182
    .line 183
    iput-object v7, v0, Ln4;->r:Landroid/widget/TextView;

    .line 184
    .line 185
    if-nez v7, :cond_bb

    .line 186
    .line 187
    goto :goto_f0

    .line 188
    :cond_bb
    iget-object v8, v0, Ln4;->e:Ljava/lang/CharSequence;

    .line 189
    .line 190
    if-eqz v8, :cond_c3

    .line 191
    .line 192
    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 193
    .line 194
    .line 195
    goto :goto_f0

    .line 196
    :cond_c3
    invoke-virtual {v7, v15}, Landroid/view/View;->setVisibility(I)V

    .line 197
    .line 198
    .line 199
    iget-object v7, v0, Ln4;->n:Landroidx/core/widget/NestedScrollView;

    .line 200
    .line 201
    iget-object v8, v0, Ln4;->r:Landroid/widget/TextView;

    .line 202
    .line 203
    invoke-virtual {v7, v8}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 204
    .line 205
    .line 206
    iget-object v7, v0, Ln4;->f:Landroidx/appcompat/app/AlertController$RecycleListView;

    .line 207
    .line 208
    if-eqz v7, :cond_ed

    .line 209
    .line 210
    iget-object v7, v0, Ln4;->n:Landroidx/core/widget/NestedScrollView;

    .line 211
    .line 212
    invoke-virtual {v7}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 213
    .line 214
    .line 215
    move-result-object v7

    .line 216
    check-cast v7, Landroid/view/ViewGroup;

    .line 217
    .line 218
    iget-object v8, v0, Ln4;->n:Landroidx/core/widget/NestedScrollView;

    .line 219
    .line 220
    invoke-virtual {v7, v8}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    .line 221
    .line 222
    .line 223
    move-result v8

    .line 224
    invoke-virtual {v7, v8}, Landroid/view/ViewGroup;->removeViewAt(I)V

    .line 225
    .line 226
    .line 227
    iget-object v9, v0, Ln4;->f:Landroidx/appcompat/app/AlertController$RecycleListView;

    .line 228
    .line 229
    new-instance v10, Landroid/view/ViewGroup$LayoutParams;

    .line 230
    .line 231
    invoke-direct {v10, v12, v12}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    .line 232
    .line 233
    .line 234
    invoke-virtual {v7, v9, v8, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    .line 235
    .line 236
    .line 237
    goto :goto_f0

    .line 238
    :cond_ed
    invoke-virtual {v5, v15}, Landroid/view/View;->setVisibility(I)V

    .line 239
    .line 240
    .line 241
    :goto_f0
    const v7, 0x1020019

    .line 242
    .line 243
    .line 244
    invoke-virtual {v6, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 245
    .line 246
    .line 247
    move-result-object v7

    .line 248
    check-cast v7, Landroid/widget/Button;

    .line 249
    .line 250
    iput-object v7, v0, Ln4;->i:Landroid/widget/Button;

    .line 251
    .line 252
    iget-object v8, v0, Ln4;->B:Lh2;

    .line 253
    .line 254
    invoke-virtual {v7, v8}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 255
    .line 256
    .line 257
    iget-object v7, v0, Ln4;->j:Ljava/lang/CharSequence;

    .line 258
    .line 259
    invoke-static {v7}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 260
    .line 261
    .line 262
    move-result v7

    .line 263
    iget-object v9, v0, Ln4;->i:Landroid/widget/Button;

    .line 264
    .line 265
    if-eqz v7, :cond_10f

    .line 266
    .line 267
    invoke-virtual {v9, v15}, Landroid/view/View;->setVisibility(I)V

    .line 268
    .line 269
    .line 270
    move v7, v13

    .line 271
    goto :goto_11a

    .line 272
    :cond_10f
    iget-object v7, v0, Ln4;->j:Ljava/lang/CharSequence;

    .line 273
    .line 274
    invoke-virtual {v9, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 275
    .line 276
    .line 277
    iget-object v7, v0, Ln4;->i:Landroid/widget/Button;

    .line 278
    .line 279
    invoke-virtual {v7, v13}, Landroid/view/View;->setVisibility(I)V

    .line 280
    .line 281
    .line 282
    const/4 v7, 0x1

    .line 283
    :goto_11a
    const v9, 0x102001a

    .line 284
    .line 285
    .line 286
    invoke-virtual {v6, v9}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 287
    .line 288
    .line 289
    move-result-object v9

    .line 290
    check-cast v9, Landroid/widget/Button;

    .line 291
    .line 292
    iput-object v9, v0, Ln4;->l:Landroid/widget/Button;

    .line 293
    .line 294
    invoke-virtual {v9, v8}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 295
    .line 296
    .line 297
    invoke-static/range {p1 .. p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 298
    .line 299
    .line 300
    move-result v9

    .line 301
    iget-object v10, v0, Ln4;->l:Landroid/widget/Button;

    .line 302
    .line 303
    if-eqz v9, :cond_136

    .line 304
    .line 305
    invoke-virtual {v10, v15}, Landroid/view/View;->setVisibility(I)V

    .line 306
    .line 307
    .line 308
    move-object/from16 v9, p1

    .line 309
    .line 310
    goto :goto_142

    .line 311
    :cond_136
    move-object/from16 v9, p1

    .line 312
    .line 313
    invoke-virtual {v10, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 314
    .line 315
    .line 316
    iget-object v10, v0, Ln4;->l:Landroid/widget/Button;

    .line 317
    .line 318
    invoke-virtual {v10, v13}, Landroid/view/View;->setVisibility(I)V

    .line 319
    .line 320
    .line 321
    or-int/lit8 v7, v7, 0x2

    .line 322
    .line 323
    :goto_142
    const v10, 0x102001b

    .line 324
    .line 325
    .line 326
    invoke-virtual {v6, v10}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 327
    .line 328
    .line 329
    move-result-object v10

    .line 330
    check-cast v10, Landroid/widget/Button;

    .line 331
    .line 332
    iput-object v10, v0, Ln4;->m:Landroid/widget/Button;

    .line 333
    .line 334
    invoke-virtual {v10, v8}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 335
    .line 336
    .line 337
    invoke-static {v9}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 338
    .line 339
    .line 340
    move-result v8

    .line 341
    iget-object v10, v0, Ln4;->m:Landroid/widget/Button;

    .line 342
    .line 343
    if-eqz v8, :cond_15c

    .line 344
    .line 345
    invoke-virtual {v10, v15}, Landroid/view/View;->setVisibility(I)V

    .line 346
    .line 347
    .line 348
    goto :goto_166

    .line 349
    :cond_15c
    invoke-virtual {v10, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 350
    .line 351
    .line 352
    iget-object v8, v0, Ln4;->m:Landroid/widget/Button;

    .line 353
    .line 354
    invoke-virtual {v8, v13}, Landroid/view/View;->setVisibility(I)V

    .line 355
    .line 356
    .line 357
    or-int/lit8 v7, v7, 0x4

    .line 358
    .line 359
    :goto_166
    new-instance v8, Landroid/util/TypedValue;

    .line 360
    .line 361
    invoke-direct {v8}, Landroid/util/TypedValue;-><init>()V

    .line 362
    .line 363
    .line 364
    invoke-virtual {v1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 365
    .line 366
    .line 367
    move-result-object v1

    .line 368
    const v10, 0x7f04002e

    .line 369
    .line 370
    .line 371
    const/4 v11, 0x1

    .line 372
    invoke-virtual {v1, v10, v8, v11}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    .line 373
    .line 374
    .line 375
    iget v1, v8, Landroid/util/TypedValue;->data:I

    .line 376
    .line 377
    const/4 v8, 0x2

    .line 378
    if-eqz v1, :cond_1b3

    .line 379
    .line 380
    const/high16 v1, 0x3f000000    # 0.5f

    .line 381
    .line 382
    if-ne v7, v11, :cond_18f

    .line 383
    .line 384
    iget-object v10, v0, Ln4;->i:Landroid/widget/Button;

    .line 385
    .line 386
    invoke-virtual {v10}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 387
    .line 388
    .line 389
    move-result-object v14

    .line 390
    check-cast v14, Landroid/widget/LinearLayout$LayoutParams;

    .line 391
    .line 392
    iput v11, v14, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    .line 393
    .line 394
    iput v1, v14, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    .line 395
    .line 396
    invoke-virtual {v10, v14}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 397
    .line 398
    .line 399
    goto :goto_1b3

    .line 400
    :cond_18f
    if-ne v7, v8, :cond_1a1

    .line 401
    .line 402
    iget-object v10, v0, Ln4;->l:Landroid/widget/Button;

    .line 403
    .line 404
    invoke-virtual {v10}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 405
    .line 406
    .line 407
    move-result-object v14

    .line 408
    check-cast v14, Landroid/widget/LinearLayout$LayoutParams;

    .line 409
    .line 410
    iput v11, v14, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    .line 411
    .line 412
    iput v1, v14, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    .line 413
    .line 414
    invoke-virtual {v10, v14}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 415
    .line 416
    .line 417
    goto :goto_1b3

    .line 418
    :cond_1a1
    const/4 v10, 0x4

    .line 419
    if-ne v7, v10, :cond_1b3

    .line 420
    .line 421
    iget-object v10, v0, Ln4;->m:Landroid/widget/Button;

    .line 422
    .line 423
    invoke-virtual {v10}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 424
    .line 425
    .line 426
    move-result-object v14

    .line 427
    check-cast v14, Landroid/widget/LinearLayout$LayoutParams;

    .line 428
    .line 429
    iput v11, v14, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    .line 430
    .line 431
    iput v1, v14, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    .line 432
    .line 433
    invoke-virtual {v10, v14}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 434
    .line 435
    .line 436
    :cond_1b3
    :goto_1b3
    if-eqz v7, :cond_1b6

    .line 437
    .line 438
    goto :goto_1b9

    .line 439
    :cond_1b6
    invoke-virtual {v6, v15}, Landroid/view/View;->setVisibility(I)V

    .line 440
    .line 441
    .line 442
    :goto_1b9
    iget-object v1, v0, Ln4;->s:Landroid/view/View;

    .line 443
    .line 444
    const v7, 0x7f09027f

    .line 445
    .line 446
    .line 447
    if-eqz v1, :cond_1d3

    .line 448
    .line 449
    new-instance v1, Landroid/view/ViewGroup$LayoutParams;

    .line 450
    .line 451
    const/4 v10, -0x2

    .line 452
    invoke-direct {v1, v12, v10}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    .line 453
    .line 454
    .line 455
    iget-object v10, v0, Ln4;->s:Landroid/view/View;

    .line 456
    .line 457
    invoke-virtual {v4, v10, v13, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    .line 458
    .line 459
    .line 460
    invoke-virtual {v2, v7}, Landroid/view/Window;->findViewById(I)Landroid/view/View;

    .line 461
    .line 462
    .line 463
    move-result-object v1

    .line 464
    invoke-virtual {v1, v15}, Landroid/view/View;->setVisibility(I)V

    .line 465
    .line 466
    .line 467
    goto :goto_236

    .line 468
    :cond_1d3
    const v1, 0x1020006

    .line 469
    .line 470
    .line 471
    invoke-virtual {v2, v1}, Landroid/view/Window;->findViewById(I)Landroid/view/View;

    .line 472
    .line 473
    .line 474
    move-result-object v1

    .line 475
    check-cast v1, Landroid/widget/ImageView;

    .line 476
    .line 477
    iput-object v1, v0, Ln4;->p:Landroid/widget/ImageView;

    .line 478
    .line 479
    iget-object v1, v0, Ln4;->d:Ljava/lang/CharSequence;

    .line 480
    .line 481
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 482
    .line 483
    .line 484
    move-result v1

    .line 485
    if-nez v1, :cond_227

    .line 486
    .line 487
    iget-boolean v1, v0, Ln4;->z:Z

    .line 488
    .line 489
    if-eqz v1, :cond_227

    .line 490
    .line 491
    const v1, 0x7f090054

    .line 492
    .line 493
    .line 494
    invoke-virtual {v2, v1}, Landroid/view/Window;->findViewById(I)Landroid/view/View;

    .line 495
    .line 496
    .line 497
    move-result-object v1

    .line 498
    check-cast v1, Landroid/widget/TextView;

    .line 499
    .line 500
    iput-object v1, v0, Ln4;->q:Landroid/widget/TextView;

    .line 501
    .line 502
    iget-object v7, v0, Ln4;->d:Ljava/lang/CharSequence;

    .line 503
    .line 504
    invoke-virtual {v1, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 505
    .line 506
    .line 507
    iget-object v1, v0, Ln4;->o:Landroid/graphics/drawable/Drawable;

    .line 508
    .line 509
    if-eqz v1, :cond_204

    .line 510
    .line 511
    iget-object v7, v0, Ln4;->p:Landroid/widget/ImageView;

    .line 512
    .line 513
    invoke-virtual {v7, v1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 514
    .line 515
    .line 516
    goto :goto_236

    .line 517
    :cond_204
    iget-object v1, v0, Ln4;->q:Landroid/widget/TextView;

    .line 518
    .line 519
    iget-object v7, v0, Ln4;->p:Landroid/widget/ImageView;

    .line 520
    .line 521
    invoke-virtual {v7}, Landroid/view/View;->getPaddingLeft()I

    .line 522
    .line 523
    .line 524
    move-result v7

    .line 525
    iget-object v10, v0, Ln4;->p:Landroid/widget/ImageView;

    .line 526
    .line 527
    invoke-virtual {v10}, Landroid/view/View;->getPaddingTop()I

    .line 528
    .line 529
    .line 530
    move-result v10

    .line 531
    iget-object v11, v0, Ln4;->p:Landroid/widget/ImageView;

    .line 532
    .line 533
    invoke-virtual {v11}, Landroid/view/View;->getPaddingRight()I

    .line 534
    .line 535
    .line 536
    move-result v11

    .line 537
    iget-object v14, v0, Ln4;->p:Landroid/widget/ImageView;

    .line 538
    .line 539
    invoke-virtual {v14}, Landroid/view/View;->getPaddingBottom()I

    .line 540
    .line 541
    .line 542
    move-result v14

    .line 543
    invoke-virtual {v1, v7, v10, v11, v14}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 544
    .line 545
    .line 546
    iget-object v1, v0, Ln4;->p:Landroid/widget/ImageView;

    .line 547
    .line 548
    invoke-virtual {v1, v15}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 549
    .line 550
    .line 551
    goto :goto_236

    .line 552
    :cond_227
    invoke-virtual {v2, v7}, Landroid/view/Window;->findViewById(I)Landroid/view/View;

    .line 553
    .line 554
    .line 555
    move-result-object v1

    .line 556
    invoke-virtual {v1, v15}, Landroid/view/View;->setVisibility(I)V

    .line 557
    .line 558
    .line 559
    iget-object v1, v0, Ln4;->p:Landroid/widget/ImageView;

    .line 560
    .line 561
    invoke-virtual {v1, v15}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 562
    .line 563
    .line 564
    invoke-virtual {v4, v15}, Landroid/view/View;->setVisibility(I)V

    .line 565
    .line 566
    .line 567
    :goto_236
    invoke-virtual {v3}, Landroid/view/View;->getVisibility()I

    .line 568
    .line 569
    .line 570
    move-result v1

    .line 571
    if-eq v1, v15, :cond_23e

    .line 572
    .line 573
    const/4 v11, 0x1

    .line 574
    goto :goto_23f

    .line 575
    :cond_23e
    move v11, v13

    .line 576
    :goto_23f
    if-eqz v4, :cond_249

    .line 577
    .line 578
    invoke-virtual {v4}, Landroid/view/View;->getVisibility()I

    .line 579
    .line 580
    .line 581
    move-result v1

    .line 582
    if-eq v1, v15, :cond_249

    .line 583
    .line 584
    const/4 v1, 0x1

    .line 585
    goto :goto_24a

    .line 586
    :cond_249
    move v1, v13

    .line 587
    :goto_24a
    invoke-virtual {v6}, Landroid/view/View;->getVisibility()I

    .line 588
    .line 589
    .line 590
    move-result v3

    .line 591
    if-eq v3, v15, :cond_252

    .line 592
    .line 593
    const/4 v3, 0x1

    .line 594
    goto :goto_253

    .line 595
    :cond_252
    move v3, v13

    .line 596
    :goto_253
    if-nez v3, :cond_261

    .line 597
    .line 598
    const v6, 0x7f09026a

    .line 599
    .line 600
    .line 601
    invoke-virtual {v5, v6}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 602
    .line 603
    .line 604
    move-result-object v6

    .line 605
    if-eqz v6, :cond_261

    .line 606
    .line 607
    invoke-virtual {v6, v13}, Landroid/view/View;->setVisibility(I)V

    .line 608
    .line 609
    .line 610
    :cond_261
    if-eqz v1, :cond_283

    .line 611
    .line 612
    iget-object v6, v0, Ln4;->n:Landroidx/core/widget/NestedScrollView;

    .line 613
    .line 614
    if-eqz v6, :cond_26b

    .line 615
    .line 616
    const/4 v7, 0x1

    .line 617
    invoke-virtual {v6, v7}, Landroid/view/ViewGroup;->setClipToPadding(Z)V

    .line 618
    .line 619
    .line 620
    :cond_26b
    iget-object v6, v0, Ln4;->e:Ljava/lang/CharSequence;

    .line 621
    .line 622
    if-nez v6, :cond_276

    .line 623
    .line 624
    iget-object v6, v0, Ln4;->f:Landroidx/appcompat/app/AlertController$RecycleListView;

    .line 625
    .line 626
    if-eqz v6, :cond_274

    .line 627
    .line 628
    goto :goto_276

    .line 629
    :cond_274
    move-object v4, v9

    .line 630
    goto :goto_27d

    .line 631
    :cond_276
    :goto_276
    const v6, 0x7f09027e

    .line 632
    .line 633
    .line 634
    invoke-virtual {v4, v6}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 635
    .line 636
    .line 637
    move-result-object v4

    .line 638
    :goto_27d
    if-eqz v4, :cond_28f

    .line 639
    .line 640
    invoke-virtual {v4, v13}, Landroid/view/View;->setVisibility(I)V

    .line 641
    .line 642
    .line 643
    goto :goto_28f

    .line 644
    :cond_283
    const v4, 0x7f09026b

    .line 645
    .line 646
    .line 647
    invoke-virtual {v5, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 648
    .line 649
    .line 650
    move-result-object v4

    .line 651
    if-eqz v4, :cond_28f

    .line 652
    .line 653
    invoke-virtual {v4, v13}, Landroid/view/View;->setVisibility(I)V

    .line 654
    .line 655
    .line 656
    :cond_28f
    :goto_28f
    iget-object v4, v0, Ln4;->f:Landroidx/appcompat/app/AlertController$RecycleListView;

    .line 657
    .line 658
    if-eqz v4, :cond_2b4

    .line 659
    .line 660
    if-eqz v3, :cond_297

    .line 661
    .line 662
    if-nez v1, :cond_2b4

    .line 663
    .line 664
    :cond_297
    invoke-virtual {v4}, Landroid/view/View;->getPaddingLeft()I

    .line 665
    .line 666
    .line 667
    move-result v6

    .line 668
    if-eqz v1, :cond_2a2

    .line 669
    .line 670
    invoke-virtual {v4}, Landroid/view/View;->getPaddingTop()I

    .line 671
    .line 672
    .line 673
    move-result v7

    .line 674
    goto :goto_2a4

    .line 675
    :cond_2a2
    iget v7, v4, Landroidx/appcompat/app/AlertController$RecycleListView;->a:I

    .line 676
    .line 677
    :goto_2a4
    invoke-virtual {v4}, Landroid/view/View;->getPaddingRight()I

    .line 678
    .line 679
    .line 680
    move-result v9

    .line 681
    if-eqz v3, :cond_2af

    .line 682
    .line 683
    invoke-virtual {v4}, Landroid/view/View;->getPaddingBottom()I

    .line 684
    .line 685
    .line 686
    move-result v10

    .line 687
    goto :goto_2b1

    .line 688
    :cond_2af
    iget v10, v4, Landroidx/appcompat/app/AlertController$RecycleListView;->b:I

    .line 689
    .line 690
    :goto_2b1
    invoke-virtual {v4, v6, v7, v9, v10}, Landroid/view/View;->setPadding(IIII)V

    .line 691
    .line 692
    .line 693
    :cond_2b4
    if-nez v11, :cond_2e1

    .line 694
    .line 695
    iget-object v4, v0, Ln4;->f:Landroidx/appcompat/app/AlertController$RecycleListView;

    .line 696
    .line 697
    if-eqz v4, :cond_2bb

    .line 698
    .line 699
    goto :goto_2bd

    .line 700
    :cond_2bb
    iget-object v4, v0, Ln4;->n:Landroidx/core/widget/NestedScrollView;

    .line 701
    .line 702
    :goto_2bd
    if-eqz v4, :cond_2e1

    .line 703
    .line 704
    if-eqz v3, :cond_2c2

    .line 705
    .line 706
    move v13, v8

    .line 707
    :cond_2c2
    or-int/2addr v1, v13

    .line 708
    const v3, 0x7f0901fe

    .line 709
    .line 710
    .line 711
    invoke-virtual {v2, v3}, Landroid/view/Window;->findViewById(I)Landroid/view/View;

    .line 712
    .line 713
    .line 714
    move-result-object v3

    .line 715
    const v6, 0x7f0901fd

    .line 716
    .line 717
    .line 718
    invoke-virtual {v2, v6}, Landroid/view/Window;->findViewById(I)Landroid/view/View;

    .line 719
    .line 720
    .line 721
    move-result-object v2

    .line 722
    sget-object v6, Ln83;->a:Ljava/util/WeakHashMap;

    .line 723
    .line 724
    const/4 v6, 0x3

    .line 725
    invoke-virtual {v4, v1, v6}, Landroid/view/View;->setScrollIndicators(II)V

    .line 726
    .line 727
    .line 728
    if-eqz v3, :cond_2dc

    .line 729
    .line 730
    invoke-virtual {v5, v3}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 731
    .line 732
    .line 733
    :cond_2dc
    if-eqz v2, :cond_2e1

    .line 734
    .line 735
    invoke-virtual {v5, v2}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 736
    .line 737
    .line 738
    :cond_2e1
    iget-object v1, v0, Ln4;->f:Landroidx/appcompat/app/AlertController$RecycleListView;

    .line 739
    .line 740
    if-eqz v1, :cond_2f7

    .line 741
    .line 742
    iget-object v2, v0, Ln4;->t:Landroid/widget/ListAdapter;

    .line 743
    .line 744
    if-eqz v2, :cond_2f7

    .line 745
    .line 746
    invoke-virtual {v1, v2}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 747
    .line 748
    .line 749
    iget v0, v0, Ln4;->u:I

    .line 750
    .line 751
    if-le v0, v12, :cond_2f7

    .line 752
    .line 753
    const/4 v7, 0x1

    .line 754
    invoke-virtual {v1, v0, v7}, Landroid/widget/AbsListView;->setItemChecked(IZ)V

    .line 755
    .line 756
    .line 757
    invoke-virtual {v1, v0}, Landroid/widget/ListView;->setSelection(I)V

    .line 758
    .line 759
    .line 760
    :cond_2f7
    return-void
.end method

.method public final onKeyDown(ILandroid/view/KeyEvent;)Z
    .registers 4

    .line 1
    iget-object v0, p0, Lp4;->f:Ln4;

    .line 2
    .line 3
    iget-object v0, v0, Ln4;->n:Landroidx/core/widget/NestedScrollView;

    .line 4
    .line 5
    if-eqz v0, :cond_e

    .line 6
    .line 7
    invoke-virtual {v0, p2}, Landroidx/core/widget/NestedScrollView;->j(Landroid/view/KeyEvent;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_e

    .line 12
    .line 13
    const/4 p0, 0x1

    .line 14
    return p0

    .line 15
    :cond_e
    invoke-super {p0, p1, p2}, Landroid/app/Dialog;->onKeyDown(ILandroid/view/KeyEvent;)Z

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    return p0
.end method

.method public final onKeyUp(ILandroid/view/KeyEvent;)Z
    .registers 4

    .line 1
    iget-object v0, p0, Lp4;->f:Ln4;

    .line 2
    .line 3
    iget-object v0, v0, Ln4;->n:Landroidx/core/widget/NestedScrollView;

    .line 4
    .line 5
    if-eqz v0, :cond_e

    .line 6
    .line 7
    invoke-virtual {v0, p2}, Landroidx/core/widget/NestedScrollView;->j(Landroid/view/KeyEvent;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_e

    .line 12
    .line 13
    const/4 p0, 0x1

    .line 14
    return p0

    .line 15
    :cond_e
    invoke-super {p0, p1, p2}, Landroid/app/Dialog;->onKeyUp(ILandroid/view/KeyEvent;)Z

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    return p0
.end method

.method public final setTitle(Ljava/lang/CharSequence;)V
    .registers 3

    .line 1
    invoke-super {p0, p1}, Lw8;->setTitle(Ljava/lang/CharSequence;)V

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lp4;->f:Ln4;

    .line 5
    .line 6
    iput-object p1, p0, Ln4;->d:Ljava/lang/CharSequence;

    .line 7
    .line 8
    iget-object v0, p0, Ln4;->q:Landroid/widget/TextView;

    .line 9
    .line 10
    if-eqz v0, :cond_e

    .line 11
    .line 12
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 13
    .line 14
    .line 15
    :cond_e
    iget-object p0, p0, Ln4;->c:Landroid/view/Window;

    .line 16
    .line 17
    invoke-virtual {p0, p1}, Landroid/view/Window;->setTitle(Ljava/lang/CharSequence;)V

    .line 18
    .line 19
    .line 20
    return-void
.end method
