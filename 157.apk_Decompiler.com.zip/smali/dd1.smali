###### Class defpackage.dd1 (dd1)
.class public final synthetic Ldd1;
.super Lnu0;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Ltt0;


# static fields
.field public static final j:Ldd1;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Ldd1;

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    invoke-direct {v0, v1}, Lnu0;-><init>(I)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Ldd1;->j:Ldd1;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final b()Lkd1;
    .registers 2

    .line 1
    const-class p0, Lqr1;

    .line 2
    .line 3
    sget-object v0, Ltd2;->a:Lud2;

    .line 4
    .line 5
    invoke-virtual {v0, p0}, Lud2;->b(Ljava/lang/Class;)Lwc1;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public final d()Ljava/lang/String;
    .registers 1

    .line 1
    const-string p0, "loadProperty(Lorg/jetbrains/kotlin/metadata/ProtoBuf$Property;)Lorg/jetbrains/kotlin/descriptors/PropertyDescriptor;"

    .line 2
    .line 3
    return-object p0
.end method

.method public final getName()Ljava/lang/String;
    .registers 1

    .line 1
    const-string p0, "loadProperty"

    .line 2
    .line 3
    return-object p0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    check-cast p1, Lqr1;

    .line 2
    .line 3
    check-cast p2, Li72;

    .line 4
    .line 5
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    .line 10
    .line 11
    invoke-virtual {p1, p2}, Lqr1;->f(Li72;)Lac0;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    return-object p0
.end method
