###### Class defpackage.wx1 (wx1)
.class public final Lwx1;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lif1;


# instance fields
.field public final a:Lif1;

.field public final b:Lxk2;


# direct methods
.method public constructor <init>(Lif1;)V
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lwx1;->a:Lif1;

    .line 8
    .line 9
    new-instance v0, Lxk2;

    .line 10
    .line 11
    invoke-interface {p1}, Lif1;->getDescriptor()Lwk2;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    invoke-direct {v0, p1}, Lxk2;-><init>(Lwk2;)V

    .line 16
    .line 17
    .line 18
    iput-object v0, p0, Lwx1;->b:Lxk2;

    .line 19
    .line 20
    return-void
.end method


# virtual methods
.method public final deserialize(Lz60;)Ljava/lang/Object;
    .registers 3

    .line 1
    invoke-interface {p1}, Lz60;->g()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_f

    .line 6
    .line 7
    iget-object p0, p0, Lwx1;->a:Lif1;

    .line 8
    .line 9
    check-cast p0, Lif1;

    .line 10
    .line 11
    invoke-interface {p1, p0}, Lz60;->c(Lif1;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    return-object p0

    .line 16
    :cond_f
    const/4 p0, 0x0

    .line 17
    return-object p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_4

    .line 3
    .line 4
    return v0

    .line 5
    :cond_4
    const/4 v1, 0x0

    .line 6
    if-eqz p1, :cond_1e

    .line 7
    .line 8
    const-class v2, Lwx1;

    .line 9
    .line 10
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    move-result-object v3

    .line 14
    if-eq v2, v3, :cond_10

    .line 15
    .line 16
    goto :goto_1e

    .line 17
    :cond_10
    check-cast p1, Lwx1;

    .line 18
    .line 19
    iget-object p0, p0, Lwx1;->a:Lif1;

    .line 20
    .line 21
    iget-object p1, p1, Lwx1;->a:Lif1;

    .line 22
    .line 23
    invoke-static {p0, p1}, Ld31;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result p0

    .line 27
    if-nez p0, :cond_1d

    .line 28
    .line 29
    return v1

    .line 30
    :cond_1d
    return v0

    .line 31
    :cond_1e
    :goto_1e
    return v1
.end method

.method public final getDescriptor()Lwk2;
    .registers 1

    .line 1
    iget-object p0, p0, Lwx1;->b:Lxk2;

    .line 2
    .line 3
    return-object p0
.end method

.method public final hashCode()I
    .registers 1

    .line 1
    iget-object p0, p0, Lwx1;->a:Lif1;

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final serialize(Lbi0;Ljava/lang/Object;)V
    .registers 3

    .line 1
    if-eqz p2, :cond_a

    .line 2
    .line 3
    iget-object p0, p0, Lwx1;->a:Lif1;

    .line 4
    .line 5
    check-cast p0, Lif1;

    .line 6
    .line 7
    invoke-interface {p1, p0, p2}, Lbi0;->e(Lif1;Ljava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    return-void

    .line 11
    :cond_a
    invoke-interface {p1}, Lbi0;->c()V

    .line 12
    .line 13
    .line 14
    return-void
.end method
