###### Class defpackage.rb1 (rb1)
.class public final Lrb1;
.super Lgk;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field public static final g:Lrb1;

.field public static final h:Lrb1;


# instance fields
.field public final f:Z


# direct methods
.method static constructor <clinit>()V
    .registers 6

    .line 1
    new-instance v0, Lrb1;

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    const/4 v2, 0x0

    .line 5
    filled-new-array {v1, v2, v2}, [I

    .line 6
    .line 7
    .line 8
    move-result-object v3

    .line 9
    invoke-direct {v0, v3, v2}, Lrb1;-><init>([IZ)V

    .line 10
    .line 11
    .line 12
    sput-object v0, Lrb1;->g:Lrb1;

    .line 13
    .line 14
    iget v3, v0, Lgk;->c:I

    .line 15
    .line 16
    iget v0, v0, Lgk;->b:I

    .line 17
    .line 18
    const/4 v4, 0x1

    .line 19
    if-ne v0, v4, :cond_22

    .line 20
    .line 21
    const/16 v5, 0x9

    .line 22
    .line 23
    if-ne v3, v5, :cond_22

    .line 24
    .line 25
    new-instance v0, Lrb1;

    .line 26
    .line 27
    filled-new-array {v1, v2, v2}, [I

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    invoke-direct {v0, v1, v2}, Lrb1;-><init>([IZ)V

    .line 32
    .line 33
    .line 34
    goto :goto_2d

    .line 35
    :cond_22
    new-instance v1, Lrb1;

    .line 36
    .line 37
    add-int/2addr v3, v4

    .line 38
    filled-new-array {v0, v3, v2}, [I

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    invoke-direct {v1, v0, v2}, Lrb1;-><init>([IZ)V

    .line 43
    .line 44
    .line 45
    move-object v0, v1

    .line 46
    :goto_2d
    sput-object v0, Lrb1;->h:Lrb1;

    .line 47
    .line 48
    new-instance v0, Lrb1;

    .line 49
    .line 50
    new-array v1, v2, [I

    .line 51
    .line 52
    invoke-direct {v0, v1, v2}, Lrb1;-><init>([IZ)V

    .line 53
    .line 54
    .line 55
    return-void
.end method

.method public constructor <init>([IZ)V
    .registers 4

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    array-length v0, p1

    .line 5
    invoke-static {p1, v0}, Ljava/util/Arrays;->copyOf([II)[I

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    invoke-direct {p0, p1}, Lgk;-><init>([I)V

    .line 10
    .line 11
    .line 12
    iput-boolean p2, p0, Lrb1;->f:Z

    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final b(Lrb1;)Z
    .registers 8

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x2

    .line 5
    sget-object v1, Lrb1;->g:Lrb1;

    .line 6
    .line 7
    iget v2, p0, Lgk;->c:I

    .line 8
    .line 9
    const/4 v3, 0x1

    .line 10
    iget v4, p0, Lgk;->b:I

    .line 11
    .line 12
    if-ne v4, v0, :cond_1a

    .line 13
    .line 14
    if-nez v2, :cond_1a

    .line 15
    .line 16
    iget v0, v1, Lgk;->b:I

    .line 17
    .line 18
    if-ne v0, v3, :cond_1a

    .line 19
    .line 20
    iget v0, v1, Lgk;->c:I

    .line 21
    .line 22
    const/16 v5, 0x8

    .line 23
    .line 24
    if-ne v0, v5, :cond_1a

    .line 25
    .line 26
    return v3

    .line 27
    :cond_1a
    iget-boolean p0, p0, Lrb1;->f:Z

    .line 28
    .line 29
    if-eqz p0, :cond_1f

    .line 30
    .line 31
    goto :goto_21

    .line 32
    :cond_1f
    sget-object v1, Lrb1;->h:Lrb1;

    .line 33
    .line 34
    :goto_21
    iget p0, v1, Lgk;->b:I

    .line 35
    .line 36
    iget v0, p1, Lgk;->b:I

    .line 37
    .line 38
    if-le p0, v0, :cond_28

    .line 39
    .line 40
    goto :goto_31

    .line 41
    :cond_28
    if-ge p0, v0, :cond_2b

    .line 42
    .line 43
    goto :goto_32

    .line 44
    :cond_2b
    iget p0, v1, Lgk;->c:I

    .line 45
    .line 46
    iget v0, p1, Lgk;->c:I

    .line 47
    .line 48
    if-le p0, v0, :cond_32

    .line 49
    .line 50
    :goto_31
    move-object p1, v1

    .line 51
    :cond_32
    :goto_32
    const/4 p0, 0x0

    .line 52
    if-ne v4, v3, :cond_38

    .line 53
    .line 54
    if-nez v2, :cond_38

    .line 55
    .line 56
    goto :goto_3a

    .line 57
    :cond_38
    if-nez v4, :cond_3b

    .line 58
    .line 59
    :goto_3a
    return p0

    .line 60
    :cond_3b
    iget v0, p1, Lgk;->b:I

    .line 61
    .line 62
    if-le v4, v0, :cond_40

    .line 63
    .line 64
    goto :goto_47

    .line 65
    :cond_40
    if-ge v4, v0, :cond_43

    .line 66
    .line 67
    goto :goto_48

    .line 68
    :cond_43
    iget p1, p1, Lgk;->c:I

    .line 69
    .line 70
    if-le v2, p1, :cond_48

    .line 71
    .line 72
    :goto_47
    move p0, v3

    .line 73
    :cond_48
    :goto_48
    xor-int/2addr p0, v3

    .line 74
    return p0
.end method
