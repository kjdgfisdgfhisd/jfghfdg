###### Class defpackage.g7 (g7)
.class public final enum Lg7;
.super Ljava/lang/Enum;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field public static final enum b:Lg7;

.field public static final enum c:Lg7;

.field public static final enum d:Lg7;

.field public static final enum e:Lg7;

.field public static final enum f:Lg7;

.field public static final enum g:Lg7;

.field public static final enum j:Lg7;

.field public static final enum l:Lg7;

.field public static final enum m:Lg7;

.field public static final synthetic n:[Lg7;


# instance fields
.field public final a:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 12

    .line 1
    new-instance v0, Lg7;

    .line 2
    .line 3
    const-string v1, "FIELD"

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v3, 0x0

    .line 7
    invoke-direct {v0, v1, v2, v3}, Lg7;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    .line 8
    .line 9
    .line 10
    sput-object v0, Lg7;->b:Lg7;

    .line 11
    .line 12
    new-instance v1, Lg7;

    .line 13
    .line 14
    const-string v3, "FILE"

    .line 15
    .line 16
    const/4 v4, 0x1

    .line 17
    invoke-direct {v1, v3, v2, v4}, Lg7;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    .line 18
    .line 19
    .line 20
    sput-object v1, Lg7;->c:Lg7;

    .line 21
    .line 22
    move-object v3, v2

    .line 23
    new-instance v2, Lg7;

    .line 24
    .line 25
    const-string v4, "PROPERTY"

    .line 26
    .line 27
    const/4 v5, 0x2

    .line 28
    invoke-direct {v2, v4, v3, v5}, Lg7;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    .line 29
    .line 30
    .line 31
    sput-object v2, Lg7;->d:Lg7;

    .line 32
    .line 33
    move-object v4, v3

    .line 34
    new-instance v3, Lg7;

    .line 35
    .line 36
    const/4 v5, 0x3

    .line 37
    const-string v6, "get"

    .line 38
    .line 39
    const-string v7, "PROPERTY_GETTER"

    .line 40
    .line 41
    invoke-direct {v3, v7, v6, v5}, Lg7;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    .line 42
    .line 43
    .line 44
    sput-object v3, Lg7;->e:Lg7;

    .line 45
    .line 46
    move-object v5, v4

    .line 47
    new-instance v4, Lg7;

    .line 48
    .line 49
    const/4 v6, 0x4

    .line 50
    const-string v7, "set"

    .line 51
    .line 52
    const-string v8, "PROPERTY_SETTER"

    .line 53
    .line 54
    invoke-direct {v4, v8, v7, v6}, Lg7;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    .line 55
    .line 56
    .line 57
    sput-object v4, Lg7;->f:Lg7;

    .line 58
    .line 59
    move-object v6, v5

    .line 60
    new-instance v5, Lg7;

    .line 61
    .line 62
    const-string v7, "RECEIVER"

    .line 63
    .line 64
    const/4 v8, 0x5

    .line 65
    invoke-direct {v5, v7, v6, v8}, Lg7;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    .line 66
    .line 67
    .line 68
    sput-object v5, Lg7;->g:Lg7;

    .line 69
    .line 70
    new-instance v6, Lg7;

    .line 71
    .line 72
    const/4 v7, 0x6

    .line 73
    const-string v8, "param"

    .line 74
    .line 75
    const-string v9, "CONSTRUCTOR_PARAMETER"

    .line 76
    .line 77
    invoke-direct {v6, v9, v8, v7}, Lg7;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    .line 78
    .line 79
    .line 80
    sput-object v6, Lg7;->j:Lg7;

    .line 81
    .line 82
    new-instance v7, Lg7;

    .line 83
    .line 84
    const/4 v8, 0x7

    .line 85
    const-string v9, "setparam"

    .line 86
    .line 87
    const-string v10, "SETTER_PARAMETER"

    .line 88
    .line 89
    invoke-direct {v7, v10, v9, v8}, Lg7;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    .line 90
    .line 91
    .line 92
    sput-object v7, Lg7;->l:Lg7;

    .line 93
    .line 94
    new-instance v8, Lg7;

    .line 95
    .line 96
    const/16 v9, 0x8

    .line 97
    .line 98
    const-string v10, "delegate"

    .line 99
    .line 100
    const-string v11, "PROPERTY_DELEGATE_FIELD"

    .line 101
    .line 102
    invoke-direct {v8, v11, v10, v9}, Lg7;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    .line 103
    .line 104
    .line 105
    sput-object v8, Lg7;->m:Lg7;

    .line 106
    .line 107
    filled-new-array/range {v0 .. v8}, [Lg7;

    .line 108
    .line 109
    .line 110
    move-result-object v0

    .line 111
    sput-object v0, Lg7;->n:[Lg7;

    .line 112
    .line 113
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;I)V
    .registers 4

    .line 1
    invoke-direct {p0, p1, p3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 2
    .line 3
    .line 4
    if-nez p2, :cond_d

    .line 5
    .line 6
    invoke-virtual {p0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    invoke-static {p1}, Lvs3;->D(Ljava/lang/String;)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object p2

    .line 14
    :cond_d
    iput-object p2, p0, Lg7;->a:Ljava/lang/String;

    .line 15
    .line 16
    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lg7;
    .registers 2

    .line 1
    const-class v0, Lg7;

    .line 2
    .line 3
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lg7;

    .line 8
    .line 9
    return-object p0
.end method

.method public static values()[Lg7;
    .registers 1

    .line 1
    sget-object v0, Lg7;->n:[Lg7;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [Lg7;

    .line 8
    .line 9
    return-object v0
.end method
