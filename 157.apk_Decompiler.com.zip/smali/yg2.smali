###### Class defpackage.yg2 (yg2)
.class public final Lyg2;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public a:Z

.field public b:Z

.field public final c:Ly50;

.field public final d:Lrg0;

.field public final e:Ljava/util/List;

.field public final f:Lcy;

.field public g:Lus0;


# direct methods
.method public constructor <init>(Ly50;Lrg0;)V
    .registers 12

    .line 1
    iget-object v0, p1, Ly50;->g:Lbh2;

    .line 2
    .line 3
    iget-object v1, p1, Ly50;->c:Ldv2;

    .line 4
    .line 5
    iget-object v4, p1, Ly50;->b:Ljava/lang/String;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object p1, p0, Lyg2;->c:Ly50;

    .line 11
    .line 12
    iput-object p2, p0, Lyg2;->d:Lrg0;

    .line 13
    .line 14
    iget-object v2, p1, Ly50;->e:Ljava/util/List;

    .line 15
    .line 16
    if-nez v2, :cond_13

    .line 17
    .line 18
    sget-object v2, Lth0;->a:Lth0;

    .line 19
    .line 20
    :cond_13
    iput-object v2, p0, Lyg2;->e:Ljava/util/List;

    .line 21
    .line 22
    iget-object v2, p1, Ly50;->p:Lei2;

    .line 23
    .line 24
    const/4 v3, 0x0

    .line 25
    const/4 v8, 0x1

    .line 26
    if-nez v2, :cond_49

    .line 27
    .line 28
    if-eqz v1, :cond_43

    .line 29
    .line 30
    iget-object v3, p1, Ly50;->a:Landroid/content/Context;

    .line 31
    .line 32
    new-instance v5, Lo4;

    .line 33
    .line 34
    iget p1, p2, Lrg0;->a:I

    .line 35
    .line 36
    invoke-direct {v5, p0, p1}, Lo4;-><init>(Lyg2;I)V

    .line 37
    .line 38
    .line 39
    new-instance v2, Lbo2;

    .line 40
    .line 41
    const/4 v6, 0x0

    .line 42
    const/4 v7, 0x0

    .line 43
    invoke-direct/range {v2 .. v7}, Lbo2;-><init>(Landroid/content/Context;Ljava/lang/String;Lo4;ZZ)V

    .line 44
    .line 45
    .line 46
    new-instance p1, Lcv2;

    .line 47
    .line 48
    new-instance p2, Lrt1;

    .line 49
    .line 50
    invoke-interface {v1, v2}, Ldv2;->b(Lbo2;)Lev2;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 55
    .line 56
    .line 57
    invoke-direct {p2}, Ljava/lang/Object;-><init>()V

    .line 58
    .line 59
    .line 60
    iput-object v1, p2, Lrt1;->a:Ljava/lang/Object;

    .line 61
    .line 62
    invoke-direct {p1, p2}, Lcv2;-><init>(Lrt1;)V

    .line 63
    .line 64
    .line 65
    iput-object p1, p0, Lyg2;->f:Lcy;

    .line 66
    .line 67
    goto :goto_84

    .line 68
    :cond_43
    const-string p0, "SQLiteManager was constructed with both null driver and open helper factory!"

    .line 69
    .line 70
    invoke-static {p0}, Lm03;->g(Ljava/lang/String;)V

    .line 71
    .line 72
    .line 73
    throw v3

    .line 74
    :cond_49
    if-nez v4, :cond_56

    .line 75
    .line 76
    new-instance p1, Ljt3;

    .line 77
    .line 78
    invoke-direct {p1, p0, v2}, Ljt3;-><init>(Lyg2;Lei2;)V

    .line 79
    .line 80
    .line 81
    new-instance p2, Lfy;

    .line 82
    .line 83
    invoke-direct {p2, p1}, Lfy;-><init>(Ljt3;)V

    .line 84
    .line 85
    .line 86
    goto :goto_82

    .line 87
    :cond_56
    new-instance p1, Ljt3;

    .line 88
    .line 89
    invoke-direct {p1, p0, v2}, Ljt3;-><init>(Lyg2;Lei2;)V

    .line 90
    .line 91
    .line 92
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 93
    .line 94
    .line 95
    move-result p2

    .line 96
    const/4 v1, 0x2

    .line 97
    if-eq p2, v8, :cond_6c

    .line 98
    .line 99
    if-ne p2, v1, :cond_66

    .line 100
    .line 101
    const/4 p2, 0x4

    .line 102
    goto :goto_6d

    .line 103
    :cond_66
    const-string p0, "Can\'t get max number of reader for journal mode \'"

    .line 104
    .line 105
    invoke-static {v0, p0}, Lt12;->s(Ljava/lang/Object;Ljava/lang/String;)V

    .line 106
    .line 107
    .line 108
    throw v3

    .line 109
    :cond_6c
    move p2, v8

    .line 110
    :goto_6d
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 111
    .line 112
    .line 113
    move-result v2

    .line 114
    if-eq v2, v8, :cond_7c

    .line 115
    .line 116
    if-ne v2, v1, :cond_76

    .line 117
    .line 118
    goto :goto_7c

    .line 119
    :cond_76
    const-string p0, "Can\'t get max number of writers for journal mode \'"

    .line 120
    .line 121
    invoke-static {v0, p0}, Lt12;->s(Ljava/lang/Object;Ljava/lang/String;)V

    .line 122
    .line 123
    .line 124
    throw v3

    .line 125
    :cond_7c
    :goto_7c
    new-instance v1, Lfy;

    .line 126
    .line 127
    invoke-direct {v1, p1, v4, p2}, Lfy;-><init>(Ljt3;Ljava/lang/String;I)V

    .line 128
    .line 129
    .line 130
    move-object p2, v1

    .line 131
    :goto_82
    iput-object p2, p0, Lyg2;->f:Lcy;

    .line 132
    .line 133
    :goto_84
    sget-object p1, Lbh2;->b:Lbh2;

    .line 134
    .line 135
    if-ne v0, p1, :cond_89

    .line 136
    .line 137
    goto :goto_8a

    .line 138
    :cond_89
    const/4 v8, 0x0

    .line 139
    :goto_8a
    invoke-virtual {p0}, Lyg2;->c()Lev2;

    .line 140
    .line 141
    .line 142
    move-result-object p0

    .line 143
    if-eqz p0, :cond_93

    .line 144
    .line 145
    invoke-interface {p0, v8}, Lev2;->setWriteAheadLoggingEnabled(Z)V

    .line 146
    .line 147
    .line 148
    :cond_93
    return-void
.end method

.method public constructor <init>(Ly50;Ls10;)V
    .registers 6

    .line 149
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 150
    iput-object p1, p0, Lyg2;->c:Ly50;

    .line 151
    new-instance p2, Lwg2;

    const/4 v0, -0x1

    .line 152
    const-string v1, ""

    invoke-direct {p2, v1, v1, v0}, Lrg0;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    .line 153
    iput-object p2, p0, Lyg2;->d:Lrg0;

    .line 154
    iget-object p2, p1, Ly50;->e:Ljava/util/List;

    sget-object v0, Lth0;->a:Lth0;

    if-nez p2, :cond_17

    move-object v1, v0

    goto :goto_18

    :cond_17
    move-object v1, p2

    :goto_18
    iput-object v1, p0, Lyg2;->e:Ljava/util/List;

    .line 155
    new-instance v1, Lq;

    const/4 v2, 0x4

    invoke-direct {v1, v2, p0}, Lq;-><init>(ILjava/lang/Object;)V

    if-nez p2, :cond_23

    move-object p2, v0

    .line 156
    :cond_23
    check-cast p2, Ljava/util/Collection;

    .line 157
    new-instance p0, Lxg2;

    invoke-direct {p0, v1}, Lxg2;-><init>(Lq;)V

    .line 158
    invoke-static {p2, p0}, Lgv;->l0(Ljava/util/Collection;Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 159
    iget-object p0, p1, Ly50;->h:Ljava/util/concurrent/Executor;

    .line 160
    iget-object p1, p1, Ly50;->i:Ljava/util/concurrent/Executor;

    .line 161
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 162
    new-instance p0, Lzw1;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lzw1;-><init>(I)V

    throw p0
.end method

.method public static a(Ldi2;)V
    .registers 6

    .line 1
    const-string v0, "PRAGMA busy_timeout"

    .line 2
    .line 3
    invoke-interface {p0, v0}, Ldi2;->A(Ljava/lang/String;)Lji2;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    :try_start_6
    invoke-interface {v0}, Lji2;->w()Z

    .line 8
    .line 9
    .line 10
    const/4 v1, 0x0

    .line 11
    invoke-interface {v0, v1}, Lji2;->getLong(I)J

    .line 12
    .line 13
    .line 14
    move-result-wide v1
    :try_end_e
    .catchall {:try_start_6 .. :try_end_e} :catchall_1e

    .line 15
    const/4 v3, 0x0

    .line 16
    invoke-static {v0, v3}, Ljw0;->d(Lji2;Ljava/lang/Throwable;)V

    .line 17
    .line 18
    .line 19
    const-wide/16 v3, 0xbb8

    .line 20
    .line 21
    cmp-long v0, v1, v3

    .line 22
    .line 23
    if-gez v0, :cond_1d

    .line 24
    .line 25
    const-string v0, "PRAGMA busy_timeout = 3000"

    .line 26
    .line 27
    invoke-static {p0, v0}, Lpf3;->j(Ldi2;Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    :cond_1d
    return-void

    .line 31
    :catchall_1e
    move-exception p0

    .line 32
    :try_start_1f
    throw p0
    :try_end_20
    .catchall {:try_start_1f .. :try_end_20} :catchall_20

    .line 33
    :catchall_20
    move-exception v1

    .line 34
    invoke-static {v0, p0}, Ljw0;->d(Lji2;Ljava/lang/Throwable;)V

    .line 35
    .line 36
    .line 37
    throw v1
.end method


# virtual methods
.method public final b(Ldi2;)V
    .registers 6

    .line 1
    const-string v0, "PRAGMA user_version = "

    .line 2
    .line 3
    iget-object v1, p0, Lyg2;->c:Ly50;

    .line 4
    .line 5
    iget-object v2, v1, Ly50;->g:Lbh2;

    .line 6
    .line 7
    sget-object v3, Lbh2;->b:Lbh2;

    .line 8
    .line 9
    if-ne v2, v3, :cond_10

    .line 10
    .line 11
    const-string v2, "PRAGMA journal_mode = WAL"

    .line 12
    .line 13
    invoke-static {p1, v2}, Lpf3;->j(Ldi2;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    goto :goto_15

    .line 17
    :cond_10
    const-string v2, "PRAGMA journal_mode = TRUNCATE"

    .line 18
    .line 19
    invoke-static {p1, v2}, Lpf3;->j(Ldi2;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    :goto_15
    iget-object v1, v1, Ly50;->g:Lbh2;

    .line 23
    .line 24
    if-ne v1, v3, :cond_1f

    .line 25
    .line 26
    const-string v1, "PRAGMA synchronous = NORMAL"

    .line 27
    .line 28
    invoke-static {p1, v1}, Lpf3;->j(Ldi2;Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    goto :goto_24

    .line 32
    :cond_1f
    const-string v1, "PRAGMA synchronous = FULL"

    .line 33
    .line 34
    invoke-static {p1, v1}, Lpf3;->j(Ldi2;Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    :goto_24
    invoke-static {p1}, Lyg2;->a(Ldi2;)V

    .line 38
    .line 39
    .line 40
    const-string v1, "PRAGMA user_version"

    .line 41
    .line 42
    invoke-interface {p1, v1}, Ldi2;->A(Ljava/lang/String;)Lji2;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    :try_start_2d
    invoke-interface {v1}, Lji2;->w()Z

    .line 47
    .line 48
    .line 49
    const/4 v2, 0x0

    .line 50
    invoke-interface {v1, v2}, Lji2;->getLong(I)J

    .line 51
    .line 52
    .line 53
    move-result-wide v2
    :try_end_35
    .catchall {:try_start_2d .. :try_end_35} :catchall_88

    .line 54
    long-to-int v2, v2

    .line 55
    const/4 v3, 0x0

    .line 56
    invoke-static {v1, v3}, Ljw0;->d(Lji2;Ljava/lang/Throwable;)V

    .line 57
    .line 58
    .line 59
    iget-object v1, p0, Lyg2;->d:Lrg0;

    .line 60
    .line 61
    iget v3, v1, Lrg0;->a:I

    .line 62
    .line 63
    iget v1, v1, Lrg0;->a:I

    .line 64
    .line 65
    if-eq v2, v3, :cond_84

    .line 66
    .line 67
    const-string v3, "BEGIN EXCLUSIVE TRANSACTION"

    .line 68
    .line 69
    invoke-static {p1, v3}, Lpf3;->j(Ldi2;Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    if-nez v2, :cond_4f

    .line 73
    .line 74
    :try_start_49
    invoke-virtual {p0, p1}, Lyg2;->d(Ldi2;)V

    .line 75
    .line 76
    .line 77
    goto :goto_52

    .line 78
    :catchall_4d
    move-exception v0

    .line 79
    goto :goto_64

    .line 80
    :cond_4f
    invoke-virtual {p0, p1, v2, v1}, Lyg2;->e(Ldi2;II)V

    .line 81
    .line 82
    .line 83
    :goto_52
    new-instance v2, Ljava/lang/StringBuilder;

    .line 84
    .line 85
    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 89
    .line 90
    .line 91
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 92
    .line 93
    .line 94
    move-result-object v0

    .line 95
    invoke-static {p1, v0}, Lpf3;->j(Ldi2;Ljava/lang/String;)V

    .line 96
    .line 97
    .line 98
    sget-object v0, Lw43;->a:Lw43;
    :try_end_63
    .catchall {:try_start_49 .. :try_end_63} :catchall_4d

    .line 99
    .line 100
    goto :goto_6a

    .line 101
    :goto_64
    new-instance v1, Ljg2;

    .line 102
    .line 103
    invoke-direct {v1, v0}, Ljg2;-><init>(Ljava/lang/Throwable;)V

    .line 104
    .line 105
    .line 106
    move-object v0, v1

    .line 107
    :goto_6a
    nop

    .line 108
    instance-of v1, v0, Ljg2;

    .line 109
    .line 110
    if-nez v1, :cond_77

    .line 111
    .line 112
    move-object v1, v0

    .line 113
    check-cast v1, Lw43;

    .line 114
    .line 115
    const-string v1, "END TRANSACTION"

    .line 116
    .line 117
    invoke-static {p1, v1}, Lpf3;->j(Ldi2;Ljava/lang/String;)V

    .line 118
    .line 119
    .line 120
    :cond_77
    invoke-static {v0}, Lry1;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 121
    .line 122
    .line 123
    move-result-object v0

    .line 124
    if-nez v0, :cond_7e

    .line 125
    .line 126
    goto :goto_84

    .line 127
    :cond_7e
    const-string p0, "ROLLBACK TRANSACTION"

    .line 128
    .line 129
    invoke-static {p1, p0}, Lpf3;->j(Ldi2;Ljava/lang/String;)V

    .line 130
    .line 131
    .line 132
    throw v0

    .line 133
    :cond_84
    :goto_84
    invoke-virtual {p0, p1}, Lyg2;->f(Ldi2;)V

    .line 134
    .line 135
    .line 136
    return-void

    .line 137
    :catchall_88
    move-exception p0

    .line 138
    :try_start_89
    throw p0
    :try_end_8a
    .catchall {:try_start_89 .. :try_end_8a} :catchall_8a

    .line 139
    :catchall_8a
    move-exception p1

    .line 140
    invoke-static {v1, p0}, Ljw0;->d(Lji2;Ljava/lang/Throwable;)V

    .line 141
    .line 142
    .line 143
    throw p1
.end method

.method public final c()Lev2;
    .registers 3

    .line 1
    iget-object p0, p0, Lyg2;->f:Lcy;

    .line 2
    .line 3
    instance-of v0, p0, Lcv2;

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    if-eqz v0, :cond_a

    .line 7
    .line 8
    check-cast p0, Lcv2;

    .line 9
    .line 10
    goto :goto_b

    .line 11
    :cond_a
    move-object p0, v1

    .line 12
    :goto_b
    if-eqz p0, :cond_14

    .line 13
    .line 14
    iget-object p0, p0, Lcv2;->a:Lrt1;

    .line 15
    .line 16
    iget-object p0, p0, Lrt1;->a:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast p0, Lev2;

    .line 19
    .line 20
    return-object p0

    .line 21
    :cond_14
    return-object v1
.end method

.method public final d(Ldi2;)V
    .registers 9

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    const-string v0, "SELECT count(*) FROM sqlite_master WHERE name != \'android_metadata\'"

    .line 5
    .line 6
    invoke-interface {p1, v0}, Ldi2;->A(Ljava/lang/String;)Lji2;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    :try_start_9
    invoke-interface {v0}, Lji2;->w()Z

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    const/4 v2, 0x0

    .line 15
    if-eqz v1, :cond_1e

    .line 16
    .line 17
    invoke-interface {v0, v2}, Lji2;->getLong(I)J

    .line 18
    .line 19
    .line 20
    move-result-wide v3
    :try_end_14
    .catchall {:try_start_9 .. :try_end_14} :catchall_1c

    .line 21
    const-wide/16 v5, 0x0

    .line 22
    .line 23
    cmp-long v1, v3, v5

    .line 24
    .line 25
    if-nez v1, :cond_1e

    .line 26
    .line 27
    const/4 v2, 0x1

    .line 28
    goto :goto_1e

    .line 29
    :catchall_1c
    move-exception p0

    .line 30
    goto :goto_65

    .line 31
    :cond_1e
    :goto_1e
    const/4 v1, 0x0

    .line 32
    invoke-static {v0, v1}, Ljw0;->d(Lji2;Ljava/lang/Throwable;)V

    .line 33
    .line 34
    .line 35
    iget-object v0, p0, Lyg2;->d:Lrg0;

    .line 36
    .line 37
    invoke-virtual {v0, p1}, Lrg0;->a(Ldi2;)V

    .line 38
    .line 39
    .line 40
    if-nez v2, :cond_3a

    .line 41
    .line 42
    invoke-virtual {v0, p1}, Lrg0;->v(Ldi2;)Lg4;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    iget-boolean v2, v1, Lg4;->b:Z

    .line 47
    .line 48
    if-eqz v2, :cond_32

    .line 49
    .line 50
    goto :goto_3a

    .line 51
    :cond_32
    const-string p0, "Pre-packaged database has an invalid schema: "

    .line 52
    .line 53
    iget-object p1, v1, Lg4;->c:Ljava/lang/String;

    .line 54
    .line 55
    invoke-static {p1, p0}, Lt12;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    return-void

    .line 59
    :cond_3a
    :goto_3a
    invoke-virtual {p0, p1}, Lyg2;->g(Ldi2;)V

    .line 60
    .line 61
    .line 62
    invoke-virtual {v0, p1}, Lrg0;->r(Ldi2;)V

    .line 63
    .line 64
    .line 65
    iget-object p0, p0, Lyg2;->e:Ljava/util/List;

    .line 66
    .line 67
    check-cast p0, Ljava/lang/Iterable;

    .line 68
    .line 69
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 70
    .line 71
    .line 72
    move-result-object p0

    .line 73
    :cond_48
    :goto_48
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 74
    .line 75
    .line 76
    move-result v0

    .line 77
    if-eqz v0, :cond_64

    .line 78
    .line 79
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    check-cast v0, Lah2;

    .line 84
    .line 85
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 86
    .line 87
    .line 88
    instance-of v0, p1, Lbv2;

    .line 89
    .line 90
    if-eqz v0, :cond_48

    .line 91
    .line 92
    move-object v0, p1

    .line 93
    check-cast v0, Lbv2;

    .line 94
    .line 95
    iget-object v0, v0, Lbv2;->a:Lus0;

    .line 96
    .line 97
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 98
    .line 99
    .line 100
    goto :goto_48

    .line 101
    :cond_64
    return-void

    .line 102
    :goto_65
    :try_start_65
    throw p0
    :try_end_66
    .catchall {:try_start_65 .. :try_end_66} :catchall_66

    .line 103
    :catchall_66
    move-exception p1

    .line 104
    invoke-static {v0, p0}, Ljw0;->d(Lji2;Ljava/lang/Throwable;)V

    .line 105
    .line 106
    .line 107
    throw p1
.end method

.method public final e(Ldi2;II)V
    .registers 16

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lyg2;->c:Ly50;

    .line 5
    .line 6
    iget-object v1, v0, Ly50;->d:Lb50;

    .line 7
    .line 8
    const/4 v2, 0x0

    .line 9
    const/4 v3, 0x0

    .line 10
    const/4 v4, 0x1

    .line 11
    if-ne p2, p3, :cond_10

    .line 12
    .line 13
    sget-object v1, Lth0;->a:Lth0;

    .line 14
    .line 15
    goto/16 :goto_97

    .line 16
    .line 17
    :cond_10
    if-le p3, p2, :cond_14

    .line 18
    .line 19
    move v5, v4

    .line 20
    goto :goto_15

    .line 21
    :cond_14
    move v5, v3

    .line 22
    :goto_15
    new-instance v6, Ljava/util/ArrayList;

    .line 23
    .line 24
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 25
    .line 26
    .line 27
    move v7, p2

    .line 28
    :cond_1b
    if-eqz v5, :cond_20

    .line 29
    .line 30
    if-ge v7, p3, :cond_96

    .line 31
    .line 32
    goto :goto_22

    .line 33
    :cond_20
    if-le v7, p3, :cond_96

    .line 34
    .line 35
    :goto_22
    iget-object v8, v1, Lb50;->a:Ljava/util/LinkedHashMap;

    .line 36
    .line 37
    if-eqz v5, :cond_3e

    .line 38
    .line 39
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 40
    .line 41
    .line 42
    move-result-object v9

    .line 43
    invoke-virtual {v8, v9}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v8

    .line 47
    check-cast v8, Ljava/util/TreeMap;

    .line 48
    .line 49
    if-nez v8, :cond_34

    .line 50
    .line 51
    :goto_32
    move-object v10, v2

    .line 52
    goto :goto_54

    .line 53
    :cond_34
    invoke-virtual {v8}, Ljava/util/TreeMap;->descendingKeySet()Ljava/util/NavigableSet;

    .line 54
    .line 55
    .line 56
    move-result-object v9

    .line 57
    new-instance v10, Lg12;

    .line 58
    .line 59
    invoke-direct {v10, v8, v9}, Lg12;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 60
    .line 61
    .line 62
    goto :goto_54

    .line 63
    :cond_3e
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 64
    .line 65
    .line 66
    move-result-object v9

    .line 67
    invoke-virtual {v8, v9}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object v8

    .line 71
    check-cast v8, Ljava/util/TreeMap;

    .line 72
    .line 73
    if-nez v8, :cond_4b

    .line 74
    .line 75
    goto :goto_32

    .line 76
    :cond_4b
    invoke-virtual {v8}, Ljava/util/TreeMap;->keySet()Ljava/util/Set;

    .line 77
    .line 78
    .line 79
    move-result-object v9

    .line 80
    new-instance v10, Lg12;

    .line 81
    .line 82
    invoke-direct {v10, v8, v9}, Lg12;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 83
    .line 84
    .line 85
    :goto_54
    if-nez v10, :cond_57

    .line 86
    .line 87
    goto :goto_94

    .line 88
    :cond_57
    iget-object v8, v10, Lg12;->a:Ljava/lang/Object;

    .line 89
    .line 90
    check-cast v8, Ljava/util/Map;

    .line 91
    .line 92
    iget-object v9, v10, Lg12;->b:Ljava/lang/Object;

    .line 93
    .line 94
    check-cast v9, Ljava/lang/Iterable;

    .line 95
    .line 96
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 97
    .line 98
    .line 99
    move-result-object v9

    .line 100
    :cond_63
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    .line 101
    .line 102
    .line 103
    move-result v10

    .line 104
    if-eqz v10, :cond_91

    .line 105
    .line 106
    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    move-result-object v10

    .line 110
    check-cast v10, Ljava/lang/Number;

    .line 111
    .line 112
    invoke-virtual {v10}, Ljava/lang/Number;->intValue()I

    .line 113
    .line 114
    .line 115
    move-result v10

    .line 116
    if-eqz v5, :cond_7c

    .line 117
    .line 118
    add-int/lit8 v11, v7, 0x1

    .line 119
    .line 120
    if-gt v11, v10, :cond_63

    .line 121
    .line 122
    if-gt v10, p3, :cond_63

    .line 123
    .line 124
    goto :goto_80

    .line 125
    :cond_7c
    if-gt p3, v10, :cond_63

    .line 126
    .line 127
    if-ge v10, v7, :cond_63

    .line 128
    .line 129
    :goto_80
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 130
    .line 131
    .line 132
    move-result-object v7

    .line 133
    invoke-interface {v8, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 134
    .line 135
    .line 136
    move-result-object v7

    .line 137
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 138
    .line 139
    .line 140
    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 141
    .line 142
    .line 143
    move v8, v4

    .line 144
    move v7, v10

    .line 145
    goto :goto_92

    .line 146
    :cond_91
    move v8, v3

    .line 147
    :goto_92
    if-nez v8, :cond_1b

    .line 148
    .line 149
    :goto_94
    move-object v1, v2

    .line 150
    goto :goto_97

    .line 151
    :cond_96
    move-object v1, v6

    .line 152
    :goto_97
    iget-object v5, p0, Lyg2;->d:Lrg0;

    .line 153
    .line 154
    if-eqz v1, :cond_cb

    .line 155
    .line 156
    invoke-virtual {v5, p1}, Lrg0;->u(Ldi2;)V

    .line 157
    .line 158
    .line 159
    check-cast v1, Ljava/lang/Iterable;

    .line 160
    .line 161
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 162
    .line 163
    .line 164
    move-result-object p2

    .line 165
    :goto_a4
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 166
    .line 167
    .line 168
    move-result p3

    .line 169
    if-eqz p3, :cond_b4

    .line 170
    .line 171
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 172
    .line 173
    .line 174
    move-result-object p3

    .line 175
    check-cast p3, Lkt1;

    .line 176
    .line 177
    invoke-virtual {p3, p1}, Lkt1;->b(Ldi2;)V

    .line 178
    .line 179
    .line 180
    goto :goto_a4

    .line 181
    :cond_b4
    invoke-virtual {v5, p1}, Lrg0;->v(Ldi2;)Lg4;

    .line 182
    .line 183
    .line 184
    move-result-object p2

    .line 185
    iget-boolean p3, p2, Lg4;->b:Z

    .line 186
    .line 187
    if-eqz p3, :cond_c3

    .line 188
    .line 189
    invoke-virtual {v5, p1}, Lrg0;->t(Ldi2;)V

    .line 190
    .line 191
    .line 192
    invoke-virtual {p0, p1}, Lyg2;->g(Ldi2;)V

    .line 193
    .line 194
    .line 195
    return-void

    .line 196
    :cond_c3
    const-string p0, "Migration didn\'t properly handle: "

    .line 197
    .line 198
    iget-object p1, p2, Lg4;->c:Ljava/lang/String;

    .line 199
    .line 200
    invoke-static {p1, p0}, Lt12;->p(Ljava/lang/Object;Ljava/lang/String;)V

    .line 201
    .line 202
    .line 203
    return-void

    .line 204
    :cond_cb
    invoke-static {v0, p2, p3}, Lmt3;->k(Ly50;II)Z

    .line 205
    .line 206
    .line 207
    move-result v1

    .line 208
    if-nez v1, :cond_191

    .line 209
    .line 210
    iget-boolean p2, v0, Ly50;->o:Z

    .line 211
    .line 212
    if-eqz p2, :cond_166

    .line 213
    .line 214
    const-string p2, "SELECT name, type FROM sqlite_master WHERE type = \'table\' OR type = \'view\'"

    .line 215
    .line 216
    invoke-interface {p1, p2}, Ldi2;->A(Ljava/lang/String;)Lji2;

    .line 217
    .line 218
    .line 219
    move-result-object p2

    .line 220
    :try_start_db
    invoke-static {}, Lia1;->m()Lhk1;

    .line 221
    .line 222
    .line 223
    move-result-object p3

    .line 224
    :cond_df
    :goto_df
    invoke-interface {p2}, Lji2;->w()Z

    .line 225
    .line 226
    .line 227
    move-result v0

    .line 228
    if-eqz v0, :cond_114

    .line 229
    .line 230
    invoke-interface {p2, v3}, Lji2;->i(I)Ljava/lang/String;

    .line 231
    .line 232
    .line 233
    move-result-object v0

    .line 234
    const-string v1, "sqlite_"

    .line 235
    .line 236
    const/4 v6, 0x2

    .line 237
    invoke-static {v6, v0, v1, v3}, Lfu2;->I(ILjava/lang/String;Ljava/lang/String;Z)Z

    .line 238
    .line 239
    .line 240
    move-result v1

    .line 241
    if-nez v1, :cond_df

    .line 242
    .line 243
    const-string v1, "android_metadata"

    .line 244
    .line 245
    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 246
    .line 247
    .line 248
    move-result v1

    .line 249
    if-eqz v1, :cond_fb

    .line 250
    .line 251
    goto :goto_df

    .line 252
    :cond_fb
    invoke-interface {p2, v4}, Lji2;->i(I)Ljava/lang/String;

    .line 253
    .line 254
    .line 255
    move-result-object v1

    .line 256
    const-string v6, "view"

    .line 257
    .line 258
    invoke-static {v1, v6}, Ld31;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 259
    .line 260
    .line 261
    move-result v1

    .line 262
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 263
    .line 264
    .line 265
    move-result-object v1

    .line 266
    new-instance v6, Lg12;

    .line 267
    .line 268
    invoke-direct {v6, v0, v1}, Lg12;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 269
    .line 270
    .line 271
    invoke-virtual {p3, v6}, Lhk1;->add(Ljava/lang/Object;)Z

    .line 272
    .line 273
    .line 274
    goto :goto_df

    .line 275
    :catchall_112
    move-exception p0

    .line 276
    goto :goto_160

    .line 277
    :cond_114
    invoke-static {p3}, Lia1;->f(Ljava/util/List;)Lhk1;

    .line 278
    .line 279
    .line 280
    move-result-object p3
    :try_end_118
    .catchall {:try_start_db .. :try_end_118} :catchall_112

    .line 281
    invoke-static {p2, v2}, Ljw0;->d(Lji2;Ljava/lang/Throwable;)V

    .line 282
    .line 283
    .line 284
    invoke-virtual {p3, v3}, Lhk1;->listIterator(I)Ljava/util/ListIterator;

    .line 285
    .line 286
    .line 287
    move-result-object p2

    .line 288
    :goto_11f
    move-object p3, p2

    .line 289
    check-cast p3, Lfk1;

    .line 290
    .line 291
    invoke-virtual {p3}, Lfk1;->hasNext()Z

    .line 292
    .line 293
    .line 294
    move-result v0

    .line 295
    if-eqz v0, :cond_169

    .line 296
    .line 297
    invoke-virtual {p3}, Lfk1;->next()Ljava/lang/Object;

    .line 298
    .line 299
    .line 300
    move-result-object p3

    .line 301
    check-cast p3, Lg12;

    .line 302
    .line 303
    iget-object v0, p3, Lg12;->a:Ljava/lang/Object;

    .line 304
    .line 305
    check-cast v0, Ljava/lang/String;

    .line 306
    .line 307
    iget-object p3, p3, Lg12;->b:Ljava/lang/Object;

    .line 308
    .line 309
    check-cast p3, Ljava/lang/Boolean;

    .line 310
    .line 311
    invoke-virtual {p3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 312
    .line 313
    .line 314
    move-result p3

    .line 315
    if-eqz p3, :cond_14e

    .line 316
    .line 317
    new-instance p3, Ljava/lang/StringBuilder;

    .line 318
    .line 319
    const-string v1, "DROP VIEW IF EXISTS "

    .line 320
    .line 321
    invoke-direct {p3, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 322
    .line 323
    .line 324
    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 325
    .line 326
    .line 327
    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 328
    .line 329
    .line 330
    move-result-object p3

    .line 331
    invoke-static {p1, p3}, Lpf3;->j(Ldi2;Ljava/lang/String;)V

    .line 332
    .line 333
    .line 334
    goto :goto_11f

    .line 335
    :cond_14e
    new-instance p3, Ljava/lang/StringBuilder;

    .line 336
    .line 337
    const-string v1, "DROP TABLE IF EXISTS "

    .line 338
    .line 339
    invoke-direct {p3, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 340
    .line 341
    .line 342
    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 343
    .line 344
    .line 345
    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 346
    .line 347
    .line 348
    move-result-object p3

    .line 349
    invoke-static {p1, p3}, Lpf3;->j(Ldi2;Ljava/lang/String;)V

    .line 350
    .line 351
    .line 352
    goto :goto_11f

    .line 353
    :goto_160
    :try_start_160
    throw p0
    :try_end_161
    .catchall {:try_start_160 .. :try_end_161} :catchall_161

    .line 354
    :catchall_161
    move-exception p1

    .line 355
    invoke-static {p2, p0}, Ljw0;->d(Lji2;Ljava/lang/Throwable;)V

    .line 356
    .line 357
    .line 358
    throw p1

    .line 359
    :cond_166
    invoke-virtual {v5, p1}, Lrg0;->c(Ldi2;)V

    .line 360
    .line 361
    .line 362
    :cond_169
    iget-object p0, p0, Lyg2;->e:Ljava/util/List;

    .line 363
    .line 364
    check-cast p0, Ljava/lang/Iterable;

    .line 365
    .line 366
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 367
    .line 368
    .line 369
    move-result-object p0

    .line 370
    :cond_171
    :goto_171
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 371
    .line 372
    .line 373
    move-result p2

    .line 374
    if-eqz p2, :cond_18d

    .line 375
    .line 376
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 377
    .line 378
    .line 379
    move-result-object p2

    .line 380
    check-cast p2, Lah2;

    .line 381
    .line 382
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 383
    .line 384
    .line 385
    instance-of p2, p1, Lbv2;

    .line 386
    .line 387
    if-eqz p2, :cond_171

    .line 388
    .line 389
    move-object p2, p1

    .line 390
    check-cast p2, Lbv2;

    .line 391
    .line 392
    iget-object p2, p2, Lbv2;->a:Lus0;

    .line 393
    .line 394
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 395
    .line 396
    .line 397
    goto :goto_171

    .line 398
    :cond_18d
    invoke-virtual {v5, p1}, Lrg0;->a(Ldi2;)V

    .line 399
    .line 400
    .line 401
    return-void

    .line 402
    :cond_191
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 403
    .line 404
    new-instance p1, Ljava/lang/StringBuilder;

    .line 405
    .line 406
    const-string v0, "A migration from "

    .line 407
    .line 408
    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 409
    .line 410
    .line 411
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 412
    .line 413
    .line 414
    const-string p2, " to "

    .line 415
    .line 416
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 417
    .line 418
    .line 419
    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 420
    .line 421
    .line 422
    const-string p2, " was required but not found. Please provide the necessary Migration path via RoomDatabase.Builder.addMigration(...) or allow for destructive migrations via one of the RoomDatabase.Builder.fallbackToDestructiveMigration* functions."

    .line 423
    .line 424
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 425
    .line 426
    .line 427
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 428
    .line 429
    .line 430
    move-result-object p1

    .line 431
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 432
    .line 433
    .line 434
    move-result-object p1

    .line 435
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 436
    .line 437
    .line 438
    throw p0
.end method

.method public final f(Ldi2;)V
    .registers 11

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    const-string v0, "Pre-packaged database has an invalid schema: "

    .line 5
    .line 6
    const-string v1, "SELECT 1 FROM sqlite_master WHERE type = \'table\' AND name = \'room_master_table\'"

    .line 7
    .line 8
    invoke-interface {p1, v1}, Ldi2;->A(Ljava/lang/String;)Lji2;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    :try_start_b
    invoke-interface {v1}, Lji2;->w()Z

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    const/4 v3, 0x1

    .line 17
    const/4 v4, 0x0

    .line 18
    if-eqz v2, :cond_22

    .line 19
    .line 20
    invoke-interface {v1, v4}, Lji2;->getLong(I)J

    .line 21
    .line 22
    .line 23
    move-result-wide v5
    :try_end_17
    .catchall {:try_start_b .. :try_end_17} :catchall_1f

    .line 24
    const-wide/16 v7, 0x0

    .line 25
    .line 26
    cmp-long v2, v5, v7

    .line 27
    .line 28
    if-eqz v2, :cond_22

    .line 29
    .line 30
    move v2, v3

    .line 31
    goto :goto_23

    .line 32
    :catchall_1f
    move-exception p0

    .line 33
    goto/16 :goto_fa

    .line 34
    .line 35
    :cond_22
    move v2, v4

    .line 36
    :goto_23
    const/4 v5, 0x0

    .line 37
    invoke-static {v1, v5}, Ljw0;->d(Lji2;Ljava/lang/Throwable;)V

    .line 38
    .line 39
    .line 40
    iget-object v1, p0, Lyg2;->d:Lrg0;

    .line 41
    .line 42
    if-eqz v2, :cond_81

    .line 43
    .line 44
    const-string v0, "SELECT identity_hash FROM room_master_table WHERE id = 42 LIMIT 1"

    .line 45
    .line 46
    invoke-interface {p1, v0}, Ldi2;->A(Ljava/lang/String;)Lji2;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    :try_start_31
    invoke-interface {v0}, Lji2;->w()Z

    .line 51
    .line 52
    .line 53
    move-result v2

    .line 54
    if-eqz v2, :cond_3e

    .line 55
    .line 56
    invoke-interface {v0, v4}, Lji2;->i(I)Ljava/lang/String;

    .line 57
    .line 58
    .line 59
    move-result-object v2
    :try_end_3b
    .catchall {:try_start_31 .. :try_end_3b} :catchall_3c

    .line 60
    goto :goto_3f

    .line 61
    :catchall_3c
    move-exception p0

    .line 62
    goto :goto_7b

    .line 63
    :cond_3e
    move-object v2, v5

    .line 64
    :goto_3f
    invoke-static {v0, v5}, Ljw0;->d(Lji2;Ljava/lang/Throwable;)V

    .line 65
    .line 66
    .line 67
    iget-object v0, v1, Lrg0;->b:Ljava/lang/Object;

    .line 68
    .line 69
    check-cast v0, Ljava/lang/String;

    .line 70
    .line 71
    invoke-virtual {v0, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    if-nez v0, :cond_ca

    .line 76
    .line 77
    iget-object v0, v1, Lrg0;->c:Ljava/lang/Object;

    .line 78
    .line 79
    check-cast v0, Ljava/lang/String;

    .line 80
    .line 81
    invoke-virtual {v0, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 82
    .line 83
    .line 84
    move-result v0

    .line 85
    if-eqz v0, :cond_57

    .line 86
    .line 87
    goto :goto_ca

    .line 88
    :cond_57
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 89
    .line 90
    iget-object p1, v1, Lrg0;->b:Ljava/lang/Object;

    .line 91
    .line 92
    check-cast p1, Ljava/lang/String;

    .line 93
    .line 94
    new-instance v0, Ljava/lang/StringBuilder;

    .line 95
    .line 96
    const-string v1, "Room cannot verify the data integrity. Looks like you\'ve changed schema but forgot to update the version number. You can simply fix this by increasing the version number. Expected identity hash: "

    .line 97
    .line 98
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 99
    .line 100
    .line 101
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 102
    .line 103
    .line 104
    const-string p1, ", found: "

    .line 105
    .line 106
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 107
    .line 108
    .line 109
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 110
    .line 111
    .line 112
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 113
    .line 114
    .line 115
    move-result-object p1

    .line 116
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 117
    .line 118
    .line 119
    move-result-object p1

    .line 120
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 121
    .line 122
    .line 123
    throw p0

    .line 124
    :goto_7b
    :try_start_7b
    throw p0
    :try_end_7c
    .catchall {:try_start_7b .. :try_end_7c} :catchall_7c

    .line 125
    :catchall_7c
    move-exception p1

    .line 126
    invoke-static {v0, p0}, Ljw0;->d(Lji2;Ljava/lang/Throwable;)V

    .line 127
    .line 128
    .line 129
    throw p1

    .line 130
    :cond_81
    const-string v2, "BEGIN EXCLUSIVE TRANSACTION"

    .line 131
    .line 132
    invoke-static {p1, v2}, Lpf3;->j(Ldi2;Ljava/lang/String;)V

    .line 133
    .line 134
    .line 135
    :try_start_86
    invoke-virtual {v1, p1}, Lrg0;->v(Ldi2;)Lg4;

    .line 136
    .line 137
    .line 138
    move-result-object v2

    .line 139
    iget-boolean v4, v2, Lg4;->b:Z

    .line 140
    .line 141
    if-eqz v4, :cond_99

    .line 142
    .line 143
    invoke-virtual {v1, p1}, Lrg0;->t(Ldi2;)V

    .line 144
    .line 145
    .line 146
    invoke-virtual {p0, p1}, Lyg2;->g(Ldi2;)V

    .line 147
    .line 148
    .line 149
    sget-object v0, Lw43;->a:Lw43;

    .line 150
    .line 151
    goto :goto_b7

    .line 152
    :catchall_97
    move-exception v0

    .line 153
    goto :goto_b1

    .line 154
    :cond_99
    new-instance v4, Ljava/lang/IllegalStateException;

    .line 155
    .line 156
    new-instance v5, Ljava/lang/StringBuilder;

    .line 157
    .line 158
    invoke-direct {v5, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 159
    .line 160
    .line 161
    iget-object v0, v2, Lg4;->c:Ljava/lang/String;

    .line 162
    .line 163
    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 164
    .line 165
    .line 166
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 167
    .line 168
    .line 169
    move-result-object v0

    .line 170
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 171
    .line 172
    .line 173
    move-result-object v0

    .line 174
    invoke-direct {v4, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 175
    .line 176
    .line 177
    throw v4
    :try_end_b1
    .catchall {:try_start_86 .. :try_end_b1} :catchall_97

    .line 178
    :goto_b1
    new-instance v2, Ljg2;

    .line 179
    .line 180
    invoke-direct {v2, v0}, Ljg2;-><init>(Ljava/lang/Throwable;)V

    .line 181
    .line 182
    .line 183
    move-object v0, v2

    .line 184
    :goto_b7
    nop

    .line 185
    instance-of v2, v0, Ljg2;

    .line 186
    .line 187
    if-nez v2, :cond_c4

    .line 188
    .line 189
    move-object v2, v0

    .line 190
    check-cast v2, Lw43;

    .line 191
    .line 192
    const-string v2, "END TRANSACTION"

    .line 193
    .line 194
    invoke-static {p1, v2}, Lpf3;->j(Ldi2;Ljava/lang/String;)V

    .line 195
    .line 196
    .line 197
    :cond_c4
    invoke-static {v0}, Lry1;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 198
    .line 199
    .line 200
    move-result-object v0

    .line 201
    if-nez v0, :cond_f4

    .line 202
    .line 203
    :cond_ca
    :goto_ca
    invoke-virtual {v1, p1}, Lrg0;->s(Ldi2;)V

    .line 204
    .line 205
    .line 206
    iget-object v0, p0, Lyg2;->e:Ljava/util/List;

    .line 207
    .line 208
    check-cast v0, Ljava/lang/Iterable;

    .line 209
    .line 210
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 211
    .line 212
    .line 213
    move-result-object v0

    .line 214
    :cond_d5
    :goto_d5
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 215
    .line 216
    .line 217
    move-result v1

    .line 218
    if-eqz v1, :cond_f1

    .line 219
    .line 220
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 221
    .line 222
    .line 223
    move-result-object v1

    .line 224
    check-cast v1, Lah2;

    .line 225
    .line 226
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 227
    .line 228
    .line 229
    instance-of v2, p1, Lbv2;

    .line 230
    .line 231
    if-eqz v2, :cond_d5

    .line 232
    .line 233
    move-object v2, p1

    .line 234
    check-cast v2, Lbv2;

    .line 235
    .line 236
    iget-object v2, v2, Lbv2;->a:Lus0;

    .line 237
    .line 238
    invoke-virtual {v1, v2}, Lah2;->a(Lus0;)V

    .line 239
    .line 240
    .line 241
    goto :goto_d5

    .line 242
    :cond_f1
    iput-boolean v3, p0, Lyg2;->a:Z

    .line 243
    .line 244
    return-void

    .line 245
    :cond_f4
    const-string p0, "ROLLBACK TRANSACTION"

    .line 246
    .line 247
    invoke-static {p1, p0}, Lpf3;->j(Ldi2;Ljava/lang/String;)V

    .line 248
    .line 249
    .line 250
    throw v0

    .line 251
    :goto_fa
    :try_start_fa
    throw p0
    :try_end_fb
    .catchall {:try_start_fa .. :try_end_fb} :catchall_fb

    .line 252
    :catchall_fb
    move-exception p1

    .line 253
    invoke-static {v1, p0}, Ljw0;->d(Lji2;Ljava/lang/Throwable;)V

    .line 254
    .line 255
    .line 256
    throw p1
.end method

.method public final g(Ldi2;)V
    .registers 4

    .line 1
    const-string v0, "CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lpf3;->j(Ldi2;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object p0, p0, Lyg2;->d:Lrg0;

    .line 7
    .line 8
    iget-object p0, p0, Lrg0;->b:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast p0, Ljava/lang/String;

    .line 11
    .line 12
    new-instance v0, Ljava/lang/StringBuilder;

    .line 13
    .line 14
    const-string v1, "INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, \'"

    .line 15
    .line 16
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 20
    .line 21
    .line 22
    const-string p0, "\')"

    .line 23
    .line 24
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 25
    .line 26
    .line 27
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    invoke-static {p1, p0}, Lpf3;->j(Ldi2;Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    return-void
.end method
