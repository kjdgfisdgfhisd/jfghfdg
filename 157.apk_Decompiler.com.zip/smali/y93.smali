###### Class defpackage.y93 (y93)
.class public abstract Ly93;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# direct methods
.method public static a(Landroid/view/View;IIII)V
    .registers 5

    .line 1
    invoke-static {p0, p1, p2, p3, p4}, Lek1;->n(Landroid/view/View;IIII)V

    .line 2
    .line 3
    .line 4
    return-void
.end method
