###### Class defpackage.gi2 (gi2)
.class public interface abstract Lgi2;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# virtual methods
.method public abstract apply(Ljava/lang/Object;)Ljava/lang/Object;
.end method
