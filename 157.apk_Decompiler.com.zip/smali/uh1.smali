###### Class defpackage.uh1 (uh1)
.class public final Luh1;
.super Lvh1;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field public static final synthetic p:I


# instance fields
.field public final n:Lxc2;

.field public final o:Lbh1;


# direct methods
.method public constructor <init>(Lfk;Lxc2;Lbh1;)V
    .registers 5

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-direct {p0, p1, v0}, Lrh1;-><init>(Lfk;Lfh1;)V

    .line 6
    .line 7
    .line 8
    iput-object p2, p0, Luh1;->n:Lxc2;

    .line 9
    .line 10
    iput-object p3, p0, Luh1;->o:Lbh1;

    .line 11
    .line 12
    return-void
.end method

.method public static v(Ll52;)Ll52;
    .registers 3

    .line 1
    invoke-interface {p0}, Lno;->j()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x2

    .line 6
    if-eq v0, v1, :cond_8

    .line 7
    .line 8
    return-object p0

    .line 9
    :cond_8
    invoke-interface {p0}, Lno;->r()Ljava/util/Collection;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    check-cast p0, Ljava/lang/Iterable;

    .line 17
    .line 18
    new-instance v0, Ljava/util/ArrayList;

    .line 19
    .line 20
    const/16 v1, 0xa

    .line 21
    .line 22
    invoke-static {p0, v1}, Liv;->M(Ljava/lang/Iterable;I)I

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 27
    .line 28
    .line 29
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    :goto_20
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 34
    .line 35
    .line 36
    move-result v1

    .line 37
    if-eqz v1, :cond_37

    .line 38
    .line 39
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    check-cast v1, Ll52;

    .line 44
    .line 45
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 46
    .line 47
    .line 48
    invoke-static {v1}, Luh1;->v(Ll52;)Ll52;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 53
    .line 54
    .line 55
    goto :goto_20

    .line 56
    :cond_37
    invoke-static {v0}, Lgv;->B0(Ljava/lang/Iterable;)Ljava/util/Set;

    .line 57
    .line 58
    .line 59
    move-result-object p0

    .line 60
    invoke-static {p0}, Lgv;->y0(Ljava/lang/Iterable;)Ljava/util/List;

    .line 61
    .line 62
    .line 63
    move-result-object p0

    .line 64
    invoke-static {p0}, Lgv;->p0(Ljava/util/List;)Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object p0

    .line 68
    check-cast p0, Ll52;

    .line 69
    .line 70
    return-object p0
.end method


# virtual methods
.method public final a(Ldv1;Lnw1;)Lau;
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    const/4 p0, 0x0

    .line 8
    return-object p0
.end method

.method public final h(Lma0;Lft0;)Ljava/util/Set;
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    sget-object p0, Lxh0;->a:Lxh0;

    .line 5
    .line 6
    return-object p0
.end method

.method public final i(Lma0;Lft0;)Ljava/util/Set;
    .registers 5

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object p1, p0, Lrh1;->e:Lzl1;

    .line 5
    .line 6
    invoke-virtual {p1}, Lzl1;->invoke()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    check-cast p1, Lt60;

    .line 11
    .line 12
    invoke-interface {p1}, Lt60;->b()Ljava/util/Set;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    invoke-static {p1}, Lgv;->B0(Ljava/lang/Iterable;)Ljava/util/Set;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    iget-object p2, p0, Luh1;->o:Lbh1;

    .line 21
    .line 22
    invoke-static {p2}, Lc10;->r(Lxt1;)Luh1;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    if-eqz v0, :cond_20

    .line 27
    .line 28
    invoke-virtual {v0}, Lrh1;->d()Ljava/util/Set;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    goto :goto_21

    .line 33
    :cond_20
    const/4 v0, 0x0

    .line 34
    :goto_21
    if-nez v0, :cond_25

    .line 35
    .line 36
    sget-object v0, Lxh0;->a:Lxh0;

    .line 37
    .line 38
    :cond_25
    invoke-interface {p1, v0}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    .line 39
    .line 40
    .line 41
    iget-object v0, p0, Luh1;->n:Lxc2;

    .line 42
    .line 43
    iget-object v0, v0, Lxc2;->a:Ljava/lang/Class;

    .line 44
    .line 45
    invoke-virtual {v0}, Ljava/lang/Class;->isEnum()Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    if-eqz v0, :cond_43

    .line 50
    .line 51
    sget-object v0, Lrr2;->c:Ldv1;

    .line 52
    .line 53
    sget-object v1, Lrr2;->a:Ldv1;

    .line 54
    .line 55
    filled-new-array {v0, v1}, [Ldv1;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    invoke-static {v0}, Lhv;->H([Ljava/lang/Object;)Ljava/util/List;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    check-cast v0, Ljava/util/Collection;

    .line 64
    .line 65
    invoke-interface {p1, v0}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    .line 66
    .line 67
    .line 68
    :cond_43
    iget-object p0, p0, Lrh1;->b:Lfk;

    .line 69
    .line 70
    iget-object v0, p0, Lfk;->a:Ljava/lang/Object;

    .line 71
    .line 72
    check-cast v0, Lx41;

    .line 73
    .line 74
    iget-object v0, v0, Lx41;->o:Ltv2;

    .line 75
    .line 76
    check-cast v0, Lih2;

    .line 77
    .line 78
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 79
    .line 80
    .line 81
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 82
    .line 83
    .line 84
    new-instance p0, Ljava/util/ArrayList;

    .line 85
    .line 86
    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    .line 87
    .line 88
    .line 89
    invoke-interface {p1, p0}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    .line 90
    .line 91
    .line 92
    return-object p1
.end method

.method public final j(Ldv1;Ljava/util/ArrayList;)V
    .registers 3

    .line 1
    iget-object p1, p0, Lrh1;->b:Lfk;

    .line 2
    .line 3
    iget-object p2, p1, Lfk;->a:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast p2, Lx41;

    .line 6
    .line 7
    iget-object p2, p2, Lx41;->o:Ltv2;

    .line 8
    .line 9
    check-cast p2, Lih2;

    .line 10
    .line 11
    iget-object p0, p0, Luh1;->o:Lbh1;

    .line 12
    .line 13
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public final k()Lt60;
    .registers 3

    .line 1
    new-instance v0, Lys;

    .line 2
    .line 3
    iget-object p0, p0, Luh1;->n:Lxc2;

    .line 4
    .line 5
    sget-object v1, Lz6;->H:Lz6;

    .line 6
    .line 7
    invoke-direct {v0, p0, v1}, Lys;-><init>(Lxc2;Lft0;)V

    .line 8
    .line 9
    .line 10
    return-object v0
.end method

.method public final m(Ljava/util/LinkedHashSet;Ldv1;)V
    .registers 6

    .line 1
    iget-object v0, p0, Luh1;->o:Lbh1;

    .line 2
    .line 3
    invoke-static {v0}, Lc10;->r(Lxt1;)Luh1;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    if-nez v1, :cond_b

    .line 8
    .line 9
    sget-object v1, Lxh0;->a:Lxh0;

    .line 10
    .line 11
    goto :goto_17

    .line 12
    :cond_b
    sget-object v2, Lnw1;->e:Lnw1;

    .line 13
    .line 14
    invoke-virtual {v1, p2, v2}, Lrh1;->b(Ldv1;Lnw1;)Ljava/util/Collection;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    check-cast v1, Ljava/lang/Iterable;

    .line 19
    .line 20
    invoke-static {v1}, Lgv;->C0(Ljava/lang/Iterable;)Ljava/util/Set;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    :goto_17
    iget-object v2, p0, Lrh1;->b:Lfk;

    .line 25
    .line 26
    iget-object v2, v2, Lfk;->a:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast v2, Lx41;

    .line 29
    .line 30
    iget-object v2, v2, Lx41;->l:Lkw1;

    .line 31
    .line 32
    check-cast v2, Llw1;

    .line 33
    .line 34
    iget-object v2, v2, Llw1;->d:Lr02;

    .line 35
    .line 36
    invoke-static {p2, v1, p1, v0, v2}, Llw0;->l0(Ldv1;Ljava/util/Collection;Ljava/util/AbstractCollection;Lxt1;Lr02;)Ljava/util/LinkedHashSet;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    invoke-interface {p1, v1}, Ljava/util/Collection;->addAll(Ljava/util/Collection;)Z

    .line 41
    .line 42
    .line 43
    iget-object p0, p0, Luh1;->n:Lxc2;

    .line 44
    .line 45
    iget-object p0, p0, Lxc2;->a:Ljava/lang/Class;

    .line 46
    .line 47
    invoke-virtual {p0}, Ljava/lang/Class;->isEnum()Z

    .line 48
    .line 49
    .line 50
    move-result p0

    .line 51
    if-eqz p0, :cond_53

    .line 52
    .line 53
    sget-object p0, Lrr2;->c:Ldv1;

    .line 54
    .line 55
    invoke-virtual {p2, p0}, Ldv1;->equals(Ljava/lang/Object;)Z

    .line 56
    .line 57
    .line 58
    move-result p0

    .line 59
    if-eqz p0, :cond_44

    .line 60
    .line 61
    invoke-static {v0}, Lyo1;->l(Lxt1;)Leo2;

    .line 62
    .line 63
    .line 64
    move-result-object p0

    .line 65
    invoke-interface {p1, p0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 66
    .line 67
    .line 68
    return-void

    .line 69
    :cond_44
    sget-object p0, Lrr2;->a:Ldv1;

    .line 70
    .line 71
    invoke-virtual {p2, p0}, Ldv1;->equals(Ljava/lang/Object;)Z

    .line 72
    .line 73
    .line 74
    move-result p0

    .line 75
    if-eqz p0, :cond_53

    .line 76
    .line 77
    invoke-static {v0}, Lyo1;->m(Lxt1;)Leo2;

    .line 78
    .line 79
    .line 80
    move-result-object p0

    .line 81
    invoke-interface {p1, p0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 82
    .line 83
    .line 84
    :cond_53
    return-void
.end method

.method public final n(Ldv1;Ljava/util/ArrayList;)V
    .registers 10

    .line 1
    new-instance v0, Ljava/util/LinkedHashSet;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    .line 4
    .line 5
    .line 6
    new-instance v1, Lk;

    .line 7
    .line 8
    const/16 v2, 0x10

    .line 9
    .line 10
    invoke-direct {v1, v2, p1}, Lk;-><init>(ILjava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    iget-object v2, p0, Luh1;->o:Lbh1;

    .line 14
    .line 15
    invoke-static {v2}, Lia1;->u(Ljava/lang/Object;)Ljava/util/List;

    .line 16
    .line 17
    .line 18
    move-result-object v3

    .line 19
    check-cast v3, Ljava/util/Collection;

    .line 20
    .line 21
    sget-object v4, Lby0;->j:Lby0;

    .line 22
    .line 23
    new-instance v5, Lth1;

    .line 24
    .line 25
    invoke-direct {v5, v2, v0, v1}, Lth1;-><init>(Lxt1;Ljava/util/Set;Lft0;)V

    .line 26
    .line 27
    .line 28
    invoke-static {v3, v4, v5}, Lg70;->d(Ljava/util/Collection;Ly40;Ll60;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    invoke-virtual {p2}, Ljava/util/ArrayList;->isEmpty()Z

    .line 32
    .line 33
    .line 34
    move-result v1

    .line 35
    iget-object v3, p0, Lrh1;->b:Lfk;

    .line 36
    .line 37
    if-nez v1, :cond_38

    .line 38
    .line 39
    iget-object v1, v3, Lfk;->a:Ljava/lang/Object;

    .line 40
    .line 41
    check-cast v1, Lx41;

    .line 42
    .line 43
    iget-object v1, v1, Lx41;->l:Lkw1;

    .line 44
    .line 45
    check-cast v1, Llw1;

    .line 46
    .line 47
    iget-object v1, v1, Llw1;->d:Lr02;

    .line 48
    .line 49
    invoke-static {p1, v0, p2, v2, v1}, Llw0;->l0(Ldv1;Ljava/util/Collection;Ljava/util/AbstractCollection;Lxt1;Lr02;)Ljava/util/LinkedHashSet;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 54
    .line 55
    .line 56
    goto :goto_9a

    .line 57
    :cond_38
    new-instance v1, Ljava/util/LinkedHashMap;

    .line 58
    .line 59
    invoke-direct {v1}, Ljava/util/LinkedHashMap;-><init>()V

    .line 60
    .line 61
    .line 62
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    :goto_41
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 67
    .line 68
    .line 69
    move-result v4

    .line 70
    if-eqz v4, :cond_66

    .line 71
    .line 72
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v4

    .line 76
    move-object v5, v4

    .line 77
    check-cast v5, Ll52;

    .line 78
    .line 79
    invoke-static {v5}, Luh1;->v(Ll52;)Ll52;

    .line 80
    .line 81
    .line 82
    move-result-object v5

    .line 83
    invoke-virtual {v1, v5}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v6

    .line 87
    if-nez v6, :cond_60

    .line 88
    .line 89
    new-instance v6, Ljava/util/ArrayList;

    .line 90
    .line 91
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 92
    .line 93
    .line 94
    invoke-interface {v1, v5, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    :cond_60
    check-cast v6, Ljava/util/List;

    .line 98
    .line 99
    invoke-interface {v6, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 100
    .line 101
    .line 102
    goto :goto_41

    .line 103
    :cond_66
    new-instance v0, Ljava/util/ArrayList;

    .line 104
    .line 105
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 106
    .line 107
    .line 108
    invoke-virtual {v1}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    .line 109
    .line 110
    .line 111
    move-result-object v1

    .line 112
    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 113
    .line 114
    .line 115
    move-result-object v1

    .line 116
    :goto_73
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 117
    .line 118
    .line 119
    move-result v4

    .line 120
    if-eqz v4, :cond_97

    .line 121
    .line 122
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 123
    .line 124
    .line 125
    move-result-object v4

    .line 126
    check-cast v4, Ljava/util/Map$Entry;

    .line 127
    .line 128
    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 129
    .line 130
    .line 131
    move-result-object v4

    .line 132
    check-cast v4, Ljava/util/Collection;

    .line 133
    .line 134
    iget-object v5, v3, Lfk;->a:Ljava/lang/Object;

    .line 135
    .line 136
    check-cast v5, Lx41;

    .line 137
    .line 138
    iget-object v5, v5, Lx41;->l:Lkw1;

    .line 139
    .line 140
    check-cast v5, Llw1;

    .line 141
    .line 142
    iget-object v5, v5, Llw1;->d:Lr02;

    .line 143
    .line 144
    invoke-static {p1, v4, p2, v2, v5}, Llw0;->l0(Ldv1;Ljava/util/Collection;Ljava/util/AbstractCollection;Lxt1;Lr02;)Ljava/util/LinkedHashSet;

    .line 145
    .line 146
    .line 147
    move-result-object v4

    .line 148
    invoke-static {v0, v4}, Lmv;->O(Ljava/util/Collection;Ljava/lang/Iterable;)V

    .line 149
    .line 150
    .line 151
    goto :goto_73

    .line 152
    :cond_97
    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 153
    .line 154
    .line 155
    :goto_9a
    iget-object p0, p0, Luh1;->n:Lxc2;

    .line 156
    .line 157
    iget-object p0, p0, Lxc2;->a:Ljava/lang/Class;

    .line 158
    .line 159
    invoke-virtual {p0}, Ljava/lang/Class;->isEnum()Z

    .line 160
    .line 161
    .line 162
    move-result p0

    .line 163
    if-eqz p0, :cond_b5

    .line 164
    .line 165
    sget-object p0, Lrr2;->b:Ldv1;

    .line 166
    .line 167
    invoke-virtual {p1, p0}, Ldv1;->equals(Ljava/lang/Object;)Z

    .line 168
    .line 169
    .line 170
    move-result p0

    .line 171
    if-eqz p0, :cond_b5

    .line 172
    .line 173
    invoke-static {v2}, Lyo1;->k(Lxt1;)Ln52;

    .line 174
    .line 175
    .line 176
    move-result-object p0

    .line 177
    if-eqz p0, :cond_b5

    .line 178
    .line 179
    invoke-virtual {p2, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 180
    .line 181
    .line 182
    :cond_b5
    return-void
.end method

.method public final o(Lma0;)Ljava/util/Set;
    .registers 7

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object p1, p0, Lrh1;->e:Lzl1;

    .line 5
    .line 6
    invoke-virtual {p1}, Lzl1;->invoke()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    check-cast p1, Lt60;

    .line 11
    .line 12
    invoke-interface {p1}, Lt60;->e()Ljava/util/Set;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    invoke-static {p1}, Lgv;->B0(Ljava/lang/Iterable;)Ljava/util/Set;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    sget-object v0, Lsh1;->b:Lsh1;

    .line 21
    .line 22
    iget-object v1, p0, Luh1;->o:Lbh1;

    .line 23
    .line 24
    invoke-static {v1}, Lia1;->u(Ljava/lang/Object;)Ljava/util/List;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    check-cast v2, Ljava/util/Collection;

    .line 29
    .line 30
    sget-object v3, Lby0;->j:Lby0;

    .line 31
    .line 32
    new-instance v4, Lth1;

    .line 33
    .line 34
    invoke-direct {v4, v1, p1, v0}, Lth1;-><init>(Lxt1;Ljava/util/Set;Lft0;)V

    .line 35
    .line 36
    .line 37
    invoke-static {v2, v3, v4}, Lg70;->d(Ljava/util/Collection;Ly40;Ll60;)Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    iget-object p0, p0, Luh1;->n:Lxc2;

    .line 41
    .line 42
    iget-object p0, p0, Lxc2;->a:Ljava/lang/Class;

    .line 43
    .line 44
    invoke-virtual {p0}, Ljava/lang/Class;->isEnum()Z

    .line 45
    .line 46
    .line 47
    move-result p0

    .line 48
    if-eqz p0, :cond_36

    .line 49
    .line 50
    sget-object p0, Lrr2;->b:Ldv1;

    .line 51
    .line 52
    invoke-interface {p1, p0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 53
    .line 54
    .line 55
    :cond_36
    return-object p1
.end method

.method public final q()Lm60;
    .registers 1

    .line 1
    iget-object p0, p0, Luh1;->o:Lbh1;

    .line 2
    .line 3
    return-object p0
.end method
