###### Class defpackage.nx3 (nx3)
.class public final Lnx3;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Las3;

.field public final synthetic c:Lpx3;


# direct methods
.method public synthetic constructor <init>(Lpx3;Las3;I)V
    .registers 4

    .line 1
    iput p3, p0, Lnx3;->a:I

    .line 2
    .line 3
    iput-object p2, p0, Lnx3;->b:Las3;

    .line 4
    .line 5
    iput-object p1, p0, Lnx3;->c:Lpx3;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    .line 1
    iget v0, p0, Lnx3;->a:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    packed-switch v0, :pswitch_data_76

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lnx3;->c:Lpx3;

    .line 8
    .line 9
    monitor-enter v0

    .line 10
    :try_start_9
    iget-object v2, p0, Lnx3;->c:Lpx3;

    .line 11
    .line 12
    iput-boolean v1, v2, Lpx3;->a:Z

    .line 13
    .line 14
    iget-object v1, p0, Lnx3;->c:Lpx3;

    .line 15
    .line 16
    iget-object v1, v1, Lpx3;->c:Lbx3;

    .line 17
    .line 18
    invoke-virtual {v1}, Lbx3;->V0()Z

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    if-nez v1, :cond_3a

    .line 23
    .line 24
    iget-object v1, p0, Lnx3;->c:Lpx3;

    .line 25
    .line 26
    iget-object v1, v1, Lpx3;->c:Lbx3;

    .line 27
    .line 28
    invoke-virtual {v1}, Lov;->l()Lqs3;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    iget-object v1, v1, Lqs3;->r:Lts3;

    .line 33
    .line 34
    const-string v2, "Connected to remote service"

    .line 35
    .line 36
    invoke-virtual {v1, v2}, Lts3;->c(Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    iget-object v1, p0, Lnx3;->c:Lpx3;

    .line 40
    .line 41
    iget-object v1, v1, Lpx3;->c:Lbx3;

    .line 42
    .line 43
    iget-object p0, p0, Lnx3;->b:Las3;

    .line 44
    .line 45
    invoke-virtual {v1}, Lgp3;->H0()V

    .line 46
    .line 47
    .line 48
    iput-object p0, v1, Lbx3;->f:Las3;

    .line 49
    .line 50
    invoke-virtual {v1}, Lbx3;->Z0()V

    .line 51
    .line 52
    .line 53
    invoke-virtual {v1}, Lbx3;->Y0()V

    .line 54
    .line 55
    .line 56
    goto :goto_3a

    .line 57
    :catchall_38
    move-exception p0

    .line 58
    goto :goto_3c

    .line 59
    :cond_3a
    :goto_3a
    monitor-exit v0

    .line 60
    return-void

    .line 61
    :goto_3c
    monitor-exit v0
    :try_end_3d
    .catchall {:try_start_9 .. :try_end_3d} :catchall_38

    .line 62
    throw p0

    .line 63
    :pswitch_3e
    iget-object v0, p0, Lnx3;->c:Lpx3;

    .line 64
    .line 65
    monitor-enter v0

    .line 66
    :try_start_41
    iget-object v2, p0, Lnx3;->c:Lpx3;

    .line 67
    .line 68
    iput-boolean v1, v2, Lpx3;->a:Z

    .line 69
    .line 70
    iget-object v1, p0, Lnx3;->c:Lpx3;

    .line 71
    .line 72
    iget-object v1, v1, Lpx3;->c:Lbx3;

    .line 73
    .line 74
    invoke-virtual {v1}, Lbx3;->V0()Z

    .line 75
    .line 76
    .line 77
    move-result v1

    .line 78
    if-nez v1, :cond_72

    .line 79
    .line 80
    iget-object v1, p0, Lnx3;->c:Lpx3;

    .line 81
    .line 82
    iget-object v1, v1, Lpx3;->c:Lbx3;

    .line 83
    .line 84
    invoke-virtual {v1}, Lov;->l()Lqs3;

    .line 85
    .line 86
    .line 87
    move-result-object v1

    .line 88
    iget-object v1, v1, Lqs3;->s:Lts3;

    .line 89
    .line 90
    const-string v2, "Connected to service"

    .line 91
    .line 92
    invoke-virtual {v1, v2}, Lts3;->c(Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    iget-object v1, p0, Lnx3;->c:Lpx3;

    .line 96
    .line 97
    iget-object v1, v1, Lpx3;->c:Lbx3;

    .line 98
    .line 99
    iget-object p0, p0, Lnx3;->b:Las3;

    .line 100
    .line 101
    invoke-virtual {v1}, Lgp3;->H0()V

    .line 102
    .line 103
    .line 104
    iput-object p0, v1, Lbx3;->f:Las3;

    .line 105
    .line 106
    invoke-virtual {v1}, Lbx3;->Z0()V

    .line 107
    .line 108
    .line 109
    invoke-virtual {v1}, Lbx3;->Y0()V

    .line 110
    .line 111
    .line 112
    goto :goto_72

    .line 113
    :catchall_70
    move-exception p0

    .line 114
    goto :goto_74

    .line 115
    :cond_72
    :goto_72
    monitor-exit v0

    .line 116
    return-void

    .line 117
    :goto_74
    monitor-exit v0
    :try_end_75
    .catchall {:try_start_41 .. :try_end_75} :catchall_70

    .line 118
    throw p0

    .line 119
    :pswitch_data_76
    .packed-switch 0x0
        :pswitch_3e
    .end packed-switch
.end method
