###### Class defpackage.ie1 (ie1)
.class public final Lie1;
.super Lod1;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final b:Ljava/lang/Class;

.field public final c:Lrg1;


# direct methods
.method public constructor <init>(Ljava/lang/Class;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lie1;->b:Ljava/lang/Class;

    .line 5
    .line 6
    new-instance p1, Lde1;

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    invoke-direct {p1, p0, v0}, Lde1;-><init>(Lie1;I)V

    .line 10
    .line 11
    .line 12
    sget-object v0, Lhi1;->a:Lhi1;

    .line 13
    .line 14
    invoke-static {v0, p1}, Lc10;->u(Lhi1;Ldt0;)Lrg1;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    iput-object p1, p0, Lie1;->c:Lrg1;

    .line 19
    .line 20
    return-void
.end method


# virtual methods
.method public final e()Ljava/lang/Class;
    .registers 1

    .line 1
    iget-object p0, p0, Lie1;->b:Ljava/lang/Class;

    .line 2
    .line 3
    return-object p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 3

    .line 1
    instance-of v0, p1, Lie1;

    .line 2
    .line 3
    if-eqz v0, :cond_12

    .line 4
    .line 5
    check-cast p1, Lie1;

    .line 6
    .line 7
    iget-object p1, p1, Lie1;->b:Ljava/lang/Class;

    .line 8
    .line 9
    iget-object p0, p0, Lie1;->b:Ljava/lang/Class;

    .line 10
    .line 11
    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 12
    .line 13
    .line 14
    move-result p0

    .line 15
    if-eqz p0, :cond_12

    .line 16
    .line 17
    const/4 p0, 0x1

    .line 18
    return p0

    .line 19
    :cond_12
    const/4 p0, 0x0

    .line 20
    return p0
.end method

.method public final hashCode()I
    .registers 1

    .line 1
    iget-object p0, p0, Lie1;->b:Ljava/lang/Class;

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final i()Ljava/util/Collection;
    .registers 1

    .line 1
    sget-object p0, Lth0;->a:Lth0;

    .line 2
    .line 3
    return-object p0
.end method

.method public final j(Ldv1;)Ljava/util/Collection;
    .registers 4

    .line 1
    iget-object p0, p0, Lie1;->c:Lrg1;

    .line 2
    .line 3
    invoke-interface {p0}, Lrg1;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lge1;

    .line 8
    .line 9
    iget-object p0, p0, Lge1;->d:Lsd2;

    .line 10
    .line 11
    sget-object v0, Lge1;->g:[Laf1;

    .line 12
    .line 13
    const/4 v1, 0x1

    .line 14
    aget-object v0, v0, v1

    .line 15
    .line 16
    invoke-virtual {p0}, Lsd2;->invoke()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 21
    .line 22
    .line 23
    check-cast p0, Lvr1;

    .line 24
    .line 25
    sget-object v0, Lnw1;->b:Lnw1;

    .line 26
    .line 27
    invoke-interface {p0, p1, v0}, Lvr1;->b(Ldv1;Lnw1;)Ljava/util/Collection;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    return-object p0
.end method

.method public final k(I)Ll52;
    .registers 10

    .line 1
    iget-object v0, p0, Lie1;->c:Lrg1;

    .line 2
    .line 3
    invoke-interface {v0}, Lrg1;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lge1;

    .line 8
    .line 9
    iget-object v0, v0, Lge1;->f:Lrg1;

    .line 10
    .line 11
    invoke-interface {v0}, Lrg1;->getValue()Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    check-cast v0, Lz03;

    .line 16
    .line 17
    if-eqz v0, :cond_43

    .line 18
    .line 19
    iget-object v1, v0, Lz03;->a:Ljava/lang/Object;

    .line 20
    .line 21
    move-object v4, v1

    .line 22
    check-cast v4, Lsb1;

    .line 23
    .line 24
    iget-object v1, v0, Lz03;->b:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast v1, Le72;

    .line 27
    .line 28
    iget-object v0, v0, Lz03;->c:Ljava/lang/Object;

    .line 29
    .line 30
    move-object v6, v0

    .line 31
    check-cast v6, Lrb1;

    .line 32
    .line 33
    sget-object v0, Llc1;->n:Liv0;

    .line 34
    .line 35
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 36
    .line 37
    .line 38
    invoke-static {v1, v0, p1}, Lfw;->p(Lgv0;Liv0;I)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    move-object v3, p1

    .line 43
    check-cast v3, Li72;

    .line 44
    .line 45
    if-eqz v3, :cond_43

    .line 46
    .line 47
    new-instance v5, Lkd0;

    .line 48
    .line 49
    iget-object p1, v1, Le72;->g:Ly72;

    .line 50
    .line 51
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 52
    .line 53
    .line 54
    invoke-direct {v5, p1}, Lkd0;-><init>(Ly72;)V

    .line 55
    .line 56
    .line 57
    sget-object v7, Lhe1;->j:Lhe1;

    .line 58
    .line 59
    iget-object v2, p0, Lie1;->b:Ljava/lang/Class;

    .line 60
    .line 61
    invoke-static/range {v2 .. v7}, Ln63;->f(Ljava/lang/Class;Lgv0;Lev1;Lkd0;Lgk;Ltt0;)Llo;

    .line 62
    .line 63
    .line 64
    move-result-object p0

    .line 65
    check-cast p0, Ll52;

    .line 66
    .line 67
    return-object p0

    .line 68
    :cond_43
    const/4 p0, 0x0

    .line 69
    return-object p0
.end method

.method public final m()Ljava/lang/Class;
    .registers 2

    .line 1
    iget-object v0, p0, Lie1;->c:Lrg1;

    .line 2
    .line 3
    invoke-interface {v0}, Lrg1;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lge1;

    .line 8
    .line 9
    iget-object v0, v0, Lge1;->e:Lrg1;

    .line 10
    .line 11
    invoke-interface {v0}, Lrg1;->getValue()Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    check-cast v0, Ljava/lang/Class;

    .line 16
    .line 17
    if-nez v0, :cond_15

    .line 18
    .line 19
    iget-object p0, p0, Lie1;->b:Ljava/lang/Class;

    .line 20
    .line 21
    return-object p0

    .line 22
    :cond_15
    return-object v0
.end method

.method public final n(Ldv1;)Ljava/util/Collection;
    .registers 4

    .line 1
    iget-object p0, p0, Lie1;->c:Lrg1;

    .line 2
    .line 3
    invoke-interface {p0}, Lrg1;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lge1;

    .line 8
    .line 9
    iget-object p0, p0, Lge1;->d:Lsd2;

    .line 10
    .line 11
    sget-object v0, Lge1;->g:[Laf1;

    .line 12
    .line 13
    const/4 v1, 0x1

    .line 14
    aget-object v0, v0, v1

    .line 15
    .line 16
    invoke-virtual {p0}, Lsd2;->invoke()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 21
    .line 22
    .line 23
    check-cast p0, Lvr1;

    .line 24
    .line 25
    sget-object v0, Lnw1;->b:Lnw1;

    .line 26
    .line 27
    invoke-interface {p0, p1, v0}, Lvr1;->c(Ldv1;Lnw1;)Ljava/util/Collection;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "file class "

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object p0, p0, Lie1;->b:Ljava/lang/Class;

    .line 9
    .line 10
    invoke-static {p0}, Lmc2;->a(Ljava/lang/Class;)Lft;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    invoke-virtual {p0}, Lft;->a()Lzq0;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 19
    .line 20
    .line 21
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object p0

    .line 25
    return-object p0
.end method
