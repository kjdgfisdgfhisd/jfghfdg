###### Class defpackage.hz1 (hz1)
.class public final Lhz1;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field public static final a:Lhz1;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Lhz1;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lhz1;->a:Lhz1;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a(Lft0;Lft0;Ldt0;Ldt0;)Landroid/window/OnBackInvokedCallback;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lft0;",
            "Lft0;",
            "Ldt0;",
            "Ldt0;",
            ")",
            "Landroid/window/OnBackInvokedCallback;"
        }
    .end annotation

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    new-instance p0, Lgz1;

    .line 14
    .line 15
    invoke-direct {p0, p1, p2, p3, p4}, Lgz1;-><init>(Lft0;Lft0;Ldt0;Ldt0;)V

    .line 16
    .line 17
    .line 18
    return-object p0
.end method
