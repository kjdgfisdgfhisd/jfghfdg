###### Class defpackage.ot3 (ot3)
.class public abstract Lot3;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field public static volatile a:Li02;

.field public static final b:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    sget-object v0, Li;->a:Li;

    .line 2
    .line 3
    sput-object v0, Lot3;->a:Li02;

    .line 4
    .line 5
    new-instance v0, Ljava/lang/Object;

    .line 6
    .line 7
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    sput-object v0, Lot3;->b:Ljava/lang/Object;

    .line 11
    .line 12
    return-void
.end method
