###### Class defpackage.nb1 (nb1)
.class public final Lnb1;
.super Lh23;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final c:Lqb1;

.field public final d:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lqb1;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lnb1;->c:Lqb1;

    .line 5
    .line 6
    invoke-virtual {p1}, Lqb1;->a()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    iput-object p1, p0, Lnb1;->d:Ljava/lang/String;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final c()Ljava/lang/String;
    .registers 1

    .line 1
    iget-object p0, p0, Lnb1;->d:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method
