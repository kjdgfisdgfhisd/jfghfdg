###### Class defpackage.nv3 (nv3)
.class public final synthetic Lnv3;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public synthetic b:Landroid/os/Bundle;

.field public synthetic c:Lhv3;


# direct methods
.method public synthetic constructor <init>()V
    .registers 2

    .line 11
    const/4 v0, 0x0

    iput v0, p0, Lnv3;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lhv3;Landroid/os/Bundle;I)V
    .registers 4

    .line 1
    iput p3, p0, Lnv3;->a:I

    .line 2
    .line 3
    iput-object p2, p0, Lnv3;->b:Landroid/os/Bundle;

    .line 4
    .line 5
    iput-object p1, p0, Lnv3;->c:Lhv3;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final run()V
    .registers 32

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, Lnv3;->a:I

    .line 4
    .line 5
    const-string v2, "time_to_live"

    .line 6
    .line 7
    const-string v3, "trigger_timeout"

    .line 8
    .line 9
    const-string v4, "trigger_event_name"

    .line 10
    .line 11
    const-string v5, "creation_timestamp"

    .line 12
    .line 13
    const-string v6, "expired_event_params"

    .line 14
    .line 15
    const-string v7, "expired_event_name"

    .line 16
    .line 17
    const-string v8, "name"

    .line 18
    .line 19
    const-string v9, "app_id"

    .line 20
    .line 21
    packed-switch v1, :pswitch_data_286

    .line 22
    .line 23
    .line 24
    iget-object v1, v0, Lnv3;->c:Lhv3;

    .line 25
    .line 26
    iget-object v0, v0, Lnv3;->b:Landroid/os/Bundle;

    .line 27
    .line 28
    invoke-virtual {v1}, Lgp3;->H0()V

    .line 29
    .line 30
    .line 31
    invoke-virtual {v1}, Let3;->L0()V

    .line 32
    .line 33
    .line 34
    invoke-virtual {v0, v8}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v14

    .line 38
    const-string v8, "origin"

    .line 39
    .line 40
    invoke-virtual {v0, v8}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v18

    .line 44
    invoke-static {v14}, Lmw1;->g(Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    invoke-static/range {v18 .. v18}, Lmw1;->g(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    const-string v8, "value"

    .line 51
    .line 52
    invoke-virtual {v0, v8}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v10

    .line 56
    invoke-static {v10}, Lmw1;->k(Ljava/lang/Object;)V

    .line 57
    .line 58
    .line 59
    iget-object v10, v1, Lov;->a:Ljava/lang/Object;

    .line 60
    .line 61
    move-object/from16 v30, v10

    .line 62
    .line 63
    check-cast v30, Lzt3;

    .line 64
    .line 65
    invoke-virtual/range {v30 .. v30}, Lzt3;->f()Z

    .line 66
    .line 67
    .line 68
    move-result v10

    .line 69
    if-nez v10, :cond_53

    .line 70
    .line 71
    invoke-virtual {v1}, Lov;->l()Lqs3;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    iget-object v0, v0, Lqs3;->s:Lts3;

    .line 76
    .line 77
    const-string v1, "Conditional property not set since app measurement is disabled"

    .line 78
    .line 79
    invoke-virtual {v0, v1}, Lts3;->c(Ljava/lang/String;)V

    .line 80
    .line 81
    .line 82
    goto/16 :goto_d7

    .line 83
    .line 84
    :cond_53
    new-instance v10, Lvz3;

    .line 85
    .line 86
    const-string v11, "triggered_timestamp"

    .line 87
    .line 88
    invoke-virtual {v0, v11}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;)J

    .line 89
    .line 90
    .line 91
    move-result-wide v11

    .line 92
    invoke-virtual {v0, v8}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object v13

    .line 96
    move-object/from16 v15, v18

    .line 97
    .line 98
    invoke-direct/range {v10 .. v15}, Lvz3;-><init>(JLjava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 99
    .line 100
    .line 101
    :try_start_64
    invoke-virtual {v1}, Lov;->G0()Lb04;

    .line 102
    .line 103
    .line 104
    move-result-object v15

    .line 105
    invoke-virtual {v0, v9}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 106
    .line 107
    .line 108
    const-string v8, "triggered_event_name"

    .line 109
    .line 110
    invoke-virtual {v0, v8}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    move-result-object v16

    .line 114
    const-string v8, "triggered_event_params"

    .line 115
    .line 116
    invoke-virtual {v0, v8}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    .line 117
    .line 118
    .line 119
    move-result-object v17

    .line 120
    const-wide/16 v19, 0x0

    .line 121
    .line 122
    const/16 v21, 0x1

    .line 123
    .line 124
    invoke-virtual/range {v15 .. v21}, Lb04;->W0(Ljava/lang/String;Landroid/os/Bundle;Ljava/lang/String;JZ)Lhn3;

    .line 125
    .line 126
    .line 127
    move-result-object v26

    .line 128
    invoke-virtual {v1}, Lov;->G0()Lb04;

    .line 129
    .line 130
    .line 131
    move-result-object v15

    .line 132
    invoke-virtual {v0, v9}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 133
    .line 134
    .line 135
    const-string v8, "timed_out_event_name"

    .line 136
    .line 137
    invoke-virtual {v0, v8}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 138
    .line 139
    .line 140
    move-result-object v16

    .line 141
    const-string v8, "timed_out_event_params"

    .line 142
    .line 143
    invoke-virtual {v0, v8}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    .line 144
    .line 145
    .line 146
    move-result-object v17

    .line 147
    const-wide/16 v19, 0x0

    .line 148
    .line 149
    const/16 v21, 0x1

    .line 150
    .line 151
    invoke-virtual/range {v15 .. v21}, Lb04;->W0(Ljava/lang/String;Landroid/os/Bundle;Ljava/lang/String;JZ)Lhn3;

    .line 152
    .line 153
    .line 154
    move-result-object v23

    .line 155
    invoke-virtual {v1}, Lov;->G0()Lb04;

    .line 156
    .line 157
    .line 158
    move-result-object v15

    .line 159
    invoke-virtual {v0, v9}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 160
    .line 161
    .line 162
    invoke-virtual {v0, v7}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 163
    .line 164
    .line 165
    move-result-object v16

    .line 166
    invoke-virtual {v0, v6}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    .line 167
    .line 168
    .line 169
    move-result-object v17

    .line 170
    const-wide/16 v19, 0x0

    .line 171
    .line 172
    const/16 v21, 0x1

    .line 173
    .line 174
    invoke-virtual/range {v15 .. v21}, Lb04;->W0(Ljava/lang/String;Landroid/os/Bundle;Ljava/lang/String;JZ)Lhn3;

    .line 175
    .line 176
    .line 177
    move-result-object v29
    :try_end_b1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_64 .. :try_end_b1} :catch_d7

    .line 178
    new-instance v15, Lll3;

    .line 179
    .line 180
    invoke-virtual {v0, v9}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 181
    .line 182
    .line 183
    move-result-object v16

    .line 184
    invoke-virtual {v0, v5}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;)J

    .line 185
    .line 186
    .line 187
    move-result-wide v19

    .line 188
    invoke-virtual {v0, v4}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 189
    .line 190
    .line 191
    move-result-object v22

    .line 192
    invoke-virtual {v0, v3}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;)J

    .line 193
    .line 194
    .line 195
    move-result-wide v24

    .line 196
    invoke-virtual {v0, v2}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;)J

    .line 197
    .line 198
    .line 199
    move-result-wide v27

    .line 200
    const/16 v21, 0x0

    .line 201
    .line 202
    move-object/from16 v17, v18

    .line 203
    .line 204
    move-object/from16 v18, v10

    .line 205
    .line 206
    invoke-direct/range {v15 .. v29}, Lll3;-><init>(Ljava/lang/String;Ljava/lang/String;Lvz3;JZLjava/lang/String;Lhn3;JLhn3;JLhn3;)V

    .line 207
    .line 208
    .line 209
    invoke-virtual/range {v30 .. v30}, Lzt3;->o()Lbx3;

    .line 210
    .line 211
    .line 212
    move-result-object v0

    .line 213
    invoke-virtual {v0, v15}, Lbx3;->Q0(Lll3;)V

    .line 214
    .line 215
    .line 216
    :catch_d7
    :goto_d7
    return-void

    .line 217
    :pswitch_d8
    iget-object v1, v0, Lnv3;->c:Lhv3;

    .line 218
    .line 219
    iget-object v0, v0, Lnv3;->b:Landroid/os/Bundle;

    .line 220
    .line 221
    invoke-virtual {v1}, Lgp3;->H0()V

    .line 222
    .line 223
    .line 224
    invoke-virtual {v1}, Let3;->L0()V

    .line 225
    .line 226
    .line 227
    invoke-virtual {v0, v8}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 228
    .line 229
    .line 230
    move-result-object v14

    .line 231
    invoke-static {v14}, Lmw1;->g(Ljava/lang/String;)V

    .line 232
    .line 233
    .line 234
    iget-object v8, v1, Lov;->a:Ljava/lang/Object;

    .line 235
    .line 236
    check-cast v8, Lzt3;

    .line 237
    .line 238
    invoke-virtual {v8}, Lzt3;->f()Z

    .line 239
    .line 240
    .line 241
    move-result v10

    .line 242
    if-nez v10, :cond_ff

    .line 243
    .line 244
    invoke-virtual {v1}, Lov;->l()Lqs3;

    .line 245
    .line 246
    .line 247
    move-result-object v0

    .line 248
    iget-object v0, v0, Lqs3;->s:Lts3;

    .line 249
    .line 250
    const-string v1, "Conditional property not cleared since app measurement is disabled"

    .line 251
    .line 252
    invoke-virtual {v0, v1}, Lts3;->c(Ljava/lang/String;)V

    .line 253
    .line 254
    .line 255
    goto :goto_153

    .line 256
    :cond_ff
    new-instance v10, Lvz3;

    .line 257
    .line 258
    const/4 v13, 0x0

    .line 259
    const-string v15, ""

    .line 260
    .line 261
    const-wide/16 v11, 0x0

    .line 262
    .line 263
    invoke-direct/range {v10 .. v15}, Lvz3;-><init>(JLjava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 264
    .line 265
    .line 266
    :try_start_109
    invoke-virtual {v1}, Lov;->G0()Lb04;

    .line 267
    .line 268
    .line 269
    move-result-object v11

    .line 270
    invoke-virtual {v0, v9}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 271
    .line 272
    .line 273
    invoke-virtual {v0, v7}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 274
    .line 275
    .line 276
    move-result-object v12

    .line 277
    invoke-virtual {v0, v6}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    .line 278
    .line 279
    .line 280
    move-result-object v13

    .line 281
    const-string v14, ""

    .line 282
    .line 283
    invoke-virtual {v0, v5}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;)J

    .line 284
    .line 285
    .line 286
    move-result-wide v15

    .line 287
    const/16 v17, 0x1

    .line 288
    .line 289
    invoke-virtual/range {v11 .. v17}, Lb04;->W0(Ljava/lang/String;Landroid/os/Bundle;Ljava/lang/String;JZ)Lhn3;

    .line 290
    .line 291
    .line 292
    move-result-object v23
    :try_end_124
    .catch Ljava/lang/IllegalArgumentException; {:try_start_109 .. :try_end_124} :catch_153

    .line 293
    new-instance v1, Lll3;

    .line 294
    .line 295
    invoke-virtual {v0, v9}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 296
    .line 297
    .line 298
    move-result-object v6

    .line 299
    invoke-virtual {v0, v5}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;)J

    .line 300
    .line 301
    .line 302
    move-result-wide v13

    .line 303
    const-string v5, "active"

    .line 304
    .line 305
    invoke-virtual {v0, v5}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    .line 306
    .line 307
    .line 308
    move-result v15

    .line 309
    invoke-virtual {v0, v4}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 310
    .line 311
    .line 312
    move-result-object v16

    .line 313
    invoke-virtual {v0, v3}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;)J

    .line 314
    .line 315
    .line 316
    move-result-wide v18

    .line 317
    const/16 v20, 0x0

    .line 318
    .line 319
    invoke-virtual {v0, v2}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;)J

    .line 320
    .line 321
    .line 322
    move-result-wide v21

    .line 323
    const-string v11, ""

    .line 324
    .line 325
    const/16 v17, 0x0

    .line 326
    .line 327
    move-object v9, v1

    .line 328
    move-object v12, v10

    .line 329
    move-object v10, v6

    .line 330
    invoke-direct/range {v9 .. v23}, Lll3;-><init>(Ljava/lang/String;Ljava/lang/String;Lvz3;JZLjava/lang/String;Lhn3;JLhn3;JLhn3;)V

    .line 331
    .line 332
    .line 333
    invoke-virtual {v8}, Lzt3;->o()Lbx3;

    .line 334
    .line 335
    .line 336
    move-result-object v0

    .line 337
    invoke-virtual {v0, v9}, Lbx3;->Q0(Lll3;)V

    .line 338
    .line 339
    .line 340
    :catch_153
    :goto_153
    return-void

    .line 341
    :pswitch_154
    iget-object v1, v0, Lnv3;->c:Lhv3;

    .line 342
    .line 343
    iget-object v0, v0, Lnv3;->b:Landroid/os/Bundle;

    .line 344
    .line 345
    iget-object v2, v1, Lhv3;->A:Luk3;

    .line 346
    .line 347
    iget-object v3, v1, Lov;->a:Ljava/lang/Object;

    .line 348
    .line 349
    move-object v8, v3

    .line 350
    check-cast v8, Lzt3;

    .line 351
    .line 352
    invoke-virtual {v0}, Landroid/os/BaseBundle;->isEmpty()Z

    .line 353
    .line 354
    .line 355
    move-result v3

    .line 356
    const/4 v9, 0x0

    .line 357
    const/4 v10, 0x0

    .line 358
    if-eqz v3, :cond_16a

    .line 359
    .line 360
    move-object v12, v0

    .line 361
    goto/16 :goto_254

    .line 362
    .line 363
    :cond_16a
    invoke-virtual {v1}, Lov;->F0()Lgt3;

    .line 364
    .line 365
    .line 366
    move-result-object v3

    .line 367
    iget-object v3, v3, Lgt3;->E:Lvd3;

    .line 368
    .line 369
    invoke-virtual {v3}, Lvd3;->c()Landroid/os/Bundle;

    .line 370
    .line 371
    .line 372
    move-result-object v3

    .line 373
    iget-object v11, v8, Lzt3;->g:Lrl3;

    .line 374
    .line 375
    sget-object v4, Ljn3;->g1:Lxr3;

    .line 376
    .line 377
    invoke-virtual {v11, v10, v4}, Lrl3;->R0(Ljava/lang/String;Lxr3;)Z

    .line 378
    .line 379
    .line 380
    move-result v4

    .line 381
    if-eqz v4, :cond_185

    .line 382
    .line 383
    new-instance v4, Landroid/os/Bundle;

    .line 384
    .line 385
    invoke-direct {v4, v3}, Landroid/os/Bundle;-><init>(Landroid/os/Bundle;)V

    .line 386
    .line 387
    .line 388
    move-object v12, v4

    .line 389
    goto :goto_186

    .line 390
    :cond_185
    move-object v12, v3

    .line 391
    :goto_186
    invoke-virtual {v0}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    .line 392
    .line 393
    .line 394
    move-result-object v3

    .line 395
    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 396
    .line 397
    .line 398
    move-result-object v13

    .line 399
    :cond_18e
    :goto_18e
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    .line 400
    .line 401
    .line 402
    move-result v3

    .line 403
    if-eqz v3, :cond_1ff

    .line 404
    .line 405
    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 406
    .line 407
    .line 408
    move-result-object v3

    .line 409
    move-object v14, v3

    .line 410
    check-cast v14, Ljava/lang/String;

    .line 411
    .line 412
    invoke-virtual {v0, v14}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    .line 413
    .line 414
    .line 415
    move-result-object v15

    .line 416
    if-eqz v15, :cond_1ce

    .line 417
    .line 418
    instance-of v3, v15, Ljava/lang/String;

    .line 419
    .line 420
    if-nez v3, :cond_1ce

    .line 421
    .line 422
    instance-of v3, v15, Ljava/lang/Long;

    .line 423
    .line 424
    if-nez v3, :cond_1ce

    .line 425
    .line 426
    instance-of v3, v15, Ljava/lang/Double;

    .line 427
    .line 428
    if-nez v3, :cond_1ce

    .line 429
    .line 430
    invoke-virtual {v1}, Lov;->G0()Lb04;

    .line 431
    .line 432
    .line 433
    invoke-static {v15}, Lb04;->p1(Ljava/lang/Object;)Z

    .line 434
    .line 435
    .line 436
    move-result v3

    .line 437
    if-eqz v3, :cond_1c2

    .line 438
    .line 439
    invoke-virtual {v1}, Lov;->G0()Lb04;

    .line 440
    .line 441
    .line 442
    const/4 v7, 0x0

    .line 443
    const/4 v3, 0x0

    .line 444
    const/16 v4, 0x1b

    .line 445
    .line 446
    const/4 v5, 0x0

    .line 447
    const/4 v6, 0x0

    .line 448
    invoke-static/range {v2 .. v7}, Lb04;->l1(Lzz3;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;I)V

    .line 449
    .line 450
    .line 451
    :cond_1c2
    invoke-virtual {v1}, Lov;->l()Lqs3;

    .line 452
    .line 453
    .line 454
    move-result-object v3

    .line 455
    iget-object v3, v3, Lqs3;->p:Lts3;

    .line 456
    .line 457
    const-string v4, "Invalid default event parameter type. Name, value"

    .line 458
    .line 459
    invoke-virtual {v3, v14, v15, v4}, Lts3;->a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    .line 460
    .line 461
    .line 462
    goto :goto_18e

    .line 463
    :cond_1ce
    invoke-static {v14}, Lb04;->M1(Ljava/lang/String;)Z

    .line 464
    .line 465
    .line 466
    move-result v3

    .line 467
    if-eqz v3, :cond_1e0

    .line 468
    .line 469
    invoke-virtual {v1}, Lov;->l()Lqs3;

    .line 470
    .line 471
    .line 472
    move-result-object v3

    .line 473
    iget-object v3, v3, Lqs3;->p:Lts3;

    .line 474
    .line 475
    const-string v4, "Invalid default event parameter name. Name"

    .line 476
    .line 477
    invoke-virtual {v3, v14, v4}, Lts3;->b(Ljava/lang/Object;Ljava/lang/String;)V

    .line 478
    .line 479
    .line 480
    goto :goto_18e

    .line 481
    :cond_1e0
    if-nez v15, :cond_1e6

    .line 482
    .line 483
    invoke-virtual {v12, v14}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 484
    .line 485
    .line 486
    goto :goto_18e

    .line 487
    :cond_1e6
    invoke-virtual {v1}, Lov;->G0()Lb04;

    .line 488
    .line 489
    .line 490
    move-result-object v3

    .line 491
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 492
    .line 493
    .line 494
    const/16 v4, 0x1f4

    .line 495
    .line 496
    const-string v5, "param"

    .line 497
    .line 498
    invoke-virtual {v3, v5, v14, v4, v15}, Lb04;->t1(Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Z

    .line 499
    .line 500
    .line 501
    move-result v3

    .line 502
    if-eqz v3, :cond_18e

    .line 503
    .line 504
    invoke-virtual {v1}, Lov;->G0()Lb04;

    .line 505
    .line 506
    .line 507
    move-result-object v3

    .line 508
    invoke-virtual {v3, v12, v14, v15}, Lb04;->b1(Landroid/os/Bundle;Ljava/lang/String;Ljava/lang/Object;)V

    .line 509
    .line 510
    .line 511
    goto :goto_18e

    .line 512
    :cond_1ff
    invoke-virtual {v1}, Lov;->G0()Lb04;

    .line 513
    .line 514
    .line 515
    invoke-virtual {v11}, Lov;->G0()Lb04;

    .line 516
    .line 517
    .line 518
    move-result-object v3

    .line 519
    const v4, 0xc02a560

    .line 520
    .line 521
    .line 522
    invoke-virtual {v3, v4}, Lb04;->y1(I)Z

    .line 523
    .line 524
    .line 525
    move-result v3

    .line 526
    if-eqz v3, :cond_212

    .line 527
    .line 528
    const/16 v3, 0x64

    .line 529
    .line 530
    goto :goto_214

    .line 531
    :cond_212
    const/16 v3, 0x19

    .line 532
    .line 533
    :goto_214
    invoke-virtual {v12}, Landroid/os/BaseBundle;->size()I

    .line 534
    .line 535
    .line 536
    move-result v4

    .line 537
    if-gt v4, v3, :cond_21b

    .line 538
    .line 539
    goto :goto_254

    .line 540
    :cond_21b
    new-instance v4, Ljava/util/TreeSet;

    .line 541
    .line 542
    invoke-virtual {v12}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    .line 543
    .line 544
    .line 545
    move-result-object v5

    .line 546
    invoke-direct {v4, v5}, Ljava/util/TreeSet;-><init>(Ljava/util/Collection;)V

    .line 547
    .line 548
    .line 549
    invoke-virtual {v4}, Ljava/util/TreeSet;->iterator()Ljava/util/Iterator;

    .line 550
    .line 551
    .line 552
    move-result-object v4

    .line 553
    move v5, v9

    .line 554
    :cond_229
    :goto_229
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 555
    .line 556
    .line 557
    move-result v6

    .line 558
    if-eqz v6, :cond_23d

    .line 559
    .line 560
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 561
    .line 562
    .line 563
    move-result-object v6

    .line 564
    check-cast v6, Ljava/lang/String;

    .line 565
    .line 566
    add-int/lit8 v5, v5, 0x1

    .line 567
    .line 568
    if-le v5, v3, :cond_229

    .line 569
    .line 570
    invoke-virtual {v12, v6}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 571
    .line 572
    .line 573
    goto :goto_229

    .line 574
    :cond_23d
    invoke-virtual {v1}, Lov;->G0()Lb04;

    .line 575
    .line 576
    .line 577
    const/4 v7, 0x0

    .line 578
    const/4 v3, 0x0

    .line 579
    const/16 v4, 0x1a

    .line 580
    .line 581
    const/4 v5, 0x0

    .line 582
    const/4 v6, 0x0

    .line 583
    invoke-static/range {v2 .. v7}, Lb04;->l1(Lzz3;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;I)V

    .line 584
    .line 585
    .line 586
    invoke-virtual {v1}, Lov;->l()Lqs3;

    .line 587
    .line 588
    .line 589
    move-result-object v2

    .line 590
    iget-object v2, v2, Lqs3;->p:Lts3;

    .line 591
    .line 592
    const-string v3, "Too many default event parameters set. Discarding beyond event parameter limit"

    .line 593
    .line 594
    invoke-virtual {v2, v3}, Lts3;->c(Ljava/lang/String;)V

    .line 595
    .line 596
    .line 597
    :goto_254
    invoke-virtual {v1}, Lov;->F0()Lgt3;

    .line 598
    .line 599
    .line 600
    move-result-object v1

    .line 601
    iget-object v1, v1, Lgt3;->E:Lvd3;

    .line 602
    .line 603
    invoke-virtual {v1, v12}, Lvd3;->h(Landroid/os/Bundle;)V

    .line 604
    .line 605
    .line 606
    invoke-virtual {v0}, Landroid/os/BaseBundle;->isEmpty()Z

    .line 607
    .line 608
    .line 609
    move-result v0

    .line 610
    if-eqz v0, :cond_26d

    .line 611
    .line 612
    iget-object v0, v8, Lzt3;->g:Lrl3;

    .line 613
    .line 614
    sget-object v1, Ljn3;->e1:Lxr3;

    .line 615
    .line 616
    invoke-virtual {v0, v10, v1}, Lrl3;->R0(Ljava/lang/String;Lxr3;)Z

    .line 617
    .line 618
    .line 619
    move-result v0

    .line 620
    if-eqz v0, :cond_285

    .line 621
    .line 622
    :cond_26d
    invoke-virtual {v8}, Lzt3;->o()Lbx3;

    .line 623
    .line 624
    .line 625
    move-result-object v0

    .line 626
    invoke-virtual {v0}, Lgp3;->H0()V

    .line 627
    .line 628
    .line 629
    invoke-virtual {v0}, Let3;->L0()V

    .line 630
    .line 631
    .line 632
    invoke-virtual {v0, v9}, Lbx3;->a1(Z)Lhz3;

    .line 633
    .line 634
    .line 635
    move-result-object v1

    .line 636
    new-instance v2, Lte2;

    .line 637
    .line 638
    const/16 v3, 0x9

    .line 639
    .line 640
    invoke-direct {v2, v0, v1, v12, v3}, Lte2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 641
    .line 642
    .line 643
    invoke-virtual {v0, v2}, Lbx3;->O0(Ljava/lang/Runnable;)V

    .line 644
    .line 645
    .line 646
    :cond_285
    return-void

    .line 647
    :pswitch_data_286
    .packed-switch 0x0
        :pswitch_154
        :pswitch_d8
    .end packed-switch
.end method
