###### Class defpackage.oh1 (oh1)
.class public final Loh1;
.super Ljava/lang/Object;

# interfaces
.implements Ldt0;


# instance fields
.field public final synthetic a:I

.field public final b:Lrh1;


# direct methods
.method public synthetic constructor <init>(Lrh1;I)V
    .registers 3

    .line 1
    iput p2, p0, Loh1;->a:I

    .line 2
    .line 3
    iput-object p1, p0, Loh1;->b:Lrh1;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 8

    .line 1
    iget v0, p0, Loh1;->a:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    iget-object p0, p0, Loh1;->b:Lrh1;

    .line 5
    .line 6
    packed-switch v0, :pswitch_data_c6

    .line 7
    .line 8
    .line 9
    sget-object v0, Lma0;->o:Lma0;

    .line 10
    .line 11
    invoke-virtual {p0, v0, v1}, Lrh1;->h(Lma0;Lft0;)Ljava/util/Set;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    return-object p0

    .line 16
    :pswitch_f
    sget-object v0, Lma0;->q:Lma0;

    .line 17
    .line 18
    invoke-virtual {p0, v0}, Lrh1;->o(Lma0;)Ljava/util/Set;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :pswitch_16
    sget-object v0, Lma0;->p:Lma0;

    .line 24
    .line 25
    invoke-virtual {p0, v0, v1}, Lrh1;->i(Lma0;Lft0;)Ljava/util/Set;

    .line 26
    .line 27
    .line 28
    move-result-object p0

    .line 29
    return-object p0

    .line 30
    :pswitch_1d
    invoke-virtual {p0}, Lrh1;->k()Lt60;

    .line 31
    .line 32
    .line 33
    move-result-object p0

    .line 34
    return-object p0

    .line 35
    :pswitch_22
    sget-object v0, Lma0;->m:Lma0;

    .line 36
    .line 37
    sget-object v1, Lvr1;->a:Lby0;

    .line 38
    .line 39
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 40
    .line 41
    .line 42
    sget-object v1, Lsh1;->d:Lsh1;

    .line 43
    .line 44
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 45
    .line 46
    .line 47
    iget-object v2, v0, Lma0;->a:Ljava/util/List;

    .line 48
    .line 49
    new-instance v3, Ljava/util/LinkedHashSet;

    .line 50
    .line 51
    invoke-direct {v3}, Ljava/util/LinkedHashSet;-><init>()V

    .line 52
    .line 53
    .line 54
    sget v4, Lma0;->l:I

    .line 55
    .line 56
    invoke-virtual {v0, v4}, Lma0;->a(I)Z

    .line 57
    .line 58
    .line 59
    move-result v4

    .line 60
    sget-object v5, Lnw1;->d:Lnw1;

    .line 61
    .line 62
    if-eqz v4, :cond_60

    .line 63
    .line 64
    invoke-virtual {p0, v0, v1}, Lrh1;->h(Lma0;Lft0;)Ljava/util/Set;

    .line 65
    .line 66
    .line 67
    move-result-object v4

    .line 68
    invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 69
    .line 70
    .line 71
    move-result-object v4

    .line 72
    :cond_47
    :goto_47
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 73
    .line 74
    .line 75
    move-result v6

    .line 76
    if-eqz v6, :cond_60

    .line 77
    .line 78
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object v6

    .line 82
    check-cast v6, Ldv1;

    .line 83
    .line 84
    invoke-virtual {v1, v6}, Lsh1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    invoke-virtual {p0, v6, v5}, Lwr1;->a(Ldv1;Lnw1;)Lau;

    .line 88
    .line 89
    .line 90
    move-result-object v6

    .line 91
    if-eqz v6, :cond_47

    .line 92
    .line 93
    invoke-interface {v3, v6}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 94
    .line 95
    .line 96
    goto :goto_47

    .line 97
    :cond_60
    sget v4, Lma0;->i:I

    .line 98
    .line 99
    invoke-virtual {v0, v4}, Lma0;->a(I)Z

    .line 100
    .line 101
    .line 102
    move-result v4

    .line 103
    if-eqz v4, :cond_8f

    .line 104
    .line 105
    sget-object v4, Lia0;->a:Lia0;

    .line 106
    .line 107
    invoke-interface {v2, v4}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 108
    .line 109
    .line 110
    move-result v4

    .line 111
    if-nez v4, :cond_8f

    .line 112
    .line 113
    invoke-virtual {p0, v0, v1}, Lrh1;->i(Lma0;Lft0;)Ljava/util/Set;

    .line 114
    .line 115
    .line 116
    move-result-object v4

    .line 117
    invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 118
    .line 119
    .line 120
    move-result-object v4

    .line 121
    :goto_78
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 122
    .line 123
    .line 124
    move-result v6

    .line 125
    if-eqz v6, :cond_8f

    .line 126
    .line 127
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 128
    .line 129
    .line 130
    move-result-object v6

    .line 131
    check-cast v6, Ldv1;

    .line 132
    .line 133
    invoke-virtual {v1, v6}, Lsh1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 134
    .line 135
    .line 136
    invoke-virtual {p0, v6, v5}, Lrh1;->b(Ldv1;Lnw1;)Ljava/util/Collection;

    .line 137
    .line 138
    .line 139
    move-result-object v6

    .line 140
    invoke-virtual {v3, v6}, Ljava/util/AbstractCollection;->addAll(Ljava/util/Collection;)Z

    .line 141
    .line 142
    .line 143
    goto :goto_78

    .line 144
    :cond_8f
    sget v4, Lma0;->j:I

    .line 145
    .line 146
    invoke-virtual {v0, v4}, Lma0;->a(I)Z

    .line 147
    .line 148
    .line 149
    move-result v4

    .line 150
    if-eqz v4, :cond_be

    .line 151
    .line 152
    sget-object v4, Lia0;->a:Lia0;

    .line 153
    .line 154
    invoke-interface {v2, v4}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 155
    .line 156
    .line 157
    move-result v2

    .line 158
    if-nez v2, :cond_be

    .line 159
    .line 160
    invoke-virtual {p0, v0}, Lrh1;->o(Lma0;)Ljava/util/Set;

    .line 161
    .line 162
    .line 163
    move-result-object v0

    .line 164
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 165
    .line 166
    .line 167
    move-result-object v0

    .line 168
    :goto_a7
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 169
    .line 170
    .line 171
    move-result v2

    .line 172
    if-eqz v2, :cond_be

    .line 173
    .line 174
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 175
    .line 176
    .line 177
    move-result-object v2

    .line 178
    check-cast v2, Ldv1;

    .line 179
    .line 180
    invoke-virtual {v1, v2}, Lsh1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 181
    .line 182
    .line 183
    invoke-virtual {p0, v2, v5}, Lrh1;->c(Ldv1;Lnw1;)Ljava/util/Collection;

    .line 184
    .line 185
    .line 186
    move-result-object v2

    .line 187
    invoke-virtual {v3, v2}, Ljava/util/AbstractCollection;->addAll(Ljava/util/Collection;)Z

    .line 188
    .line 189
    .line 190
    goto :goto_a7

    .line 191
    :cond_be
    invoke-static {v3}, Lgv;->y0(Ljava/lang/Iterable;)Ljava/util/List;

    .line 192
    .line 193
    .line 194
    move-result-object p0

    .line 195
    check-cast p0, Ljava/util/Collection;

    .line 196
    .line 197
    return-object p0

    .line 198
    nop

    .line 199
    :pswitch_data_c6
    .packed-switch 0x0
        :pswitch_22
        :pswitch_1d
        :pswitch_16
        :pswitch_f
    .end packed-switch
.end method
