###### Class defpackage.wh1 (wh1)
.class public final Lwh1;
.super Ly;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final p:Lfk;

.field public final q:Lmd2;


# direct methods
.method public constructor <init>(Lfk;Lmd2;ILm60;)V
    .registers 14

    .line 1
    iget-object v0, p1, Lfk;->a:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lx41;

    .line 4
    .line 5
    iget-object v5, v0, Lx41;->a:Lcm1;

    .line 6
    .line 7
    new-instance v3, Lzg1;

    .line 8
    .line 9
    const/4 v0, 0x0

    .line 10
    invoke-direct {v3, p1, p2, v0}, Lzg1;-><init>(Lfk;Lg41;Z)V

    .line 11
    .line 12
    .line 13
    iget-object v0, p2, Lmd2;->a:Ljava/lang/reflect/TypeVariable;

    .line 14
    .line 15
    invoke-interface {v0}, Ljava/lang/reflect/TypeVariable;->getName()Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-static {v0}, Ldv1;->e(Ljava/lang/String;)Ldv1;

    .line 20
    .line 21
    .line 22
    move-result-object v6

    .line 23
    sget-object v7, Lf73;->c:Lf73;

    .line 24
    .line 25
    const/4 v8, 0x0

    .line 26
    move-object v1, p0

    .line 27
    move v2, p3

    .line 28
    move-object v4, p4

    .line 29
    invoke-direct/range {v1 .. v8}, Ld1;-><init>(ILl7;Lm60;Lcm1;Ldv1;Lf73;Z)V

    .line 30
    .line 31
    .line 32
    iput-object p1, v1, Lwh1;->p:Lfk;

    .line 33
    .line 34
    iput-object p2, v1, Lwh1;->q:Lmd2;

    .line 35
    .line 36
    return-void
.end method


# virtual methods
.method public final K0(Ljava/util/List;)Ljava/util/List;
    .registers 13

    .line 1
    iget-object v3, p0, Lwh1;->p:Lfk;

    .line 2
    .line 3
    iget-object v0, v3, Lfk;->a:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lx41;

    .line 6
    .line 7
    iget-object v6, v0, Lx41;->k:Le51;

    .line 8
    .line 9
    check-cast p1, Ljava/lang/Iterable;

    .line 10
    .line 11
    new-instance v10, Ljava/util/ArrayList;

    .line 12
    .line 13
    const/16 v0, 0xa

    .line 14
    .line 15
    invoke-static {p1, v0}, Liv;->M(Ljava/lang/Iterable;I)I

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    invoke-direct {v10, v0}, Ljava/util/ArrayList;-><init>(I)V

    .line 20
    .line 21
    .line 22
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    :goto_19
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    if-eqz v0, :cond_54

    .line 31
    .line 32
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    move-object v7, v0

    .line 37
    check-cast v7, Lgg1;

    .line 38
    .line 39
    sget-object v0, Lsh1;->z:Lsh1;

    .line 40
    .line 41
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 42
    .line 43
    .line 44
    const/4 v1, 0x0

    .line 45
    invoke-static {v7, v0, v1}, La33;->c(Lgg1;Lft0;Lcq2;)Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    if-eqz v0, :cond_36

    .line 50
    .line 51
    move-object v1, p0

    .line 52
    move-object v4, v6

    .line 53
    move-object v6, v7

    .line 54
    goto :goto_4d

    .line 55
    :cond_36
    new-instance v0, Lbo2;

    .line 56
    .line 57
    sget-object v4, Le7;->f:Le7;

    .line 58
    .line 59
    const/4 v5, 0x0

    .line 60
    const/4 v2, 0x0

    .line 61
    move-object v1, p0

    .line 62
    invoke-direct/range {v0 .. v5}, Lbo2;-><init>(La6;ZLfk;Le7;Z)V

    .line 63
    .line 64
    .line 65
    const/4 v8, 0x0

    .line 66
    const/4 v9, 0x0

    .line 67
    move-object v4, v6

    .line 68
    move-object v6, v7

    .line 69
    sget-object v7, Lth0;->a:Lth0;

    .line 70
    .line 71
    move-object v5, v0

    .line 72
    invoke-virtual/range {v4 .. v9}, Le51;->d(Lbo2;Lgg1;Ljava/util/List;Lv13;Z)Lgg1;

    .line 73
    .line 74
    .line 75
    move-result-object v7

    .line 76
    if-nez v7, :cond_4e

    .line 77
    .line 78
    :goto_4d
    move-object v7, v6

    .line 79
    :cond_4e
    invoke-virtual {v10, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 80
    .line 81
    .line 82
    move-object p0, v1

    .line 83
    move-object v6, v4

    .line 84
    goto :goto_19

    .line 85
    :cond_54
    return-object v10
.end method

.method public final L0()Ljava/util/List;
    .registers 9

    .line 1
    iget-object v0, p0, Lwh1;->q:Lmd2;

    .line 2
    .line 3
    iget-object v0, v0, Lmd2;->a:Ljava/lang/reflect/TypeVariable;

    .line 4
    .line 5
    invoke-interface {v0}, Ljava/lang/reflect/TypeVariable;->getBounds()[Ljava/lang/reflect/Type;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    new-instance v1, Ljava/util/ArrayList;

    .line 13
    .line 14
    array-length v2, v0

    .line 15
    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    .line 16
    .line 17
    .line 18
    array-length v2, v0

    .line 19
    const/4 v3, 0x0

    .line 20
    move v4, v3

    .line 21
    :goto_14
    if-ge v4, v2, :cond_23

    .line 22
    .line 23
    aget-object v5, v0, v4

    .line 24
    .line 25
    new-instance v6, Lad2;

    .line 26
    .line 27
    invoke-direct {v6, v5}, Lad2;-><init>(Ljava/lang/reflect/Type;)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    add-int/lit8 v4, v4, 0x1

    .line 34
    .line 35
    goto :goto_14

    .line 36
    :cond_23
    invoke-static {v1}, Lgv;->r0(Ljava/util/List;)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    check-cast v0, Lad2;

    .line 41
    .line 42
    if-eqz v0, :cond_2e

    .line 43
    .line 44
    iget-object v0, v0, Lad2;->a:Ljava/lang/reflect/Type;

    .line 45
    .line 46
    goto :goto_2f

    .line 47
    :cond_2e
    const/4 v0, 0x0

    .line 48
    :goto_2f
    const-class v2, Ljava/lang/Object;

    .line 49
    .line 50
    invoke-static {v0, v2}, Ld31;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    if-eqz v0, :cond_39

    .line 55
    .line 56
    sget-object v1, Lth0;->a:Lth0;

    .line 57
    .line 58
    :cond_39
    check-cast v1, Ljava/util/Collection;

    .line 59
    .line 60
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    iget-object v2, p0, Lwh1;->p:Lfk;

    .line 65
    .line 66
    if-eqz v0, :cond_64

    .line 67
    .line 68
    iget-object p0, v2, Lfk;->a:Ljava/lang/Object;

    .line 69
    .line 70
    check-cast p0, Lx41;

    .line 71
    .line 72
    iget-object p0, p0, Lx41;->h:Lau1;

    .line 73
    .line 74
    iget-object p0, p0, Lau1;->f:Lxf1;

    .line 75
    .line 76
    invoke-virtual {p0}, Lxf1;->e()Lko2;

    .line 77
    .line 78
    .line 79
    move-result-object p0

    .line 80
    iget-object v0, v2, Lfk;->a:Ljava/lang/Object;

    .line 81
    .line 82
    check-cast v0, Lx41;

    .line 83
    .line 84
    iget-object v0, v0, Lx41;->h:Lau1;

    .line 85
    .line 86
    iget-object v0, v0, Lau1;->f:Lxf1;

    .line 87
    .line 88
    invoke-virtual {v0}, Lxf1;->o()Lko2;

    .line 89
    .line 90
    .line 91
    move-result-object v0

    .line 92
    invoke-static {p0, v0}, Lkv3;->e(Lko2;Lko2;)Lv53;

    .line 93
    .line 94
    .line 95
    move-result-object p0

    .line 96
    invoke-static {p0}, Lia1;->u(Ljava/lang/Object;)Ljava/util/List;

    .line 97
    .line 98
    .line 99
    move-result-object p0

    .line 100
    return-object p0

    .line 101
    :cond_64
    check-cast v1, Ljava/lang/Iterable;

    .line 102
    .line 103
    new-instance v0, Ljava/util/ArrayList;

    .line 104
    .line 105
    const/16 v4, 0xa

    .line 106
    .line 107
    invoke-static {v1, v4}, Liv;->M(Ljava/lang/Iterable;I)I

    .line 108
    .line 109
    .line 110
    move-result v4

    .line 111
    invoke-direct {v0, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 112
    .line 113
    .line 114
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 115
    .line 116
    .line 117
    move-result-object v1

    .line 118
    :goto_75
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 119
    .line 120
    .line 121
    move-result v4

    .line 122
    if-eqz v4, :cond_94

    .line 123
    .line 124
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 125
    .line 126
    .line 127
    move-result-object v4

    .line 128
    check-cast v4, Lad2;

    .line 129
    .line 130
    iget-object v5, v2, Lfk;->e:Ljava/lang/Object;

    .line 131
    .line 132
    check-cast v5, Lna;

    .line 133
    .line 134
    sget-object v6, Ly23;->b:Ly23;

    .line 135
    .line 136
    const/4 v7, 0x3

    .line 137
    invoke-static {v6, v3, p0, v7}, Ld31;->B(Ly23;ZLwh1;I)Ld51;

    .line 138
    .line 139
    .line 140
    move-result-object v6

    .line 141
    invoke-virtual {v5, v4, v6}, Lna;->U(Lld2;Ld51;)Lgg1;

    .line 142
    .line 143
    .line 144
    move-result-object v4

    .line 145
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 146
    .line 147
    .line 148
    goto :goto_75

    .line 149
    :cond_94
    return-object v0
.end method
