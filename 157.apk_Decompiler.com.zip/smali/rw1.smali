###### Class defpackage.rw1 (rw1)
.class public final Lrw1;
.super Ldb0;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# direct methods
.method public constructor <init>(Lcm1;Ldt0;)V
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0, p1, p2}, Ldb0;-><init>(Lcm1;Ldt0;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final isEmpty()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method
