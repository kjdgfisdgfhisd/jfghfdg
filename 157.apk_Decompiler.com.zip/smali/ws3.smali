###### Class defpackage.ws3 (ws3)
.class public final Lws3;
.super Ljava/lang/Exception;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"
