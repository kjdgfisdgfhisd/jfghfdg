###### Class defpackage.fv (fv)
.class public final Lfv;
.super Lh13;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final p:Lh13;


# direct methods
.method public constructor <init>(Ljava/lang/Class;Lk13;Lh13;[Lh13;Lh13;Ljava/lang/Object;Ljava/lang/Object;Z)V
    .registers 18

    .line 1
    invoke-virtual {p5}, Lh13;->hashCode()I

    .line 2
    .line 3
    .line 4
    move-result v5

    .line 5
    move-object v0, p0

    .line 6
    move-object v1, p1

    .line 7
    move-object v2, p2

    .line 8
    move-object v3, p3

    .line 9
    move-object v4, p4

    .line 10
    move-object v6, p6

    .line 11
    move-object/from16 v7, p7

    .line 12
    .line 13
    move/from16 v8, p8

    .line 14
    .line 15
    invoke-direct/range {v0 .. v8}, Lh13;-><init>(Ljava/lang/Class;Lk13;Lh13;[Lh13;ILjava/lang/Object;Ljava/lang/Object;Z)V

    .line 16
    .line 17
    .line 18
    iput-object p5, p0, Lfv;->p:Lh13;

    .line 19
    .line 20
    return-void
.end method


# virtual methods
.method public final G()Ljava/lang/String;
    .registers 4

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    iget-object v1, p0, Lh13;->d:Ljava/lang/Class;

    .line 4
    .line 5
    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    iget-object p0, p0, Lfv;->p:Lh13;

    .line 13
    .line 14
    if-eqz p0, :cond_28

    .line 15
    .line 16
    invoke-virtual {v1}, Ljava/lang/Class;->getTypeParameters()[Ljava/lang/reflect/TypeVariable;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    array-length v1, v1

    .line 21
    const/4 v2, 0x1

    .line 22
    if-ne v1, v2, :cond_28

    .line 23
    .line 24
    const/16 v1, 0x3c

    .line 25
    .line 26
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 27
    .line 28
    .line 29
    invoke-virtual {p0}, Lh13;->G()Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 34
    .line 35
    .line 36
    const/16 p0, 0x3e

    .line 37
    .line 38
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 39
    .line 40
    .line 41
    :cond_28
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object p0

    .line 45
    return-object p0
.end method

.method public final J()Lh13;
    .registers 1

    .line 1
    iget-object p0, p0, Lfv;->p:Lh13;

    .line 2
    .line 3
    return-object p0
.end method

.method public final K(Ljava/lang/StringBuilder;)Ljava/lang/StringBuilder;
    .registers 3

    .line 1
    iget-object p0, p0, Lh13;->d:Ljava/lang/Class;

    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    invoke-static {p0, p1, v0}, Lh13;->F(Ljava/lang/Class;Ljava/lang/StringBuilder;Z)V

    .line 5
    .line 6
    .line 7
    return-object p1
.end method

.method public final L(Ljava/lang/StringBuilder;)Ljava/lang/StringBuilder;
    .registers 4

    .line 1
    iget-object v0, p0, Lh13;->d:Ljava/lang/Class;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-static {v0, p1, v1}, Lh13;->F(Ljava/lang/Class;Ljava/lang/StringBuilder;Z)V

    .line 5
    .line 6
    .line 7
    const/16 v0, 0x3c

    .line 8
    .line 9
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 10
    .line 11
    .line 12
    iget-object p0, p0, Lfv;->p:Lh13;

    .line 13
    .line 14
    invoke-virtual {p0, p1}, Lh13;->L(Ljava/lang/StringBuilder;)Ljava/lang/StringBuilder;

    .line 15
    .line 16
    .line 17
    const-string p0, ">;"

    .line 18
    .line 19
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 20
    .line 21
    .line 22
    return-object p1
.end method

.method public final Q()Z
    .registers 2

    .line 1
    invoke-super {p0}, Lh13;->Q()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_11

    .line 6
    .line 7
    iget-object p0, p0, Lfv;->p:Lh13;

    .line 8
    .line 9
    invoke-virtual {p0}, Lh13;->Q()Z

    .line 10
    .line 11
    .line 12
    move-result p0

    .line 13
    if-eqz p0, :cond_f

    .line 14
    .line 15
    goto :goto_11

    .line 16
    :cond_f
    const/4 p0, 0x0

    .line 17
    return p0

    .line 18
    :cond_11
    :goto_11
    const/4 p0, 0x1

    .line 19
    return p0
.end method

.method public final S()Z
    .registers 1

    .line 1
    const/4 p0, 0x1

    .line 2
    return p0
.end method

.method public final V(Ljava/lang/Class;Lk13;Lh13;[Lh13;)Lh13;
    .registers 14

    .line 1
    new-instance v0, Lfv;

    .line 2
    .line 3
    iget-object v7, p0, Lh13;->g:Ljava/lang/Object;

    .line 4
    .line 5
    iget-boolean v8, p0, Lh13;->j:Z

    .line 6
    .line 7
    iget-object v5, p0, Lfv;->p:Lh13;

    .line 8
    .line 9
    iget-object v6, p0, Lh13;->f:Ljava/lang/Object;

    .line 10
    .line 11
    move-object v1, p1

    .line 12
    move-object v2, p2

    .line 13
    move-object v3, p3

    .line 14
    move-object v4, p4

    .line 15
    invoke-direct/range {v0 .. v8}, Lfv;-><init>(Ljava/lang/Class;Lk13;Lh13;[Lh13;Lh13;Ljava/lang/Object;Ljava/lang/Object;Z)V

    .line 16
    .line 17
    .line 18
    return-object v0
.end method

.method public final W(Lh13;)Lh13;
    .registers 12

    .line 1
    iget-object v0, p0, Lfv;->p:Lh13;

    .line 2
    .line 3
    if-ne v0, p1, :cond_5

    .line 4
    .line 5
    return-object p0

    .line 6
    :cond_5
    new-instance v1, Lfv;

    .line 7
    .line 8
    iget-object v8, p0, Lh13;->g:Ljava/lang/Object;

    .line 9
    .line 10
    iget-boolean v9, p0, Lh13;->j:Z

    .line 11
    .line 12
    iget-object v2, p0, Lh13;->d:Ljava/lang/Class;

    .line 13
    .line 14
    iget-object v3, p0, Lh13;->n:Lk13;

    .line 15
    .line 16
    iget-object v4, p0, Lh13;->l:Lh13;

    .line 17
    .line 18
    iget-object v5, p0, Lh13;->m:[Lh13;

    .line 19
    .line 20
    iget-object v7, p0, Lh13;->f:Ljava/lang/Object;

    .line 21
    .line 22
    move-object v6, p1

    .line 23
    invoke-direct/range {v1 .. v9}, Lfv;-><init>(Ljava/lang/Class;Lk13;Lh13;[Lh13;Lh13;Ljava/lang/Object;Ljava/lang/Object;Z)V

    .line 24
    .line 25
    .line 26
    return-object v1
.end method

.method public final X(Lt23;)Lh13;
    .registers 11

    .line 1
    new-instance v0, Lfv;

    .line 2
    .line 3
    iget-object v1, p0, Lfv;->p:Lh13;

    .line 4
    .line 5
    invoke-virtual {v1, p1}, Lh13;->a0(Ljava/lang/Object;)Lh13;

    .line 6
    .line 7
    .line 8
    move-result-object v5

    .line 9
    iget-object v7, p0, Lh13;->g:Ljava/lang/Object;

    .line 10
    .line 11
    iget-boolean v8, p0, Lh13;->j:Z

    .line 12
    .line 13
    iget-object v1, p0, Lh13;->d:Ljava/lang/Class;

    .line 14
    .line 15
    iget-object v2, p0, Lh13;->n:Lk13;

    .line 16
    .line 17
    iget-object v3, p0, Lh13;->l:Lh13;

    .line 18
    .line 19
    iget-object v4, p0, Lh13;->m:[Lh13;

    .line 20
    .line 21
    iget-object v6, p0, Lh13;->f:Ljava/lang/Object;

    .line 22
    .line 23
    invoke-direct/range {v0 .. v8}, Lfv;-><init>(Ljava/lang/Class;Lk13;Lh13;[Lh13;Lh13;Ljava/lang/Object;Ljava/lang/Object;Z)V

    .line 24
    .line 25
    .line 26
    return-object v0
.end method

.method public final Y(Lh13;)Lh13;
    .registers 3

    .line 1
    invoke-super {p0, p1}, Lh13;->Y(Lh13;)Lh13;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {p1}, Lh13;->J()Lh13;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    if-eqz p1, :cond_17

    .line 10
    .line 11
    iget-object p0, p0, Lfv;->p:Lh13;

    .line 12
    .line 13
    invoke-virtual {p0, p1}, Lh13;->Y(Lh13;)Lh13;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    if-eq p1, p0, :cond_17

    .line 18
    .line 19
    invoke-virtual {v0, p1}, Lh13;->W(Lh13;)Lh13;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    return-object p0

    .line 24
    :cond_17
    return-object v0
.end method

.method public final Z()Lh13;
    .registers 11

    .line 1
    iget-boolean v0, p0, Lh13;->j:Z

    .line 2
    .line 3
    if-eqz v0, :cond_5

    .line 4
    .line 5
    return-object p0

    .line 6
    :cond_5
    new-instance v1, Lfv;

    .line 7
    .line 8
    iget-object v0, p0, Lfv;->p:Lh13;

    .line 9
    .line 10
    invoke-virtual {v0}, Lh13;->Z()Lh13;

    .line 11
    .line 12
    .line 13
    move-result-object v6

    .line 14
    iget-object v8, p0, Lh13;->g:Ljava/lang/Object;

    .line 15
    .line 16
    const/4 v9, 0x1

    .line 17
    iget-object v2, p0, Lh13;->d:Ljava/lang/Class;

    .line 18
    .line 19
    iget-object v3, p0, Lh13;->n:Lk13;

    .line 20
    .line 21
    iget-object v4, p0, Lh13;->l:Lh13;

    .line 22
    .line 23
    iget-object v5, p0, Lh13;->m:[Lh13;

    .line 24
    .line 25
    iget-object v7, p0, Lh13;->f:Ljava/lang/Object;

    .line 26
    .line 27
    invoke-direct/range {v1 .. v9}, Lfv;-><init>(Ljava/lang/Class;Lk13;Lh13;[Lh13;Lh13;Ljava/lang/Object;Ljava/lang/Object;Z)V

    .line 28
    .line 29
    .line 30
    return-object v1
.end method

.method public final a0(Ljava/lang/Object;)Lh13;
    .registers 11

    .line 1
    new-instance v0, Lfv;

    .line 2
    .line 3
    iget-object v6, p0, Lh13;->f:Ljava/lang/Object;

    .line 4
    .line 5
    iget-boolean v8, p0, Lh13;->j:Z

    .line 6
    .line 7
    iget-object v1, p0, Lh13;->d:Ljava/lang/Class;

    .line 8
    .line 9
    iget-object v2, p0, Lh13;->n:Lk13;

    .line 10
    .line 11
    iget-object v3, p0, Lh13;->l:Lh13;

    .line 12
    .line 13
    iget-object v4, p0, Lh13;->m:[Lh13;

    .line 14
    .line 15
    iget-object v5, p0, Lfv;->p:Lh13;

    .line 16
    .line 17
    move-object v7, p1

    .line 18
    invoke-direct/range {v0 .. v8}, Lfv;-><init>(Ljava/lang/Class;Lk13;Lh13;[Lh13;Lh13;Ljava/lang/Object;Ljava/lang/Object;Z)V

    .line 19
    .line 20
    .line 21
    return-object v0
.end method

.method public final b0(Ljava/lang/Object;)Lh13;
    .registers 11

    .line 1
    new-instance v0, Lfv;

    .line 2
    .line 3
    iget-object v7, p0, Lh13;->g:Ljava/lang/Object;

    .line 4
    .line 5
    iget-boolean v8, p0, Lh13;->j:Z

    .line 6
    .line 7
    iget-object v1, p0, Lh13;->d:Ljava/lang/Class;

    .line 8
    .line 9
    iget-object v2, p0, Lh13;->n:Lk13;

    .line 10
    .line 11
    iget-object v3, p0, Lh13;->l:Lh13;

    .line 12
    .line 13
    iget-object v4, p0, Lh13;->m:[Lh13;

    .line 14
    .line 15
    iget-object v5, p0, Lfv;->p:Lh13;

    .line 16
    .line 17
    move-object v6, p1

    .line 18
    invoke-direct/range {v0 .. v8}, Lfv;-><init>(Ljava/lang/Class;Lk13;Lh13;[Lh13;Lh13;Ljava/lang/Object;Ljava/lang/Object;Z)V

    .line 19
    .line 20
    .line 21
    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p1, p0, :cond_4

    .line 3
    .line 4
    return v0

    .line 5
    :cond_4
    const/4 v1, 0x0

    .line 6
    if-nez p1, :cond_8

    .line 7
    .line 8
    return v1

    .line 9
    :cond_8
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    move-result-object v2

    .line 13
    const-class v3, Lfv;

    .line 14
    .line 15
    if-eq v2, v3, :cond_11

    .line 16
    .line 17
    return v1

    .line 18
    :cond_11
    check-cast p1, Lfv;

    .line 19
    .line 20
    iget-object v2, p0, Lh13;->d:Ljava/lang/Class;

    .line 21
    .line 22
    iget-object v3, p1, Lh13;->d:Ljava/lang/Class;

    .line 23
    .line 24
    if-ne v2, v3, :cond_24

    .line 25
    .line 26
    iget-object p0, p0, Lfv;->p:Lh13;

    .line 27
    .line 28
    iget-object p1, p1, Lfv;->p:Lh13;

    .line 29
    .line 30
    invoke-virtual {p0, p1}, Lh13;->equals(Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result p0

    .line 34
    if-eqz p0, :cond_24

    .line 35
    .line 36
    return v0

    .line 37
    :cond_24
    return v1
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "[collection type; class "

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, Lh13;->d:Ljava/lang/Class;

    .line 9
    .line 10
    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 15
    .line 16
    .line 17
    const-string v1, ", contains "

    .line 18
    .line 19
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 20
    .line 21
    .line 22
    iget-object p0, p0, Lfv;->p:Lh13;

    .line 23
    .line 24
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 25
    .line 26
    .line 27
    const-string p0, "]"

    .line 28
    .line 29
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 30
    .line 31
    .line 32
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object p0

    .line 36
    return-object p0
.end method
