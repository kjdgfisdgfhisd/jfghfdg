###### Class defpackage.y13 (y13)
.class public final Ly13;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field public static final b:[Lh13;

.field public static final c:Ly13;

.field public static final d:Lk13;

.field public static final e:Ljava/lang/Class;

.field public static final f:Ljava/lang/Class;

.field public static final g:Ljava/lang/Class;

.field public static final j:Ljava/lang/Class;

.field public static final l:Ljava/lang/Class;

.field public static final m:Ljava/lang/Class;

.field public static final n:Ljava/lang/Class;

.field public static final o:Ljava/lang/Class;

.field public static final p:Llo2;

.field public static final q:Llo2;

.field public static final r:Llo2;

.field public static final s:Llo2;

.field public static final t:Llo2;

.field public static final u:Llo2;

.field public static final v:Llo2;

.field public static final w:Llo2;


# instance fields
.field public final a:Lng1;


# direct methods
.method static constructor <clinit>()V
    .registers 9

    .line 1
    const/4 v0, 0x0

    .line 2
    new-array v0, v0, [Lh13;

    .line 3
    .line 4
    sput-object v0, Ly13;->b:[Lh13;

    .line 5
    .line 6
    new-instance v0, Ly13;

    .line 7
    .line 8
    invoke-direct {v0}, Ly13;-><init>()V

    .line 9
    .line 10
    .line 11
    sput-object v0, Ly13;->c:Ly13;

    .line 12
    .line 13
    sget-object v0, Lk13;->g:Lk13;

    .line 14
    .line 15
    sput-object v0, Ly13;->d:Lk13;

    .line 16
    .line 17
    const-class v0, Ljava/lang/String;

    .line 18
    .line 19
    sput-object v0, Ly13;->e:Ljava/lang/Class;

    .line 20
    .line 21
    const-class v1, Ljava/lang/Object;

    .line 22
    .line 23
    sput-object v1, Ly13;->f:Ljava/lang/Class;

    .line 24
    .line 25
    const-class v2, Ljava/lang/Comparable;

    .line 26
    .line 27
    sput-object v2, Ly13;->g:Ljava/lang/Class;

    .line 28
    .line 29
    const-class v3, Ljava/lang/Enum;

    .line 30
    .line 31
    sput-object v3, Ly13;->j:Ljava/lang/Class;

    .line 32
    .line 33
    const-class v4, Lt81;

    .line 34
    .line 35
    sput-object v4, Ly13;->l:Ljava/lang/Class;

    .line 36
    .line 37
    sget-object v5, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    .line 38
    .line 39
    sput-object v5, Ly13;->m:Ljava/lang/Class;

    .line 40
    .line 41
    sget-object v6, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    .line 42
    .line 43
    sput-object v6, Ly13;->n:Ljava/lang/Class;

    .line 44
    .line 45
    sget-object v7, Ljava/lang/Long;->TYPE:Ljava/lang/Class;

    .line 46
    .line 47
    sput-object v7, Ly13;->o:Ljava/lang/Class;

    .line 48
    .line 49
    new-instance v8, Llo2;

    .line 50
    .line 51
    invoke-direct {v8, v5}, Llo2;-><init>(Ljava/lang/Class;)V

    .line 52
    .line 53
    .line 54
    sput-object v8, Ly13;->p:Llo2;

    .line 55
    .line 56
    new-instance v5, Llo2;

    .line 57
    .line 58
    invoke-direct {v5, v6}, Llo2;-><init>(Ljava/lang/Class;)V

    .line 59
    .line 60
    .line 61
    sput-object v5, Ly13;->q:Llo2;

    .line 62
    .line 63
    new-instance v5, Llo2;

    .line 64
    .line 65
    invoke-direct {v5, v7}, Llo2;-><init>(Ljava/lang/Class;)V

    .line 66
    .line 67
    .line 68
    sput-object v5, Ly13;->r:Llo2;

    .line 69
    .line 70
    new-instance v5, Llo2;

    .line 71
    .line 72
    invoke-direct {v5, v0}, Llo2;-><init>(Ljava/lang/Class;)V

    .line 73
    .line 74
    .line 75
    sput-object v5, Ly13;->s:Llo2;

    .line 76
    .line 77
    new-instance v0, Llo2;

    .line 78
    .line 79
    invoke-direct {v0, v1}, Llo2;-><init>(Ljava/lang/Class;)V

    .line 80
    .line 81
    .line 82
    sput-object v0, Ly13;->t:Llo2;

    .line 83
    .line 84
    new-instance v0, Llo2;

    .line 85
    .line 86
    invoke-direct {v0, v2}, Llo2;-><init>(Ljava/lang/Class;)V

    .line 87
    .line 88
    .line 89
    sput-object v0, Ly13;->u:Llo2;

    .line 90
    .line 91
    new-instance v0, Llo2;

    .line 92
    .line 93
    invoke-direct {v0, v3}, Llo2;-><init>(Ljava/lang/Class;)V

    .line 94
    .line 95
    .line 96
    sput-object v0, Ly13;->v:Llo2;

    .line 97
    .line 98
    new-instance v0, Llo2;

    .line 99
    .line 100
    invoke-direct {v0, v4}, Llo2;-><init>(Ljava/lang/Class;)V

    .line 101
    .line 102
    .line 103
    sput-object v0, Ly13;->w:Llo2;

    .line 104
    .line 105
    return-void
.end method

.method public constructor <init>()V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lng1;

    .line 5
    .line 6
    const/16 v1, 0x10

    .line 7
    .line 8
    const/16 v2, 0xc8

    .line 9
    .line 10
    invoke-direct {v0, v1, v2}, Lng1;-><init>(II)V

    .line 11
    .line 12
    .line 13
    iput-object v0, p0, Ly13;->a:Lng1;

    .line 14
    .line 15
    return-void
.end method

.method public static a(Ljava/lang/Class;)Llo2;
    .registers 2

    .line 1
    invoke-virtual {p0}, Ljava/lang/Class;->isPrimitive()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_1b

    .line 6
    .line 7
    sget-object v0, Ly13;->m:Ljava/lang/Class;

    .line 8
    .line 9
    if-ne p0, v0, :cond_d

    .line 10
    .line 11
    sget-object p0, Ly13;->p:Llo2;

    .line 12
    .line 13
    return-object p0

    .line 14
    :cond_d
    sget-object v0, Ly13;->n:Ljava/lang/Class;

    .line 15
    .line 16
    if-ne p0, v0, :cond_14

    .line 17
    .line 18
    sget-object p0, Ly13;->q:Llo2;

    .line 19
    .line 20
    return-object p0

    .line 21
    :cond_14
    sget-object v0, Ly13;->o:Ljava/lang/Class;

    .line 22
    .line 23
    if-ne p0, v0, :cond_30

    .line 24
    .line 25
    sget-object p0, Ly13;->r:Llo2;

    .line 26
    .line 27
    return-object p0

    .line 28
    :cond_1b
    sget-object v0, Ly13;->e:Ljava/lang/Class;

    .line 29
    .line 30
    if-ne p0, v0, :cond_22

    .line 31
    .line 32
    sget-object p0, Ly13;->s:Llo2;

    .line 33
    .line 34
    return-object p0

    .line 35
    :cond_22
    sget-object v0, Ly13;->f:Ljava/lang/Class;

    .line 36
    .line 37
    if-ne p0, v0, :cond_29

    .line 38
    .line 39
    sget-object p0, Ly13;->t:Llo2;

    .line 40
    .line 41
    return-object p0

    .line 42
    :cond_29
    sget-object v0, Ly13;->l:Ljava/lang/Class;

    .line 43
    .line 44
    if-ne p0, v0, :cond_30

    .line 45
    .line 46
    sget-object p0, Ly13;->w:Llo2;

    .line 47
    .line 48
    return-object p0

    .line 49
    :cond_30
    const/4 p0, 0x0

    .line 50
    return-object p0
.end method

.method public static e(Lh13;Lh13;)Z
    .registers 8

    .line 1
    instance-of v0, p1, Ls12;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_a

    .line 5
    .line 6
    check-cast p1, Ls12;

    .line 7
    .line 8
    iput-object p0, p1, Ls12;->q:Lh13;

    .line 9
    .line 10
    return v1

    .line 11
    :cond_a
    iget-object v0, p0, Lh13;->d:Ljava/lang/Class;

    .line 12
    .line 13
    iget-object v2, p1, Lh13;->d:Ljava/lang/Class;

    .line 14
    .line 15
    const/4 v3, 0x0

    .line 16
    if-eq v0, v2, :cond_12

    .line 17
    .line 18
    goto :goto_3b

    .line 19
    :cond_12
    invoke-virtual {p0}, Lh13;->I()Lk13;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    invoke-virtual {p0}, Lk13;->e()Ljava/util/List;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    invoke-virtual {p1}, Lh13;->I()Lk13;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    invoke-virtual {p1}, Lk13;->e()Ljava/util/List;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    invoke-interface {p0}, Ljava/util/List;->size()I

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    move v2, v3

    .line 40
    :goto_27
    if-ge v2, v0, :cond_3f

    .line 41
    .line 42
    invoke-interface {p0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v4

    .line 46
    check-cast v4, Lh13;

    .line 47
    .line 48
    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object v5

    .line 52
    check-cast v5, Lh13;

    .line 53
    .line 54
    invoke-static {v4, v5}, Ly13;->e(Lh13;Lh13;)Z

    .line 55
    .line 56
    .line 57
    move-result v4

    .line 58
    if-nez v4, :cond_3c

    .line 59
    .line 60
    :goto_3b
    return v3

    .line 61
    :cond_3c
    add-int/lit8 v2, v2, 0x1

    .line 62
    .line 63
    goto :goto_27

    .line 64
    :cond_3f
    return v1
.end method

.method public static f(Lh13;Ljava/lang/Class;)Lh13;
    .registers 4

    .line 1
    iget-object v0, p0, Lh13;->d:Ljava/lang/Class;

    .line 2
    .line 3
    if-ne v0, p1, :cond_5

    .line 4
    .line 5
    return-object p0

    .line 6
    :cond_5
    invoke-virtual {p0, p1}, Lh13;->H(Ljava/lang/Class;)Lh13;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    if-nez v1, :cond_2d

    .line 11
    .line 12
    invoke-virtual {p1, v0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    const/4 v1, 0x0

    .line 17
    if-nez v0, :cond_20

    .line 18
    .line 19
    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    filled-new-array {p1, p0}, [Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    const-string p1, "Class %s not a super-type of %s"

    .line 28
    .line 29
    invoke-static {p1, p0}, Lvn0;->j(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    return-object v1

    .line 33
    :cond_20
    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    filled-new-array {p1, p0}, [Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object p0

    .line 41
    const-string p1, "Internal error: class %s not included as super-type for %s"

    .line 42
    .line 43
    invoke-static {p1, p0}, Lvn0;->j(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    :cond_2d
    return-object v1
.end method

.method public static h(Lh13;Ljava/lang/Class;)[Lh13;
    .registers 2

    .line 1
    invoke-virtual {p0, p1}, Lh13;->H(Ljava/lang/Class;)Lh13;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    if-nez p0, :cond_9

    .line 6
    .line 7
    sget-object p0, Ly13;->b:[Lh13;

    .line 8
    .line 9
    return-object p0

    .line 10
    :cond_9
    invoke-virtual {p0}, Lh13;->I()Lk13;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    iget-object p0, p0, Lk13;->b:[Lh13;

    .line 15
    .line 16
    return-object p0
.end method

.method public static i(Ljava/lang/Class;)V
    .registers 4

    .line 1
    sget-object v0, Ly13;->d:Lk13;

    .line 2
    .line 3
    invoke-virtual {v0}, Lk13;->f()Z

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    if-eqz v1, :cond_f

    .line 8
    .line 9
    invoke-static {p0}, Ly13;->a(Ljava/lang/Class;)Llo2;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    if-eqz v1, :cond_f

    .line 14
    .line 15
    return-void

    .line 16
    :cond_f
    new-instance v1, Llo2;

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-direct {v1, p0, v0, v2, v2}, Llo2;-><init>(Ljava/lang/Class;Lk13;Lh13;[Lh13;)V

    .line 20
    .line 21
    .line 22
    return-void
.end method

.method public static j()Llo2;
    .registers 1

    .line 1
    sget-object v0, Ly13;->c:Ly13;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    sget-object v0, Ly13;->t:Llo2;

    .line 7
    .line 8
    return-object v0
.end method


# virtual methods
.method public final b(Lna;Ljava/lang/reflect/Type;Lk13;)Lh13;
    .registers 13

    .line 1
    instance-of v0, p2, Ljava/lang/Class;

    .line 2
    .line 3
    if-eqz v0, :cond_d

    .line 4
    .line 5
    check-cast p2, Ljava/lang/Class;

    .line 6
    .line 7
    sget-object p3, Ly13;->d:Lk13;

    .line 8
    .line 9
    invoke-virtual {p0, p1, p2, p3}, Ly13;->c(Lna;Ljava/lang/Class;Lk13;)Lh13;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    return-object p0

    .line 14
    :cond_d
    instance-of v0, p2, Ljava/lang/reflect/ParameterizedType;

    .line 15
    .line 16
    const/4 v1, 0x0

    .line 17
    if-eqz v0, :cond_4e

    .line 18
    .line 19
    check-cast p2, Ljava/lang/reflect/ParameterizedType;

    .line 20
    .line 21
    invoke-interface {p2}, Ljava/lang/reflect/ParameterizedType;->getRawType()Ljava/lang/reflect/Type;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    check-cast v0, Ljava/lang/Class;

    .line 26
    .line 27
    sget-object v2, Ly13;->j:Ljava/lang/Class;

    .line 28
    .line 29
    if-ne v0, v2, :cond_21

    .line 30
    .line 31
    sget-object p0, Ly13;->v:Llo2;

    .line 32
    .line 33
    return-object p0

    .line 34
    :cond_21
    sget-object v2, Ly13;->g:Ljava/lang/Class;

    .line 35
    .line 36
    if-ne v0, v2, :cond_28

    .line 37
    .line 38
    sget-object p0, Ly13;->u:Llo2;

    .line 39
    .line 40
    return-object p0

    .line 41
    :cond_28
    invoke-interface {p2}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    .line 42
    .line 43
    .line 44
    move-result-object p2

    .line 45
    if-nez p2, :cond_30

    .line 46
    .line 47
    move v2, v1

    .line 48
    goto :goto_31

    .line 49
    :cond_30
    array-length v2, p2

    .line 50
    :goto_31
    if-nez v2, :cond_36

    .line 51
    .line 52
    sget-object p2, Ly13;->d:Lk13;

    .line 53
    .line 54
    goto :goto_49

    .line 55
    :cond_36
    new-array v3, v2, [Lh13;

    .line 56
    .line 57
    :goto_38
    if-ge v1, v2, :cond_45

    .line 58
    .line 59
    aget-object v4, p2, v1

    .line 60
    .line 61
    invoke-virtual {p0, p1, v4, p3}, Ly13;->b(Lna;Ljava/lang/reflect/Type;Lk13;)Lh13;

    .line 62
    .line 63
    .line 64
    move-result-object v4

    .line 65
    aput-object v4, v3, v1

    .line 66
    .line 67
    add-int/lit8 v1, v1, 0x1

    .line 68
    .line 69
    goto :goto_38

    .line 70
    :cond_45
    invoke-static {v0, v3}, Lk13;->c(Ljava/lang/Class;[Lh13;)Lk13;

    .line 71
    .line 72
    .line 73
    move-result-object p2

    .line 74
    :goto_49
    invoke-virtual {p0, p1, v0, p2}, Ly13;->c(Lna;Ljava/lang/Class;Lk13;)Lh13;

    .line 75
    .line 76
    .line 77
    move-result-object p0

    .line 78
    return-object p0

    .line 79
    :cond_4e
    instance-of v0, p2, Lh13;

    .line 80
    .line 81
    if-eqz v0, :cond_55

    .line 82
    .line 83
    check-cast p2, Lh13;

    .line 84
    .line 85
    return-object p2

    .line 86
    :cond_55
    instance-of v0, p2, Ljava/lang/reflect/GenericArrayType;

    .line 87
    .line 88
    if-eqz v0, :cond_75

    .line 89
    .line 90
    check-cast p2, Ljava/lang/reflect/GenericArrayType;

    .line 91
    .line 92
    invoke-interface {p2}, Ljava/lang/reflect/GenericArrayType;->getGenericComponentType()Ljava/lang/reflect/Type;

    .line 93
    .line 94
    .line 95
    move-result-object p2

    .line 96
    invoke-virtual {p0, p1, p2, p3}, Ly13;->b(Lna;Ljava/lang/reflect/Type;Lk13;)Lh13;

    .line 97
    .line 98
    .line 99
    move-result-object v3

    .line 100
    sget p0, Lsb;->r:I

    .line 101
    .line 102
    iget-object p0, v3, Lh13;->d:Ljava/lang/Class;

    .line 103
    .line 104
    invoke-static {p0, v1}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;I)Ljava/lang/Object;

    .line 105
    .line 106
    .line 107
    move-result-object v5

    .line 108
    new-instance v2, Lsb;

    .line 109
    .line 110
    const/4 v8, 0x0

    .line 111
    const/4 v6, 0x0

    .line 112
    const/4 v7, 0x0

    .line 113
    move-object v4, p3

    .line 114
    invoke-direct/range {v2 .. v8}, Lsb;-><init>(Lh13;Lk13;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)V

    .line 115
    .line 116
    .line 117
    return-object v2

    .line 118
    :cond_75
    move-object v4, p3

    .line 119
    instance-of p3, p2, Ljava/lang/reflect/TypeVariable;

    .line 120
    .line 121
    if-eqz p3, :cond_f9

    .line 122
    .line 123
    check-cast p2, Ljava/lang/reflect/TypeVariable;

    .line 124
    .line 125
    invoke-interface {p2}, Ljava/lang/reflect/TypeVariable;->getName()Ljava/lang/String;

    .line 126
    .line 127
    .line 128
    move-result-object p3

    .line 129
    const/4 v0, 0x0

    .line 130
    if-eqz v4, :cond_ed

    .line 131
    .line 132
    iget-object v2, v4, Lk13;->a:[Ljava/lang/String;

    .line 133
    .line 134
    array-length v3, v2

    .line 135
    move v5, v1

    .line 136
    :goto_87
    if-ge v5, v3, :cond_a5

    .line 137
    .line 138
    aget-object v6, v2, v5

    .line 139
    .line 140
    invoke-virtual {p3, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 141
    .line 142
    .line 143
    move-result v6

    .line 144
    if-eqz v6, :cond_a2

    .line 145
    .line 146
    iget-object v0, v4, Lk13;->b:[Lh13;

    .line 147
    .line 148
    aget-object v0, v0, v5

    .line 149
    .line 150
    instance-of v2, v0, Lpf2;

    .line 151
    .line 152
    if-eqz v2, :cond_a5

    .line 153
    .line 154
    move-object v2, v0

    .line 155
    check-cast v2, Lpf2;

    .line 156
    .line 157
    iget-object v2, v2, Lpf2;->p:Lh13;

    .line 158
    .line 159
    if-eqz v2, :cond_a5

    .line 160
    .line 161
    move-object v0, v2

    .line 162
    goto :goto_a5

    .line 163
    :cond_a2
    add-int/lit8 v5, v5, 0x1

    .line 164
    .line 165
    goto :goto_87

    .line 166
    :cond_a5
    :goto_a5
    if-eqz v0, :cond_a8

    .line 167
    .line 168
    return-object v0

    .line 169
    :cond_a8
    iget-object v0, v4, Lk13;->c:[Ljava/lang/String;

    .line 170
    .line 171
    if-eqz v0, :cond_bc

    .line 172
    .line 173
    array-length v2, v0

    .line 174
    :cond_ad
    add-int/lit8 v2, v2, -0x1

    .line 175
    .line 176
    if-ltz v2, :cond_bc

    .line 177
    .line 178
    aget-object v3, v0, v2

    .line 179
    .line 180
    invoke-virtual {p3, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 181
    .line 182
    .line 183
    move-result v3

    .line 184
    if-eqz v3, :cond_ad

    .line 185
    .line 186
    sget-object p0, Ly13;->t:Llo2;

    .line 187
    .line 188
    return-object p0

    .line 189
    :cond_bc
    iget-object v0, v4, Lk13;->c:[Ljava/lang/String;

    .line 190
    .line 191
    if-nez v0, :cond_c2

    .line 192
    .line 193
    move v2, v1

    .line 194
    goto :goto_c3

    .line 195
    :cond_c2
    array-length v2, v0

    .line 196
    :goto_c3
    if-nez v2, :cond_c9

    .line 197
    .line 198
    const/4 v0, 0x1

    .line 199
    new-array v0, v0, [Ljava/lang/String;

    .line 200
    .line 201
    goto :goto_d1

    .line 202
    :cond_c9
    add-int/lit8 v3, v2, 0x1

    .line 203
    .line 204
    invoke-static {v0, v3}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 205
    .line 206
    .line 207
    move-result-object v0

    .line 208
    check-cast v0, [Ljava/lang/String;

    .line 209
    .line 210
    :goto_d1
    aput-object p3, v0, v2

    .line 211
    .line 212
    new-instance p3, Lk13;

    .line 213
    .line 214
    iget-object v2, v4, Lk13;->a:[Ljava/lang/String;

    .line 215
    .line 216
    iget-object v3, v4, Lk13;->b:[Lh13;

    .line 217
    .line 218
    invoke-direct {p3, v2, v3, v0}, Lk13;-><init>([Ljava/lang/String;[Lh13;[Ljava/lang/String;)V

    .line 219
    .line 220
    .line 221
    monitor-enter p2

    .line 222
    :try_start_dd
    invoke-interface {p2}, Ljava/lang/reflect/TypeVariable;->getBounds()[Ljava/lang/reflect/Type;

    .line 223
    .line 224
    .line 225
    move-result-object v0

    .line 226
    monitor-exit p2
    :try_end_e2
    .catchall {:try_start_dd .. :try_end_e2} :catchall_e9

    .line 227
    aget-object p2, v0, v1

    .line 228
    .line 229
    invoke-virtual {p0, p1, p2, p3}, Ly13;->b(Lna;Ljava/lang/reflect/Type;Lk13;)Lh13;

    .line 230
    .line 231
    .line 232
    move-result-object p0

    .line 233
    return-object p0

    .line 234
    :catchall_e9
    move-exception v0

    .line 235
    move-object p0, v0

    .line 236
    :try_start_eb
    monitor-exit p2
    :try_end_ec
    .catchall {:try_start_eb .. :try_end_ec} :catchall_e9

    .line 237
    throw p0

    .line 238
    :cond_ed
    const-string p0, "Null `bindings` passed (type variable \""

    .line 239
    .line 240
    const-string p1, "\")"

    .line 241
    .line 242
    invoke-static {p0, p3, p1}, Ln10;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 243
    .line 244
    .line 245
    move-result-object p0

    .line 246
    invoke-static {p0}, Lm03;->g(Ljava/lang/String;)V

    .line 247
    .line 248
    .line 249
    return-object v0

    .line 250
    :cond_f9
    instance-of p3, p2, Ljava/lang/reflect/WildcardType;

    .line 251
    .line 252
    if-eqz p3, :cond_10a

    .line 253
    .line 254
    check-cast p2, Ljava/lang/reflect/WildcardType;

    .line 255
    .line 256
    invoke-interface {p2}, Ljava/lang/reflect/WildcardType;->getUpperBounds()[Ljava/lang/reflect/Type;

    .line 257
    .line 258
    .line 259
    move-result-object p2

    .line 260
    aget-object p2, p2, v1

    .line 261
    .line 262
    invoke-virtual {p0, p1, p2, v4}, Ly13;->b(Lna;Ljava/lang/reflect/Type;Lk13;)Lh13;

    .line 263
    .line 264
    .line 265
    move-result-object p0

    .line 266
    return-object p0

    .line 267
    :cond_10a
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 268
    .line 269
    new-instance p1, Ljava/lang/StringBuilder;

    .line 270
    .line 271
    const-string p3, "Unrecognized Type: "

    .line 272
    .line 273
    invoke-direct {p1, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 274
    .line 275
    .line 276
    if-nez p2, :cond_118

    .line 277
    .line 278
    const-string p2, "[null]"

    .line 279
    .line 280
    goto :goto_11c

    .line 281
    :cond_118
    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 282
    .line 283
    .line 284
    move-result-object p2

    .line 285
    :goto_11c
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 286
    .line 287
    .line 288
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 289
    .line 290
    .line 291
    move-result-object p1

    .line 292
    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 293
    .line 294
    .line 295
    throw p0
.end method

.method public final c(Lna;Ljava/lang/Class;Lk13;)Lh13;
    .registers 23

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    move-object/from16 v3, p3

    .line 8
    .line 9
    iget-object v4, v0, Ly13;->a:Lng1;

    .line 10
    .line 11
    iget-object v4, v4, Lng1;->a:Ljava/io/Serializable;

    .line 12
    .line 13
    move-object v10, v4

    .line 14
    check-cast v10, Lw42;

    .line 15
    .line 16
    invoke-static {v2}, Ly13;->a(Ljava/lang/Class;)Llo2;

    .line 17
    .line 18
    .line 19
    move-result-object v4

    .line 20
    if-eqz v4, :cond_16

    .line 21
    .line 22
    return-object v4

    .line 23
    :cond_16
    const/4 v11, 0x0

    .line 24
    const/4 v12, 0x0

    .line 25
    if-eqz v3, :cond_3b

    .line 26
    .line 27
    invoke-virtual {v3}, Lk13;->f()Z

    .line 28
    .line 29
    .line 30
    move-result v4

    .line 31
    if-eqz v4, :cond_21

    .line 32
    .line 33
    goto :goto_3b

    .line 34
    :cond_21
    iget-object v4, v3, Lk13;->b:[Lh13;

    .line 35
    .line 36
    array-length v5, v4

    .line 37
    move v6, v11

    .line 38
    :goto_25
    if-ge v6, v5, :cond_32

    .line 39
    .line 40
    aget-object v7, v4, v6

    .line 41
    .line 42
    instance-of v7, v7, Lg01;

    .line 43
    .line 44
    if-eqz v7, :cond_2f

    .line 45
    .line 46
    move-object v5, v12

    .line 47
    goto :goto_39

    .line 48
    :cond_2f
    add-int/lit8 v6, v6, 0x1

    .line 49
    .line 50
    goto :goto_25

    .line 51
    :cond_32
    new-instance v5, Li13;

    .line 52
    .line 53
    iget v6, v3, Lk13;->d:I

    .line 54
    .line 55
    invoke-direct {v5, v2, v4, v6}, Li13;-><init>(Ljava/lang/Class;[Lh13;I)V

    .line 56
    .line 57
    .line 58
    :goto_39
    move-object v13, v5

    .line 59
    goto :goto_3c

    .line 60
    :cond_3b
    :goto_3b
    move-object v13, v2

    .line 61
    :goto_3c
    if-nez v13, :cond_40

    .line 62
    .line 63
    move-object v4, v12

    .line 64
    goto :goto_46

    .line 65
    :cond_40
    invoke-virtual {v10, v13}, Lw42;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object v4

    .line 69
    check-cast v4, Lh13;

    .line 70
    .line 71
    :goto_46
    if-eqz v4, :cond_49

    .line 72
    .line 73
    return-object v4

    .line 74
    :cond_49
    if-nez v1, :cond_52

    .line 75
    .line 76
    new-instance v1, Lna;

    .line 77
    .line 78
    invoke-direct {v1, v12, v2}, Lna;-><init>(Lna;Ljava/lang/Class;)V

    .line 79
    .line 80
    .line 81
    move-object v14, v1

    .line 82
    goto :goto_94

    .line 83
    :cond_52
    iget-object v5, v1, Lna;->c:Ljava/lang/Object;

    .line 84
    .line 85
    check-cast v5, Ljava/lang/Class;

    .line 86
    .line 87
    if-ne v5, v2, :cond_5a

    .line 88
    .line 89
    move-object v9, v1

    .line 90
    goto :goto_6c

    .line 91
    :cond_5a
    iget-object v5, v1, Lna;->b:Ljava/lang/Object;

    .line 92
    .line 93
    :goto_5c
    check-cast v5, Lna;

    .line 94
    .line 95
    if-eqz v5, :cond_6b

    .line 96
    .line 97
    iget-object v6, v5, Lna;->c:Ljava/lang/Object;

    .line 98
    .line 99
    check-cast v6, Ljava/lang/Class;

    .line 100
    .line 101
    if-ne v6, v2, :cond_68

    .line 102
    .line 103
    move-object v9, v5

    .line 104
    goto :goto_6c

    .line 105
    :cond_68
    iget-object v5, v5, Lna;->b:Ljava/lang/Object;

    .line 106
    .line 107
    goto :goto_5c

    .line 108
    :cond_6b
    move-object v9, v12

    .line 109
    :goto_6c
    if-eqz v9, :cond_8e

    .line 110
    .line 111
    new-instance v0, Lpf2;

    .line 112
    .line 113
    const/4 v7, 0x0

    .line 114
    const/4 v8, 0x0

    .line 115
    sget-object v2, Ly13;->d:Lk13;

    .line 116
    .line 117
    const/4 v3, 0x0

    .line 118
    const/4 v4, 0x0

    .line 119
    const/4 v5, 0x0

    .line 120
    const/4 v6, 0x0

    .line 121
    move-object/from16 v1, p2

    .line 122
    .line 123
    invoke-direct/range {v0 .. v8}, Lh13;-><init>(Ljava/lang/Class;Lk13;Lh13;[Lh13;ILjava/lang/Object;Ljava/lang/Object;Z)V

    .line 124
    .line 125
    .line 126
    iget-object v1, v9, Lna;->d:Ljava/lang/Object;

    .line 127
    .line 128
    check-cast v1, Ljava/util/ArrayList;

    .line 129
    .line 130
    if-nez v1, :cond_8a

    .line 131
    .line 132
    new-instance v1, Ljava/util/ArrayList;

    .line 133
    .line 134
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 135
    .line 136
    .line 137
    iput-object v1, v9, Lna;->d:Ljava/lang/Object;

    .line 138
    .line 139
    :cond_8a
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 140
    .line 141
    .line 142
    return-object v0

    .line 143
    :cond_8e
    new-instance v5, Lna;

    .line 144
    .line 145
    invoke-direct {v5, v1, v2}, Lna;-><init>(Lna;Ljava/lang/Class;)V

    .line 146
    .line 147
    .line 148
    move-object v14, v5

    .line 149
    :goto_94
    invoke-virtual {v2}, Ljava/lang/Class;->isArray()Z

    .line 150
    .line 151
    .line 152
    move-result v1

    .line 153
    const/4 v15, 0x1

    .line 154
    if-eqz v1, :cond_ba

    .line 155
    .line 156
    invoke-virtual {v2}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    .line 157
    .line 158
    .line 159
    move-result-object v1

    .line 160
    invoke-virtual {v0, v14, v1, v3}, Ly13;->b(Lna;Ljava/lang/reflect/Type;Lk13;)Lh13;

    .line 161
    .line 162
    .line 163
    move-result-object v1

    .line 164
    sget v0, Lsb;->r:I

    .line 165
    .line 166
    iget-object v0, v1, Lh13;->d:Ljava/lang/Class;

    .line 167
    .line 168
    invoke-static {v0, v11}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;I)Ljava/lang/Object;

    .line 169
    .line 170
    .line 171
    move-result-object v0

    .line 172
    move-object v3, v0

    .line 173
    new-instance v0, Lsb;

    .line 174
    .line 175
    const/4 v6, 0x0

    .line 176
    const/4 v4, 0x0

    .line 177
    const/4 v5, 0x0

    .line 178
    move-object/from16 v2, p3

    .line 179
    .line 180
    invoke-direct/range {v0 .. v6}, Lsb;-><init>(Lh13;Lk13;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)V

    .line 181
    .line 182
    .line 183
    move-object/from16 v17, v12

    .line 184
    .line 185
    goto/16 :goto_1f2

    .line 186
    .line 187
    :cond_ba
    invoke-virtual {v2}, Ljava/lang/Class;->isInterface()Z

    .line 188
    .line 189
    .line 190
    move-result v1

    .line 191
    if-eqz v1, :cond_c6

    .line 192
    .line 193
    invoke-virtual {v0, v14, v2, v3}, Ly13;->d(Lna;Ljava/lang/Class;Lk13;)[Lh13;

    .line 194
    .line 195
    .line 196
    move-result-object v0

    .line 197
    move-object v1, v12

    .line 198
    goto :goto_d8

    .line 199
    :cond_c6
    sget-object v1, Lut;->a:[Ljava/lang/annotation/Annotation;

    .line 200
    .line 201
    invoke-virtual {v2}, Ljava/lang/Class;->getGenericSuperclass()Ljava/lang/reflect/Type;

    .line 202
    .line 203
    .line 204
    move-result-object v1

    .line 205
    if-nez v1, :cond_d0

    .line 206
    .line 207
    move-object v1, v12

    .line 208
    goto :goto_d4

    .line 209
    :cond_d0
    invoke-virtual {v0, v14, v1, v3}, Ly13;->b(Lna;Ljava/lang/reflect/Type;Lk13;)Lh13;

    .line 210
    .line 211
    .line 212
    move-result-object v1

    .line 213
    :goto_d4
    invoke-virtual {v0, v14, v2, v3}, Ly13;->d(Lna;Ljava/lang/Class;Lk13;)[Lh13;

    .line 214
    .line 215
    .line 216
    move-result-object v0

    .line 217
    :goto_d8
    sget-object v5, Ly13;->s:Llo2;

    .line 218
    .line 219
    const-class v6, Ljava/util/Properties;

    .line 220
    .line 221
    if-ne v2, v6, :cond_fa

    .line 222
    .line 223
    move-object v4, v0

    .line 224
    new-instance v0, Lto1;

    .line 225
    .line 226
    const/4 v8, 0x0

    .line 227
    const/4 v9, 0x0

    .line 228
    const/4 v7, 0x0

    .line 229
    move-object/from16 v16, v6

    .line 230
    .line 231
    move-object v6, v5

    .line 232
    move-object/from16 v17, v3

    .line 233
    .line 234
    move-object v3, v1

    .line 235
    move-object v1, v2

    .line 236
    move-object/from16 v2, v17

    .line 237
    .line 238
    move-object/from16 v17, v12

    .line 239
    .line 240
    move-object/from16 v12, v16

    .line 241
    .line 242
    invoke-direct/range {v0 .. v9}, Lto1;-><init>(Ljava/lang/Class;Lk13;Lh13;[Lh13;Lh13;Lh13;Ljava/lang/Object;Ljava/lang/Object;Z)V

    .line 243
    .line 244
    .line 245
    move-object/from16 v18, v2

    .line 246
    .line 247
    move-object v2, v1

    .line 248
    move-object/from16 v1, v18

    .line 249
    .line 250
    goto :goto_10d

    .line 251
    :cond_fa
    move-object/from16 v17, v4

    .line 252
    .line 253
    move-object v4, v0

    .line 254
    move-object/from16 v0, v17

    .line 255
    .line 256
    move-object/from16 v17, v3

    .line 257
    .line 258
    move-object v3, v1

    .line 259
    move-object/from16 v1, v17

    .line 260
    .line 261
    move-object/from16 v17, v12

    .line 262
    .line 263
    move-object v12, v6

    .line 264
    if-eqz v3, :cond_10d

    .line 265
    .line 266
    invoke-virtual {v3, v2, v1, v3, v4}, Lh13;->V(Ljava/lang/Class;Lk13;Lh13;[Lh13;)Lh13;

    .line 267
    .line 268
    .line 269
    move-result-object v0

    .line 270
    :cond_10d
    :goto_10d
    if-nez v0, :cond_1f2

    .line 271
    .line 272
    if-nez v1, :cond_114

    .line 273
    .line 274
    sget-object v0, Ly13;->d:Lk13;

    .line 275
    .line 276
    goto :goto_115

    .line 277
    :cond_114
    move-object v0, v1

    .line 278
    :goto_115
    const-class v6, Ljava/util/Map;

    .line 279
    .line 280
    sget-object v7, Ly13;->t:Llo2;

    .line 281
    .line 282
    if-ne v2, v6, :cond_16d

    .line 283
    .line 284
    if-ne v2, v12, :cond_120

    .line 285
    .line 286
    move-object v2, v0

    .line 287
    :goto_11e
    move-object v6, v5

    .line 288
    goto :goto_160

    .line 289
    :cond_120
    invoke-virtual {v0}, Lk13;->e()Ljava/util/List;

    .line 290
    .line 291
    .line 292
    move-result-object v5

    .line 293
    invoke-interface {v5}, Ljava/util/List;->size()I

    .line 294
    .line 295
    .line 296
    move-result v6

    .line 297
    if-eqz v6, :cond_15d

    .line 298
    .line 299
    const/4 v7, 0x2

    .line 300
    if-eq v6, v7, :cond_14c

    .line 301
    .line 302
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 303
    .line 304
    invoke-static {v2}, Lut;->u(Ljava/lang/Class;)Ljava/lang/String;

    .line 305
    .line 306
    .line 307
    move-result-object v2

    .line 308
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 309
    .line 310
    .line 311
    move-result-object v3

    .line 312
    if-ne v6, v15, :cond_13c

    .line 313
    .line 314
    const-string v4, ""

    .line 315
    .line 316
    goto :goto_13e

    .line 317
    :cond_13c
    const-string v4, "s"

    .line 318
    .line 319
    :goto_13e
    filled-new-array {v2, v3, v4, v0}, [Ljava/lang/Object;

    .line 320
    .line 321
    .line 322
    move-result-object v0

    .line 323
    const-string v2, "Strange Map type %s with %d type parameter%s (%s), can not resolve"

    .line 324
    .line 325
    invoke-static {v2, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 326
    .line 327
    .line 328
    move-result-object v0

    .line 329
    invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 330
    .line 331
    .line 332
    throw v1

    .line 333
    :cond_14c
    invoke-interface {v5, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 334
    .line 335
    .line 336
    move-result-object v6

    .line 337
    check-cast v6, Lh13;

    .line 338
    .line 339
    invoke-interface {v5, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 340
    .line 341
    .line 342
    move-result-object v5

    .line 343
    check-cast v5, Lh13;

    .line 344
    .line 345
    move-object v2, v6

    .line 346
    move-object v6, v5

    .line 347
    move-object v5, v2

    .line 348
    move-object v2, v0

    .line 349
    goto :goto_160

    .line 350
    :cond_15d
    move-object v2, v0

    .line 351
    move-object v5, v7

    .line 352
    goto :goto_11e

    .line 353
    :goto_160
    new-instance v0, Lto1;

    .line 354
    .line 355
    const/4 v8, 0x0

    .line 356
    const/4 v9, 0x0

    .line 357
    const/4 v7, 0x0

    .line 358
    move-object v12, v1

    .line 359
    move-object/from16 v1, p2

    .line 360
    .line 361
    invoke-direct/range {v0 .. v9}, Lto1;-><init>(Ljava/lang/Class;Lk13;Lh13;[Lh13;Lh13;Lh13;Ljava/lang/Object;Ljava/lang/Object;Z)V

    .line 362
    .line 363
    .line 364
    goto/16 :goto_1d7

    .line 365
    .line 366
    :cond_16d
    move-object v12, v1

    .line 367
    move-object v1, v2

    .line 368
    move-object v2, v0

    .line 369
    const-class v0, Ljava/util/Collection;

    .line 370
    .line 371
    const-string v5, ": cannot determine type parameters"

    .line 372
    .line 373
    if-ne v1, v0, :cond_1a3

    .line 374
    .line 375
    invoke-virtual {v2}, Lk13;->e()Ljava/util/List;

    .line 376
    .line 377
    .line 378
    move-result-object v0

    .line 379
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 380
    .line 381
    .line 382
    move-result v6

    .line 383
    if-eqz v6, :cond_182

    .line 384
    .line 385
    :goto_180
    move-object v5, v7

    .line 386
    goto :goto_190

    .line 387
    :cond_182
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 388
    .line 389
    .line 390
    move-result v6

    .line 391
    if-ne v6, v15, :cond_199

    .line 392
    .line 393
    invoke-interface {v0, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 394
    .line 395
    .line 396
    move-result-object v0

    .line 397
    move-object v7, v0

    .line 398
    check-cast v7, Lh13;

    .line 399
    .line 400
    goto :goto_180

    .line 401
    :goto_190
    new-instance v0, Lfv;

    .line 402
    .line 403
    const/4 v7, 0x0

    .line 404
    const/4 v8, 0x0

    .line 405
    const/4 v6, 0x0

    .line 406
    invoke-direct/range {v0 .. v8}, Lfv;-><init>(Ljava/lang/Class;Lk13;Lh13;[Lh13;Lh13;Ljava/lang/Object;Ljava/lang/Object;Z)V

    .line 407
    .line 408
    .line 409
    goto :goto_1d7

    .line 410
    :cond_199
    const-string v0, "Strange Collection type "

    .line 411
    .line 412
    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 413
    .line 414
    .line 415
    move-result-object v1

    .line 416
    invoke-static {v1, v5, v0}, Ly0;->f(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    .line 417
    .line 418
    .line 419
    return-object v17

    .line 420
    :cond_1a3
    const-class v0, Ljava/util/concurrent/atomic/AtomicReference;

    .line 421
    .line 422
    if-ne v1, v0, :cond_1d5

    .line 423
    .line 424
    invoke-virtual {v2}, Lk13;->e()Ljava/util/List;

    .line 425
    .line 426
    .line 427
    move-result-object v0

    .line 428
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 429
    .line 430
    .line 431
    move-result v6

    .line 432
    if-eqz v6, :cond_1b3

    .line 433
    .line 434
    :goto_1b1
    move-object v5, v7

    .line 435
    goto :goto_1c1

    .line 436
    :cond_1b3
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 437
    .line 438
    .line 439
    move-result v6

    .line 440
    if-ne v6, v15, :cond_1cb

    .line 441
    .line 442
    invoke-interface {v0, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 443
    .line 444
    .line 445
    move-result-object v0

    .line 446
    move-object v7, v0

    .line 447
    check-cast v7, Lh13;

    .line 448
    .line 449
    goto :goto_1b1

    .line 450
    :goto_1c1
    new-instance v0, Lkc2;

    .line 451
    .line 452
    const/4 v8, 0x0

    .line 453
    const/4 v9, 0x0

    .line 454
    const/4 v6, 0x0

    .line 455
    const/4 v7, 0x0

    .line 456
    invoke-direct/range {v0 .. v9}, Lkc2;-><init>(Ljava/lang/Class;Lk13;Lh13;[Lh13;Lh13;Lh13;Ljava/lang/Object;Ljava/lang/Object;Z)V

    .line 457
    .line 458
    .line 459
    goto :goto_1d7

    .line 460
    :cond_1cb
    const-string v0, "Strange Reference type "

    .line 461
    .line 462
    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 463
    .line 464
    .line 465
    move-result-object v1

    .line 466
    invoke-static {v1, v5, v0}, Ly0;->f(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    .line 467
    .line 468
    .line 469
    return-object v17

    .line 470
    :cond_1d5
    move-object/from16 v0, v17

    .line 471
    .line 472
    :goto_1d7
    if-nez v0, :cond_1f2

    .line 473
    .line 474
    array-length v0, v4

    .line 475
    :goto_1da
    if-ge v11, v0, :cond_1e9

    .line 476
    .line 477
    aget-object v2, v4, v11

    .line 478
    .line 479
    invoke-virtual {v2, v1, v12, v3, v4}, Lh13;->V(Ljava/lang/Class;Lk13;Lh13;[Lh13;)Lh13;

    .line 480
    .line 481
    .line 482
    move-result-object v2

    .line 483
    if-eqz v2, :cond_1e6

    .line 484
    .line 485
    move-object v0, v2

    .line 486
    goto :goto_1eb

    .line 487
    :cond_1e6
    add-int/lit8 v11, v11, 0x1

    .line 488
    .line 489
    goto :goto_1da

    .line 490
    :cond_1e9
    move-object/from16 v0, v17

    .line 491
    .line 492
    :goto_1eb
    if-nez v0, :cond_1f2

    .line 493
    .line 494
    new-instance v0, Llo2;

    .line 495
    .line 496
    invoke-direct {v0, v1, v12, v3, v4}, Llo2;-><init>(Ljava/lang/Class;Lk13;Lh13;[Lh13;)V

    .line 497
    .line 498
    .line 499
    :cond_1f2
    :goto_1f2
    iget-object v1, v14, Lna;->d:Ljava/lang/Object;

    .line 500
    .line 501
    check-cast v1, Ljava/util/ArrayList;

    .line 502
    .line 503
    if-eqz v1, :cond_219

    .line 504
    .line 505
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 506
    .line 507
    .line 508
    move-result-object v1

    .line 509
    :goto_1fc
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 510
    .line 511
    .line 512
    move-result v2

    .line 513
    if-eqz v2, :cond_219

    .line 514
    .line 515
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 516
    .line 517
    .line 518
    move-result-object v2

    .line 519
    check-cast v2, Lpf2;

    .line 520
    .line 521
    iget-object v3, v2, Lpf2;->p:Lh13;

    .line 522
    .line 523
    if-nez v3, :cond_20f

    .line 524
    .line 525
    iput-object v0, v2, Lpf2;->p:Lh13;

    .line 526
    .line 527
    goto :goto_1fc

    .line 528
    :cond_20f
    iget-object v1, v2, Lpf2;->p:Lh13;

    .line 529
    .line 530
    const-string v2, ", new = "

    .line 531
    .line 532
    const-string v3, "Trying to re-set self reference; old value = "

    .line 533
    .line 534
    invoke-static {v3, v1, v2, v0}, Lt12;->j(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 535
    .line 536
    .line 537
    return-object v17

    .line 538
    :cond_219
    if-eqz v13, :cond_224

    .line 539
    .line 540
    invoke-virtual {v0}, Lh13;->Q()Z

    .line 541
    .line 542
    .line 543
    move-result v1

    .line 544
    if-nez v1, :cond_224

    .line 545
    .line 546
    invoke-virtual {v10, v13, v0, v15}, Lw42;->g(Ljava/lang/Object;Ljava/lang/Object;Z)Ljava/lang/Object;

    .line 547
    .line 548
    .line 549
    :cond_224
    return-object v0
.end method

.method public final d(Lna;Ljava/lang/Class;Lk13;)[Lh13;
    .registers 8

    .line 1
    sget-object v0, Lut;->a:[Ljava/lang/annotation/Annotation;

    .line 2
    .line 3
    invoke-virtual {p2}, Ljava/lang/Class;->getGenericInterfaces()[Ljava/lang/reflect/Type;

    .line 4
    .line 5
    .line 6
    move-result-object p2

    .line 7
    if-eqz p2, :cond_1e

    .line 8
    .line 9
    array-length v0, p2

    .line 10
    if-nez v0, :cond_c

    .line 11
    .line 12
    goto :goto_1e

    .line 13
    :cond_c
    array-length v0, p2

    .line 14
    new-array v1, v0, [Lh13;

    .line 15
    .line 16
    const/4 v2, 0x0

    .line 17
    :goto_10
    if-ge v2, v0, :cond_1d

    .line 18
    .line 19
    aget-object v3, p2, v2

    .line 20
    .line 21
    invoke-virtual {p0, p1, v3, p3}, Ly13;->b(Lna;Ljava/lang/reflect/Type;Lk13;)Lh13;

    .line 22
    .line 23
    .line 24
    move-result-object v3

    .line 25
    aput-object v3, v1, v2

    .line 26
    .line 27
    add-int/lit8 v2, v2, 0x1

    .line 28
    .line 29
    goto :goto_10

    .line 30
    :cond_1d
    return-object v1

    .line 31
    :cond_1e
    :goto_1e
    sget-object p0, Ly13;->b:[Lh13;

    .line 32
    .line 33
    return-object p0
.end method

.method public final g(Lh13;Ljava/lang/Class;Z)Lh13;
    .registers 26

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    iget-object v3, v1, Lh13;->d:Ljava/lang/Class;

    .line 8
    .line 9
    if-ne v3, v2, :cond_b

    .line 10
    .line 11
    goto :goto_62

    .line 12
    :cond_b
    const-class v4, Ljava/lang/Object;

    .line 13
    .line 14
    sget-object v5, Ly13;->d:Lk13;

    .line 15
    .line 16
    const/4 v6, 0x0

    .line 17
    if-ne v3, v4, :cond_18

    .line 18
    .line 19
    invoke-virtual {v0, v6, v2, v5}, Ly13;->c(Lna;Ljava/lang/Class;Lk13;)Lh13;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    goto/16 :goto_15e

    .line 24
    .line 25
    :cond_18
    invoke-virtual {v3, v2}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 26
    .line 27
    .line 28
    move-result v7

    .line 29
    if-eqz v7, :cond_173

    .line 30
    .line 31
    invoke-virtual {v1}, Lh13;->S()Z

    .line 32
    .line 33
    .line 34
    move-result v7

    .line 35
    if-eqz v7, :cond_72

    .line 36
    .line 37
    instance-of v7, v1, Lto1;

    .line 38
    .line 39
    if-eqz v7, :cond_49

    .line 40
    .line 41
    const-class v7, Ljava/util/HashMap;

    .line 42
    .line 43
    if-eq v2, v7, :cond_38

    .line 44
    .line 45
    const-class v7, Ljava/util/LinkedHashMap;

    .line 46
    .line 47
    if-eq v2, v7, :cond_38

    .line 48
    .line 49
    const-class v7, Ljava/util/EnumMap;

    .line 50
    .line 51
    if-eq v2, v7, :cond_38

    .line 52
    .line 53
    const-class v7, Ljava/util/TreeMap;

    .line 54
    .line 55
    if-ne v2, v7, :cond_72

    .line 56
    .line 57
    :cond_38
    move-object v3, v1

    .line 58
    check-cast v3, Lto1;

    .line 59
    .line 60
    iget-object v4, v3, Lto1;->p:Lh13;

    .line 61
    .line 62
    iget-object v3, v3, Lto1;->q:Lh13;

    .line 63
    .line 64
    invoke-static {v2, v4, v3}, Lk13;->b(Ljava/lang/Class;Lh13;Lh13;)Lk13;

    .line 65
    .line 66
    .line 67
    move-result-object v3

    .line 68
    invoke-virtual {v0, v6, v2, v3}, Ly13;->c(Lna;Ljava/lang/Class;Lk13;)Lh13;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    goto/16 :goto_15e

    .line 73
    .line 74
    :cond_49
    instance-of v7, v1, Lfv;

    .line 75
    .line 76
    if-eqz v7, :cond_72

    .line 77
    .line 78
    const-class v7, Ljava/util/ArrayList;

    .line 79
    .line 80
    if-eq v2, v7, :cond_63

    .line 81
    .line 82
    const-class v7, Ljava/util/LinkedList;

    .line 83
    .line 84
    if-eq v2, v7, :cond_63

    .line 85
    .line 86
    const-class v7, Ljava/util/HashSet;

    .line 87
    .line 88
    if-eq v2, v7, :cond_63

    .line 89
    .line 90
    const-class v7, Ljava/util/TreeSet;

    .line 91
    .line 92
    if-ne v2, v7, :cond_5e

    .line 93
    .line 94
    goto :goto_63

    .line 95
    :cond_5e
    const-class v7, Ljava/util/EnumSet;

    .line 96
    .line 97
    if-ne v3, v7, :cond_72

    .line 98
    .line 99
    :goto_62
    return-object v1

    .line 100
    :cond_63
    :goto_63
    move-object v3, v1

    .line 101
    check-cast v3, Lfv;

    .line 102
    .line 103
    iget-object v3, v3, Lfv;->p:Lh13;

    .line 104
    .line 105
    invoke-static {v3, v2}, Lk13;->a(Lh13;Ljava/lang/Class;)Lk13;

    .line 106
    .line 107
    .line 108
    move-result-object v3

    .line 109
    invoke-virtual {v0, v6, v2, v3}, Ly13;->c(Lna;Ljava/lang/Class;Lk13;)Lh13;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    goto/16 :goto_15e

    .line 114
    .line 115
    :cond_72
    invoke-virtual {v1}, Lh13;->I()Lk13;

    .line 116
    .line 117
    .line 118
    move-result-object v7

    .line 119
    invoke-virtual {v7}, Lk13;->f()Z

    .line 120
    .line 121
    .line 122
    move-result v7

    .line 123
    if-eqz v7, :cond_82

    .line 124
    .line 125
    invoke-virtual {v0, v6, v2, v5}, Ly13;->c(Lna;Ljava/lang/Class;Lk13;)Lh13;

    .line 126
    .line 127
    .line 128
    move-result-object v0

    .line 129
    goto/16 :goto_15e

    .line 130
    .line 131
    :cond_82
    invoke-virtual {v2}, Ljava/lang/Class;->getTypeParameters()[Ljava/lang/reflect/TypeVariable;

    .line 132
    .line 133
    .line 134
    move-result-object v7

    .line 135
    array-length v7, v7

    .line 136
    if-nez v7, :cond_8f

    .line 137
    .line 138
    invoke-virtual {v0, v6, v2, v5}, Ly13;->c(Lna;Ljava/lang/Class;Lk13;)Lh13;

    .line 139
    .line 140
    .line 141
    move-result-object v0

    .line 142
    goto/16 :goto_15e

    .line 143
    .line 144
    :cond_8f
    new-array v5, v7, [Ls12;

    .line 145
    .line 146
    const/4 v9, 0x0

    .line 147
    :goto_92
    if-ge v9, v7, :cond_9e

    .line 148
    .line 149
    new-instance v10, Ls12;

    .line 150
    .line 151
    invoke-direct {v10, v9}, Ls12;-><init>(I)V

    .line 152
    .line 153
    .line 154
    aput-object v10, v5, v9

    .line 155
    .line 156
    add-int/lit8 v9, v9, 0x1

    .line 157
    .line 158
    goto :goto_92

    .line 159
    :cond_9e
    invoke-static {v2, v5}, Lk13;->c(Ljava/lang/Class;[Lh13;)Lk13;

    .line 160
    .line 161
    .line 162
    move-result-object v9

    .line 163
    invoke-virtual {v0, v6, v2, v9}, Ly13;->c(Lna;Ljava/lang/Class;Lk13;)Lh13;

    .line 164
    .line 165
    .line 166
    move-result-object v9

    .line 167
    invoke-virtual {v9, v3}, Lh13;->H(Ljava/lang/Class;)Lh13;

    .line 168
    .line 169
    .line 170
    move-result-object v9

    .line 171
    if-eqz v9, :cond_163

    .line 172
    .line 173
    invoke-virtual {v1}, Lh13;->I()Lk13;

    .line 174
    .line 175
    .line 176
    move-result-object v3

    .line 177
    invoke-virtual {v3}, Lk13;->e()Ljava/util/List;

    .line 178
    .line 179
    .line 180
    move-result-object v3

    .line 181
    invoke-virtual {v9}, Lh13;->I()Lk13;

    .line 182
    .line 183
    .line 184
    move-result-object v9

    .line 185
    invoke-virtual {v9}, Lk13;->e()Ljava/util/List;

    .line 186
    .line 187
    .line 188
    move-result-object v9

    .line 189
    invoke-interface {v9}, Ljava/util/List;->size()I

    .line 190
    .line 191
    .line 192
    move-result v10

    .line 193
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 194
    .line 195
    .line 196
    move-result v11

    .line 197
    const/4 v12, 0x0

    .line 198
    :goto_c5
    if-ge v12, v11, :cond_129

    .line 199
    .line 200
    invoke-interface {v3, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 201
    .line 202
    .line 203
    move-result-object v13

    .line 204
    check-cast v13, Lh13;

    .line 205
    .line 206
    if-ge v12, v10, :cond_d6

    .line 207
    .line 208
    invoke-interface {v9, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 209
    .line 210
    .line 211
    move-result-object v14

    .line 212
    check-cast v14, Lh13;

    .line 213
    .line 214
    goto :goto_da

    .line 215
    :cond_d6
    invoke-static {}, Ly13;->j()Llo2;

    .line 216
    .line 217
    .line 218
    move-result-object v14

    .line 219
    :goto_da
    invoke-static {v13, v14}, Ly13;->e(Lh13;Lh13;)Z

    .line 220
    .line 221
    .line 222
    move-result v15

    .line 223
    if-nez v15, :cond_126

    .line 224
    .line 225
    invoke-virtual {v13, v4}, Lh13;->R(Ljava/lang/Class;)Z

    .line 226
    .line 227
    .line 228
    move-result v15

    .line 229
    iget-object v8, v13, Lh13;->d:Ljava/lang/Class;

    .line 230
    .line 231
    if-eqz v15, :cond_e9

    .line 232
    .line 233
    goto :goto_126

    .line 234
    :cond_e9
    if-nez v12, :cond_f6

    .line 235
    .line 236
    instance-of v15, v1, Lto1;

    .line 237
    .line 238
    if-eqz v15, :cond_f6

    .line 239
    .line 240
    invoke-virtual {v14, v4}, Lh13;->R(Ljava/lang/Class;)Z

    .line 241
    .line 242
    .line 243
    move-result v15

    .line 244
    if-eqz v15, :cond_f6

    .line 245
    .line 246
    goto :goto_126

    .line 247
    :cond_f6
    invoke-virtual {v8}, Ljava/lang/Class;->isInterface()Z

    .line 248
    .line 249
    .line 250
    move-result v15

    .line 251
    if-eqz v15, :cond_107

    .line 252
    .line 253
    iget-object v15, v14, Lh13;->d:Ljava/lang/Class;

    .line 254
    .line 255
    if-eq v8, v15, :cond_126

    .line 256
    .line 257
    invoke-virtual {v8, v15}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 258
    .line 259
    .line 260
    move-result v8

    .line 261
    if-eqz v8, :cond_107

    .line 262
    .line 263
    goto :goto_126

    .line 264
    :cond_107
    add-int/lit8 v12, v12, 0x1

    .line 265
    .line 266
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 267
    .line 268
    .line 269
    move-result-object v3

    .line 270
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 271
    .line 272
    .line 273
    move-result-object v4

    .line 274
    invoke-virtual {v13}, Lh13;->G()Ljava/lang/String;

    .line 275
    .line 276
    .line 277
    move-result-object v8

    .line 278
    invoke-virtual {v14}, Lh13;->G()Ljava/lang/String;

    .line 279
    .line 280
    .line 281
    move-result-object v9

    .line 282
    filled-new-array {v3, v4, v8, v9}, [Ljava/lang/Object;

    .line 283
    .line 284
    .line 285
    move-result-object v3

    .line 286
    const-string v4, "Type parameter #%d/%d differs; can not specialize %s with %s"

    .line 287
    .line 288
    invoke-static {v4, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 289
    .line 290
    .line 291
    move-result-object v3

    .line 292
    move-object/from16 v21, v3

    .line 293
    .line 294
    goto :goto_12b

    .line 295
    :cond_126
    :goto_126
    add-int/lit8 v12, v12, 0x1

    .line 296
    .line 297
    goto :goto_c5

    .line 298
    :cond_129
    move-object/from16 v21, v6

    .line 299
    .line 300
    :goto_12b
    if-eqz v21, :cond_142

    .line 301
    .line 302
    if-eqz p3, :cond_130

    .line 303
    .line 304
    goto :goto_142

    .line 305
    :cond_130
    invoke-virtual {v1}, Lh13;->G()Ljava/lang/String;

    .line 306
    .line 307
    .line 308
    move-result-object v17

    .line 309
    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 310
    .line 311
    .line 312
    move-result-object v19

    .line 313
    const-string v20, ", problem: "

    .line 314
    .line 315
    const-string v16, "Failed to specialize base type "

    .line 316
    .line 317
    const-string v18, " as "

    .line 318
    .line 319
    invoke-static/range {v16 .. v21}, Lvn0;->i(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 320
    .line 321
    .line 322
    return-object v6

    .line 323
    :cond_142
    :goto_142
    new-array v3, v7, [Lh13;

    .line 324
    .line 325
    const/4 v8, 0x0

    .line 326
    :goto_145
    if-ge v8, v7, :cond_156

    .line 327
    .line 328
    aget-object v4, v5, v8

    .line 329
    .line 330
    iget-object v4, v4, Ls12;->q:Lh13;

    .line 331
    .line 332
    if-nez v4, :cond_151

    .line 333
    .line 334
    invoke-static {}, Ly13;->j()Llo2;

    .line 335
    .line 336
    .line 337
    move-result-object v4

    .line 338
    :cond_151
    aput-object v4, v3, v8

    .line 339
    .line 340
    add-int/lit8 v8, v8, 0x1

    .line 341
    .line 342
    goto :goto_145

    .line 343
    :cond_156
    invoke-static {v2, v3}, Lk13;->c(Ljava/lang/Class;[Lh13;)Lk13;

    .line 344
    .line 345
    .line 346
    move-result-object v3

    .line 347
    invoke-virtual {v0, v6, v2, v3}, Ly13;->c(Lna;Ljava/lang/Class;Lk13;)Lh13;

    .line 348
    .line 349
    .line 350
    move-result-object v0

    .line 351
    :goto_15e
    invoke-virtual {v0, v1}, Lh13;->Y(Lh13;)Lh13;

    .line 352
    .line 353
    .line 354
    move-result-object v0

    .line 355
    return-object v0

    .line 356
    :cond_163
    invoke-virtual {v3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 357
    .line 358
    .line 359
    move-result-object v0

    .line 360
    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 361
    .line 362
    .line 363
    move-result-object v1

    .line 364
    const-string v2, "Internal error: unable to locate supertype ("

    .line 365
    .line 366
    const-string v3, ") from resolved subtype "

    .line 367
    .line 368
    invoke-static {v2, v0, v3, v1}, Lm03;->e(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 369
    .line 370
    .line 371
    return-object v6

    .line 372
    :cond_173
    invoke-static {v2}, Lut;->u(Ljava/lang/Class;)Ljava/lang/String;

    .line 373
    .line 374
    .line 375
    move-result-object v0

    .line 376
    invoke-static {v1}, Lut;->n(Lh13;)Ljava/lang/String;

    .line 377
    .line 378
    .line 379
    move-result-object v1

    .line 380
    const-string v2, "Class "

    .line 381
    .line 382
    const-string v3, " not subtype of "

    .line 383
    .line 384
    invoke-static {v2, v0, v3, v1}, Lm03;->e(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 385
    .line 386
    .line 387
    return-object v6
.end method
