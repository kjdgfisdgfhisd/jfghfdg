###### Class defpackage.rq3 (rq3)
.class public final Lrq3;
.super Lov3;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field private static final zzc:Lrq3;

.field private static volatile zzd:Lvw3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lvw3;"
        }
    .end annotation
.end field


# instance fields
.field private zze:I

.field private zzf:Ljava/lang/String;

.field private zzg:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lrq3;

    .line 2
    .line 3
    invoke-direct {v0}, Lrq3;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lrq3;->zzc:Lrq3;

    .line 7
    .line 8
    const-class v1, Lrq3;

    .line 9
    .line 10
    invoke-static {v1, v0}, Lov3;->f(Ljava/lang/Class;Lov3;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Lov3;-><init>()V

    .line 2
    .line 3
    .line 4
    const-string v0, ""

    .line 5
    .line 6
    iput-object v0, p0, Lrq3;->zzf:Ljava/lang/String;

    .line 7
    .line 8
    iput-object v0, p0, Lrq3;->zzg:Ljava/lang/String;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final c(I)Ljava/lang/Object;
    .registers 4

    .line 1
    sget-object p0, Luq3;->a:[I

    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    sub-int/2addr p1, v0

    .line 5
    aget p0, p0, p1

    .line 6
    .line 7
    const/4 p1, 0x0

    .line 8
    packed-switch p0, :pswitch_data_54

    .line 9
    .line 10
    .line 11
    invoke-static {}, Lvn0;->n()V

    .line 12
    .line 13
    .line 14
    :pswitch_d
    return-object p1

    .line 15
    :pswitch_e
    invoke-static {v0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    return-object p0

    .line 20
    :pswitch_13
    sget-object p0, Lrq3;->zzd:Lvw3;

    .line 21
    .line 22
    if-nez p0, :cond_2e

    .line 23
    .line 24
    const-class p1, Lrq3;

    .line 25
    .line 26
    monitor-enter p1

    .line 27
    :try_start_1a
    sget-object p0, Lrq3;->zzd:Lvw3;

    .line 28
    .line 29
    if-nez p0, :cond_2a

    .line 30
    .line 31
    new-instance p0, Lap3;

    .line 32
    .line 33
    const/16 v0, 0xc

    .line 34
    .line 35
    invoke-direct {p0, v0}, Lap3;-><init>(I)V

    .line 36
    .line 37
    .line 38
    sput-object p0, Lrq3;->zzd:Lvw3;

    .line 39
    .line 40
    goto :goto_2a

    .line 41
    :catchall_28
    move-exception p0

    .line 42
    goto :goto_2c

    .line 43
    :cond_2a
    :goto_2a
    monitor-exit p1

    .line 44
    return-object p0

    .line 45
    :goto_2c
    monitor-exit p1
    :try_end_2d
    .catchall {:try_start_1a .. :try_end_2d} :catchall_28

    .line 46
    throw p0

    .line 47
    :cond_2e
    return-object p0

    .line 48
    :pswitch_2f
    sget-object p0, Lrq3;->zzc:Lrq3;

    .line 49
    .line 50
    return-object p0

    .line 51
    :pswitch_32
    const-string p0, "zze"

    .line 52
    .line 53
    const-string p1, "zzf"

    .line 54
    .line 55
    const-string v0, "zzg"

    .line 56
    .line 57
    filled-new-array {p0, p1, v0}, [Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object p0

    .line 61
    const-string p1, "\u0004\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u1008\u0000\u0002\u1008\u0001"

    .line 62
    .line 63
    sget-object v0, Lrq3;->zzc:Lrq3;

    .line 64
    .line 65
    new-instance v1, Lcx3;

    .line 66
    .line 67
    invoke-direct {v1, v0, p1, p0}, Lcx3;-><init>(Leu3;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 68
    .line 69
    .line 70
    return-object v1

    .line 71
    :pswitch_46
    new-instance p0, Laq3;

    .line 72
    .line 73
    sget-object p1, Lrq3;->zzc:Lrq3;

    .line 74
    .line 75
    invoke-direct {p0, p1}, Lmv3;-><init>(Lov3;)V

    .line 76
    .line 77
    .line 78
    return-object p0

    .line 79
    :pswitch_4e
    new-instance p0, Lrq3;

    .line 80
    .line 81
    invoke-direct {p0}, Lrq3;-><init>()V

    .line 82
    .line 83
    .line 84
    return-object p0

    .line 85
    :pswitch_data_54
    .packed-switch 0x1
        :pswitch_4e
        :pswitch_46
        :pswitch_32
        :pswitch_2f
        :pswitch_13
        :pswitch_e
        :pswitch_d
    .end packed-switch
.end method
