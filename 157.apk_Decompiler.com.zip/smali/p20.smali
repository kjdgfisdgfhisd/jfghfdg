###### Class defpackage.p20 (p20)
.class public final synthetic Lp20;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 1
    iput p1, p0, Lp20;->a:I

    .line 2
    .line 3
    iput-object p2, p0, Lp20;->b:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .registers 12

    .line 1
    iget v0, p0, Lp20;->a:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v2, 0x0

    .line 5
    const/4 v3, 0x2

    .line 6
    const-string v4, "FirebaseCrashlytics"

    .line 7
    .line 8
    const/4 v5, 0x0

    .line 9
    iget-object p0, p0, Lp20;->b:Ljava/lang/Object;

    .line 10
    .line 11
    packed-switch v0, :pswitch_data_136

    .line 12
    .line 13
    .line 14
    const-string v0, "Requesting settings from "

    .line 15
    .line 16
    check-cast p0, Lm92;

    .line 17
    .line 18
    iget-object p0, p0, Lm92;->b:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast p0, Lbk;

    .line 21
    .line 22
    iget-object v1, p0, Lbk;->e:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v1, Lk80;

    .line 25
    .line 26
    iget-object p0, p0, Lbk;->b:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast p0, Lrm2;

    .line 29
    .line 30
    iget-object v2, v1, Lk80;->b:Ljava/lang/String;

    .line 31
    .line 32
    const-string v6, "Settings query params were: "

    .line 33
    .line 34
    invoke-static {}, Lna;->n()V

    .line 35
    .line 36
    .line 37
    :try_start_24
    invoke-static {p0}, Lk80;->b(Lrm2;)Ljava/util/HashMap;

    .line 38
    .line 39
    .line 40
    move-result-object v7

    .line 41
    new-instance v8, Lna;

    .line 42
    .line 43
    invoke-direct {v8, v2, v7}, Lna;-><init>(Ljava/lang/String;Ljava/util/HashMap;)V

    .line 44
    .line 45
    .line 46
    const-string v9, "User-Agent"

    .line 47
    .line 48
    const-string v10, "Crashlytics Android SDK/19.3.0"

    .line 49
    .line 50
    invoke-virtual {v8, v9, v10}, Lna;->J(Ljava/lang/String;Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    const-string v9, "X-CRASHLYTICS-DEVELOPER-TOKEN"

    .line 54
    .line 55
    const-string v10, "470fa2b4ae81cd56ecbcda9735803434cec591fa"

    .line 56
    .line 57
    invoke-virtual {v8, v9, v10}, Lna;->J(Ljava/lang/String;Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    invoke-static {v8, p0}, Lk80;->a(Lna;Lrm2;)V

    .line 61
    .line 62
    .line 63
    invoke-virtual {v0, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object p0

    .line 67
    const/4 v0, 0x3

    .line 68
    invoke-static {v4, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 69
    .line 70
    .line 71
    move-result v0

    .line 72
    if-eqz v0, :cond_4c

    .line 73
    .line 74
    invoke-static {v4, p0, v5}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 75
    .line 76
    .line 77
    :cond_4c
    new-instance p0, Ljava/lang/StringBuilder;

    .line 78
    .line 79
    invoke-direct {p0, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 80
    .line 81
    .line 82
    invoke-virtual {p0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 83
    .line 84
    .line 85
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 86
    .line 87
    .line 88
    move-result-object p0

    .line 89
    invoke-static {v4, v3}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 90
    .line 91
    .line 92
    move-result v0

    .line 93
    if-eqz v0, :cond_61

    .line 94
    .line 95
    invoke-static {v4, p0, v5}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 96
    .line 97
    .line 98
    :cond_61
    invoke-virtual {v8}, Lna;->v()Lo4;

    .line 99
    .line 100
    .line 101
    move-result-object p0

    .line 102
    invoke-virtual {v1, p0}, Lk80;->d(Lo4;)Lorg/json/JSONObject;

    .line 103
    .line 104
    .line 105
    move-result-object v5
    :try_end_69
    .catch Ljava/io/IOException; {:try_start_24 .. :try_end_69} :catch_6a

    .line 106
    goto :goto_70

    .line 107
    :catch_6a
    move-exception p0

    .line 108
    const-string v0, "Settings request failed."

    .line 109
    .line 110
    invoke-static {v4, v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 111
    .line 112
    .line 113
    :goto_70
    return-object v5

    .line 114
    :pswitch_71
    check-cast p0, Le01;

    .line 115
    .line 116
    iget-object p0, p0, Le01;->a:Landroidx/work/impl/WorkDatabase;

    .line 117
    .line 118
    invoke-virtual {p0}, Landroidx/work/impl/WorkDatabase;->s()Lf32;

    .line 119
    .line 120
    .line 121
    move-result-object v0

    .line 122
    const-string v3, "next_job_scheduler_id"

    .line 123
    .line 124
    invoke-virtual {v0, v3}, Lf32;->a(Ljava/lang/String;)Ljava/lang/Long;

    .line 125
    .line 126
    .line 127
    move-result-object v0

    .line 128
    if-eqz v0, :cond_87

    .line 129
    .line 130
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 131
    .line 132
    .line 133
    move-result-wide v4

    .line 134
    long-to-int v0, v4

    .line 135
    goto :goto_88

    .line 136
    :cond_87
    move v0, v2

    .line 137
    :goto_88
    const v4, 0x7fffffff

    .line 138
    .line 139
    .line 140
    if-ne v0, v4, :cond_8f

    .line 141
    .line 142
    move v5, v2

    .line 143
    goto :goto_91

    .line 144
    :cond_8f
    add-int/lit8 v5, v0, 0x1

    .line 145
    .line 146
    :goto_91
    invoke-virtual {p0}, Landroidx/work/impl/WorkDatabase;->s()Lf32;

    .line 147
    .line 148
    .line 149
    move-result-object v6

    .line 150
    new-instance v7, Le32;

    .line 151
    .line 152
    int-to-long v8, v5

    .line 153
    invoke-static {v8, v9}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 154
    .line 155
    .line 156
    move-result-object v5

    .line 157
    invoke-direct {v7, v3, v5}, Le32;-><init>(Ljava/lang/String;Ljava/lang/Long;)V

    .line 158
    .line 159
    .line 160
    iget-object v5, v6, Lf32;->a:Lch2;

    .line 161
    .line 162
    new-instance v8, Lx90;

    .line 163
    .line 164
    const/4 v9, 0x6

    .line 165
    invoke-direct {v8, v6, v9, v7}, Lx90;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 166
    .line 167
    .line 168
    invoke-static {v5, v2, v1, v8}, Lh50;->k(Lch2;ZZLft0;)Ljava/lang/Object;

    .line 169
    .line 170
    .line 171
    if-ltz v0, :cond_b0

    .line 172
    .line 173
    if-gt v0, v4, :cond_b0

    .line 174
    .line 175
    move v2, v0

    .line 176
    goto :goto_c9

    .line 177
    :cond_b0
    invoke-virtual {p0}, Landroidx/work/impl/WorkDatabase;->s()Lf32;

    .line 178
    .line 179
    .line 180
    move-result-object p0

    .line 181
    new-instance v0, Le32;

    .line 182
    .line 183
    const-wide/16 v4, 0x1

    .line 184
    .line 185
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 186
    .line 187
    .line 188
    move-result-object v4

    .line 189
    invoke-direct {v0, v3, v4}, Le32;-><init>(Ljava/lang/String;Ljava/lang/Long;)V

    .line 190
    .line 191
    .line 192
    iget-object v3, p0, Lf32;->a:Lch2;

    .line 193
    .line 194
    new-instance v4, Lx90;

    .line 195
    .line 196
    invoke-direct {v4, p0, v9, v0}, Lx90;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 197
    .line 198
    .line 199
    invoke-static {v3, v2, v1, v4}, Lh50;->k(Lch2;ZZLft0;)Ljava/lang/Object;

    .line 200
    .line 201
    .line 202
    :goto_c9
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 203
    .line 204
    .line 205
    move-result-object p0

    .line 206
    return-object p0

    .line 207
    :pswitch_ce
    check-cast p0, Ls20;

    .line 208
    .line 209
    iget-object p0, p0, Ls20;->g:Ln20;

    .line 210
    .line 211
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 212
    .line 213
    .line 214
    invoke-static {}, Lna;->m()V

    .line 215
    .line 216
    .line 217
    iget-object v0, p0, Ln20;->c:Ljt3;

    .line 218
    .line 219
    iget-object v6, v0, Ljt3;->c:Ljava/lang/Object;

    .line 220
    .line 221
    check-cast v6, Lcn0;

    .line 222
    .line 223
    iget-object v7, v0, Ljt3;->b:Ljava/lang/Object;

    .line 224
    .line 225
    check-cast v7, Ljava/lang/String;

    .line 226
    .line 227
    new-instance v8, Ljava/io/File;

    .line 228
    .line 229
    iget-object v6, v6, Lcn0;->c:Ljava/lang/Object;

    .line 230
    .line 231
    check-cast v6, Ljava/io/File;

    .line 232
    .line 233
    invoke-direct {v8, v6, v7}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 234
    .line 235
    .line 236
    invoke-virtual {v8}, Ljava/io/File;->exists()Z

    .line 237
    .line 238
    .line 239
    move-result v6

    .line 240
    if-nez v6, :cond_115

    .line 241
    .line 242
    iget-object v0, p0, Ln20;->m:Ly8;

    .line 243
    .line 244
    iget-object v0, v0, Ly8;->b:Ljava/lang/Object;

    .line 245
    .line 246
    check-cast v0, Lx30;

    .line 247
    .line 248
    invoke-virtual {v0}, Lx30;->c()Ljava/util/NavigableSet;

    .line 249
    .line 250
    .line 251
    move-result-object v0

    .line 252
    invoke-interface {v0}, Ljava/util/Set;->isEmpty()Z

    .line 253
    .line 254
    .line 255
    move-result v3

    .line 256
    if-nez v3, :cond_108

    .line 257
    .line 258
    invoke-interface {v0}, Ljava/util/SortedSet;->first()Ljava/lang/Object;

    .line 259
    .line 260
    .line 261
    move-result-object v0

    .line 262
    move-object v5, v0

    .line 263
    check-cast v5, Ljava/lang/String;

    .line 264
    .line 265
    :cond_108
    if-eqz v5, :cond_113

    .line 266
    .line 267
    iget-object p0, p0, Ln20;->j:Lu20;

    .line 268
    .line 269
    invoke-virtual {p0}, Lu20;->c()Z

    .line 270
    .line 271
    .line 272
    move-result p0

    .line 273
    if-eqz p0, :cond_113

    .line 274
    .line 275
    goto :goto_130

    .line 276
    :cond_113
    move v1, v2

    .line 277
    goto :goto_130

    .line 278
    :cond_115
    invoke-static {v4, v3}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 279
    .line 280
    .line 281
    move-result p0

    .line 282
    if-eqz p0, :cond_120

    .line 283
    .line 284
    const-string p0, "Found previous crash marker."

    .line 285
    .line 286
    invoke-static {v4, p0, v5}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 287
    .line 288
    .line 289
    :cond_120
    iget-object p0, v0, Ljt3;->c:Ljava/lang/Object;

    .line 290
    .line 291
    check-cast p0, Lcn0;

    .line 292
    .line 293
    new-instance v0, Ljava/io/File;

    .line 294
    .line 295
    iget-object p0, p0, Lcn0;->c:Ljava/lang/Object;

    .line 296
    .line 297
    check-cast p0, Ljava/io/File;

    .line 298
    .line 299
    invoke-direct {v0, p0, v7}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 300
    .line 301
    .line 302
    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    .line 303
    .line 304
    .line 305
    :goto_130
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 306
    .line 307
    .line 308
    move-result-object p0

    .line 309
    return-object p0

    .line 310
    nop

    .line 311
    :pswitch_data_136
    .packed-switch 0x0
        :pswitch_ce
        :pswitch_71
    .end packed-switch
.end method
