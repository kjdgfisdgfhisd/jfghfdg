###### Class defpackage.om0 (om0)
.class public final Lom0;
.super Lov;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# direct methods
.method public constructor <init>(Ll7;Ln52;)V
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0, p1}, Lov;-><init>(Ll7;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method
