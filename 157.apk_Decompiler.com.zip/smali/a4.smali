###### Class defpackage.a4 (a4)
.class public La4;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final synthetic a:I

.field public b:I

.field public final c:Ljava/lang/Object;

.field public final d:Ljava/lang/Object;

.field public e:Ljava/lang/Object;

.field public f:Ljava/lang/Object;

.field public g:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Landroid/content/res/ColorStateList;Landroid/content/res/ColorStateList;Landroid/content/res/ColorStateList;ILvm2;Landroid/graphics/Rect;)V
    .registers 8

    const/4 v0, 0x2

    iput v0, p0, La4;->a:I

    .line 42
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 43
    iget v0, p6, Landroid/graphics/Rect;->left:I

    invoke-static {v0}, Lh23;->h(I)V

    .line 44
    iget v0, p6, Landroid/graphics/Rect;->top:I

    invoke-static {v0}, Lh23;->h(I)V

    .line 45
    iget v0, p6, Landroid/graphics/Rect;->right:I

    invoke-static {v0}, Lh23;->h(I)V

    .line 46
    iget v0, p6, Landroid/graphics/Rect;->bottom:I

    invoke-static {v0}, Lh23;->h(I)V

    .line 47
    iput-object p6, p0, La4;->c:Ljava/lang/Object;

    .line 48
    iput-object p2, p0, La4;->d:Ljava/lang/Object;

    .line 49
    iput-object p1, p0, La4;->e:Ljava/lang/Object;

    .line 50
    iput-object p3, p0, La4;->f:Ljava/lang/Object;

    .line 51
    iput p4, p0, La4;->b:I

    .line 52
    iput-object p5, p0, La4;->g:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/view/View;)V
    .registers 3

    const/4 v0, 0x1

    iput v0, p0, La4;->a:I

    .line 53
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    .line 54
    iput v0, p0, La4;->b:I

    .line 55
    iput-object p1, p0, La4;->c:Ljava/lang/Object;

    .line 56
    invoke-static {}, Lz8;->a()Lz8;

    move-result-object p1

    iput-object p1, p0, La4;->d:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroidx/recyclerview/widget/b;)V
    .registers 5

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, La4;->a:I

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    new-instance v1, Lp22;

    .line 8
    .line 9
    const/16 v2, 0x1e

    .line 10
    .line 11
    invoke-direct {v1, v2}, Lp22;-><init>(I)V

    .line 12
    .line 13
    .line 14
    iput-object v1, p0, La4;->c:Ljava/lang/Object;

    .line 15
    .line 16
    new-instance v1, Ljava/util/ArrayList;

    .line 17
    .line 18
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 19
    .line 20
    .line 21
    iput-object v1, p0, La4;->d:Ljava/lang/Object;

    .line 22
    .line 23
    new-instance v1, Ljava/util/ArrayList;

    .line 24
    .line 25
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 26
    .line 27
    .line 28
    iput-object v1, p0, La4;->e:Ljava/lang/Object;

    .line 29
    .line 30
    iput v0, p0, La4;->b:I

    .line 31
    .line 32
    iput-object p1, p0, La4;->f:Ljava/lang/Object;

    .line 33
    .line 34
    new-instance p1, Lrt1;

    .line 35
    .line 36
    invoke-direct {p1, p0, v0}, Lrt1;-><init>(Ljava/lang/Object;Z)V

    .line 37
    .line 38
    .line 39
    iput-object p1, p0, La4;->g:Ljava/lang/Object;

    .line 40
    .line 41
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Lq61;)V
    .registers 4

    const/4 v0, 0x3

    iput v0, p0, La4;->a:I

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 57
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, La4;->c:Ljava/lang/Object;

    .line 58
    new-instance v0, Lvv;

    invoke-direct {v0, p2}, Lvv;-><init>(Lq61;)V

    iput-object v0, p0, La4;->d:Ljava/lang/Object;

    .line 59
    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    iput-object p2, p0, La4;->f:Ljava/lang/Object;

    .line 60
    iput-object p1, p0, La4;->g:Ljava/lang/Object;

    return-void
.end method

.method public static o(Landroid/content/Context;I)La4;
    .registers 15

    .line 1
    const/4 v0, 0x1

    .line 2
    const/4 v1, 0x0

    .line 3
    if-eqz p1, :cond_6

    .line 4
    .line 5
    move v2, v0

    .line 6
    goto :goto_7

    .line 7
    :cond_6
    move v2, v1

    .line 8
    :goto_7
    const-string v3, "Cannot create a CalendarItemStyle with a styleResId of 0"

    .line 9
    .line 10
    invoke-static {v3, v2}, Lh23;->g(Ljava/lang/String;Z)V

    .line 11
    .line 12
    .line 13
    sget-object v2, Lz92;->t:[I

    .line 14
    .line 15
    invoke-virtual {p0, p1, v2}, Landroid/content/Context;->obtainStyledAttributes(I[I)Landroid/content/res/TypedArray;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    invoke-virtual {p1, v1, v1}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    .line 20
    .line 21
    .line 22
    move-result v2

    .line 23
    const/4 v3, 0x2

    .line 24
    invoke-virtual {p1, v3, v1}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    .line 25
    .line 26
    .line 27
    move-result v3

    .line 28
    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    .line 29
    .line 30
    .line 31
    move-result v4

    .line 32
    const/4 v5, 0x3

    .line 33
    invoke-virtual {p1, v5, v1}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    .line 34
    .line 35
    .line 36
    move-result v5

    .line 37
    new-instance v12, Landroid/graphics/Rect;

    .line 38
    .line 39
    invoke-direct {v12, v2, v3, v4, v5}, Landroid/graphics/Rect;-><init>(IIII)V

    .line 40
    .line 41
    .line 42
    const/4 v2, 0x4

    .line 43
    invoke-static {p0, p1, v2}, Lb21;->i(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    .line 44
    .line 45
    .line 46
    move-result-object v7

    .line 47
    const/16 v2, 0x9

    .line 48
    .line 49
    invoke-static {p0, p1, v2}, Lb21;->i(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    .line 50
    .line 51
    .line 52
    move-result-object v8

    .line 53
    const/4 v2, 0x7

    .line 54
    invoke-static {p0, p1, v2}, Lb21;->i(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    .line 55
    .line 56
    .line 57
    move-result-object v9

    .line 58
    const/16 v2, 0x8

    .line 59
    .line 60
    invoke-virtual {p1, v2, v1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 61
    .line 62
    .line 63
    move-result v10

    .line 64
    const/4 v2, 0x5

    .line 65
    invoke-virtual {p1, v2, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 66
    .line 67
    .line 68
    move-result v2

    .line 69
    const/4 v3, 0x6

    .line 70
    invoke-virtual {p1, v3, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 71
    .line 72
    .line 73
    move-result v1

    .line 74
    new-instance v3, Lj;

    .line 75
    .line 76
    const/4 v4, 0x0

    .line 77
    invoke-direct {v3, v4}, Lj;-><init>(F)V

    .line 78
    .line 79
    .line 80
    new-instance v4, Landroid/view/ContextThemeWrapper;

    .line 81
    .line 82
    invoke-direct {v4, p0, v2}, Landroid/view/ContextThemeWrapper;-><init>(Landroid/content/Context;I)V

    .line 83
    .line 84
    .line 85
    if-eqz v1, :cond_5d

    .line 86
    .line 87
    invoke-virtual {v4}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 88
    .line 89
    .line 90
    move-result-object p0

    .line 91
    invoke-virtual {p0, v1, v0}, Landroid/content/res/Resources$Theme;->applyStyle(IZ)V

    .line 92
    .line 93
    .line 94
    :cond_5d
    sget-object p0, Lz92;->H:[I

    .line 95
    .line 96
    invoke-virtual {v4, p0}, Landroid/content/Context;->obtainStyledAttributes([I)Landroid/content/res/TypedArray;

    .line 97
    .line 98
    .line 99
    move-result-object p0

    .line 100
    invoke-static {p0, v3}, Lvm2;->h(Landroid/content/res/TypedArray;Lj;)Lum2;

    .line 101
    .line 102
    .line 103
    move-result-object p0

    .line 104
    invoke-virtual {p0}, Lum2;->a()Lvm2;

    .line 105
    .line 106
    .line 107
    move-result-object v11

    .line 108
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    .line 109
    .line 110
    .line 111
    new-instance v6, La4;

    .line 112
    .line 113
    invoke-direct/range {v6 .. v12}, La4;-><init>(Landroid/content/res/ColorStateList;Landroid/content/res/ColorStateList;Landroid/content/res/ColorStateList;ILvm2;Landroid/graphics/Rect;)V

    .line 114
    .line 115
    .line 116
    return-object v6
.end method

.method public static synthetic s(La4;Ljava/lang/String;II)V
    .registers 5

    .line 1
    and-int/lit8 v0, p3, 0x2

    .line 2
    .line 3
    if-eqz v0, :cond_6

    .line 4
    .line 5
    iget p2, p0, La4;->b:I

    .line 6
    .line 7
    :cond_6
    and-int/lit8 p3, p3, 0x4

    .line 8
    .line 9
    const/4 v0, 0x0

    .line 10
    if-eqz p3, :cond_d

    .line 11
    .line 12
    move-object p3, v0

    .line 13
    goto :goto_f

    .line 14
    :cond_d
    const-string p3, "It is possible to deserialize them using \'JsonBuilder.allowSpecialFloatingPointValues = true\'"

    .line 15
    .line 16
    :goto_f
    invoke-virtual {p0, p1, p3, p2}, La4;->r(Ljava/lang/String;Ljava/lang/String;I)V

    .line 17
    .line 18
    .line 19
    throw v0
.end method


# virtual methods
.method public A()V
    .registers 2

    .line 1
    const/4 v0, -0x1

    .line 2
    iput v0, p0, La4;->b:I

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-virtual {p0, v0}, La4;->H(Landroid/content/res/ColorStateList;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0}, La4;->b()V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public B(I)V
    .registers 5

    .line 1
    iput p1, p0, La4;->b:I

    .line 2
    .line 3
    iget-object v0, p0, La4;->d:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lz8;

    .line 6
    .line 7
    if-eqz v0, :cond_1c

    .line 8
    .line 9
    iget-object v1, p0, La4;->c:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v1, Landroid/view/View;

    .line 12
    .line 13
    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    monitor-enter v0

    .line 18
    :try_start_11
    iget-object v2, v0, Lz8;->a:Lzf2;

    .line 19
    .line 20
    invoke-virtual {v2, v1, p1}, Lzf2;->f(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    .line 21
    .line 22
    .line 23
    move-result-object p1
    :try_end_17
    .catchall {:try_start_11 .. :try_end_17} :catchall_19

    .line 24
    monitor-exit v0

    .line 25
    goto :goto_1d

    .line 26
    :catchall_19
    move-exception p0

    .line 27
    :try_start_1a
    monitor-exit v0
    :try_end_1b
    .catchall {:try_start_1a .. :try_end_1b} :catchall_19

    .line 28
    throw p0

    .line 29
    :cond_1c
    const/4 p1, 0x0

    .line 30
    :goto_1d
    invoke-virtual {p0, p1}, La4;->H(Landroid/content/res/ColorStateList;)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {p0}, La4;->b()V

    .line 34
    .line 35
    .line 36
    return-void
.end method

.method public C()B
    .registers 6

    .line 1
    iget-object v0, p0, La4;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/lang/String;

    .line 4
    .line 5
    iget v1, p0, La4;->b:I

    .line 6
    .line 7
    :goto_6
    invoke-virtual {p0, v1}, La4;->F(I)I

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    const/4 v2, -0x1

    .line 12
    const/16 v3, 0xa

    .line 13
    .line 14
    if-eq v1, v2, :cond_2b

    .line 15
    .line 16
    invoke-virtual {v0, v1}, Ljava/lang/String;->charAt(I)C

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    const/16 v4, 0x9

    .line 21
    .line 22
    if-eq v2, v4, :cond_28

    .line 23
    .line 24
    if-eq v2, v3, :cond_28

    .line 25
    .line 26
    const/16 v3, 0xd

    .line 27
    .line 28
    if-eq v2, v3, :cond_28

    .line 29
    .line 30
    const/16 v3, 0x20

    .line 31
    .line 32
    if-eq v2, v3, :cond_28

    .line 33
    .line 34
    iput v1, p0, La4;->b:I

    .line 35
    .line 36
    invoke-static {v2}, Lh23;->f(C)B

    .line 37
    .line 38
    .line 39
    move-result p0

    .line 40
    return p0

    .line 41
    :cond_28
    add-int/lit8 v1, v1, 0x1

    .line 42
    .line 43
    goto :goto_6

    .line 44
    :cond_2b
    iput v1, p0, La4;->b:I

    .line 45
    .line 46
    return v3
.end method

.method public D(Lz3;)V
    .registers 5

    .line 1
    iget-object v0, p0, La4;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/recyclerview/widget/b;

    .line 4
    .line 5
    iget-object p0, p0, La4;->e:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast p0, Ljava/util/ArrayList;

    .line 8
    .line 9
    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    iget p0, p1, Lz3;->a:I

    .line 13
    .line 14
    const/4 v1, 0x1

    .line 15
    if-eq p0, v1, :cond_3f

    .line 16
    .line 17
    const/4 v2, 0x2

    .line 18
    if-eq p0, v2, :cond_32

    .line 19
    .line 20
    const/4 v1, 0x4

    .line 21
    if-eq p0, v1, :cond_28

    .line 22
    .line 23
    const/16 v1, 0x8

    .line 24
    .line 25
    if-ne p0, v1, :cond_22

    .line 26
    .line 27
    iget p0, p1, Lz3;->b:I

    .line 28
    .line 29
    iget p1, p1, Lz3;->d:I

    .line 30
    .line 31
    invoke-virtual {v0, p0, p1}, Landroidx/recyclerview/widget/b;->e(II)V

    .line 32
    .line 33
    .line 34
    return-void

    .line 35
    :cond_22
    const-string p0, "Unknown update op type for "

    .line 36
    .line 37
    invoke-static {p1, p0}, Lt12;->i(Ljava/lang/Object;Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    return-void

    .line 41
    :cond_28
    iget p0, p1, Lz3;->b:I

    .line 42
    .line 43
    iget v1, p1, Lz3;->d:I

    .line 44
    .line 45
    iget-object p1, p1, Lz3;->c:Ljava/lang/Object;

    .line 46
    .line 47
    invoke-virtual {v0, p0, v1, p1}, Landroidx/recyclerview/widget/b;->c(IILjava/lang/Object;)V

    .line 48
    .line 49
    .line 50
    return-void

    .line 51
    :cond_32
    iget p0, p1, Lz3;->b:I

    .line 52
    .line 53
    iget p1, p1, Lz3;->d:I

    .line 54
    .line 55
    iget-object v0, v0, Landroidx/recyclerview/widget/b;->a:Landroidx/recyclerview/widget/RecyclerView;

    .line 56
    .line 57
    const/4 v2, 0x0

    .line 58
    invoke-virtual {v0, p0, p1, v2}, Landroidx/recyclerview/widget/RecyclerView;->Q(IIZ)V

    .line 59
    .line 60
    .line 61
    iput-boolean v1, v0, Landroidx/recyclerview/widget/RecyclerView;->C0:Z

    .line 62
    .line 63
    return-void

    .line 64
    :cond_3f
    iget p0, p1, Lz3;->b:I

    .line 65
    .line 66
    iget p1, p1, Lz3;->d:I

    .line 67
    .line 68
    invoke-virtual {v0, p0, p1}, Landroidx/recyclerview/widget/b;->d(II)V

    .line 69
    .line 70
    .line 71
    return-void
.end method

.method public E()V
    .registers 21

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, La4;->c:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Lp22;

    .line 6
    .line 7
    iget-object v2, v0, La4;->f:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v2, Landroidx/recyclerview/widget/b;

    .line 10
    .line 11
    iget-object v3, v0, La4;->g:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v3, Lrt1;

    .line 14
    .line 15
    iget-object v4, v0, La4;->d:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast v4, Ljava/util/ArrayList;

    .line 18
    .line 19
    :cond_12
    :goto_12
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 20
    .line 21
    .line 22
    move-result v5

    .line 23
    const/4 v6, 0x1

    .line 24
    sub-int/2addr v5, v6

    .line 25
    const/4 v8, 0x0

    .line 26
    :goto_19
    const/16 v9, 0x8

    .line 27
    .line 28
    const/4 v10, -0x1

    .line 29
    if-ltz v5, :cond_2f

    .line 30
    .line 31
    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v11

    .line 35
    check-cast v11, Lz3;

    .line 36
    .line 37
    iget v11, v11, Lz3;->a:I

    .line 38
    .line 39
    if-ne v11, v9, :cond_2b

    .line 40
    .line 41
    if-eqz v8, :cond_2c

    .line 42
    .line 43
    goto :goto_30

    .line 44
    :cond_2b
    move v8, v6

    .line 45
    :cond_2c
    add-int/lit8 v5, v5, -0x1

    .line 46
    .line 47
    goto :goto_19

    .line 48
    :cond_2f
    move v5, v10

    .line 49
    :goto_30
    const/4 v11, 0x2

    .line 50
    const/4 v12, 0x4

    .line 51
    if-eq v5, v10, :cond_1d3

    .line 52
    .line 53
    add-int/lit8 v9, v5, 0x1

    .line 54
    .line 55
    iget-object v13, v3, Lrt1;->a:Ljava/lang/Object;

    .line 56
    .line 57
    check-cast v13, La4;

    .line 58
    .line 59
    iget-object v14, v13, La4;->c:Ljava/lang/Object;

    .line 60
    .line 61
    check-cast v14, Lp22;

    .line 62
    .line 63
    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v15

    .line 67
    check-cast v15, Lz3;

    .line 68
    .line 69
    invoke-virtual {v4, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object v16

    .line 73
    move-object/from16 v7, v16

    .line 74
    .line 75
    check-cast v7, Lz3;

    .line 76
    .line 77
    iget v10, v7, Lz3;->a:I

    .line 78
    .line 79
    if-eq v10, v6, :cond_1a6

    .line 80
    .line 81
    if-eq v10, v11, :cond_b3

    .line 82
    .line 83
    if-eq v10, v12, :cond_55

    .line 84
    .line 85
    goto :goto_12

    .line 86
    :cond_55
    iget v10, v15, Lz3;->d:I

    .line 87
    .line 88
    iget v11, v7, Lz3;->b:I

    .line 89
    .line 90
    if-ge v10, v11, :cond_60

    .line 91
    .line 92
    add-int/lit8 v11, v11, -0x1

    .line 93
    .line 94
    iput v11, v7, Lz3;->b:I

    .line 95
    .line 96
    goto :goto_72

    .line 97
    :cond_60
    iget v8, v7, Lz3;->d:I

    .line 98
    .line 99
    add-int/2addr v11, v8

    .line 100
    if-ge v10, v11, :cond_72

    .line 101
    .line 102
    add-int/lit8 v8, v8, -0x1

    .line 103
    .line 104
    iput v8, v7, Lz3;->d:I

    .line 105
    .line 106
    iget v8, v15, Lz3;->b:I

    .line 107
    .line 108
    iget-object v10, v7, Lz3;->c:Ljava/lang/Object;

    .line 109
    .line 110
    invoke-virtual {v13, v10, v12, v8, v6}, La4;->z(Ljava/lang/Object;III)Lz3;

    .line 111
    .line 112
    .line 113
    move-result-object v6

    .line 114
    goto :goto_73

    .line 115
    :cond_72
    :goto_72
    const/4 v6, 0x0

    .line 116
    :goto_73
    iget v8, v15, Lz3;->b:I

    .line 117
    .line 118
    iget v10, v7, Lz3;->b:I

    .line 119
    .line 120
    if-gt v8, v10, :cond_7e

    .line 121
    .line 122
    add-int/lit8 v10, v10, 0x1

    .line 123
    .line 124
    iput v10, v7, Lz3;->b:I

    .line 125
    .line 126
    goto :goto_92

    .line 127
    :cond_7e
    iget v11, v7, Lz3;->d:I

    .line 128
    .line 129
    add-int/2addr v10, v11

    .line 130
    if-ge v8, v10, :cond_92

    .line 131
    .line 132
    sub-int/2addr v10, v8

    .line 133
    add-int/lit8 v8, v8, 0x1

    .line 134
    .line 135
    iget-object v11, v7, Lz3;->c:Ljava/lang/Object;

    .line 136
    .line 137
    invoke-virtual {v13, v11, v12, v8, v10}, La4;->z(Ljava/lang/Object;III)Lz3;

    .line 138
    .line 139
    .line 140
    move-result-object v8

    .line 141
    iget v11, v7, Lz3;->d:I

    .line 142
    .line 143
    sub-int/2addr v11, v10

    .line 144
    iput v11, v7, Lz3;->d:I

    .line 145
    .line 146
    goto :goto_93

    .line 147
    :cond_92
    :goto_92
    const/4 v8, 0x0

    .line 148
    :goto_93
    invoke-virtual {v4, v9, v15}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 149
    .line 150
    .line 151
    iget v9, v7, Lz3;->d:I

    .line 152
    .line 153
    if-lez v9, :cond_9e

    .line 154
    .line 155
    invoke-virtual {v4, v5, v7}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 156
    .line 157
    .line 158
    goto :goto_a7

    .line 159
    :cond_9e
    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 160
    .line 161
    .line 162
    const/4 v9, 0x0

    .line 163
    iput-object v9, v7, Lz3;->c:Ljava/lang/Object;

    .line 164
    .line 165
    invoke-virtual {v14, v7}, Lp22;->a(Ljava/lang/Object;)Z

    .line 166
    .line 167
    .line 168
    :goto_a7
    if-eqz v6, :cond_ac

    .line 169
    .line 170
    invoke-virtual {v4, v5, v6}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    .line 171
    .line 172
    .line 173
    :cond_ac
    if-eqz v8, :cond_12

    .line 174
    .line 175
    invoke-virtual {v4, v5, v8}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    .line 176
    .line 177
    .line 178
    goto/16 :goto_12

    .line 179
    .line 180
    :cond_b3
    iget v8, v15, Lz3;->b:I

    .line 181
    .line 182
    iget v10, v15, Lz3;->d:I

    .line 183
    .line 184
    iget v12, v7, Lz3;->b:I

    .line 185
    .line 186
    if-ge v8, v10, :cond_cb

    .line 187
    .line 188
    if-ne v12, v8, :cond_c7

    .line 189
    .line 190
    iget v6, v7, Lz3;->d:I

    .line 191
    .line 192
    sub-int v8, v10, v8

    .line 193
    .line 194
    if-ne v6, v8, :cond_c7

    .line 195
    .line 196
    const/4 v6, 0x0

    .line 197
    :goto_c4
    const/16 v17, 0x1

    .line 198
    .line 199
    goto :goto_d8

    .line 200
    :cond_c7
    const/4 v6, 0x0

    .line 201
    :goto_c8
    const/16 v17, 0x0

    .line 202
    .line 203
    goto :goto_d8

    .line 204
    :cond_cb
    add-int/lit8 v6, v10, 0x1

    .line 205
    .line 206
    if-ne v12, v6, :cond_d6

    .line 207
    .line 208
    iget v6, v7, Lz3;->d:I

    .line 209
    .line 210
    sub-int/2addr v8, v10

    .line 211
    if-ne v6, v8, :cond_d6

    .line 212
    .line 213
    const/4 v6, 0x1

    .line 214
    goto :goto_c4

    .line 215
    :cond_d6
    const/4 v6, 0x1

    .line 216
    goto :goto_c8

    .line 217
    :goto_d8
    if-ge v10, v12, :cond_df

    .line 218
    .line 219
    add-int/lit8 v12, v12, -0x1

    .line 220
    .line 221
    iput v12, v7, Lz3;->b:I

    .line 222
    .line 223
    goto :goto_fe

    .line 224
    :cond_df
    iget v8, v7, Lz3;->d:I

    .line 225
    .line 226
    add-int v11, v12, v8

    .line 227
    .line 228
    if-ge v10, v11, :cond_fe

    .line 229
    .line 230
    add-int/lit8 v8, v8, -0x1

    .line 231
    .line 232
    iput v8, v7, Lz3;->d:I

    .line 233
    .line 234
    const/4 v5, 0x2

    .line 235
    iput v5, v15, Lz3;->a:I

    .line 236
    .line 237
    const/4 v5, 0x1

    .line 238
    iput v5, v15, Lz3;->d:I

    .line 239
    .line 240
    iget v5, v7, Lz3;->d:I

    .line 241
    .line 242
    if-nez v5, :cond_12

    .line 243
    .line 244
    invoke-virtual {v4, v9}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 245
    .line 246
    .line 247
    const/4 v9, 0x0

    .line 248
    iput-object v9, v7, Lz3;->c:Ljava/lang/Object;

    .line 249
    .line 250
    invoke-virtual {v14, v7}, Lp22;->a(Ljava/lang/Object;)Z

    .line 251
    .line 252
    .line 253
    goto/16 :goto_12

    .line 254
    .line 255
    :cond_fe
    :goto_fe
    iget v8, v15, Lz3;->b:I

    .line 256
    .line 257
    if-gt v8, v12, :cond_108

    .line 258
    .line 259
    add-int/lit8 v12, v12, 0x1

    .line 260
    .line 261
    iput v12, v7, Lz3;->b:I

    .line 262
    .line 263
    :cond_106
    const/4 v10, 0x0

    .line 264
    goto :goto_120

    .line 265
    :cond_108
    iget v10, v7, Lz3;->d:I

    .line 266
    .line 267
    add-int/2addr v12, v10

    .line 268
    if-ge v8, v12, :cond_106

    .line 269
    .line 270
    sub-int/2addr v12, v8

    .line 271
    add-int/lit8 v8, v8, 0x1

    .line 272
    .line 273
    const/4 v10, 0x0

    .line 274
    const/4 v11, 0x2

    .line 275
    invoke-virtual {v13, v10, v11, v8, v12}, La4;->z(Ljava/lang/Object;III)Lz3;

    .line 276
    .line 277
    .line 278
    move-result-object v18

    .line 279
    iget v8, v15, Lz3;->b:I

    .line 280
    .line 281
    iget v11, v7, Lz3;->b:I

    .line 282
    .line 283
    sub-int/2addr v8, v11

    .line 284
    iput v8, v7, Lz3;->d:I

    .line 285
    .line 286
    move-object/from16 v8, v18

    .line 287
    .line 288
    goto :goto_121

    .line 289
    :goto_120
    move-object v8, v10

    .line 290
    :goto_121
    if-eqz v17, :cond_130

    .line 291
    .line 292
    invoke-virtual {v4, v5, v7}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 293
    .line 294
    .line 295
    invoke-virtual {v4, v9}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 296
    .line 297
    .line 298
    iput-object v10, v15, Lz3;->c:Ljava/lang/Object;

    .line 299
    .line 300
    invoke-virtual {v14, v15}, Lp22;->a(Ljava/lang/Object;)Z

    .line 301
    .line 302
    .line 303
    goto/16 :goto_12

    .line 304
    .line 305
    :cond_130
    if-eqz v6, :cond_161

    .line 306
    .line 307
    if-eqz v8, :cond_14a

    .line 308
    .line 309
    iget v6, v15, Lz3;->b:I

    .line 310
    .line 311
    iget v10, v8, Lz3;->b:I

    .line 312
    .line 313
    if-le v6, v10, :cond_13f

    .line 314
    .line 315
    iget v10, v8, Lz3;->d:I

    .line 316
    .line 317
    sub-int/2addr v6, v10

    .line 318
    iput v6, v15, Lz3;->b:I

    .line 319
    .line 320
    :cond_13f
    iget v6, v15, Lz3;->d:I

    .line 321
    .line 322
    iget v10, v8, Lz3;->b:I

    .line 323
    .line 324
    if-le v6, v10, :cond_14a

    .line 325
    .line 326
    iget v10, v8, Lz3;->d:I

    .line 327
    .line 328
    sub-int/2addr v6, v10

    .line 329
    iput v6, v15, Lz3;->d:I

    .line 330
    .line 331
    :cond_14a
    iget v6, v15, Lz3;->b:I

    .line 332
    .line 333
    iget v10, v7, Lz3;->b:I

    .line 334
    .line 335
    if-le v6, v10, :cond_155

    .line 336
    .line 337
    iget v10, v7, Lz3;->d:I

    .line 338
    .line 339
    sub-int/2addr v6, v10

    .line 340
    iput v6, v15, Lz3;->b:I

    .line 341
    .line 342
    :cond_155
    iget v6, v15, Lz3;->d:I

    .line 343
    .line 344
    iget v10, v7, Lz3;->b:I

    .line 345
    .line 346
    if-le v6, v10, :cond_18f

    .line 347
    .line 348
    iget v10, v7, Lz3;->d:I

    .line 349
    .line 350
    sub-int/2addr v6, v10

    .line 351
    iput v6, v15, Lz3;->d:I

    .line 352
    .line 353
    goto :goto_18f

    .line 354
    :cond_161
    if-eqz v8, :cond_179

    .line 355
    .line 356
    iget v6, v15, Lz3;->b:I

    .line 357
    .line 358
    iget v10, v8, Lz3;->b:I

    .line 359
    .line 360
    if-lt v6, v10, :cond_16e

    .line 361
    .line 362
    iget v10, v8, Lz3;->d:I

    .line 363
    .line 364
    sub-int/2addr v6, v10

    .line 365
    iput v6, v15, Lz3;->b:I

    .line 366
    .line 367
    :cond_16e
    iget v6, v15, Lz3;->d:I

    .line 368
    .line 369
    iget v10, v8, Lz3;->b:I

    .line 370
    .line 371
    if-lt v6, v10, :cond_179

    .line 372
    .line 373
    iget v10, v8, Lz3;->d:I

    .line 374
    .line 375
    sub-int/2addr v6, v10

    .line 376
    iput v6, v15, Lz3;->d:I

    .line 377
    .line 378
    :cond_179
    iget v6, v15, Lz3;->b:I

    .line 379
    .line 380
    iget v10, v7, Lz3;->b:I

    .line 381
    .line 382
    if-lt v6, v10, :cond_184

    .line 383
    .line 384
    iget v10, v7, Lz3;->d:I

    .line 385
    .line 386
    sub-int/2addr v6, v10

    .line 387
    iput v6, v15, Lz3;->b:I

    .line 388
    .line 389
    :cond_184
    iget v6, v15, Lz3;->d:I

    .line 390
    .line 391
    iget v10, v7, Lz3;->b:I

    .line 392
    .line 393
    if-lt v6, v10, :cond_18f

    .line 394
    .line 395
    iget v10, v7, Lz3;->d:I

    .line 396
    .line 397
    sub-int/2addr v6, v10

    .line 398
    iput v6, v15, Lz3;->d:I

    .line 399
    .line 400
    :cond_18f
    :goto_18f
    invoke-virtual {v4, v5, v7}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 401
    .line 402
    .line 403
    iget v6, v15, Lz3;->b:I

    .line 404
    .line 405
    iget v7, v15, Lz3;->d:I

    .line 406
    .line 407
    if-eq v6, v7, :cond_19c

    .line 408
    .line 409
    invoke-virtual {v4, v9, v15}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 410
    .line 411
    .line 412
    goto :goto_19f

    .line 413
    :cond_19c
    invoke-virtual {v4, v9}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 414
    .line 415
    .line 416
    :goto_19f
    if-eqz v8, :cond_12

    .line 417
    .line 418
    invoke-virtual {v4, v5, v8}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    .line 419
    .line 420
    .line 421
    goto/16 :goto_12

    .line 422
    .line 423
    :cond_1a6
    iget v6, v15, Lz3;->d:I

    .line 424
    .line 425
    iget v8, v7, Lz3;->b:I

    .line 426
    .line 427
    if-ge v6, v8, :cond_1af

    .line 428
    .line 429
    const/16 v16, -0x1

    .line 430
    .line 431
    goto :goto_1b1

    .line 432
    :cond_1af
    const/16 v16, 0x0

    .line 433
    .line 434
    :goto_1b1
    iget v10, v15, Lz3;->b:I

    .line 435
    .line 436
    if-ge v10, v8, :cond_1b7

    .line 437
    .line 438
    add-int/lit8 v16, v16, 0x1

    .line 439
    .line 440
    :cond_1b7
    if-gt v8, v10, :cond_1be

    .line 441
    .line 442
    iget v8, v7, Lz3;->d:I

    .line 443
    .line 444
    add-int/2addr v10, v8

    .line 445
    iput v10, v15, Lz3;->b:I

    .line 446
    .line 447
    :cond_1be
    iget v8, v7, Lz3;->b:I

    .line 448
    .line 449
    if-gt v8, v6, :cond_1c7

    .line 450
    .line 451
    iget v10, v7, Lz3;->d:I

    .line 452
    .line 453
    add-int/2addr v6, v10

    .line 454
    iput v6, v15, Lz3;->d:I

    .line 455
    .line 456
    :cond_1c7
    add-int v8, v8, v16

    .line 457
    .line 458
    iput v8, v7, Lz3;->b:I

    .line 459
    .line 460
    invoke-virtual {v4, v5, v7}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 461
    .line 462
    .line 463
    invoke-virtual {v4, v9, v15}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 464
    .line 465
    .line 466
    goto/16 :goto_12

    .line 467
    .line 468
    :cond_1d3
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 469
    .line 470
    .line 471
    move-result v3

    .line 472
    const/4 v5, 0x0

    .line 473
    :goto_1d8
    if-ge v5, v3, :cond_2be

    .line 474
    .line 475
    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 476
    .line 477
    .line 478
    move-result-object v6

    .line 479
    check-cast v6, Lz3;

    .line 480
    .line 481
    iget v7, v6, Lz3;->a:I

    .line 482
    .line 483
    const/4 v8, 0x1

    .line 484
    if-eq v7, v8, :cond_2b3

    .line 485
    .line 486
    const/4 v11, 0x2

    .line 487
    if-eq v7, v11, :cond_24d

    .line 488
    .line 489
    if-eq v7, v12, :cond_1f6

    .line 490
    .line 491
    if-eq v7, v9, :cond_1f2

    .line 492
    .line 493
    :goto_1ec
    const/4 v8, 0x0

    .line 494
    const/4 v15, 0x2

    .line 495
    const/16 v19, 0x1

    .line 496
    .line 497
    goto/16 :goto_2ba

    .line 498
    .line 499
    :cond_1f2
    invoke-virtual {v0, v6}, La4;->D(Lz3;)V

    .line 500
    .line 501
    .line 502
    goto :goto_1ec

    .line 503
    :cond_1f6
    iget v7, v6, Lz3;->b:I

    .line 504
    .line 505
    iget v8, v6, Lz3;->d:I

    .line 506
    .line 507
    add-int/2addr v8, v7

    .line 508
    move v10, v7

    .line 509
    const/4 v11, 0x0

    .line 510
    const/4 v13, -0x1

    .line 511
    :goto_1fe
    if-ge v7, v8, :cond_233

    .line 512
    .line 513
    invoke-virtual {v2, v7}, Landroidx/recyclerview/widget/b;->b(I)Landroidx/recyclerview/widget/g;

    .line 514
    .line 515
    .line 516
    move-result-object v14

    .line 517
    if-nez v14, :cond_21f

    .line 518
    .line 519
    invoke-virtual {v0, v7}, La4;->d(I)Z

    .line 520
    .line 521
    .line 522
    move-result v14

    .line 523
    if-eqz v14, :cond_20d

    .line 524
    .line 525
    goto :goto_21f

    .line 526
    :cond_20d
    const/4 v14, 0x1

    .line 527
    if-ne v13, v14, :cond_21b

    .line 528
    .line 529
    iget-object v13, v6, Lz3;->c:Ljava/lang/Object;

    .line 530
    .line 531
    invoke-virtual {v0, v13, v12, v10, v11}, La4;->z(Ljava/lang/Object;III)Lz3;

    .line 532
    .line 533
    .line 534
    move-result-object v10

    .line 535
    invoke-virtual {v0, v10}, La4;->D(Lz3;)V

    .line 536
    .line 537
    .line 538
    move v10, v7

    .line 539
    const/4 v11, 0x0

    .line 540
    :cond_21b
    const/4 v13, 0x0

    .line 541
    :goto_21c
    const/16 v19, 0x1

    .line 542
    .line 543
    goto :goto_22e

    .line 544
    :cond_21f
    :goto_21f
    if-nez v13, :cond_22c

    .line 545
    .line 546
    iget-object v13, v6, Lz3;->c:Ljava/lang/Object;

    .line 547
    .line 548
    invoke-virtual {v0, v13, v12, v10, v11}, La4;->z(Ljava/lang/Object;III)Lz3;

    .line 549
    .line 550
    .line 551
    move-result-object v10

    .line 552
    invoke-virtual {v0, v10}, La4;->p(Lz3;)V

    .line 553
    .line 554
    .line 555
    move v10, v7

    .line 556
    const/4 v11, 0x0

    .line 557
    :cond_22c
    const/4 v13, 0x1

    .line 558
    goto :goto_21c

    .line 559
    :goto_22e
    add-int/lit8 v11, v11, 0x1

    .line 560
    .line 561
    add-int/lit8 v7, v7, 0x1

    .line 562
    .line 563
    goto :goto_1fe

    .line 564
    :cond_233
    iget v7, v6, Lz3;->d:I

    .line 565
    .line 566
    if-eq v11, v7, :cond_243

    .line 567
    .line 568
    iget-object v7, v6, Lz3;->c:Ljava/lang/Object;

    .line 569
    .line 570
    const/4 v8, 0x0

    .line 571
    iput-object v8, v6, Lz3;->c:Ljava/lang/Object;

    .line 572
    .line 573
    invoke-virtual {v1, v6}, Lp22;->a(Ljava/lang/Object;)Z

    .line 574
    .line 575
    .line 576
    invoke-virtual {v0, v7, v12, v10, v11}, La4;->z(Ljava/lang/Object;III)Lz3;

    .line 577
    .line 578
    .line 579
    move-result-object v6

    .line 580
    :cond_243
    if-nez v13, :cond_249

    .line 581
    .line 582
    invoke-virtual {v0, v6}, La4;->p(Lz3;)V

    .line 583
    .line 584
    .line 585
    goto :goto_1ec

    .line 586
    :cond_249
    invoke-virtual {v0, v6}, La4;->D(Lz3;)V

    .line 587
    .line 588
    .line 589
    goto :goto_1ec

    .line 590
    :cond_24d
    iget v7, v6, Lz3;->b:I

    .line 591
    .line 592
    iget v8, v6, Lz3;->d:I

    .line 593
    .line 594
    add-int/2addr v8, v7

    .line 595
    move v10, v7

    .line 596
    const/4 v11, 0x0

    .line 597
    const/4 v13, -0x1

    .line 598
    :goto_255
    if-ge v10, v8, :cond_295

    .line 599
    .line 600
    invoke-virtual {v2, v10}, Landroidx/recyclerview/widget/b;->b(I)Landroidx/recyclerview/widget/g;

    .line 601
    .line 602
    .line 603
    move-result-object v14

    .line 604
    if-nez v14, :cond_263

    .line 605
    .line 606
    invoke-virtual {v0, v10}, La4;->d(I)Z

    .line 607
    .line 608
    .line 609
    move-result v14

    .line 610
    if-eqz v14, :cond_266

    .line 611
    .line 612
    :cond_263
    const/4 v14, 0x0

    .line 613
    const/4 v15, 0x2

    .line 614
    goto :goto_279

    .line 615
    :cond_266
    const/4 v14, 0x1

    .line 616
    if-ne v13, v14, :cond_274

    .line 617
    .line 618
    const/4 v14, 0x0

    .line 619
    const/4 v15, 0x2

    .line 620
    invoke-virtual {v0, v14, v15, v7, v11}, La4;->z(Ljava/lang/Object;III)Lz3;

    .line 621
    .line 622
    .line 623
    move-result-object v13

    .line 624
    invoke-virtual {v0, v13}, La4;->D(Lz3;)V

    .line 625
    .line 626
    .line 627
    const/4 v13, 0x1

    .line 628
    goto :goto_277

    .line 629
    :cond_274
    const/4 v14, 0x0

    .line 630
    const/4 v15, 0x2

    .line 631
    const/4 v13, 0x0

    .line 632
    :goto_277
    const/4 v14, 0x0

    .line 633
    goto :goto_286

    .line 634
    :goto_279
    if-nez v13, :cond_284

    .line 635
    .line 636
    invoke-virtual {v0, v14, v15, v7, v11}, La4;->z(Ljava/lang/Object;III)Lz3;

    .line 637
    .line 638
    .line 639
    move-result-object v13

    .line 640
    invoke-virtual {v0, v13}, La4;->p(Lz3;)V

    .line 641
    .line 642
    .line 643
    const/4 v13, 0x1

    .line 644
    goto :goto_285

    .line 645
    :cond_284
    const/4 v13, 0x0

    .line 646
    :goto_285
    const/4 v14, 0x1

    .line 647
    :goto_286
    if-eqz v13, :cond_28e

    .line 648
    .line 649
    sub-int/2addr v10, v11

    .line 650
    sub-int/2addr v8, v11

    .line 651
    const/4 v11, 0x1

    .line 652
    :goto_28b
    const/16 v19, 0x1

    .line 653
    .line 654
    goto :goto_291

    .line 655
    :cond_28e
    add-int/lit8 v11, v11, 0x1

    .line 656
    .line 657
    goto :goto_28b

    .line 658
    :goto_291
    add-int/lit8 v10, v10, 0x1

    .line 659
    .line 660
    move v13, v14

    .line 661
    goto :goto_255

    .line 662
    :cond_295
    const/16 v19, 0x1

    .line 663
    .line 664
    iget v8, v6, Lz3;->d:I

    .line 665
    .line 666
    if-eq v11, v8, :cond_2a7

    .line 667
    .line 668
    const/4 v8, 0x0

    .line 669
    iput-object v8, v6, Lz3;->c:Ljava/lang/Object;

    .line 670
    .line 671
    invoke-virtual {v1, v6}, Lp22;->a(Ljava/lang/Object;)Z

    .line 672
    .line 673
    .line 674
    const/4 v15, 0x2

    .line 675
    invoke-virtual {v0, v8, v15, v7, v11}, La4;->z(Ljava/lang/Object;III)Lz3;

    .line 676
    .line 677
    .line 678
    move-result-object v6

    .line 679
    goto :goto_2a9

    .line 680
    :cond_2a7
    const/4 v8, 0x0

    .line 681
    const/4 v15, 0x2

    .line 682
    :goto_2a9
    if-nez v13, :cond_2af

    .line 683
    .line 684
    invoke-virtual {v0, v6}, La4;->p(Lz3;)V

    .line 685
    .line 686
    .line 687
    goto :goto_2ba

    .line 688
    :cond_2af
    invoke-virtual {v0, v6}, La4;->D(Lz3;)V

    .line 689
    .line 690
    .line 691
    goto :goto_2ba

    .line 692
    :cond_2b3
    move/from16 v19, v8

    .line 693
    .line 694
    const/4 v8, 0x0

    .line 695
    const/4 v15, 0x2

    .line 696
    invoke-virtual {v0, v6}, La4;->D(Lz3;)V

    .line 697
    .line 698
    .line 699
    :goto_2ba
    add-int/lit8 v5, v5, 0x1

    .line 700
    .line 701
    goto/16 :goto_1d8

    .line 702
    .line 703
    :cond_2be
    invoke-virtual {v4}, Ljava/util/ArrayList;->clear()V

    .line 704
    .line 705
    .line 706
    return-void
.end method

.method public F(I)I
    .registers 2

    .line 1
    iget-object p0, p0, La4;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Ljava/lang/String;

    .line 4
    .line 5
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 6
    .line 7
    .line 8
    move-result p0

    .line 9
    if-ge p1, p0, :cond_b

    .line 10
    .line 11
    return p1

    .line 12
    :cond_b
    const/4 p0, -0x1

    .line 13
    return p0
.end method

.method public G(Ljava/util/ArrayList;)V
    .registers 6

    .line 1
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    :goto_5
    if-ge v1, v0, :cond_1a

    .line 7
    .line 8
    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v2

    .line 12
    check-cast v2, Lz3;

    .line 13
    .line 14
    const/4 v3, 0x0

    .line 15
    iput-object v3, v2, Lz3;->c:Ljava/lang/Object;

    .line 16
    .line 17
    iget-object v3, p0, La4;->c:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v3, Lp22;

    .line 20
    .line 21
    invoke-virtual {v3, v2}, Lp22;->a(Ljava/lang/Object;)Z

    .line 22
    .line 23
    .line 24
    add-int/lit8 v1, v1, 0x1

    .line 25
    .line 26
    goto :goto_5

    .line 27
    :cond_1a
    invoke-virtual {p1}, Ljava/util/ArrayList;->clear()V

    .line 28
    .line 29
    .line 30
    return-void
.end method

.method public H(Landroid/content/res/ColorStateList;)V
    .registers 3

    .line 1
    if-eqz p1, :cond_15

    .line 2
    .line 3
    iget-object v0, p0, La4;->e:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Liy;

    .line 6
    .line 7
    if-nez v0, :cond_f

    .line 8
    .line 9
    new-instance v0, Liy;

    .line 10
    .line 11
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 12
    .line 13
    .line 14
    iput-object v0, p0, La4;->e:Ljava/lang/Object;

    .line 15
    .line 16
    :cond_f
    iput-object p1, v0, Liy;->c:Ljava/lang/Object;

    .line 17
    .line 18
    const/4 p1, 0x1

    .line 19
    iput-boolean p1, v0, Liy;->b:Z

    .line 20
    .line 21
    goto :goto_18

    .line 22
    :cond_15
    const/4 p1, 0x0

    .line 23
    iput-object p1, p0, La4;->e:Ljava/lang/Object;

    .line 24
    .line 25
    :goto_18
    invoke-virtual {p0}, La4;->b()V

    .line 26
    .line 27
    .line 28
    return-void
.end method

.method public I(Landroid/content/res/ColorStateList;)V
    .registers 3

    .line 1
    iget-object v0, p0, La4;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Liy;

    .line 4
    .line 5
    if-nez v0, :cond_d

    .line 6
    .line 7
    new-instance v0, Liy;

    .line 8
    .line 9
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    iput-object v0, p0, La4;->f:Ljava/lang/Object;

    .line 13
    .line 14
    :cond_d
    iput-object p1, v0, Liy;->c:Ljava/lang/Object;

    .line 15
    .line 16
    const/4 p1, 0x1

    .line 17
    iput-boolean p1, v0, Liy;->b:Z

    .line 18
    .line 19
    invoke-virtual {p0}, La4;->b()V

    .line 20
    .line 21
    .line 22
    return-void
.end method

.method public J(Landroid/graphics/PorterDuff$Mode;)V
    .registers 3

    .line 1
    iget-object v0, p0, La4;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Liy;

    .line 4
    .line 5
    if-nez v0, :cond_d

    .line 6
    .line 7
    new-instance v0, Liy;

    .line 8
    .line 9
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    iput-object v0, p0, La4;->f:Ljava/lang/Object;

    .line 13
    .line 14
    :cond_d
    iput-object p1, v0, Liy;->d:Ljava/io/Serializable;

    .line 15
    .line 16
    const/4 p1, 0x1

    .line 17
    iput-boolean p1, v0, Liy;->a:Z

    .line 18
    .line 19
    invoke-virtual {p0}, La4;->b()V

    .line 20
    .line 21
    .line 22
    return-void
.end method

.method public K()I
    .registers 5

    .line 1
    iget v0, p0, La4;->b:I

    .line 2
    .line 3
    const/4 v1, -0x1

    .line 4
    if-ne v0, v1, :cond_6

    .line 5
    .line 6
    return v0

    .line 7
    :cond_6
    iget-object v1, p0, La4;->g:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v1, Ljava/lang/String;

    .line 10
    .line 11
    :goto_a
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    if-ge v0, v2, :cond_27

    .line 16
    .line 17
    invoke-virtual {v1, v0}, Ljava/lang/String;->charAt(I)C

    .line 18
    .line 19
    .line 20
    move-result v2

    .line 21
    const/16 v3, 0x20

    .line 22
    .line 23
    if-eq v2, v3, :cond_24

    .line 24
    .line 25
    const/16 v3, 0xa

    .line 26
    .line 27
    if-eq v2, v3, :cond_24

    .line 28
    .line 29
    const/16 v3, 0xd

    .line 30
    .line 31
    if-eq v2, v3, :cond_24

    .line 32
    .line 33
    const/16 v3, 0x9

    .line 34
    .line 35
    if-ne v2, v3, :cond_27

    .line 36
    .line 37
    :cond_24
    add-int/lit8 v0, v0, 0x1

    .line 38
    .line 39
    goto :goto_a

    .line 40
    :cond_27
    iput v0, p0, La4;->b:I

    .line 41
    .line 42
    return v0
.end method

.method public L(Landroid/widget/TextView;)V
    .registers 13

    .line 1
    iget-object v0, p0, La4;->d:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/content/res/ColorStateList;

    .line 4
    .line 5
    new-instance v1, Lyq1;

    .line 6
    .line 7
    invoke-direct {v1}, Lyq1;-><init>()V

    .line 8
    .line 9
    .line 10
    new-instance v2, Lyq1;

    .line 11
    .line 12
    invoke-direct {v2}, Lyq1;-><init>()V

    .line 13
    .line 14
    .line 15
    iget-object v3, p0, La4;->g:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast v3, Lvm2;

    .line 18
    .line 19
    invoke-virtual {v1, v3}, Lyq1;->setShapeAppearanceModel(Lvm2;)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {v2, v3}, Lyq1;->setShapeAppearanceModel(Lvm2;)V

    .line 23
    .line 24
    .line 25
    iget-object v3, p0, La4;->e:Ljava/lang/Object;

    .line 26
    .line 27
    check-cast v3, Landroid/content/res/ColorStateList;

    .line 28
    .line 29
    invoke-virtual {v1, v3}, Lyq1;->t(Landroid/content/res/ColorStateList;)V

    .line 30
    .line 31
    .line 32
    iget v3, p0, La4;->b:I

    .line 33
    .line 34
    int-to-float v3, v3

    .line 35
    iget-object v4, p0, La4;->f:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast v4, Landroid/content/res/ColorStateList;

    .line 38
    .line 39
    invoke-virtual {v1, v3}, Lyq1;->A(F)V

    .line 40
    .line 41
    .line 42
    invoke-virtual {v1, v4}, Lyq1;->y(Landroid/content/res/ColorStateList;)V

    .line 43
    .line 44
    .line 45
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setTextColor(Landroid/content/res/ColorStateList;)V

    .line 46
    .line 47
    .line 48
    new-instance v6, Landroid/graphics/drawable/RippleDrawable;

    .line 49
    .line 50
    const/16 v3, 0x1e

    .line 51
    .line 52
    invoke-virtual {v0, v3}, Landroid/content/res/ColorStateList;->withAlpha(I)Landroid/content/res/ColorStateList;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    invoke-direct {v6, v0, v1, v2}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 57
    .line 58
    .line 59
    new-instance v5, Landroid/graphics/drawable/InsetDrawable;

    .line 60
    .line 61
    iget-object p0, p0, La4;->c:Ljava/lang/Object;

    .line 62
    .line 63
    check-cast p0, Landroid/graphics/Rect;

    .line 64
    .line 65
    iget v7, p0, Landroid/graphics/Rect;->left:I

    .line 66
    .line 67
    iget v8, p0, Landroid/graphics/Rect;->top:I

    .line 68
    .line 69
    iget v9, p0, Landroid/graphics/Rect;->right:I

    .line 70
    .line 71
    iget v10, p0, Landroid/graphics/Rect;->bottom:I

    .line 72
    .line 73
    invoke-direct/range {v5 .. v10}, Landroid/graphics/drawable/InsetDrawable;-><init>(Landroid/graphics/drawable/Drawable;IIII)V

    .line 74
    .line 75
    .line 76
    invoke-virtual {p1, v5}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 77
    .line 78
    .line 79
    return-void
.end method

.method public M()Z
    .registers 5

    .line 1
    invoke-virtual {p0}, La4;->K()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    iget-object v1, p0, La4;->g:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Ljava/lang/String;

    .line 8
    .line 9
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    const/4 v3, 0x0

    .line 14
    if-ge v0, v2, :cond_22

    .line 15
    .line 16
    const/4 v2, -0x1

    .line 17
    if-ne v0, v2, :cond_13

    .line 18
    .line 19
    goto :goto_22

    .line 20
    :cond_13
    invoke-virtual {v1, v0}, Ljava/lang/String;->charAt(I)C

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    const/16 v1, 0x2c

    .line 25
    .line 26
    if-ne v0, v1, :cond_22

    .line 27
    .line 28
    iget v0, p0, La4;->b:I

    .line 29
    .line 30
    const/4 v1, 0x1

    .line 31
    add-int/2addr v0, v1

    .line 32
    iput v0, p0, La4;->b:I

    .line 33
    .line 34
    return v1

    .line 35
    :cond_22
    :goto_22
    return v3
.end method

.method public N(C)V
    .registers 8

    .line 1
    iget-object v0, p0, La4;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/lang/String;

    .line 4
    .line 5
    iget v1, p0, La4;->b:I

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-lez v1, :cond_30

    .line 9
    .line 10
    const/16 v3, 0x22

    .line 11
    .line 12
    if-ne p1, v3, :cond_30

    .line 13
    .line 14
    add-int/lit8 v3, v1, -0x1

    .line 15
    .line 16
    :try_start_f
    iput v3, p0, La4;->b:I

    .line 17
    .line 18
    invoke-virtual {p0}, La4;->m()Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v3
    :try_end_15
    .catchall {:try_start_f .. :try_end_15} :catchall_2c

    .line 22
    iput v1, p0, La4;->b:I

    .line 23
    .line 24
    const-string v1, "null"

    .line 25
    .line 26
    invoke-static {v3, v1}, Ld31;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    if-nez v1, :cond_20

    .line 31
    .line 32
    goto :goto_30

    .line 33
    :cond_20
    iget p1, p0, La4;->b:I

    .line 34
    .line 35
    add-int/lit8 p1, p1, -0x1

    .line 36
    .line 37
    const-string v0, "Use \'coerceInputValues = true\' in \'Json {}\' builder to coerce nulls if property has a default value."

    .line 38
    .line 39
    const-string v1, "Expected string literal but \'null\' literal was found"

    .line 40
    .line 41
    invoke-virtual {p0, v1, v0, p1}, La4;->r(Ljava/lang/String;Ljava/lang/String;I)V

    .line 42
    .line 43
    .line 44
    throw v2

    .line 45
    :catchall_2c
    move-exception p1

    .line 46
    iput v1, p0, La4;->b:I

    .line 47
    .line 48
    throw p1

    .line 49
    :cond_30
    :goto_30
    invoke-static {p1}, Lh23;->f(C)B

    .line 50
    .line 51
    .line 52
    move-result p1

    .line 53
    invoke-static {p1}, Lh23;->u(B)Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    iget v1, p0, La4;->b:I

    .line 58
    .line 59
    if-lez v1, :cond_3f

    .line 60
    .line 61
    add-int/lit8 v3, v1, -0x1

    .line 62
    .line 63
    goto :goto_40

    .line 64
    :cond_3f
    move v3, v1

    .line 65
    :goto_40
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 66
    .line 67
    .line 68
    move-result v4

    .line 69
    if-eq v1, v4, :cond_52

    .line 70
    .line 71
    if-gez v3, :cond_49

    .line 72
    .line 73
    goto :goto_52

    .line 74
    :cond_49
    invoke-virtual {v0, v3}, Ljava/lang/String;->charAt(I)C

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    invoke-static {v0}, Ljava/lang/String;->valueOf(C)Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    goto :goto_54

    .line 83
    :cond_52
    :goto_52
    const-string v0, "EOF"

    .line 84
    .line 85
    :goto_54
    const-string v1, ", but had \'"

    .line 86
    .line 87
    const-string v4, "\' instead"

    .line 88
    .line 89
    const-string v5, "Expected "

    .line 90
    .line 91
    invoke-static {v5, p1, v1, v0, v4}, Ln10;->j(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 92
    .line 93
    .line 94
    move-result-object p1

    .line 95
    const/4 v0, 0x4

    .line 96
    invoke-static {p0, p1, v3, v0}, La4;->s(La4;Ljava/lang/String;II)V

    .line 97
    .line 98
    .line 99
    throw v2
.end method

.method public O(II)I
    .registers 12

    .line 1
    iget-object v0, p0, La4;->c:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lp22;

    .line 4
    .line 5
    iget-object p0, p0, La4;->e:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast p0, Ljava/util/ArrayList;

    .line 8
    .line 9
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    const/4 v2, 0x1

    .line 14
    sub-int/2addr v1, v2

    .line 15
    :goto_e
    const/16 v3, 0x8

    .line 16
    .line 17
    if-ltz v1, :cond_84

    .line 18
    .line 19
    invoke-virtual {p0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v4

    .line 23
    check-cast v4, Lz3;

    .line 24
    .line 25
    iget v5, v4, Lz3;->a:I

    .line 26
    .line 27
    iget v6, v4, Lz3;->b:I

    .line 28
    .line 29
    const/4 v7, 0x2

    .line 30
    if-ne v5, v3, :cond_66

    .line 31
    .line 32
    iget v3, v4, Lz3;->d:I

    .line 33
    .line 34
    if-ge v6, v3, :cond_26

    .line 35
    .line 36
    move v8, v3

    .line 37
    move v5, v6

    .line 38
    goto :goto_28

    .line 39
    :cond_26
    move v5, v3

    .line 40
    move v8, v6

    .line 41
    :goto_28
    if-lt p1, v5, :cond_4e

    .line 42
    .line 43
    if-gt p1, v8, :cond_4e

    .line 44
    .line 45
    if-ne v5, v6, :cond_3e

    .line 46
    .line 47
    if-ne p2, v2, :cond_35

    .line 48
    .line 49
    add-int/lit8 v3, v3, 0x1

    .line 50
    .line 51
    iput v3, v4, Lz3;->d:I

    .line 52
    .line 53
    goto :goto_3b

    .line 54
    :cond_35
    if-ne p2, v7, :cond_3b

    .line 55
    .line 56
    add-int/lit8 v3, v3, -0x1

    .line 57
    .line 58
    iput v3, v4, Lz3;->d:I

    .line 59
    .line 60
    :cond_3b
    :goto_3b
    add-int/lit8 p1, p1, 0x1

    .line 61
    .line 62
    goto :goto_81

    .line 63
    :cond_3e
    if-ne p2, v2, :cond_45

    .line 64
    .line 65
    add-int/lit8 v6, v6, 0x1

    .line 66
    .line 67
    iput v6, v4, Lz3;->b:I

    .line 68
    .line 69
    goto :goto_4b

    .line 70
    :cond_45
    if-ne p2, v7, :cond_4b

    .line 71
    .line 72
    add-int/lit8 v6, v6, -0x1

    .line 73
    .line 74
    iput v6, v4, Lz3;->b:I

    .line 75
    .line 76
    :cond_4b
    :goto_4b
    add-int/lit8 p1, p1, -0x1

    .line 77
    .line 78
    goto :goto_81

    .line 79
    :cond_4e
    if-ge p1, v6, :cond_81

    .line 80
    .line 81
    if-ne p2, v2, :cond_5b

    .line 82
    .line 83
    add-int/lit8 v6, v6, 0x1

    .line 84
    .line 85
    iput v6, v4, Lz3;->b:I

    .line 86
    .line 87
    add-int/lit8 v3, v3, 0x1

    .line 88
    .line 89
    iput v3, v4, Lz3;->d:I

    .line 90
    .line 91
    goto :goto_81

    .line 92
    :cond_5b
    if-ne p2, v7, :cond_81

    .line 93
    .line 94
    add-int/lit8 v6, v6, -0x1

    .line 95
    .line 96
    iput v6, v4, Lz3;->b:I

    .line 97
    .line 98
    add-int/lit8 v3, v3, -0x1

    .line 99
    .line 100
    iput v3, v4, Lz3;->d:I

    .line 101
    .line 102
    goto :goto_81

    .line 103
    :cond_66
    if-gt v6, p1, :cond_74

    .line 104
    .line 105
    if-ne v5, v2, :cond_6e

    .line 106
    .line 107
    iget v3, v4, Lz3;->d:I

    .line 108
    .line 109
    sub-int/2addr p1, v3

    .line 110
    goto :goto_81

    .line 111
    :cond_6e
    if-ne v5, v7, :cond_81

    .line 112
    .line 113
    iget v3, v4, Lz3;->d:I

    .line 114
    .line 115
    add-int/2addr p1, v3

    .line 116
    goto :goto_81

    .line 117
    :cond_74
    if-ne p2, v2, :cond_7b

    .line 118
    .line 119
    add-int/lit8 v6, v6, 0x1

    .line 120
    .line 121
    iput v6, v4, Lz3;->b:I

    .line 122
    .line 123
    goto :goto_81

    .line 124
    :cond_7b
    if-ne p2, v7, :cond_81

    .line 125
    .line 126
    add-int/lit8 v6, v6, -0x1

    .line 127
    .line 128
    iput v6, v4, Lz3;->b:I

    .line 129
    .line 130
    :cond_81
    :goto_81
    add-int/lit8 v1, v1, -0x1

    .line 131
    .line 132
    goto :goto_e

    .line 133
    :cond_84
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    .line 134
    .line 135
    .line 136
    move-result p2

    .line 137
    sub-int/2addr p2, v2

    .line 138
    :goto_89
    if-ltz p2, :cond_b4

    .line 139
    .line 140
    invoke-virtual {p0, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 141
    .line 142
    .line 143
    move-result-object v1

    .line 144
    check-cast v1, Lz3;

    .line 145
    .line 146
    iget v2, v1, Lz3;->a:I

    .line 147
    .line 148
    iget v4, v1, Lz3;->d:I

    .line 149
    .line 150
    const/4 v5, 0x0

    .line 151
    if-ne v2, v3, :cond_a7

    .line 152
    .line 153
    iget v2, v1, Lz3;->b:I

    .line 154
    .line 155
    if-eq v4, v2, :cond_9e

    .line 156
    .line 157
    if-gez v4, :cond_b1

    .line 158
    .line 159
    :cond_9e
    invoke-virtual {p0, p2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 160
    .line 161
    .line 162
    iput-object v5, v1, Lz3;->c:Ljava/lang/Object;

    .line 163
    .line 164
    invoke-virtual {v0, v1}, Lp22;->a(Ljava/lang/Object;)Z

    .line 165
    .line 166
    .line 167
    goto :goto_b1

    .line 168
    :cond_a7
    if-gtz v4, :cond_b1

    .line 169
    .line 170
    invoke-virtual {p0, p2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 171
    .line 172
    .line 173
    iput-object v5, v1, Lz3;->c:Ljava/lang/Object;

    .line 174
    .line 175
    invoke-virtual {v0, v1}, Lp22;->a(Ljava/lang/Object;)Z

    .line 176
    .line 177
    .line 178
    :cond_b1
    :goto_b1
    add-int/lit8 p2, p2, -0x1

    .line 179
    .line 180
    goto :goto_89

    .line 181
    :cond_b4
    return p1
.end method

.method public a(Ljava/lang/CharSequence;I)I
    .registers 7

    .line 1
    add-int/lit8 v0, p2, 0x4

    .line 2
    .line 3
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    if-lt v0, v1, :cond_20

    .line 8
    .line 9
    iput p2, p0, La4;->b:I

    .line 10
    .line 11
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    .line 12
    .line 13
    .line 14
    move-result p2

    .line 15
    if-ge v0, p2, :cond_17

    .line 16
    .line 17
    iget p2, p0, La4;->b:I

    .line 18
    .line 19
    invoke-virtual {p0, p1, p2}, La4;->a(Ljava/lang/CharSequence;I)I

    .line 20
    .line 21
    .line 22
    move-result p0

    .line 23
    return p0

    .line 24
    :cond_17
    const/4 p1, 0x0

    .line 25
    const/4 p2, 0x6

    .line 26
    const-string v0, "Unexpected EOF during unicode escape"

    .line 27
    .line 28
    invoke-static {p0, v0, p1, p2}, La4;->s(La4;Ljava/lang/String;II)V

    .line 29
    .line 30
    .line 31
    const/4 p0, 0x0

    .line 32
    throw p0

    .line 33
    :cond_20
    iget-object v1, p0, La4;->f:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast v1, Ljava/lang/StringBuilder;

    .line 36
    .line 37
    invoke-virtual {p0, p1, p2}, La4;->u(Ljava/lang/CharSequence;I)I

    .line 38
    .line 39
    .line 40
    move-result v2

    .line 41
    shl-int/lit8 v2, v2, 0xc

    .line 42
    .line 43
    add-int/lit8 v3, p2, 0x1

    .line 44
    .line 45
    invoke-virtual {p0, p1, v3}, La4;->u(Ljava/lang/CharSequence;I)I

    .line 46
    .line 47
    .line 48
    move-result v3

    .line 49
    shl-int/lit8 v3, v3, 0x8

    .line 50
    .line 51
    add-int/2addr v2, v3

    .line 52
    add-int/lit8 v3, p2, 0x2

    .line 53
    .line 54
    invoke-virtual {p0, p1, v3}, La4;->u(Ljava/lang/CharSequence;I)I

    .line 55
    .line 56
    .line 57
    move-result v3

    .line 58
    shl-int/lit8 v3, v3, 0x4

    .line 59
    .line 60
    add-int/2addr v2, v3

    .line 61
    add-int/lit8 p2, p2, 0x3

    .line 62
    .line 63
    invoke-virtual {p0, p1, p2}, La4;->u(Ljava/lang/CharSequence;I)I

    .line 64
    .line 65
    .line 66
    move-result p0

    .line 67
    add-int/2addr p0, v2

    .line 68
    int-to-char p0, p0

    .line 69
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 70
    .line 71
    .line 72
    return v0
.end method

.method public b()V
    .registers 6

    .line 1
    iget-object v0, p0, La4;->c:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/view/View;

    .line 4
    .line 5
    invoke-virtual {v0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    if-eqz v1, :cond_6f

    .line 10
    .line 11
    iget-object v2, p0, La4;->e:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v2, Liy;

    .line 14
    .line 15
    if-eqz v2, :cond_50

    .line 16
    .line 17
    iget-object v2, p0, La4;->g:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v2, Liy;

    .line 20
    .line 21
    if-nez v2, :cond_1d

    .line 22
    .line 23
    new-instance v2, Liy;

    .line 24
    .line 25
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 26
    .line 27
    .line 28
    iput-object v2, p0, La4;->g:Ljava/lang/Object;

    .line 29
    .line 30
    :cond_1d
    const/4 v3, 0x0

    .line 31
    iput-object v3, v2, Liy;->c:Ljava/lang/Object;

    .line 32
    .line 33
    const/4 v4, 0x0

    .line 34
    iput-boolean v4, v2, Liy;->b:Z

    .line 35
    .line 36
    iput-object v3, v2, Liy;->d:Ljava/io/Serializable;

    .line 37
    .line 38
    iput-boolean v4, v2, Liy;->a:Z

    .line 39
    .line 40
    sget-object v3, Ln83;->a:Ljava/util/WeakHashMap;

    .line 41
    .line 42
    invoke-virtual {v0}, Landroid/view/View;->getBackgroundTintList()Landroid/content/res/ColorStateList;

    .line 43
    .line 44
    .line 45
    move-result-object v3

    .line 46
    const/4 v4, 0x1

    .line 47
    if-eqz v3, :cond_34

    .line 48
    .line 49
    iput-boolean v4, v2, Liy;->b:Z

    .line 50
    .line 51
    iput-object v3, v2, Liy;->c:Ljava/lang/Object;

    .line 52
    .line 53
    :cond_34
    invoke-virtual {v0}, Landroid/view/View;->getBackgroundTintMode()Landroid/graphics/PorterDuff$Mode;

    .line 54
    .line 55
    .line 56
    move-result-object v3

    .line 57
    if-eqz v3, :cond_3e

    .line 58
    .line 59
    iput-boolean v4, v2, Liy;->a:Z

    .line 60
    .line 61
    iput-object v3, v2, Liy;->d:Ljava/io/Serializable;

    .line 62
    .line 63
    :cond_3e
    iget-boolean v3, v2, Liy;->b:Z

    .line 64
    .line 65
    if-nez v3, :cond_46

    .line 66
    .line 67
    iget-boolean v3, v2, Liy;->a:Z

    .line 68
    .line 69
    if-eqz v3, :cond_50

    .line 70
    .line 71
    :cond_46
    invoke-virtual {v0}, Landroid/view/View;->getDrawableState()[I

    .line 72
    .line 73
    .line 74
    move-result-object p0

    .line 75
    sget-object v0, Lz8;->b:Landroid/graphics/PorterDuff$Mode;

    .line 76
    .line 77
    invoke-static {v1, v2, p0}, Lzf2;->h(Landroid/graphics/drawable/Drawable;Liy;[I)V

    .line 78
    .line 79
    .line 80
    return-void

    .line 81
    :cond_50
    iget-object v2, p0, La4;->f:Ljava/lang/Object;

    .line 82
    .line 83
    check-cast v2, Liy;

    .line 84
    .line 85
    if-eqz v2, :cond_60

    .line 86
    .line 87
    invoke-virtual {v0}, Landroid/view/View;->getDrawableState()[I

    .line 88
    .line 89
    .line 90
    move-result-object p0

    .line 91
    sget-object v0, Lz8;->b:Landroid/graphics/PorterDuff$Mode;

    .line 92
    .line 93
    invoke-static {v1, v2, p0}, Lzf2;->h(Landroid/graphics/drawable/Drawable;Liy;[I)V

    .line 94
    .line 95
    .line 96
    return-void

    .line 97
    :cond_60
    iget-object p0, p0, La4;->e:Ljava/lang/Object;

    .line 98
    .line 99
    check-cast p0, Liy;

    .line 100
    .line 101
    if-eqz p0, :cond_6f

    .line 102
    .line 103
    invoke-virtual {v0}, Landroid/view/View;->getDrawableState()[I

    .line 104
    .line 105
    .line 106
    move-result-object v0

    .line 107
    sget-object v2, Lz8;->b:Landroid/graphics/PorterDuff$Mode;

    .line 108
    .line 109
    invoke-static {v1, p0, v0}, Lzf2;->h(Landroid/graphics/drawable/Drawable;Liy;[I)V

    .line 110
    .line 111
    .line 112
    :cond_6f
    return-void
.end method

.method public c()Z
    .registers 6

    .line 1
    iget v0, p0, La4;->b:I

    .line 2
    .line 3
    const/4 v1, -0x1

    .line 4
    const/4 v2, 0x0

    .line 5
    if-ne v0, v1, :cond_7

    .line 6
    .line 7
    return v2

    .line 8
    :cond_7
    iget-object v1, p0, La4;->g:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v1, Ljava/lang/String;

    .line 11
    .line 12
    :goto_b
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 13
    .line 14
    .line 15
    move-result v3

    .line 16
    if-ge v0, v3, :cond_3e

    .line 17
    .line 18
    invoke-virtual {v1, v0}, Ljava/lang/String;->charAt(I)C

    .line 19
    .line 20
    .line 21
    move-result v3

    .line 22
    const/16 v4, 0x20

    .line 23
    .line 24
    if-eq v3, v4, :cond_3b

    .line 25
    .line 26
    const/16 v4, 0xa

    .line 27
    .line 28
    if-eq v3, v4, :cond_3b

    .line 29
    .line 30
    const/16 v4, 0xd

    .line 31
    .line 32
    if-eq v3, v4, :cond_3b

    .line 33
    .line 34
    const/16 v4, 0x9

    .line 35
    .line 36
    if-ne v3, v4, :cond_26

    .line 37
    .line 38
    goto :goto_3b

    .line 39
    :cond_26
    iput v0, p0, La4;->b:I

    .line 40
    .line 41
    const/16 p0, 0x2c

    .line 42
    .line 43
    if-eq v3, p0, :cond_3a

    .line 44
    .line 45
    const/16 p0, 0x3a

    .line 46
    .line 47
    if-eq v3, p0, :cond_3a

    .line 48
    .line 49
    const/16 p0, 0x5d

    .line 50
    .line 51
    if-eq v3, p0, :cond_3a

    .line 52
    .line 53
    const/16 p0, 0x7d

    .line 54
    .line 55
    if-eq v3, p0, :cond_3a

    .line 56
    .line 57
    const/4 p0, 0x1

    .line 58
    return p0

    .line 59
    :cond_3a
    return v2

    .line 60
    :cond_3b
    :goto_3b
    add-int/lit8 v0, v0, 0x1

    .line 61
    .line 62
    goto :goto_b

    .line 63
    :cond_3e
    iput v0, p0, La4;->b:I

    .line 64
    .line 65
    return v2
.end method

.method public d(I)Z
    .registers 10

    .line 1
    iget-object v0, p0, La4;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/util/ArrayList;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const/4 v2, 0x0

    .line 10
    move v3, v2

    .line 11
    :goto_a
    if-ge v3, v1, :cond_3c

    .line 12
    .line 13
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v4

    .line 17
    check-cast v4, Lz3;

    .line 18
    .line 19
    iget v5, v4, Lz3;->a:I

    .line 20
    .line 21
    const/16 v6, 0x8

    .line 22
    .line 23
    const/4 v7, 0x1

    .line 24
    if-ne v5, v6, :cond_24

    .line 25
    .line 26
    iget v4, v4, Lz3;->d:I

    .line 27
    .line 28
    add-int/lit8 v5, v3, 0x1

    .line 29
    .line 30
    invoke-virtual {p0, v4, v5}, La4;->t(II)I

    .line 31
    .line 32
    .line 33
    move-result v4

    .line 34
    if-ne v4, p1, :cond_39

    .line 35
    .line 36
    goto :goto_35

    .line 37
    :cond_24
    if-ne v5, v7, :cond_39

    .line 38
    .line 39
    iget v5, v4, Lz3;->b:I

    .line 40
    .line 41
    iget v4, v4, Lz3;->d:I

    .line 42
    .line 43
    add-int/2addr v4, v5

    .line 44
    :goto_2b
    if-ge v5, v4, :cond_39

    .line 45
    .line 46
    add-int/lit8 v6, v3, 0x1

    .line 47
    .line 48
    invoke-virtual {p0, v5, v6}, La4;->t(II)I

    .line 49
    .line 50
    .line 51
    move-result v6

    .line 52
    if-ne v6, p1, :cond_36

    .line 53
    .line 54
    :goto_35
    return v7

    .line 55
    :cond_36
    add-int/lit8 v5, v5, 0x1

    .line 56
    .line 57
    goto :goto_2b

    .line 58
    :cond_39
    add-int/lit8 v3, v3, 0x1

    .line 59
    .line 60
    goto :goto_a

    .line 61
    :cond_3c
    return v2
.end method

.method public e(ILjava/lang/String;)V
    .registers 11

    .line 1
    iget-object v0, p0, La4;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/lang/String;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    sub-int/2addr v1, p1

    .line 10
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    .line 11
    .line 12
    .line 13
    move-result v2

    .line 14
    const/4 v3, 0x0

    .line 15
    const/4 v4, 0x6

    .line 16
    const/4 v5, 0x0

    .line 17
    if-lt v1, v2, :cond_4d

    .line 18
    .line 19
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    move v2, v5

    .line 24
    :goto_17
    if-ge v2, v1, :cond_45

    .line 25
    .line 26
    invoke-virtual {p2, v2}, Ljava/lang/String;->charAt(I)C

    .line 27
    .line 28
    .line 29
    move-result v6

    .line 30
    add-int v7, p1, v2

    .line 31
    .line 32
    invoke-virtual {v0, v7}, Ljava/lang/String;->charAt(I)C

    .line 33
    .line 34
    .line 35
    move-result v7

    .line 36
    or-int/lit8 v7, v7, 0x20

    .line 37
    .line 38
    if-ne v6, v7, :cond_2a

    .line 39
    .line 40
    add-int/lit8 v2, v2, 0x1

    .line 41
    .line 42
    goto :goto_17

    .line 43
    :cond_2a
    new-instance p1, Ljava/lang/StringBuilder;

    .line 44
    .line 45
    const-string p2, "Expected valid boolean literal prefix, but had \'"

    .line 46
    .line 47
    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    invoke-virtual {p0}, La4;->m()Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object p2

    .line 54
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 55
    .line 56
    .line 57
    const/16 p2, 0x27

    .line 58
    .line 59
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 60
    .line 61
    .line 62
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object p1

    .line 66
    invoke-static {p0, p1, v5, v4}, La4;->s(La4;Ljava/lang/String;II)V

    .line 67
    .line 68
    .line 69
    throw v3

    .line 70
    :cond_45
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    .line 71
    .line 72
    .line 73
    move-result p2

    .line 74
    add-int/2addr p2, p1

    .line 75
    iput p2, p0, La4;->b:I

    .line 76
    .line 77
    return-void

    .line 78
    :cond_4d
    const-string p1, "Unexpected end of boolean literal"

    .line 79
    .line 80
    invoke-static {p0, p1, v5, v4}, La4;->s(La4;Ljava/lang/String;II)V

    .line 81
    .line 82
    .line 83
    throw v3
.end method

.method public f()Ljava/lang/String;
    .registers 15

    .line 1
    iget-object v0, p0, La4;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/lang/StringBuilder;

    .line 4
    .line 5
    iget-object v1, p0, La4;->g:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Ljava/lang/String;

    .line 8
    .line 9
    const/16 v2, 0x22

    .line 10
    .line 11
    invoke-virtual {p0, v2}, La4;->i(C)V

    .line 12
    .line 13
    .line 14
    iget v3, p0, La4;->b:I

    .line 15
    .line 16
    const/4 v4, 0x0

    .line 17
    const/4 v5, 0x4

    .line 18
    invoke-static {v1, v2, v3, v4, v5}, Lxt2;->Q(Ljava/lang/CharSequence;CIZI)I

    .line 19
    .line 20
    .line 21
    move-result v6

    .line 22
    const/4 v7, 0x0

    .line 23
    const/4 v8, -0x1

    .line 24
    if-ne v6, v8, :cond_3e

    .line 25
    .line 26
    invoke-virtual {p0}, La4;->m()Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    iget v0, p0, La4;->b:I

    .line 30
    .line 31
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 32
    .line 33
    .line 34
    move-result v2

    .line 35
    if-eq v0, v2, :cond_30

    .line 36
    .line 37
    if-gez v0, :cond_27

    .line 38
    .line 39
    goto :goto_30

    .line 40
    :cond_27
    invoke-virtual {v1, v0}, Ljava/lang/String;->charAt(I)C

    .line 41
    .line 42
    .line 43
    move-result v1

    .line 44
    invoke-static {v1}, Ljava/lang/String;->valueOf(C)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    goto :goto_32

    .line 49
    :cond_30
    :goto_30
    const-string v1, "EOF"

    .line 50
    .line 51
    :goto_32
    const-string v2, "Expected quotation mark \'\"\', but had \'"

    .line 52
    .line 53
    const-string v3, "\' instead"

    .line 54
    .line 55
    invoke-static {v2, v1, v3}, Ln10;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object v1

    .line 59
    invoke-static {p0, v1, v0, v5}, La4;->s(La4;Ljava/lang/String;II)V

    .line 60
    .line 61
    .line 62
    throw v7

    .line 63
    :cond_3e
    move v9, v3

    .line 64
    :goto_3f
    if-ge v9, v6, :cond_e2

    .line 65
    .line 66
    invoke-virtual {v1, v9}, Ljava/lang/String;->charAt(I)C

    .line 67
    .line 68
    .line 69
    move-result v10

    .line 70
    const/16 v11, 0x5c

    .line 71
    .line 72
    if-ne v10, v11, :cond_de

    .line 73
    .line 74
    iget v3, p0, La4;->b:I

    .line 75
    .line 76
    invoke-virtual {v1, v9}, Ljava/lang/String;->charAt(I)C

    .line 77
    .line 78
    .line 79
    move-result v6

    .line 80
    move v10, v4

    .line 81
    :goto_50
    const/4 v12, 0x1

    .line 82
    if-eq v6, v2, :cond_c4

    .line 83
    .line 84
    const-string v13, "Unexpected EOF"

    .line 85
    .line 86
    if-ne v6, v11, :cond_a9

    .line 87
    .line 88
    invoke-virtual {v0, v1, v3, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    .line 89
    .line 90
    .line 91
    add-int/lit8 v9, v9, 0x1

    .line 92
    .line 93
    invoke-virtual {p0, v9}, La4;->F(I)I

    .line 94
    .line 95
    .line 96
    move-result v3

    .line 97
    const/4 v6, 0x6

    .line 98
    if-eq v3, v8, :cond_a3

    .line 99
    .line 100
    add-int/lit8 v9, v3, 0x1

    .line 101
    .line 102
    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    .line 103
    .line 104
    .line 105
    move-result v3

    .line 106
    const/16 v10, 0x75

    .line 107
    .line 108
    if-ne v3, v10, :cond_72

    .line 109
    .line 110
    invoke-virtual {p0, v1, v9}, La4;->a(Ljava/lang/CharSequence;I)I

    .line 111
    .line 112
    .line 113
    move-result v9

    .line 114
    goto :goto_7f

    .line 115
    :cond_72
    if-ge v3, v10, :cond_79

    .line 116
    .line 117
    sget-object v10, Lqr;->a:[C

    .line 118
    .line 119
    aget-char v10, v10, v3

    .line 120
    .line 121
    goto :goto_7a

    .line 122
    :cond_79
    move v10, v4

    .line 123
    :goto_7a
    if-eqz v10, :cond_8c

    .line 124
    .line 125
    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 126
    .line 127
    .line 128
    :goto_7f
    invoke-virtual {p0, v9}, La4;->F(I)I

    .line 129
    .line 130
    .line 131
    move-result v3

    .line 132
    if-eq v3, v8, :cond_88

    .line 133
    .line 134
    :goto_85
    move v9, v3

    .line 135
    move v10, v12

    .line 136
    goto :goto_bf

    .line 137
    :cond_88
    invoke-static {p0, v13, v3, v5}, La4;->s(La4;Ljava/lang/String;II)V

    .line 138
    .line 139
    .line 140
    throw v7

    .line 141
    :cond_8c
    new-instance v0, Ljava/lang/StringBuilder;

    .line 142
    .line 143
    const-string v1, "Invalid escaped char \'"

    .line 144
    .line 145
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 146
    .line 147
    .line 148
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 149
    .line 150
    .line 151
    const/16 v1, 0x27

    .line 152
    .line 153
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 154
    .line 155
    .line 156
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 157
    .line 158
    .line 159
    move-result-object v0

    .line 160
    invoke-static {p0, v0, v4, v6}, La4;->s(La4;Ljava/lang/String;II)V

    .line 161
    .line 162
    .line 163
    throw v7

    .line 164
    :cond_a3
    const-string v0, "Expected escape sequence to continue, got EOF"

    .line 165
    .line 166
    invoke-static {p0, v0, v4, v6}, La4;->s(La4;Ljava/lang/String;II)V

    .line 167
    .line 168
    .line 169
    throw v7

    .line 170
    :cond_a9
    add-int/lit8 v9, v9, 0x1

    .line 171
    .line 172
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 173
    .line 174
    .line 175
    move-result v6

    .line 176
    if-lt v9, v6, :cond_bf

    .line 177
    .line 178
    invoke-virtual {v0, v1, v3, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    .line 179
    .line 180
    .line 181
    invoke-virtual {p0, v9}, La4;->F(I)I

    .line 182
    .line 183
    .line 184
    move-result v3

    .line 185
    if-eq v3, v8, :cond_bb

    .line 186
    .line 187
    goto :goto_85

    .line 188
    :cond_bb
    invoke-static {p0, v13, v3, v5}, La4;->s(La4;Ljava/lang/String;II)V

    .line 189
    .line 190
    .line 191
    throw v7

    .line 192
    :cond_bf
    :goto_bf
    invoke-virtual {v1, v9}, Ljava/lang/String;->charAt(I)C

    .line 193
    .line 194
    .line 195
    move-result v6

    .line 196
    goto :goto_50

    .line 197
    :cond_c4
    if-nez v10, :cond_cf

    .line 198
    .line 199
    invoke-virtual {v1, v3, v9}, Ljava/lang/String;->subSequence(II)Ljava/lang/CharSequence;

    .line 200
    .line 201
    .line 202
    move-result-object v0

    .line 203
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 204
    .line 205
    .line 206
    move-result-object v0

    .line 207
    goto :goto_da

    .line 208
    :cond_cf
    invoke-virtual {v0, v1, v3, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    .line 209
    .line 210
    .line 211
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 212
    .line 213
    .line 214
    move-result-object v1

    .line 215
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->setLength(I)V

    .line 216
    .line 217
    .line 218
    move-object v0, v1

    .line 219
    :goto_da
    add-int/2addr v9, v12

    .line 220
    iput v9, p0, La4;->b:I

    .line 221
    .line 222
    return-object v0

    .line 223
    :cond_de
    add-int/lit8 v9, v9, 0x1

    .line 224
    .line 225
    goto/16 :goto_3f

    .line 226
    .line 227
    :cond_e2
    add-int/lit8 v0, v6, 0x1

    .line 228
    .line 229
    iput v0, p0, La4;->b:I

    .line 230
    .line 231
    invoke-virtual {v1, v3, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 232
    .line 233
    .line 234
    move-result-object p0

    .line 235
    return-object p0
.end method

.method public g()B
    .registers 6

    .line 1
    iget-object v0, p0, La4;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/lang/String;

    .line 4
    .line 5
    iget v1, p0, La4;->b:I

    .line 6
    .line 7
    :goto_6
    const/4 v2, -0x1

    .line 8
    const/16 v3, 0xa

    .line 9
    .line 10
    if-eq v1, v2, :cond_2f

    .line 11
    .line 12
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    if-ge v1, v2, :cond_2f

    .line 17
    .line 18
    add-int/lit8 v2, v1, 0x1

    .line 19
    .line 20
    invoke-virtual {v0, v1}, Ljava/lang/String;->charAt(I)C

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    const/16 v4, 0x20

    .line 25
    .line 26
    if-eq v1, v4, :cond_2d

    .line 27
    .line 28
    if-eq v1, v3, :cond_2d

    .line 29
    .line 30
    const/16 v3, 0xd

    .line 31
    .line 32
    if-eq v1, v3, :cond_2d

    .line 33
    .line 34
    const/16 v3, 0x9

    .line 35
    .line 36
    if-ne v1, v3, :cond_26

    .line 37
    .line 38
    goto :goto_2d

    .line 39
    :cond_26
    iput v2, p0, La4;->b:I

    .line 40
    .line 41
    invoke-static {v1}, Lh23;->f(C)B

    .line 42
    .line 43
    .line 44
    move-result p0

    .line 45
    return p0

    .line 46
    :cond_2d
    :goto_2d
    move v1, v2

    .line 47
    goto :goto_6

    .line 48
    :cond_2f
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    iput v0, p0, La4;->b:I

    .line 53
    .line 54
    return v3
.end method

.method public h(B)B
    .registers 7

    .line 1
    iget-object v0, p0, La4;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/lang/String;

    .line 4
    .line 5
    invoke-virtual {p0}, La4;->g()B

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    if-eq v1, p1, :cond_3a

    .line 10
    .line 11
    invoke-static {p1}, Lh23;->u(B)Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    iget v1, p0, La4;->b:I

    .line 16
    .line 17
    if-lez v1, :cond_15

    .line 18
    .line 19
    add-int/lit8 v2, v1, -0x1

    .line 20
    .line 21
    goto :goto_16

    .line 22
    :cond_15
    move v2, v1

    .line 23
    :goto_16
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 24
    .line 25
    .line 26
    move-result v3

    .line 27
    if-eq v1, v3, :cond_28

    .line 28
    .line 29
    if-gez v2, :cond_1f

    .line 30
    .line 31
    goto :goto_28

    .line 32
    :cond_1f
    invoke-virtual {v0, v2}, Ljava/lang/String;->charAt(I)C

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    invoke-static {v0}, Ljava/lang/String;->valueOf(C)Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    goto :goto_2a

    .line 41
    :cond_28
    :goto_28
    const-string v0, "EOF"

    .line 42
    .line 43
    :goto_2a
    const-string v1, ", but had \'"

    .line 44
    .line 45
    const-string v3, "\' instead"

    .line 46
    .line 47
    const-string v4, "Expected "

    .line 48
    .line 49
    invoke-static {v4, p1, v1, v0, v3}, Ln10;->j(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    const/4 v0, 0x4

    .line 54
    invoke-static {p0, p1, v2, v0}, La4;->s(La4;Ljava/lang/String;II)V

    .line 55
    .line 56
    .line 57
    const/4 p0, 0x0

    .line 58
    throw p0

    .line 59
    :cond_3a
    return v1
.end method

.method public i(C)V
    .registers 8

    .line 1
    iget v0, p0, La4;->b:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, -0x1

    .line 5
    if-eq v0, v2, :cond_38

    .line 6
    .line 7
    iget-object v3, p0, La4;->g:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v3, Ljava/lang/String;

    .line 10
    .line 11
    :goto_a
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    .line 12
    .line 13
    .line 14
    move-result v4

    .line 15
    if-ge v0, v4, :cond_32

    .line 16
    .line 17
    add-int/lit8 v4, v0, 0x1

    .line 18
    .line 19
    invoke-virtual {v3, v0}, Ljava/lang/String;->charAt(I)C

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    const/16 v5, 0x20

    .line 24
    .line 25
    if-eq v0, v5, :cond_30

    .line 26
    .line 27
    const/16 v5, 0xa

    .line 28
    .line 29
    if-eq v0, v5, :cond_30

    .line 30
    .line 31
    const/16 v5, 0xd

    .line 32
    .line 33
    if-eq v0, v5, :cond_30

    .line 34
    .line 35
    const/16 v5, 0x9

    .line 36
    .line 37
    if-ne v0, v5, :cond_27

    .line 38
    .line 39
    goto :goto_30

    .line 40
    :cond_27
    iput v4, p0, La4;->b:I

    .line 41
    .line 42
    if-ne v0, p1, :cond_2c

    .line 43
    .line 44
    return-void

    .line 45
    :cond_2c
    invoke-virtual {p0, p1}, La4;->N(C)V

    .line 46
    .line 47
    .line 48
    throw v1

    .line 49
    :cond_30
    :goto_30
    move v0, v4

    .line 50
    goto :goto_a

    .line 51
    :cond_32
    iput v2, p0, La4;->b:I

    .line 52
    .line 53
    invoke-virtual {p0, p1}, La4;->N(C)V

    .line 54
    .line 55
    .line 56
    throw v1

    .line 57
    :cond_38
    invoke-virtual {p0, p1}, La4;->N(C)V

    .line 58
    .line 59
    .line 60
    throw v1
.end method

.method public j()J
    .registers 25

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    invoke-virtual {v0}, La4;->K()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    invoke-virtual {v0, v1}, La4;->F(I)I

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    iget-object v2, v0, La4;->g:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v2, Ljava/lang/String;

    .line 14
    .line 15
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 16
    .line 17
    .line 18
    move-result v3

    .line 19
    const-string v4, "EOF"

    .line 20
    .line 21
    const/4 v5, 0x6

    .line 22
    const/4 v6, 0x0

    .line 23
    const/4 v7, 0x0

    .line 24
    if-ge v1, v3, :cond_1ad

    .line 25
    .line 26
    const/4 v3, -0x1

    .line 27
    if-eq v1, v3, :cond_1ad

    .line 28
    .line 29
    invoke-virtual {v2, v1}, Ljava/lang/String;->charAt(I)C

    .line 30
    .line 31
    .line 32
    move-result v3

    .line 33
    const/16 v8, 0x22

    .line 34
    .line 35
    if-ne v3, v8, :cond_32

    .line 36
    .line 37
    add-int/lit8 v1, v1, 0x1

    .line 38
    .line 39
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 40
    .line 41
    .line 42
    move-result v3

    .line 43
    if-eq v1, v3, :cond_2e

    .line 44
    .line 45
    const/4 v3, 0x1

    .line 46
    goto :goto_33

    .line 47
    :cond_2e
    invoke-static {v0, v4, v7, v5}, La4;->s(La4;Ljava/lang/String;II)V

    .line 48
    .line 49
    .line 50
    throw v6

    .line 51
    :cond_32
    move v3, v7

    .line 52
    :goto_33
    move v12, v1

    .line 53
    move-object/from16 v19, v6

    .line 54
    .line 55
    move v11, v7

    .line 56
    move v13, v11

    .line 57
    move v14, v13

    .line 58
    const-wide/16 v9, 0x0

    .line 59
    .line 60
    const-wide/16 v15, 0x0

    .line 61
    .line 62
    const-wide/16 v17, 0x0

    .line 63
    .line 64
    :goto_3f
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 65
    .line 66
    .line 67
    move-result v6

    .line 68
    move-wide/from16 v20, v15

    .line 69
    .line 70
    const-string v15, "Numeric value overflow"

    .line 71
    .line 72
    if-eq v12, v6, :cond_115

    .line 73
    .line 74
    invoke-virtual {v2, v12}, Ljava/lang/String;->charAt(I)C

    .line 75
    .line 76
    .line 77
    move-result v6

    .line 78
    const/16 v5, 0x65

    .line 79
    .line 80
    const-string v7, "\' in numeric literal"

    .line 81
    .line 82
    const-string v8, "Unexpected symbol \'"

    .line 83
    .line 84
    if-eq v6, v5, :cond_59

    .line 85
    .line 86
    const/16 v5, 0x45

    .line 87
    .line 88
    if-ne v6, v5, :cond_7c

    .line 89
    .line 90
    :cond_59
    if-nez v13, :cond_7c

    .line 91
    .line 92
    if-eq v12, v1, :cond_68

    .line 93
    .line 94
    add-int/lit8 v12, v12, 0x1

    .line 95
    .line 96
    move-wide/from16 v15, v20

    .line 97
    .line 98
    const/4 v5, 0x6

    .line 99
    const/4 v7, 0x0

    .line 100
    const/16 v8, 0x22

    .line 101
    .line 102
    const/4 v11, 0x1

    .line 103
    const/4 v13, 0x1

    .line 104
    goto :goto_3f

    .line 105
    :cond_68
    new-instance v1, Ljava/lang/StringBuilder;

    .line 106
    .line 107
    invoke-direct {v1, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 108
    .line 109
    .line 110
    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 111
    .line 112
    .line 113
    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 114
    .line 115
    .line 116
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 117
    .line 118
    .line 119
    move-result-object v1

    .line 120
    const/4 v5, 0x4

    .line 121
    invoke-static {v0, v1, v12, v5}, La4;->s(La4;Ljava/lang/String;II)V

    .line 122
    .line 123
    .line 124
    throw v19

    .line 125
    :cond_7c
    const-string v5, "Unexpected symbol \'-\' in numeric literal"

    .line 126
    .line 127
    move/from16 v22, v3

    .line 128
    .line 129
    const/16 v3, 0x2d

    .line 130
    .line 131
    if-ne v6, v3, :cond_99

    .line 132
    .line 133
    if-eqz v13, :cond_99

    .line 134
    .line 135
    if-eq v12, v1, :cond_94

    .line 136
    .line 137
    add-int/lit8 v12, v12, 0x1

    .line 138
    .line 139
    move-wide/from16 v15, v20

    .line 140
    .line 141
    move/from16 v3, v22

    .line 142
    .line 143
    const/4 v5, 0x6

    .line 144
    const/4 v7, 0x0

    .line 145
    const/16 v8, 0x22

    .line 146
    .line 147
    const/4 v11, 0x0

    .line 148
    goto :goto_3f

    .line 149
    :cond_94
    const/4 v3, 0x4

    .line 150
    invoke-static {v0, v5, v12, v3}, La4;->s(La4;Ljava/lang/String;II)V

    .line 151
    .line 152
    .line 153
    throw v19

    .line 154
    :cond_99
    const/16 v3, 0x2b

    .line 155
    .line 156
    if-ne v6, v3, :cond_b4

    .line 157
    .line 158
    if-eqz v13, :cond_b4

    .line 159
    .line 160
    if-eq v12, v1, :cond_ad

    .line 161
    .line 162
    add-int/lit8 v12, v12, 0x1

    .line 163
    .line 164
    move-wide/from16 v15, v20

    .line 165
    .line 166
    move/from16 v3, v22

    .line 167
    .line 168
    const/4 v5, 0x6

    .line 169
    const/4 v7, 0x0

    .line 170
    const/16 v8, 0x22

    .line 171
    .line 172
    const/4 v11, 0x1

    .line 173
    goto :goto_3f

    .line 174
    :cond_ad
    const-string v1, "Unexpected symbol \'+\' in numeric literal"

    .line 175
    .line 176
    const/4 v3, 0x4

    .line 177
    invoke-static {v0, v1, v12, v3}, La4;->s(La4;Ljava/lang/String;II)V

    .line 178
    .line 179
    .line 180
    throw v19

    .line 181
    :cond_b4
    const/16 v3, 0x2d

    .line 182
    .line 183
    if-ne v6, v3, :cond_cc

    .line 184
    .line 185
    if-ne v12, v1, :cond_c7

    .line 186
    .line 187
    add-int/lit8 v12, v12, 0x1

    .line 188
    .line 189
    move-wide/from16 v15, v20

    .line 190
    .line 191
    move/from16 v3, v22

    .line 192
    .line 193
    const/4 v5, 0x6

    .line 194
    const/4 v7, 0x0

    .line 195
    const/16 v8, 0x22

    .line 196
    .line 197
    const/4 v14, 0x1

    .line 198
    goto/16 :goto_3f

    .line 199
    .line 200
    :cond_c7
    const/4 v3, 0x4

    .line 201
    invoke-static {v0, v5, v12, v3}, La4;->s(La4;Ljava/lang/String;II)V

    .line 202
    .line 203
    .line 204
    throw v19

    .line 205
    :cond_cc
    invoke-static {v6}, Lh23;->f(C)B

    .line 206
    .line 207
    .line 208
    move-result v3

    .line 209
    if-nez v3, :cond_117

    .line 210
    .line 211
    add-int/lit8 v3, v12, 0x1

    .line 212
    .line 213
    add-int/lit8 v5, v6, -0x30

    .line 214
    .line 215
    if-ltz v5, :cond_101

    .line 216
    .line 217
    move/from16 v23, v3

    .line 218
    .line 219
    const/16 v3, 0xa

    .line 220
    .line 221
    if-ge v5, v3, :cond_101

    .line 222
    .line 223
    const-wide/16 v6, 0xa

    .line 224
    .line 225
    if-eqz v13, :cond_f1

    .line 226
    .line 227
    mul-long/2addr v9, v6

    .line 228
    int-to-long v5, v5

    .line 229
    add-long/2addr v9, v5

    .line 230
    :goto_e5
    move-wide/from16 v15, v20

    .line 231
    .line 232
    move/from16 v3, v22

    .line 233
    .line 234
    move/from16 v12, v23

    .line 235
    .line 236
    const/4 v5, 0x6

    .line 237
    const/4 v7, 0x0

    .line 238
    const/16 v8, 0x22

    .line 239
    .line 240
    goto/16 :goto_3f

    .line 241
    .line 242
    :cond_f1
    mul-long v17, v17, v6

    .line 243
    .line 244
    int-to-long v5, v5

    .line 245
    sub-long v17, v17, v5

    .line 246
    .line 247
    cmp-long v3, v17, v20

    .line 248
    .line 249
    if-gtz v3, :cond_fb

    .line 250
    .line 251
    goto :goto_e5

    .line 252
    :cond_fb
    const/4 v3, 0x6

    .line 253
    const/4 v5, 0x0

    .line 254
    invoke-static {v0, v15, v5, v3}, La4;->s(La4;Ljava/lang/String;II)V

    .line 255
    .line 256
    .line 257
    throw v19

    .line 258
    :cond_101
    new-instance v1, Ljava/lang/StringBuilder;

    .line 259
    .line 260
    invoke-direct {v1, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 261
    .line 262
    .line 263
    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 264
    .line 265
    .line 266
    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 267
    .line 268
    .line 269
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 270
    .line 271
    .line 272
    move-result-object v1

    .line 273
    const/4 v3, 0x4

    .line 274
    invoke-static {v0, v1, v12, v3}, La4;->s(La4;Ljava/lang/String;II)V

    .line 275
    .line 276
    .line 277
    throw v19

    .line 278
    :cond_115
    move/from16 v22, v3

    .line 279
    .line 280
    :cond_117
    if-eq v12, v1, :cond_11b

    .line 281
    .line 282
    const/4 v3, 0x1

    .line 283
    goto :goto_11c

    .line 284
    :cond_11b
    const/4 v3, 0x0

    .line 285
    :goto_11c
    if-eq v1, v12, :cond_1a6

    .line 286
    .line 287
    if-eqz v14, :cond_124

    .line 288
    .line 289
    add-int/lit8 v5, v12, -0x1

    .line 290
    .line 291
    if-eq v1, v5, :cond_1a6

    .line 292
    .line 293
    :cond_124
    if-eqz v22, :cond_140

    .line 294
    .line 295
    if-eqz v3, :cond_13a

    .line 296
    .line 297
    invoke-virtual {v2, v12}, Ljava/lang/String;->charAt(I)C

    .line 298
    .line 299
    .line 300
    move-result v1

    .line 301
    const/16 v2, 0x22

    .line 302
    .line 303
    if-ne v1, v2, :cond_133

    .line 304
    .line 305
    add-int/lit8 v12, v12, 0x1

    .line 306
    .line 307
    goto :goto_140

    .line 308
    :cond_133
    const-string v1, "Expected closing quotation mark"

    .line 309
    .line 310
    const/4 v3, 0x4

    .line 311
    invoke-static {v0, v1, v12, v3}, La4;->s(La4;Ljava/lang/String;II)V

    .line 312
    .line 313
    .line 314
    throw v19

    .line 315
    :cond_13a
    const/4 v3, 0x6

    .line 316
    const/4 v5, 0x0

    .line 317
    invoke-static {v0, v4, v5, v3}, La4;->s(La4;Ljava/lang/String;II)V

    .line 318
    .line 319
    .line 320
    throw v19

    .line 321
    :cond_140
    :goto_140
    iput v12, v0, La4;->b:I

    .line 322
    .line 323
    move-wide/from16 v1, v17

    .line 324
    .line 325
    if-eqz v13, :cond_194

    .line 326
    .line 327
    long-to-double v1, v1

    .line 328
    const-wide/high16 v3, 0x4024000000000000L    # 10.0

    .line 329
    .line 330
    if-nez v11, :cond_152

    .line 331
    .line 332
    long-to-double v5, v9

    .line 333
    neg-double v5, v5

    .line 334
    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->pow(DD)D

    .line 335
    .line 336
    .line 337
    move-result-wide v3

    .line 338
    goto :goto_15a

    .line 339
    :cond_152
    const/4 v5, 0x1

    .line 340
    if-ne v11, v5, :cond_190

    .line 341
    .line 342
    long-to-double v5, v9

    .line 343
    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->pow(DD)D

    .line 344
    .line 345
    .line 346
    move-result-wide v3

    .line 347
    :goto_15a
    mul-double/2addr v1, v3

    .line 348
    const-wide/high16 v3, 0x43e0000000000000L    # 9.223372036854776E18

    .line 349
    .line 350
    cmpl-double v3, v1, v3

    .line 351
    .line 352
    if-gtz v3, :cond_18a

    .line 353
    .line 354
    const-wide/high16 v3, -0x3c20000000000000L    # -9.223372036854776E18

    .line 355
    .line 356
    cmpg-double v3, v1, v3

    .line 357
    .line 358
    if-ltz v3, :cond_18a

    .line 359
    .line 360
    invoke-static {v1, v2}, Ljava/lang/Math;->floor(D)D

    .line 361
    .line 362
    .line 363
    move-result-wide v3

    .line 364
    cmpg-double v3, v3, v1

    .line 365
    .line 366
    if-nez v3, :cond_171

    .line 367
    .line 368
    double-to-long v10, v1

    .line 369
    goto :goto_195

    .line 370
    :cond_171
    new-instance v3, Ljava/lang/StringBuilder;

    .line 371
    .line 372
    const-string v4, "Can\'t convert "

    .line 373
    .line 374
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 375
    .line 376
    .line 377
    invoke-virtual {v3, v1, v2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 378
    .line 379
    .line 380
    const-string v1, " to Long"

    .line 381
    .line 382
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 383
    .line 384
    .line 385
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 386
    .line 387
    .line 388
    move-result-object v1

    .line 389
    const/4 v3, 0x6

    .line 390
    const/4 v5, 0x0

    .line 391
    invoke-static {v0, v1, v5, v3}, La4;->s(La4;Ljava/lang/String;II)V

    .line 392
    .line 393
    .line 394
    throw v19

    .line 395
    :cond_18a
    const/4 v3, 0x6

    .line 396
    const/4 v5, 0x0

    .line 397
    invoke-static {v0, v15, v5, v3}, La4;->s(La4;Ljava/lang/String;II)V

    .line 398
    .line 399
    .line 400
    throw v19

    .line 401
    :cond_190
    invoke-static {}, Lm03;->a()V

    .line 402
    .line 403
    .line 404
    return-wide v20

    .line 405
    :cond_194
    move-wide v10, v1

    .line 406
    :goto_195
    if-eqz v14, :cond_198

    .line 407
    .line 408
    return-wide v10

    .line 409
    :cond_198
    const-wide/high16 v1, -0x8000000000000000L

    .line 410
    .line 411
    cmp-long v1, v10, v1

    .line 412
    .line 413
    if-eqz v1, :cond_1a0

    .line 414
    .line 415
    neg-long v0, v10

    .line 416
    return-wide v0

    .line 417
    :cond_1a0
    const/4 v3, 0x6

    .line 418
    const/4 v5, 0x0

    .line 419
    invoke-static {v0, v15, v5, v3}, La4;->s(La4;Ljava/lang/String;II)V

    .line 420
    .line 421
    .line 422
    throw v19

    .line 423
    :cond_1a6
    const-string v1, "Expected numeric literal"

    .line 424
    .line 425
    const/4 v3, 0x4

    .line 426
    invoke-static {v0, v1, v12, v3}, La4;->s(La4;Ljava/lang/String;II)V

    .line 427
    .line 428
    .line 429
    throw v19

    .line 430
    :cond_1ad
    move v3, v5

    .line 431
    move-object/from16 v19, v6

    .line 432
    .line 433
    move v5, v7

    .line 434
    invoke-static {v0, v4, v5, v3}, La4;->s(La4;Ljava/lang/String;II)V

    .line 435
    .line 436
    .line 437
    throw v19
.end method

.method public k()V
    .registers 7

    .line 1
    iget-object v0, p0, La4;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/util/ArrayList;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const/4 v2, 0x0

    .line 10
    move v3, v2

    .line 11
    :goto_a
    if-ge v3, v1, :cond_1c

    .line 12
    .line 13
    iget-object v4, p0, La4;->f:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v4, Landroidx/recyclerview/widget/b;

    .line 16
    .line 17
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v5

    .line 21
    check-cast v5, Lz3;

    .line 22
    .line 23
    invoke-virtual {v4, v5}, Landroidx/recyclerview/widget/b;->a(Lz3;)V

    .line 24
    .line 25
    .line 26
    add-int/lit8 v3, v3, 0x1

    .line 27
    .line 28
    goto :goto_a

    .line 29
    :cond_1c
    invoke-virtual {p0, v0}, La4;->G(Ljava/util/ArrayList;)V

    .line 30
    .line 31
    .line 32
    iput v2, p0, La4;->b:I

    .line 33
    .line 34
    return-void
.end method

.method public l()Ljava/lang/String;
    .registers 3

    .line 1
    iget-object v0, p0, La4;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/lang/String;

    .line 4
    .line 5
    if-eqz v0, :cond_d

    .line 6
    .line 7
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    const/4 v1, 0x0

    .line 11
    iput-object v1, p0, La4;->e:Ljava/lang/Object;

    .line 12
    .line 13
    return-object v0

    .line 14
    :cond_d
    invoke-virtual {p0}, La4;->f()Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    return-object p0
.end method

.method public m()Ljava/lang/String;
    .registers 9

    .line 1
    iget-object v0, p0, La4;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/lang/StringBuilder;

    .line 4
    .line 5
    iget-object v1, p0, La4;->g:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Ljava/lang/String;

    .line 8
    .line 9
    iget-object v2, p0, La4;->e:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v2, Ljava/lang/String;

    .line 12
    .line 13
    const/4 v3, 0x0

    .line 14
    if-eqz v2, :cond_15

    .line 15
    .line 16
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    iput-object v3, p0, La4;->e:Ljava/lang/Object;

    .line 20
    .line 21
    return-object v2

    .line 22
    :cond_15
    invoke-virtual {p0}, La4;->K()I

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 27
    .line 28
    .line 29
    move-result v4

    .line 30
    if-ge v2, v4, :cond_95

    .line 31
    .line 32
    const/4 v4, -0x1

    .line 33
    if-eq v2, v4, :cond_95

    .line 34
    .line 35
    invoke-virtual {v1, v2}, Ljava/lang/String;->charAt(I)C

    .line 36
    .line 37
    .line 38
    move-result v5

    .line 39
    invoke-static {v5}, Lh23;->f(C)B

    .line 40
    .line 41
    .line 42
    move-result v5

    .line 43
    const/4 v6, 0x1

    .line 44
    if-ne v5, v6, :cond_32

    .line 45
    .line 46
    invoke-virtual {p0}, La4;->l()Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object p0

    .line 50
    return-object p0

    .line 51
    :cond_32
    const/4 v7, 0x0

    .line 52
    if-nez v5, :cond_7e

    .line 53
    .line 54
    move v3, v7

    .line 55
    :cond_36
    :goto_36
    invoke-virtual {v1, v2}, Ljava/lang/String;->charAt(I)C

    .line 56
    .line 57
    .line 58
    move-result v5

    .line 59
    invoke-static {v5}, Lh23;->f(C)B

    .line 60
    .line 61
    .line 62
    move-result v5

    .line 63
    if-nez v5, :cond_63

    .line 64
    .line 65
    add-int/lit8 v2, v2, 0x1

    .line 66
    .line 67
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 68
    .line 69
    .line 70
    move-result v5

    .line 71
    if-lt v2, v5, :cond_36

    .line 72
    .line 73
    iget v3, p0, La4;->b:I

    .line 74
    .line 75
    invoke-virtual {v0, v1, v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    .line 76
    .line 77
    .line 78
    invoke-virtual {p0, v2}, La4;->F(I)I

    .line 79
    .line 80
    .line 81
    move-result v3

    .line 82
    if-ne v3, v4, :cond_60

    .line 83
    .line 84
    iput v2, p0, La4;->b:I

    .line 85
    .line 86
    invoke-virtual {v0, v1, v7, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    .line 87
    .line 88
    .line 89
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object p0

    .line 93
    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->setLength(I)V

    .line 94
    .line 95
    .line 96
    return-object p0

    .line 97
    :cond_60
    move v2, v3

    .line 98
    move v3, v6

    .line 99
    goto :goto_36

    .line 100
    :cond_63
    iget v4, p0, La4;->b:I

    .line 101
    .line 102
    if-nez v3, :cond_70

    .line 103
    .line 104
    invoke-virtual {v1, v4, v2}, Ljava/lang/String;->subSequence(II)Ljava/lang/CharSequence;

    .line 105
    .line 106
    .line 107
    move-result-object v0

    .line 108
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 109
    .line 110
    .line 111
    move-result-object v0

    .line 112
    goto :goto_7b

    .line 113
    :cond_70
    invoke-virtual {v0, v1, v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    .line 114
    .line 115
    .line 116
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 117
    .line 118
    .line 119
    move-result-object v1

    .line 120
    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->setLength(I)V

    .line 121
    .line 122
    .line 123
    move-object v0, v1

    .line 124
    :goto_7b
    iput v2, p0, La4;->b:I

    .line 125
    .line 126
    return-object v0

    .line 127
    :cond_7e
    new-instance v0, Ljava/lang/StringBuilder;

    .line 128
    .line 129
    const-string v4, "Expected beginning of the string, but got "

    .line 130
    .line 131
    invoke-direct {v0, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 132
    .line 133
    .line 134
    invoke-virtual {v1, v2}, Ljava/lang/String;->charAt(I)C

    .line 135
    .line 136
    .line 137
    move-result v1

    .line 138
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 139
    .line 140
    .line 141
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 142
    .line 143
    .line 144
    move-result-object v0

    .line 145
    const/4 v1, 0x6

    .line 146
    invoke-static {p0, v0, v7, v1}, La4;->s(La4;Ljava/lang/String;II)V

    .line 147
    .line 148
    .line 149
    throw v3

    .line 150
    :cond_95
    const-string v0, "EOF"

    .line 151
    .line 152
    const/4 v1, 0x4

    .line 153
    invoke-static {p0, v0, v2, v1}, La4;->s(La4;Ljava/lang/String;II)V

    .line 154
    .line 155
    .line 156
    throw v3
.end method

.method public n()V
    .registers 10

    .line 1
    iget-object v0, p0, La4;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/recyclerview/widget/b;

    .line 4
    .line 5
    invoke-virtual {p0}, La4;->k()V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, La4;->d:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v1, Ljava/util/ArrayList;

    .line 11
    .line 12
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    const/4 v3, 0x0

    .line 17
    move v4, v3

    .line 18
    :goto_11
    if-ge v4, v2, :cond_64

    .line 19
    .line 20
    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v5

    .line 24
    check-cast v5, Lz3;

    .line 25
    .line 26
    iget v6, v5, Lz3;->a:I

    .line 27
    .line 28
    const/4 v7, 0x1

    .line 29
    if-eq v6, v7, :cond_57

    .line 30
    .line 31
    const/4 v8, 0x2

    .line 32
    if-eq v6, v8, :cond_41

    .line 33
    .line 34
    const/4 v7, 0x4

    .line 35
    if-eq v6, v7, :cond_34

    .line 36
    .line 37
    const/16 v7, 0x8

    .line 38
    .line 39
    if-eq v6, v7, :cond_29

    .line 40
    .line 41
    goto :goto_61

    .line 42
    :cond_29
    invoke-virtual {v0, v5}, Landroidx/recyclerview/widget/b;->a(Lz3;)V

    .line 43
    .line 44
    .line 45
    iget v6, v5, Lz3;->b:I

    .line 46
    .line 47
    iget v5, v5, Lz3;->d:I

    .line 48
    .line 49
    invoke-virtual {v0, v6, v5}, Landroidx/recyclerview/widget/b;->e(II)V

    .line 50
    .line 51
    .line 52
    goto :goto_61

    .line 53
    :cond_34
    invoke-virtual {v0, v5}, Landroidx/recyclerview/widget/b;->a(Lz3;)V

    .line 54
    .line 55
    .line 56
    iget v6, v5, Lz3;->b:I

    .line 57
    .line 58
    iget v7, v5, Lz3;->d:I

    .line 59
    .line 60
    iget-object v5, v5, Lz3;->c:Ljava/lang/Object;

    .line 61
    .line 62
    invoke-virtual {v0, v6, v7, v5}, Landroidx/recyclerview/widget/b;->c(IILjava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    goto :goto_61

    .line 66
    :cond_41
    invoke-virtual {v0, v5}, Landroidx/recyclerview/widget/b;->a(Lz3;)V

    .line 67
    .line 68
    .line 69
    iget v6, v5, Lz3;->b:I

    .line 70
    .line 71
    iget v5, v5, Lz3;->d:I

    .line 72
    .line 73
    iget-object v8, v0, Landroidx/recyclerview/widget/b;->a:Landroidx/recyclerview/widget/RecyclerView;

    .line 74
    .line 75
    invoke-virtual {v8, v6, v5, v7}, Landroidx/recyclerview/widget/RecyclerView;->Q(IIZ)V

    .line 76
    .line 77
    .line 78
    iput-boolean v7, v8, Landroidx/recyclerview/widget/RecyclerView;->C0:Z

    .line 79
    .line 80
    iget-object v6, v8, Landroidx/recyclerview/widget/RecyclerView;->z0:Lcc2;

    .line 81
    .line 82
    iget v7, v6, Lcc2;->c:I

    .line 83
    .line 84
    add-int/2addr v7, v5

    .line 85
    iput v7, v6, Lcc2;->c:I

    .line 86
    .line 87
    goto :goto_61

    .line 88
    :cond_57
    invoke-virtual {v0, v5}, Landroidx/recyclerview/widget/b;->a(Lz3;)V

    .line 89
    .line 90
    .line 91
    iget v6, v5, Lz3;->b:I

    .line 92
    .line 93
    iget v5, v5, Lz3;->d:I

    .line 94
    .line 95
    invoke-virtual {v0, v6, v5}, Landroidx/recyclerview/widget/b;->d(II)V

    .line 96
    .line 97
    .line 98
    :goto_61
    add-int/lit8 v4, v4, 0x1

    .line 99
    .line 100
    goto :goto_11

    .line 101
    :cond_64
    invoke-virtual {p0, v1}, La4;->G(Ljava/util/ArrayList;)V

    .line 102
    .line 103
    .line 104
    iput v3, p0, La4;->b:I

    .line 105
    .line 106
    return-void
.end method

.method public p(Lz3;)V
    .registers 15

    .line 1
    iget-object v0, p0, La4;->c:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lp22;

    .line 4
    .line 5
    iget v1, p1, Lz3;->a:I

    .line 6
    .line 7
    const/4 v2, 0x1

    .line 8
    if-eq v1, v2, :cond_79

    .line 9
    .line 10
    const/16 v3, 0x8

    .line 11
    .line 12
    if-eq v1, v3, :cond_79

    .line 13
    .line 14
    iget v3, p1, Lz3;->b:I

    .line 15
    .line 16
    invoke-virtual {p0, v3, v1}, La4;->O(II)I

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    iget v3, p1, Lz3;->b:I

    .line 21
    .line 22
    iget v4, p1, Lz3;->a:I

    .line 23
    .line 24
    const/4 v5, 0x2

    .line 25
    const/4 v6, 0x4

    .line 26
    if-eq v4, v5, :cond_25

    .line 27
    .line 28
    if-ne v4, v6, :cond_1f

    .line 29
    .line 30
    move v4, v2

    .line 31
    goto :goto_26

    .line 32
    :cond_1f
    const-string p0, "op should be remove or update."

    .line 33
    .line 34
    invoke-static {p1, p0}, Lt12;->i(Ljava/lang/Object;Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    return-void

    .line 38
    :cond_25
    const/4 v4, 0x0

    .line 39
    :goto_26
    move v7, v2

    .line 40
    move v8, v7

    .line 41
    :goto_28
    iget v9, p1, Lz3;->d:I

    .line 42
    .line 43
    const/4 v10, 0x0

    .line 44
    if-ge v7, v9, :cond_61

    .line 45
    .line 46
    iget v9, p1, Lz3;->b:I

    .line 47
    .line 48
    mul-int v11, v4, v7

    .line 49
    .line 50
    add-int/2addr v11, v9

    .line 51
    iget v9, p1, Lz3;->a:I

    .line 52
    .line 53
    invoke-virtual {p0, v11, v9}, La4;->O(II)I

    .line 54
    .line 55
    .line 56
    move-result v9

    .line 57
    iget v11, p1, Lz3;->a:I

    .line 58
    .line 59
    if-eq v11, v5, :cond_44

    .line 60
    .line 61
    if-eq v11, v6, :cond_3f

    .line 62
    .line 63
    goto :goto_49

    .line 64
    :cond_3f
    add-int/lit8 v12, v1, 0x1

    .line 65
    .line 66
    if-ne v9, v12, :cond_49

    .line 67
    .line 68
    goto :goto_46

    .line 69
    :cond_44
    if-ne v9, v1, :cond_49

    .line 70
    .line 71
    :goto_46
    add-int/lit8 v8, v8, 0x1

    .line 72
    .line 73
    goto :goto_5e

    .line 74
    :cond_49
    :goto_49
    iget-object v12, p1, Lz3;->c:Ljava/lang/Object;

    .line 75
    .line 76
    invoke-virtual {p0, v12, v11, v1, v8}, La4;->z(Ljava/lang/Object;III)Lz3;

    .line 77
    .line 78
    .line 79
    move-result-object v1

    .line 80
    invoke-virtual {p0, v1, v3}, La4;->q(Lz3;I)V

    .line 81
    .line 82
    .line 83
    iput-object v10, v1, Lz3;->c:Ljava/lang/Object;

    .line 84
    .line 85
    invoke-virtual {v0, v1}, Lp22;->a(Ljava/lang/Object;)Z

    .line 86
    .line 87
    .line 88
    iget v1, p1, Lz3;->a:I

    .line 89
    .line 90
    if-ne v1, v6, :cond_5c

    .line 91
    .line 92
    add-int/2addr v3, v8

    .line 93
    :cond_5c
    move v8, v2

    .line 94
    move v1, v9

    .line 95
    :goto_5e
    add-int/lit8 v7, v7, 0x1

    .line 96
    .line 97
    goto :goto_28

    .line 98
    :cond_61
    iget-object v2, p1, Lz3;->c:Ljava/lang/Object;

    .line 99
    .line 100
    iput-object v10, p1, Lz3;->c:Ljava/lang/Object;

    .line 101
    .line 102
    invoke-virtual {v0, p1}, Lp22;->a(Ljava/lang/Object;)Z

    .line 103
    .line 104
    .line 105
    if-lez v8, :cond_78

    .line 106
    .line 107
    iget p1, p1, Lz3;->a:I

    .line 108
    .line 109
    invoke-virtual {p0, v2, p1, v1, v8}, La4;->z(Ljava/lang/Object;III)Lz3;

    .line 110
    .line 111
    .line 112
    move-result-object p1

    .line 113
    invoke-virtual {p0, p1, v3}, La4;->q(Lz3;I)V

    .line 114
    .line 115
    .line 116
    iput-object v10, p1, Lz3;->c:Ljava/lang/Object;

    .line 117
    .line 118
    invoke-virtual {v0, p1}, Lp22;->a(Ljava/lang/Object;)Z

    .line 119
    .line 120
    .line 121
    :cond_78
    return-void

    .line 122
    :cond_79
    const-string p0, "should not dispatch add or move for pre layout"

    .line 123
    .line 124
    invoke-static {p0}, Lm03;->g(Ljava/lang/String;)V

    .line 125
    .line 126
    .line 127
    return-void
.end method

.method public q(Lz3;I)V
    .registers 5

    .line 1
    iget-object p0, p0, La4;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Landroidx/recyclerview/widget/b;

    .line 4
    .line 5
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/b;->a(Lz3;)V

    .line 6
    .line 7
    .line 8
    iget v0, p1, Lz3;->a:I

    .line 9
    .line 10
    const/4 v1, 0x2

    .line 11
    if-eq v0, v1, :cond_1d

    .line 12
    .line 13
    const/4 v1, 0x4

    .line 14
    if-ne v0, v1, :cond_17

    .line 15
    .line 16
    iget v0, p1, Lz3;->d:I

    .line 17
    .line 18
    iget-object p1, p1, Lz3;->c:Ljava/lang/Object;

    .line 19
    .line 20
    invoke-virtual {p0, p2, v0, p1}, Landroidx/recyclerview/widget/b;->c(IILjava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    return-void

    .line 24
    :cond_17
    const-string p0, "only remove and update ops can be dispatched in first pass"

    .line 25
    .line 26
    invoke-static {p0}, Lm03;->g(Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :cond_1d
    iget p1, p1, Lz3;->d:I

    .line 31
    .line 32
    iget-object p0, p0, Landroidx/recyclerview/widget/b;->a:Landroidx/recyclerview/widget/RecyclerView;

    .line 33
    .line 34
    const/4 v0, 0x1

    .line 35
    invoke-virtual {p0, p2, p1, v0}, Landroidx/recyclerview/widget/RecyclerView;->Q(IIZ)V

    .line 36
    .line 37
    .line 38
    iput-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->C0:Z

    .line 39
    .line 40
    iget-object p0, p0, Landroidx/recyclerview/widget/RecyclerView;->z0:Lcc2;

    .line 41
    .line 42
    iget p2, p0, Lcc2;->c:I

    .line 43
    .line 44
    add-int/2addr p2, p1

    .line 45
    iput p2, p0, Lcc2;->c:I

    .line 46
    .line 47
    return-void
.end method

.method public r(Ljava/lang/String;Ljava/lang/String;I)V
    .registers 6

    .line 1
    iget-object v0, p0, La4;->d:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lvv;

    .line 4
    .line 5
    invoke-virtual {v0}, Lvv;->a()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iget-object v1, p0, La4;->g:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v1, Ljava/lang/String;

    .line 12
    .line 13
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    iget-object p0, p0, La4;->c:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast p0, Lq61;

    .line 19
    .line 20
    iget-boolean p0, p0, Lq61;->g:Z

    .line 21
    .line 22
    if-eqz p0, :cond_20

    .line 23
    .line 24
    invoke-static {v1, p3}, Lsn2;->t(Ljava/lang/CharSequence;I)Ljava/lang/CharSequence;

    .line 25
    .line 26
    .line 27
    move-result-object p0

    .line 28
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object p0

    .line 32
    goto :goto_21

    .line 33
    :cond_20
    const/4 p0, 0x0

    .line 34
    :goto_21
    new-instance v1, Lz61;

    .line 35
    .line 36
    invoke-static {p3, p1, v0, p2, p0}, Lsn2;->l(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object p0

    .line 40
    invoke-direct {v1, p0}, Lj71;-><init>(Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    throw v1
.end method

.method public t(II)I
    .registers 8

    .line 1
    iget-object p0, p0, La4;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Ljava/util/ArrayList;

    .line 4
    .line 5
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    :goto_8
    if-ge p2, v0, :cond_3f

    .line 10
    .line 11
    invoke-virtual {p0, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    check-cast v1, Lz3;

    .line 16
    .line 17
    iget v2, v1, Lz3;->a:I

    .line 18
    .line 19
    iget v3, v1, Lz3;->b:I

    .line 20
    .line 21
    const/16 v4, 0x8

    .line 22
    .line 23
    if-ne v2, v4, :cond_28

    .line 24
    .line 25
    if-ne v3, p1, :cond_1d

    .line 26
    .line 27
    iget p1, v1, Lz3;->d:I

    .line 28
    .line 29
    goto :goto_3c

    .line 30
    :cond_1d
    if-ge v3, p1, :cond_21

    .line 31
    .line 32
    add-int/lit8 p1, p1, -0x1

    .line 33
    .line 34
    :cond_21
    iget v1, v1, Lz3;->d:I

    .line 35
    .line 36
    if-gt v1, p1, :cond_3c

    .line 37
    .line 38
    add-int/lit8 p1, p1, 0x1

    .line 39
    .line 40
    goto :goto_3c

    .line 41
    :cond_28
    if-gt v3, p1, :cond_3c

    .line 42
    .line 43
    const/4 v4, 0x2

    .line 44
    if-ne v2, v4, :cond_36

    .line 45
    .line 46
    iget v1, v1, Lz3;->d:I

    .line 47
    .line 48
    add-int/2addr v3, v1

    .line 49
    if-ge p1, v3, :cond_34

    .line 50
    .line 51
    const/4 p0, -0x1

    .line 52
    return p0

    .line 53
    :cond_34
    sub-int/2addr p1, v1

    .line 54
    goto :goto_3c

    .line 55
    :cond_36
    const/4 v3, 0x1

    .line 56
    if-ne v2, v3, :cond_3c

    .line 57
    .line 58
    iget v1, v1, Lz3;->d:I

    .line 59
    .line 60
    add-int/2addr p1, v1

    .line 61
    :cond_3c
    :goto_3c
    add-int/lit8 p2, p2, 0x1

    .line 62
    .line 63
    goto :goto_8

    .line 64
    :cond_3f
    return p1
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    .line 1
    iget v0, p0, La4;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_2c

    .line 4
    .line 5
    .line 6
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    return-object p0

    .line 11
    :pswitch_a
    new-instance v0, Ljava/lang/StringBuilder;

    .line 12
    .line 13
    const-string v1, "JsonReader(source=\'"

    .line 14
    .line 15
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    iget-object v1, p0, La4;->g:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v1, Ljava/lang/String;

    .line 21
    .line 22
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 23
    .line 24
    .line 25
    const-string v1, "\', currentPosition="

    .line 26
    .line 27
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    iget p0, p0, La4;->b:I

    .line 31
    .line 32
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 33
    .line 34
    .line 35
    const/16 p0, 0x29

    .line 36
    .line 37
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 38
    .line 39
    .line 40
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object p0

    .line 44
    return-object p0

    .line 45
    :pswitch_data_2c
    .packed-switch 0x3
        :pswitch_a
    .end packed-switch
.end method

.method public u(Ljava/lang/CharSequence;I)I
    .registers 4

    .line 1
    invoke-interface {p1, p2}, Ljava/lang/CharSequence;->charAt(I)C

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    const/16 p2, 0x30

    .line 6
    .line 7
    if-gt p2, p1, :cond_e

    .line 8
    .line 9
    const/16 v0, 0x3a

    .line 10
    .line 11
    if-ge p1, v0, :cond_e

    .line 12
    .line 13
    sub-int/2addr p1, p2

    .line 14
    return p1

    .line 15
    :cond_e
    const/16 p2, 0x61

    .line 16
    .line 17
    if-gt p2, p1, :cond_19

    .line 18
    .line 19
    const/16 p2, 0x67

    .line 20
    .line 21
    if-ge p1, p2, :cond_19

    .line 22
    .line 23
    add-int/lit8 p1, p1, -0x57

    .line 24
    .line 25
    return p1

    .line 26
    :cond_19
    const/16 p2, 0x41

    .line 27
    .line 28
    if-gt p2, p1, :cond_24

    .line 29
    .line 30
    const/16 p2, 0x47

    .line 31
    .line 32
    if-ge p1, p2, :cond_24

    .line 33
    .line 34
    add-int/lit8 p1, p1, -0x37

    .line 35
    .line 36
    return p1

    .line 37
    :cond_24
    new-instance p2, Ljava/lang/StringBuilder;

    .line 38
    .line 39
    const-string v0, "Invalid toHexChar char \'"

    .line 40
    .line 41
    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 45
    .line 46
    .line 47
    const-string p1, "\' in unicode escape"

    .line 48
    .line 49
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 50
    .line 51
    .line 52
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object p1

    .line 56
    const/4 p2, 0x0

    .line 57
    const/4 v0, 0x6

    .line 58
    invoke-static {p0, p1, p2, v0}, La4;->s(La4;Ljava/lang/String;II)V

    .line 59
    .line 60
    .line 61
    const/4 p0, 0x0

    .line 62
    throw p0
.end method

.method public v()Landroid/content/res/ColorStateList;
    .registers 1

    .line 1
    iget-object p0, p0, La4;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Liy;

    .line 4
    .line 5
    if-eqz p0, :cond_b

    .line 6
    .line 7
    iget-object p0, p0, Liy;->c:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast p0, Landroid/content/res/ColorStateList;

    .line 10
    .line 11
    return-object p0

    .line 12
    :cond_b
    const/4 p0, 0x0

    .line 13
    return-object p0
.end method

.method public w()Landroid/graphics/PorterDuff$Mode;
    .registers 1

    .line 1
    iget-object p0, p0, La4;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Liy;

    .line 4
    .line 5
    if-eqz p0, :cond_b

    .line 6
    .line 7
    iget-object p0, p0, Liy;->d:Ljava/io/Serializable;

    .line 8
    .line 9
    check-cast p0, Landroid/graphics/PorterDuff$Mode;

    .line 10
    .line 11
    return-object p0

    .line 12
    :cond_b
    const/4 p0, 0x0

    .line 13
    return-object p0
.end method

.method public x()Z
    .registers 1

    .line 1
    iget-object p0, p0, La4;->d:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Ljava/util/ArrayList;

    .line 4
    .line 5
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    .line 6
    .line 7
    .line 8
    move-result p0

    .line 9
    if-lez p0, :cond_c

    .line 10
    .line 11
    const/4 p0, 0x1

    .line 12
    return p0

    .line 13
    :cond_c
    const/4 p0, 0x0

    .line 14
    return p0
.end method

.method public y(Landroid/util/AttributeSet;I)V
    .registers 13

    .line 1
    iget-object v0, p0, La4;->c:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/view/View;

    .line 4
    .line 5
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    sget-object v4, Laa2;->z:[I

    .line 10
    .line 11
    const/4 v8, 0x0

    .line 12
    invoke-static {p2, v8, v1, p1, v4}, Lt51;->f(IILandroid/content/Context;Landroid/util/AttributeSet;[I)Lt51;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    iget-object v2, v1, Lt51;->c:Ljava/lang/Object;

    .line 17
    .line 18
    move-object v9, v2

    .line 19
    check-cast v9, Landroid/content/res/TypedArray;

    .line 20
    .line 21
    iget-object v2, p0, La4;->c:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v2, Landroid/view/View;

    .line 24
    .line 25
    invoke-virtual {v2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 26
    .line 27
    .line 28
    move-result-object v3

    .line 29
    iget-object v5, v1, Lt51;->c:Ljava/lang/Object;

    .line 30
    .line 31
    move-object v6, v5

    .line 32
    check-cast v6, Landroid/content/res/TypedArray;

    .line 33
    .line 34
    move-object v5, p1

    .line 35
    move v7, p2

    .line 36
    invoke-static/range {v2 .. v7}, Ln83;->m(Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;I)V

    .line 37
    .line 38
    .line 39
    :try_start_26
    invoke-virtual {v9, v8}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 40
    .line 41
    .line 42
    move-result p1

    .line 43
    const/4 p2, -0x1

    .line 44
    if-eqz p1, :cond_52

    .line 45
    .line 46
    invoke-virtual {v9, v8, p2}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 47
    .line 48
    .line 49
    move-result p1

    .line 50
    iput p1, p0, La4;->b:I

    .line 51
    .line 52
    iget-object p1, p0, La4;->d:Ljava/lang/Object;

    .line 53
    .line 54
    check-cast p1, Lz8;

    .line 55
    .line 56
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 57
    .line 58
    .line 59
    move-result-object v2

    .line 60
    iget v3, p0, La4;->b:I

    .line 61
    .line 62
    monitor-enter p1
    :try_end_3e
    .catchall {:try_start_26 .. :try_end_3e} :catchall_4b

    .line 63
    :try_start_3e
    iget-object v4, p1, Lz8;->a:Lzf2;

    .line 64
    .line 65
    invoke-virtual {v4, v2, v3}, Lzf2;->f(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    .line 66
    .line 67
    .line 68
    move-result-object v2
    :try_end_44
    .catchall {:try_start_3e .. :try_end_44} :catchall_4e

    .line 69
    :try_start_44
    monitor-exit p1

    .line 70
    if-eqz v2, :cond_52

    .line 71
    .line 72
    invoke-virtual {p0, v2}, La4;->H(Landroid/content/res/ColorStateList;)V
    :try_end_4a
    .catchall {:try_start_44 .. :try_end_4a} :catchall_4b

    .line 73
    .line 74
    .line 75
    goto :goto_52

    .line 76
    :catchall_4b
    move-exception v0

    .line 77
    move-object p0, v0

    .line 78
    goto :goto_77

    .line 79
    :catchall_4e
    move-exception v0

    .line 80
    move-object p0, v0

    .line 81
    :try_start_50
    monitor-exit p1
    :try_end_51
    .catchall {:try_start_50 .. :try_end_51} :catchall_4e

    .line 82
    :try_start_51
    throw p0

    .line 83
    :cond_52
    :goto_52
    const/4 p0, 0x1

    .line 84
    invoke-virtual {v9, p0}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 85
    .line 86
    .line 87
    move-result p1

    .line 88
    if-eqz p1, :cond_60

    .line 89
    .line 90
    invoke-virtual {v1, p0}, Lt51;->b(I)Landroid/content/res/ColorStateList;

    .line 91
    .line 92
    .line 93
    move-result-object p0

    .line 94
    invoke-virtual {v0, p0}, Landroid/view/View;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 95
    .line 96
    .line 97
    :cond_60
    const/4 p0, 0x2

    .line 98
    invoke-virtual {v9, p0}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 99
    .line 100
    .line 101
    move-result p1

    .line 102
    if-eqz p1, :cond_73

    .line 103
    .line 104
    invoke-virtual {v9, p0, p2}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 105
    .line 106
    .line 107
    move-result p0

    .line 108
    const/4 p1, 0x0

    .line 109
    invoke-static {p0, p1}, Lte0;->c(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;

    .line 110
    .line 111
    .line 112
    move-result-object p0

    .line 113
    invoke-virtual {v0, p0}, Landroid/view/View;->setBackgroundTintMode(Landroid/graphics/PorterDuff$Mode;)V
    :try_end_73
    .catchall {:try_start_51 .. :try_end_73} :catchall_4b

    .line 114
    .line 115
    .line 116
    :cond_73
    invoke-virtual {v1}, Lt51;->h()V

    .line 117
    .line 118
    .line 119
    return-void

    .line 120
    :goto_77
    invoke-virtual {v1}, Lt51;->h()V

    .line 121
    .line 122
    .line 123
    throw p0
.end method

.method public z(Ljava/lang/Object;III)Lz3;
    .registers 5

    .line 1
    iget-object p0, p0, La4;->c:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lp22;

    .line 4
    .line 5
    invoke-virtual {p0}, Lp22;->g()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    check-cast p0, Lz3;

    .line 10
    .line 11
    if-nez p0, :cond_1a

    .line 12
    .line 13
    new-instance p0, Lz3;

    .line 14
    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 16
    .line 17
    .line 18
    iput p2, p0, Lz3;->a:I

    .line 19
    .line 20
    iput p3, p0, Lz3;->b:I

    .line 21
    .line 22
    iput p4, p0, Lz3;->d:I

    .line 23
    .line 24
    iput-object p1, p0, Lz3;->c:Ljava/lang/Object;

    .line 25
    .line 26
    return-object p0

    .line 27
    :cond_1a
    iput p2, p0, Lz3;->a:I

    .line 28
    .line 29
    iput p3, p0, Lz3;->b:I

    .line 30
    .line 31
    iput p4, p0, Lz3;->d:I

    .line 32
    .line 33
    iput-object p1, p0, Lz3;->c:Ljava/lang/Object;

    .line 34
    .line 35
    return-object p0
.end method
