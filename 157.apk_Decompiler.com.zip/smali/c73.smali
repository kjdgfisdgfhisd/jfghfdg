###### Class defpackage.c73 (c73)
.class public Lc73;
.super Le73;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lh12;


# instance fields
.field public final j:I

.field public final l:Z

.field public final m:Z

.field public final n:Z

.field public final o:Lgg1;

.field public final p:Lc73;


# direct methods
.method public constructor <init>(Llo;Lc73;ILl7;Ldv1;Lgg1;ZZZLgg1;Loq2;)V
    .registers 18

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    invoke-virtual/range {p11 .. p11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    move-object v0, p0

    .line 17
    move-object v1, p1

    .line 18
    move-object v2, p4

    .line 19
    move-object v3, p5

    .line 20
    move-object v4, p6

    .line 21
    move-object/from16 v5, p11

    .line 22
    .line 23
    invoke-direct/range {v0 .. v5}, Le73;-><init>(Lm60;Ll7;Ldv1;Lgg1;Loq2;)V

    .line 24
    .line 25
    .line 26
    iput p3, p0, Lc73;->j:I

    .line 27
    .line 28
    iput-boolean p7, p0, Lc73;->l:Z

    .line 29
    .line 30
    iput-boolean p8, p0, Lc73;->m:Z

    .line 31
    .line 32
    iput-boolean p9, p0, Lc73;->n:Z

    .line 33
    .line 34
    move-object/from16 p1, p10

    .line 35
    .line 36
    iput-object p1, p0, Lc73;->o:Lgg1;

    .line 37
    .line 38
    if-nez p2, :cond_28

    .line 39
    .line 40
    move-object p2, p0

    .line 41
    :cond_28
    iput-object p2, p0, Lc73;->p:Lc73;

    .line 42
    .line 43
    return-void
.end method


# virtual methods
.method public final G()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final bridge synthetic J0()Lo60;
    .registers 1

    .line 1
    invoke-virtual {p0}, Lc73;->N0()Lc73;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public K0(Lmu0;Ldv1;I)Lc73;
    .registers 16

    .line 1
    new-instance v0, Lc73;

    .line 2
    .line 3
    invoke-virtual {p0}, Lov;->getAnnotations()Ll7;

    .line 4
    .line 5
    .line 6
    move-result-object v4

    .line 7
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0}, Le73;->getType()Lgg1;

    .line 11
    .line 12
    .line 13
    move-result-object v6

    .line 14
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    invoke-virtual {p0}, Lc73;->L0()Z

    .line 18
    .line 19
    .line 20
    move-result v7

    .line 21
    iget-object v10, p0, Lc73;->o:Lgg1;

    .line 22
    .line 23
    sget-object v11, Loq2;->e0:Ll01;

    .line 24
    .line 25
    const/4 v2, 0x0

    .line 26
    iget-boolean v8, p0, Lc73;->m:Z

    .line 27
    .line 28
    iget-boolean v9, p0, Lc73;->n:Z

    .line 29
    .line 30
    move-object v1, p1

    .line 31
    move-object v5, p2

    .line 32
    move v3, p3

    .line 33
    invoke-direct/range {v0 .. v11}, Lc73;-><init>(Llo;Lc73;ILl7;Ldv1;Lgg1;ZZZLgg1;Loq2;)V

    .line 34
    .line 35
    .line 36
    return-object v0
.end method

.method public final L0()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lc73;->l:Z

    .line 2
    .line 3
    if-eqz v0, :cond_13

    .line 4
    .line 5
    invoke-virtual {p0}, Lc73;->M0()Llo;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    check-cast p0, Lno;

    .line 10
    .line 11
    invoke-interface {p0}, Lno;->j()I

    .line 12
    .line 13
    .line 14
    move-result p0

    .line 15
    const/4 v0, 0x2

    .line 16
    if-eq p0, v0, :cond_13

    .line 17
    .line 18
    const/4 p0, 0x1

    .line 19
    return p0

    .line 20
    :cond_13
    const/4 p0, 0x0

    .line 21
    return p0
.end method

.method public final M0()Llo;
    .registers 1

    .line 1
    invoke-super {p0}, Lp60;->p()Lm60;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    check-cast p0, Llo;

    .line 9
    .line 10
    return-object p0
.end method

.method public final N0()Lc73;
    .registers 2

    .line 1
    iget-object v0, p0, Lc73;->p:Lc73;

    .line 2
    .line 3
    if-ne v0, p0, :cond_5

    .line 4
    .line 5
    return-object p0

    .line 6
    :cond_5
    invoke-virtual {v0}, Lc73;->N0()Lc73;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    return-object p0
.end method

.method public final bridge synthetic b()Llo;
    .registers 1

    .line 1
    invoke-virtual {p0}, Lc73;->N0()Lc73;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public final bridge synthetic b()Lm60;
    .registers 1

    .line 6
    invoke-virtual {p0}, Lc73;->N0()Lc73;

    move-result-object p0

    return-object p0
.end method

.method public final e(Lx23;)Lo60;
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object p1, p1, Lx23;->a:Lv23;

    .line 5
    .line 6
    invoke-virtual {p1}, Lv23;->e()Z

    .line 7
    .line 8
    .line 9
    move-result p1

    .line 10
    if-eqz p1, :cond_c

    .line 11
    .line 12
    return-object p0

    .line 13
    :cond_c
    invoke-static {}, Lvn0;->n()V

    .line 14
    .line 15
    .line 16
    const/4 p0, 0x0

    .line 17
    return-object p0
.end method

.method public final g()Lya0;
    .registers 1

    .line 1
    sget-object p0, Lza0;->f:Lya0;

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    return-object p0
.end method

.method public final l0()Lsy;
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return-object p0
.end method

.method public final n0(Lq60;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    invoke-interface {p1, p0, p2}, Lq60;->j(Lc73;Ljava/lang/Object;)Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public final bridge synthetic p()Lm60;
    .registers 1

    .line 1
    invoke-virtual {p0}, Lc73;->M0()Llo;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public final r()Ljava/util/Collection;
    .registers 5

    .line 1
    invoke-virtual {p0}, Lc73;->M0()Llo;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-interface {v0}, Llo;->r()Ljava/util/Collection;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    check-cast v0, Ljava/lang/Iterable;

    .line 13
    .line 14
    new-instance v1, Ljava/util/ArrayList;

    .line 15
    .line 16
    const/16 v2, 0xa

    .line 17
    .line 18
    invoke-static {v0, v2}, Liv;->M(Ljava/lang/Iterable;I)I

    .line 19
    .line 20
    .line 21
    move-result v2

    .line 22
    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    .line 23
    .line 24
    .line 25
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    :goto_1c
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 30
    .line 31
    .line 32
    move-result v2

    .line 33
    if-eqz v2, :cond_38

    .line 34
    .line 35
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v2

    .line 39
    check-cast v2, Llo;

    .line 40
    .line 41
    invoke-interface {v2}, Llo;->r0()Ljava/util/List;

    .line 42
    .line 43
    .line 44
    move-result-object v2

    .line 45
    iget v3, p0, Lc73;->j:I

    .line 46
    .line 47
    invoke-interface {v2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v2

    .line 51
    check-cast v2, Lc73;

    .line 52
    .line 53
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 54
    .line 55
    .line 56
    goto :goto_1c

    .line 57
    :cond_38
    return-object v1
.end method
