###### Class defpackage.r03 (r03)
.class public final Lr03;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lhp0;


# instance fields
.field public final synthetic a:Ljc2;

.field public final synthetic b:Lhp0;

.field public final synthetic c:[Ljava/lang/String;

.field public final synthetic d:[I


# direct methods
.method public constructor <init>(Ljc2;Lhp0;[Ljava/lang/String;[I)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lr03;->a:Ljc2;

    .line 5
    .line 6
    iput-object p2, p0, Lr03;->b:Lhp0;

    .line 7
    .line 8
    iput-object p3, p0, Lr03;->c:[Ljava/lang/String;

    .line 9
    .line 10
    iput-object p4, p0, Lr03;->d:[I

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final a([ILw00;)Ljava/lang/Object;
    .registers 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    instance-of v3, v2, Lq03;

    .line 8
    .line 9
    if-eqz v3, :cond_19

    .line 10
    .line 11
    move-object v3, v2

    .line 12
    check-cast v3, Lq03;

    .line 13
    .line 14
    iget v4, v3, Lq03;->o:I

    .line 15
    .line 16
    const/high16 v5, -0x80000000

    .line 17
    .line 18
    and-int v6, v4, v5

    .line 19
    .line 20
    if-eqz v6, :cond_19

    .line 21
    .line 22
    sub-int/2addr v4, v5

    .line 23
    iput v4, v3, Lq03;->o:I

    .line 24
    .line 25
    goto :goto_1e

    .line 26
    :cond_19
    new-instance v3, Lq03;

    .line 27
    .line 28
    invoke-direct {v3, v0, v2}, Lq03;-><init>(Lr03;Lw00;)V

    .line 29
    .line 30
    .line 31
    :goto_1e
    iget-object v2, v3, Lq03;->m:Ljava/lang/Object;

    .line 32
    .line 33
    iget v4, v3, Lq03;->o:I

    .line 34
    .line 35
    const/4 v5, 0x0

    .line 36
    const/4 v6, 0x2

    .line 37
    const/4 v7, 0x1

    .line 38
    if-eqz v4, :cond_3f

    .line 39
    .line 40
    if-eq v4, v7, :cond_32

    .line 41
    .line 42
    if-ne v4, v6, :cond_2c

    .line 43
    .line 44
    goto :goto_32

    .line 45
    :cond_2c
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 46
    .line 47
    invoke-static {v0}, Ly0;->h(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    return-object v5

    .line 51
    :cond_32
    :goto_32
    iget-object v0, v3, Lq03;->l:[I

    .line 52
    .line 53
    iget-object v1, v3, Lq03;->j:Lr03;

    .line 54
    .line 55
    invoke-static {v2}, Lh23;->t(Ljava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    move-object/from16 v16, v1

    .line 59
    .line 60
    move-object v1, v0

    .line 61
    move-object/from16 v0, v16

    .line 62
    .line 63
    goto :goto_a7

    .line 64
    :cond_3f
    invoke-static {v2}, Lh23;->t(Ljava/lang/Object;)V

    .line 65
    .line 66
    .line 67
    iget-object v2, v0, Lr03;->a:Ljc2;

    .line 68
    .line 69
    iget-object v4, v2, Ljc2;->a:Ljava/lang/Object;

    .line 70
    .line 71
    iget-object v8, v0, Lr03;->c:[Ljava/lang/String;

    .line 72
    .line 73
    iget-object v9, v0, Lr03;->b:Lhp0;

    .line 74
    .line 75
    sget-object v10, Lb20;->a:Lb20;

    .line 76
    .line 77
    if-nez v4, :cond_5f

    .line 78
    .line 79
    invoke-static {v8}, Lub;->U([Ljava/lang/Object;)Ljava/util/Set;

    .line 80
    .line 81
    .line 82
    move-result-object v2

    .line 83
    iput-object v0, v3, Lq03;->j:Lr03;

    .line 84
    .line 85
    iput-object v1, v3, Lq03;->l:[I

    .line 86
    .line 87
    iput v7, v3, Lq03;->o:I

    .line 88
    .line 89
    invoke-interface {v9, v2, v3}, Lhp0;->g(Ljava/lang/Object;Lw00;)Ljava/lang/Object;

    .line 90
    .line 91
    .line 92
    move-result-object v2

    .line 93
    if-ne v2, v10, :cond_a7

    .line 94
    .line 95
    goto :goto_a6

    .line 96
    :cond_5f
    new-instance v4, Ljava/util/ArrayList;

    .line 97
    .line 98
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 99
    .line 100
    .line 101
    array-length v7, v8

    .line 102
    const/4 v11, 0x0

    .line 103
    move v12, v11

    .line 104
    :goto_67
    if-ge v11, v7, :cond_90

    .line 105
    .line 106
    aget-object v13, v8, v11

    .line 107
    .line 108
    add-int/lit8 v14, v12, 0x1

    .line 109
    .line 110
    iget-object v15, v2, Ljc2;->a:Ljava/lang/Object;

    .line 111
    .line 112
    if-eqz v15, :cond_88

    .line 113
    .line 114
    check-cast v15, [I

    .line 115
    .line 116
    move-object/from16 p2, v5

    .line 117
    .line 118
    iget-object v5, v0, Lr03;->d:[I

    .line 119
    .line 120
    aget v5, v5, v12

    .line 121
    .line 122
    aget v12, v15, v5

    .line 123
    .line 124
    aget v5, v1, v5

    .line 125
    .line 126
    if-eq v12, v5, :cond_82

    .line 127
    .line 128
    invoke-virtual {v4, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 129
    .line 130
    .line 131
    :cond_82
    add-int/lit8 v11, v11, 0x1

    .line 132
    .line 133
    move-object/from16 v5, p2

    .line 134
    .line 135
    move v12, v14

    .line 136
    goto :goto_67

    .line 137
    :cond_88
    move-object/from16 p2, v5

    .line 138
    .line 139
    const-string v0, "Required value was null."

    .line 140
    .line 141
    invoke-static {v0}, Ly0;->h(Ljava/lang/String;)V

    .line 142
    .line 143
    .line 144
    return-object p2

    .line 145
    :cond_90
    invoke-virtual {v4}, Ljava/util/ArrayList;->isEmpty()Z

    .line 146
    .line 147
    .line 148
    move-result v2

    .line 149
    if-nez v2, :cond_a7

    .line 150
    .line 151
    invoke-static {v4}, Lgv;->C0(Ljava/lang/Iterable;)Ljava/util/Set;

    .line 152
    .line 153
    .line 154
    move-result-object v2

    .line 155
    iput-object v0, v3, Lq03;->j:Lr03;

    .line 156
    .line 157
    iput-object v1, v3, Lq03;->l:[I

    .line 158
    .line 159
    iput v6, v3, Lq03;->o:I

    .line 160
    .line 161
    invoke-interface {v9, v2, v3}, Lhp0;->g(Ljava/lang/Object;Lw00;)Ljava/lang/Object;

    .line 162
    .line 163
    .line 164
    move-result-object v2

    .line 165
    if-ne v2, v10, :cond_a7

    .line 166
    .line 167
    :goto_a6
    return-object v10

    .line 168
    :cond_a7
    :goto_a7
    iget-object v0, v0, Lr03;->a:Ljc2;

    .line 169
    .line 170
    iput-object v1, v0, Ljc2;->a:Ljava/lang/Object;

    .line 171
    .line 172
    sget-object v0, Lw43;->a:Lw43;

    .line 173
    .line 174
    return-object v0
.end method

.method public final bridge synthetic g(Ljava/lang/Object;Lw00;)Ljava/lang/Object;
    .registers 3

    .line 1
    check-cast p1, [I

    .line 2
    .line 3
    invoke-virtual {p0, p1, p2}, Lr03;->a([ILw00;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method
