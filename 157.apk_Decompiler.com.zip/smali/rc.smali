###### Class defpackage.rc (rc)
.class public final Lrc;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lhy1;


# static fields
.field public static final a:Lrc;

.field public static final b:Lnm0;

.field public static final c:Lnm0;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Lrc;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lrc;->a:Lrc;

    .line 7
    .line 8
    const-string v0, "privacyContext"

    .line 9
    .line 10
    invoke-static {v0}, Lnm0;->a(Ljava/lang/String;)Lnm0;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    sput-object v0, Lrc;->b:Lnm0;

    .line 15
    .line 16
    const-string v0, "productIdOrigin"

    .line 17
    .line 18
    invoke-static {v0}, Lnm0;->a(Ljava/lang/String;)Lnm0;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    sput-object v0, Lrc;->c:Lnm0;

    .line 23
    .line 24
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 3

    .line 1
    check-cast p1, Lnw;

    .line 2
    .line 3
    check-cast p2, Liy1;

    .line 4
    .line 5
    check-cast p1, Lte;

    .line 6
    .line 7
    iget-object p0, p1, Lte;->a:Lng;

    .line 8
    .line 9
    sget-object p1, Lrc;->b:Lnm0;

    .line 10
    .line 11
    invoke-interface {p2, p1, p0}, Liy1;->a(Lnm0;Ljava/lang/Object;)Liy1;

    .line 12
    .line 13
    .line 14
    sget-object p0, Lrc;->c:Lnm0;

    .line 15
    .line 16
    sget-object p1, Lmw;->a:Lmw;

    .line 17
    .line 18
    invoke-interface {p2, p0, p1}, Liy1;->a(Lnm0;Ljava/lang/Object;)Liy1;

    .line 19
    .line 20
    .line 21
    return-void
.end method
