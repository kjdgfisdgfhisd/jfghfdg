###### Class defpackage.q72 (q72)
.class public final Lq72;
.super Ljv0;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field public static final j:Lq72;

.field public static final l:Lac1;


# instance fields
.field public final a:Lun;

.field public b:I

.field public c:Lp72;

.field public d:Ls72;

.field public e:I

.field public f:B

.field public g:I


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lac1;

    .line 2
    .line 3
    const/16 v1, 0x16

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lac1;-><init>(I)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lq72;->l:Lac1;

    .line 9
    .line 10
    new-instance v0, Lq72;

    .line 11
    .line 12
    invoke-direct {v0}, Lq72;-><init>()V

    .line 13
    .line 14
    .line 15
    sput-object v0, Lq72;->j:Lq72;

    .line 16
    .line 17
    sget-object v1, Lp72;->d:Lp72;

    .line 18
    .line 19
    iput-object v1, v0, Lq72;->c:Lp72;

    .line 20
    .line 21
    sget-object v1, Ls72;->w:Ls72;

    .line 22
    .line 23
    iput-object v1, v0, Lq72;->d:Ls72;

    .line 24
    .line 25
    const/4 v1, 0x0

    .line 26
    iput v1, v0, Lq72;->e:I

    .line 27
    .line 28
    return-void
.end method

.method public constructor <init>()V
    .registers 2

    .line 216
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    .line 217
    iput-byte v0, p0, Lq72;->f:B

    .line 218
    iput v0, p0, Lq72;->g:I

    .line 219
    sget-object v0, Lun;->a:Lfl1;

    iput-object v0, p0, Lq72;->a:Lun;

    return-void
.end method

.method public constructor <init>(Lo72;)V
    .registers 3

    .line 220
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    .line 221
    iput-byte v0, p0, Lq72;->f:B

    .line 222
    iput v0, p0, Lq72;->g:I

    .line 223
    iget-object p1, p1, Lcv0;->a:Lun;

    .line 224
    iput-object p1, p0, Lq72;->a:Lun;

    return-void
.end method

.method public constructor <init>(Lwu;Lpl0;)V
    .registers 12

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, -0x1

    .line 5
    iput-byte v0, p0, Lq72;->f:B

    .line 6
    .line 7
    iput v0, p0, Lq72;->g:I

    .line 8
    .line 9
    sget-object v0, Lp72;->d:Lp72;

    .line 10
    .line 11
    iput-object v0, p0, Lq72;->c:Lp72;

    .line 12
    .line 13
    sget-object v1, Ls72;->w:Ls72;

    .line 14
    .line 15
    iput-object v1, p0, Lq72;->d:Ls72;

    .line 16
    .line 17
    const/4 v1, 0x0

    .line 18
    iput v1, p0, Lq72;->e:I

    .line 19
    .line 20
    new-instance v2, Ltn;

    .line 21
    .line 22
    invoke-direct {v2}, Ltn;-><init>()V

    .line 23
    .line 24
    .line 25
    const/4 v3, 0x1

    .line 26
    invoke-static {v2, v3}, Lzu;->j(Ljava/io/OutputStream;I)Lzu;

    .line 27
    .line 28
    .line 29
    move-result-object v4

    .line 30
    :cond_1d
    :goto_1d
    if-nez v1, :cond_c5

    .line 31
    .line 32
    :try_start_1f
    invoke-virtual {p1}, Lwu;->m()I

    .line 33
    .line 34
    .line 35
    move-result v5

    .line 36
    if-eqz v5, :cond_39

    .line 37
    .line 38
    const/16 v6, 0x8

    .line 39
    .line 40
    const/4 v7, 0x0

    .line 41
    const/4 v8, 0x2

    .line 42
    if-eq v5, v6, :cond_79

    .line 43
    .line 44
    const/16 v6, 0x12

    .line 45
    .line 46
    if-eq v5, v6, :cond_50

    .line 47
    .line 48
    const/16 v6, 0x18

    .line 49
    .line 50
    if-eq v5, v6, :cond_43

    .line 51
    .line 52
    invoke-virtual {p1, v5, v4}, Lwu;->p(ILzu;)Z

    .line 53
    .line 54
    .line 55
    move-result v5

    .line 56
    if-nez v5, :cond_1d

    .line 57
    .line 58
    :cond_39
    move v1, v3

    .line 59
    goto :goto_1d

    .line 60
    :catchall_3b
    move-exception p1

    .line 61
    goto/16 :goto_b2

    .line 62
    .line 63
    :catch_3e
    move-exception p1

    .line 64
    goto :goto_a3

    .line 65
    :catch_40
    move-exception p1

    .line 66
    goto/16 :goto_af

    .line 67
    .line 68
    :cond_43
    iget v5, p0, Lq72;->b:I

    .line 69
    .line 70
    or-int/lit8 v5, v5, 0x4

    .line 71
    .line 72
    iput v5, p0, Lq72;->b:I

    .line 73
    .line 74
    invoke-virtual {p1}, Lwu;->j()I

    .line 75
    .line 76
    .line 77
    move-result v5

    .line 78
    iput v5, p0, Lq72;->e:I

    .line 79
    .line 80
    goto :goto_1d

    .line 81
    :cond_50
    iget v5, p0, Lq72;->b:I

    .line 82
    .line 83
    and-int/2addr v5, v8

    .line 84
    if-ne v5, v8, :cond_5e

    .line 85
    .line 86
    iget-object v5, p0, Lq72;->d:Ls72;

    .line 87
    .line 88
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 89
    .line 90
    .line 91
    invoke-static {v5}, Ls72;->q(Ls72;)Lr72;

    .line 92
    .line 93
    .line 94
    move-result-object v7

    .line 95
    :cond_5e
    sget-object v5, Ls72;->x:Lac1;

    .line 96
    .line 97
    invoke-virtual {p1, v5, p2}, Lwu;->f(Lac1;Lpl0;)Le0;

    .line 98
    .line 99
    .line 100
    move-result-object v5

    .line 101
    check-cast v5, Ls72;

    .line 102
    .line 103
    iput-object v5, p0, Lq72;->d:Ls72;

    .line 104
    .line 105
    if-eqz v7, :cond_73

    .line 106
    .line 107
    invoke-virtual {v7, v5}, Lr72;->i(Ls72;)Lr72;

    .line 108
    .line 109
    .line 110
    invoke-virtual {v7}, Lr72;->g()Ls72;

    .line 111
    .line 112
    .line 113
    move-result-object v5

    .line 114
    iput-object v5, p0, Lq72;->d:Ls72;

    .line 115
    .line 116
    :cond_73
    iget v5, p0, Lq72;->b:I

    .line 117
    .line 118
    or-int/2addr v5, v8

    .line 119
    iput v5, p0, Lq72;->b:I

    .line 120
    .line 121
    goto :goto_1d

    .line 122
    :cond_79
    invoke-virtual {p1}, Lwu;->j()I

    .line 123
    .line 124
    .line 125
    move-result v6

    .line 126
    if-eqz v6, :cond_8f

    .line 127
    .line 128
    if-eq v6, v3, :cond_8c

    .line 129
    .line 130
    if-eq v6, v8, :cond_8a

    .line 131
    .line 132
    const/4 v8, 0x3

    .line 133
    if-eq v6, v8, :cond_87

    .line 134
    .line 135
    goto :goto_91

    .line 136
    :cond_87
    sget-object v7, Lp72;->e:Lp72;

    .line 137
    .line 138
    goto :goto_91

    .line 139
    :cond_8a
    move-object v7, v0

    .line 140
    goto :goto_91

    .line 141
    :cond_8c
    sget-object v7, Lp72;->c:Lp72;

    .line 142
    .line 143
    goto :goto_91

    .line 144
    :cond_8f
    sget-object v7, Lp72;->b:Lp72;

    .line 145
    .line 146
    :goto_91
    if-nez v7, :cond_9a

    .line 147
    .line 148
    invoke-virtual {v4, v5}, Lzu;->v(I)V

    .line 149
    .line 150
    .line 151
    invoke-virtual {v4, v6}, Lzu;->v(I)V

    .line 152
    .line 153
    .line 154
    goto :goto_1d

    .line 155
    :cond_9a
    iget v5, p0, Lq72;->b:I

    .line 156
    .line 157
    or-int/2addr v5, v3

    .line 158
    iput v5, p0, Lq72;->b:I

    .line 159
    .line 160
    iput-object v7, p0, Lq72;->c:Lp72;
    :try_end_a1
    .catch Lg31; {:try_start_1f .. :try_end_a1} :catch_40
    .catch Ljava/io/IOException; {:try_start_1f .. :try_end_a1} :catch_3e
    .catchall {:try_start_1f .. :try_end_a1} :catchall_3b

    .line 161
    .line 162
    goto/16 :goto_1d

    .line 163
    .line 164
    :goto_a3
    :try_start_a3
    new-instance p2, Lg31;

    .line 165
    .line 166
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 167
    .line 168
    .line 169
    move-result-object p1

    .line 170
    invoke-direct {p2, p1}, Lg31;-><init>(Ljava/lang/String;)V

    .line 171
    .line 172
    .line 173
    iput-object p0, p2, Lg31;->a:Le0;

    .line 174
    .line 175
    throw p2

    .line 176
    :goto_af
    iput-object p0, p1, Lg31;->a:Le0;

    .line 177
    .line 178
    throw p1
    :try_end_b2
    .catchall {:try_start_a3 .. :try_end_b2} :catchall_3b

    .line 179
    :goto_b2
    :try_start_b2
    invoke-virtual {v4}, Lzu;->k()V
    :try_end_b5
    .catch Ljava/io/IOException; {:try_start_b2 .. :try_end_b5} :catch_b5
    .catchall {:try_start_b2 .. :try_end_b5} :catchall_bc

    .line 180
    .line 181
    .line 182
    :catch_b5
    invoke-virtual {v2}, Ltn;->j()Lun;

    .line 183
    .line 184
    .line 185
    move-result-object p2

    .line 186
    iput-object p2, p0, Lq72;->a:Lun;

    .line 187
    .line 188
    goto :goto_c4

    .line 189
    :catchall_bc
    move-exception p1

    .line 190
    invoke-virtual {v2}, Ltn;->j()Lun;

    .line 191
    .line 192
    .line 193
    move-result-object p2

    .line 194
    iput-object p2, p0, Lq72;->a:Lun;

    .line 195
    .line 196
    throw p1

    .line 197
    :goto_c4
    throw p1

    .line 198
    :cond_c5
    :try_start_c5
    invoke-virtual {v4}, Lzu;->k()V
    :try_end_c8
    .catch Ljava/io/IOException; {:try_start_c5 .. :try_end_c8} :catch_c8
    .catchall {:try_start_c5 .. :try_end_c8} :catchall_cf

    .line 199
    .line 200
    .line 201
    :catch_c8
    invoke-virtual {v2}, Ltn;->j()Lun;

    .line 202
    .line 203
    .line 204
    move-result-object p1

    .line 205
    iput-object p1, p0, Lq72;->a:Lun;

    .line 206
    .line 207
    return-void

    .line 208
    :catchall_cf
    move-exception p1

    .line 209
    invoke-virtual {v2}, Ltn;->j()Lun;

    .line 210
    .line 211
    .line 212
    move-result-object p2

    .line 213
    iput-object p2, p0, Lq72;->a:Lun;

    .line 214
    .line 215
    throw p1
.end method


# virtual methods
.method public final b()Z
    .registers 5

    .line 1
    iget-byte v0, p0, Lq72;->f:B

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-ne v0, v1, :cond_6

    .line 5
    .line 6
    return v1

    .line 7
    :cond_6
    const/4 v2, 0x0

    .line 8
    if-nez v0, :cond_a

    .line 9
    .line 10
    return v2

    .line 11
    :cond_a
    iget v0, p0, Lq72;->b:I

    .line 12
    .line 13
    const/4 v3, 0x2

    .line 14
    and-int/2addr v0, v3

    .line 15
    if-ne v0, v3, :cond_1b

    .line 16
    .line 17
    iget-object v0, p0, Lq72;->d:Ls72;

    .line 18
    .line 19
    invoke-virtual {v0}, Ls72;->b()Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-nez v0, :cond_1b

    .line 24
    .line 25
    iput-byte v2, p0, Lq72;->f:B

    .line 26
    .line 27
    return v2

    .line 28
    :cond_1b
    iput-byte v1, p0, Lq72;->f:B

    .line 29
    .line 30
    return v1
.end method

.method public final c()I
    .registers 4

    .line 1
    iget v0, p0, Lq72;->g:I

    .line 2
    .line 3
    const/4 v1, -0x1

    .line 4
    if-eq v0, v1, :cond_6

    .line 5
    .line 6
    return v0

    .line 7
    :cond_6
    iget v0, p0, Lq72;->b:I

    .line 8
    .line 9
    const/4 v1, 0x1

    .line 10
    and-int/2addr v0, v1

    .line 11
    if-ne v0, v1, :cond_15

    .line 12
    .line 13
    iget-object v0, p0, Lq72;->c:Lp72;

    .line 14
    .line 15
    iget v0, v0, Lp72;->a:I

    .line 16
    .line 17
    invoke-static {v1, v0}, Lzu;->a(II)I

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    goto :goto_16

    .line 22
    :cond_15
    const/4 v0, 0x0

    .line 23
    :goto_16
    iget v1, p0, Lq72;->b:I

    .line 24
    .line 25
    const/4 v2, 0x2

    .line 26
    and-int/2addr v1, v2

    .line 27
    if-ne v1, v2, :cond_23

    .line 28
    .line 29
    iget-object v1, p0, Lq72;->d:Ls72;

    .line 30
    .line 31
    invoke-static {v2, v1}, Lzu;->d(ILe0;)I

    .line 32
    .line 33
    .line 34
    move-result v1

    .line 35
    add-int/2addr v0, v1

    .line 36
    :cond_23
    iget v1, p0, Lq72;->b:I

    .line 37
    .line 38
    const/4 v2, 0x4

    .line 39
    and-int/2addr v1, v2

    .line 40
    if-ne v1, v2, :cond_31

    .line 41
    .line 42
    const/4 v1, 0x3

    .line 43
    iget v2, p0, Lq72;->e:I

    .line 44
    .line 45
    invoke-static {v1, v2}, Lzu;->b(II)I

    .line 46
    .line 47
    .line 48
    move-result v1

    .line 49
    add-int/2addr v0, v1

    .line 50
    :cond_31
    iget-object v1, p0, Lq72;->a:Lun;

    .line 51
    .line 52
    invoke-virtual {v1}, Lun;->size()I

    .line 53
    .line 54
    .line 55
    move-result v1

    .line 56
    add-int/2addr v1, v0

    .line 57
    iput v1, p0, Lq72;->g:I

    .line 58
    .line 59
    return v1
.end method

.method public final d()Lcv0;
    .registers 2

    .line 1
    new-instance p0, Lo72;

    .line 2
    .line 3
    invoke-direct {p0}, Lcv0;-><init>()V

    .line 4
    .line 5
    .line 6
    sget-object v0, Lp72;->d:Lp72;

    .line 7
    .line 8
    iput-object v0, p0, Lo72;->c:Lp72;

    .line 9
    .line 10
    sget-object v0, Ls72;->w:Ls72;

    .line 11
    .line 12
    iput-object v0, p0, Lo72;->d:Ls72;

    .line 13
    .line 14
    return-object p0
.end method

.method public final e()Lcv0;
    .registers 3

    .line 1
    new-instance v0, Lo72;

    .line 2
    .line 3
    invoke-direct {v0}, Lcv0;-><init>()V

    .line 4
    .line 5
    .line 6
    sget-object v1, Lp72;->d:Lp72;

    .line 7
    .line 8
    iput-object v1, v0, Lo72;->c:Lp72;

    .line 9
    .line 10
    sget-object v1, Ls72;->w:Ls72;

    .line 11
    .line 12
    iput-object v1, v0, Lo72;->d:Ls72;

    .line 13
    .line 14
    invoke-virtual {v0, p0}, Lo72;->g(Lq72;)V

    .line 15
    .line 16
    .line 17
    return-object v0
.end method

.method public final f(Lzu;)V
    .registers 4

    .line 1
    invoke-virtual {p0}, Lq72;->c()I

    .line 2
    .line 3
    .line 4
    iget v0, p0, Lq72;->b:I

    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    and-int/2addr v0, v1

    .line 8
    if-ne v0, v1, :cond_10

    .line 9
    .line 10
    iget-object v0, p0, Lq72;->c:Lp72;

    .line 11
    .line 12
    iget v0, v0, Lp72;->a:I

    .line 13
    .line 14
    invoke-virtual {p1, v1, v0}, Lzu;->l(II)V

    .line 15
    .line 16
    .line 17
    :cond_10
    iget v0, p0, Lq72;->b:I

    .line 18
    .line 19
    const/4 v1, 0x2

    .line 20
    and-int/2addr v0, v1

    .line 21
    if-ne v0, v1, :cond_1b

    .line 22
    .line 23
    iget-object v0, p0, Lq72;->d:Ls72;

    .line 24
    .line 25
    invoke-virtual {p1, v1, v0}, Lzu;->o(ILe0;)V

    .line 26
    .line 27
    .line 28
    :cond_1b
    iget v0, p0, Lq72;->b:I

    .line 29
    .line 30
    const/4 v1, 0x4

    .line 31
    and-int/2addr v0, v1

    .line 32
    if-ne v0, v1, :cond_27

    .line 33
    .line 34
    const/4 v0, 0x3

    .line 35
    iget v1, p0, Lq72;->e:I

    .line 36
    .line 37
    invoke-virtual {p1, v0, v1}, Lzu;->m(II)V

    .line 38
    .line 39
    .line 40
    :cond_27
    iget-object p0, p0, Lq72;->a:Lun;

    .line 41
    .line 42
    invoke-virtual {p1, p0}, Lzu;->r(Lun;)V

    .line 43
    .line 44
    .line 45
    return-void
.end method
