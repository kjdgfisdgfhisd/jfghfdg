###### Class defpackage.kc3 (kc3)
.class public Lkc3;
.super Ljc3;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# direct methods
.method public constructor <init>(Lqc3;Landroid/view/WindowInsets;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Ljc3;-><init>(Lqc3;Landroid/view/WindowInsets;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method
