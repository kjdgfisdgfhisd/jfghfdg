###### Class defpackage.gx3 (gx3)
.class public final Lgx3;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lhz3;

.field public final synthetic c:Z

.field public final synthetic d:Lbx3;

.field public final synthetic e:Lt0;


# direct methods
.method public constructor <init>(Lbx3;Lhz3;ZLll3;Lll3;)V
    .registers 6

    .line 1
    const/4 p5, 0x2

    .line 2
    iput p5, p0, Lgx3;->a:I

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p2, p0, Lgx3;->b:Lhz3;

    .line 8
    .line 9
    iput-boolean p3, p0, Lgx3;->c:Z

    .line 10
    .line 11
    iput-object p4, p0, Lgx3;->e:Lt0;

    .line 12
    .line 13
    iput-object p1, p0, Lgx3;->d:Lbx3;

    .line 14
    .line 15
    return-void
.end method

.method public synthetic constructor <init>(Lbx3;Lhz3;ZLt0;I)V
    .registers 6

    .line 16
    iput p5, p0, Lgx3;->a:I

    iput-object p2, p0, Lgx3;->b:Lhz3;

    iput-boolean p3, p0, Lgx3;->c:Z

    iput-object p4, p0, Lgx3;->e:Lt0;

    iput-object p1, p0, Lgx3;->d:Lbx3;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 6

    .line 1
    iget v0, p0, Lgx3;->a:I

    .line 2
    .line 3
    iget-object v1, p0, Lgx3;->e:Lt0;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    iget-boolean v3, p0, Lgx3;->c:Z

    .line 7
    .line 8
    iget-object v4, p0, Lgx3;->d:Lbx3;

    .line 9
    .line 10
    iget-object p0, p0, Lgx3;->b:Lhz3;

    .line 11
    .line 12
    packed-switch v0, :pswitch_data_66

    .line 13
    .line 14
    .line 15
    iget-object v0, v4, Lbx3;->f:Las3;

    .line 16
    .line 17
    if-nez v0, :cond_1e

    .line 18
    .line 19
    invoke-virtual {v4}, Lov;->l()Lqs3;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    iget-object p0, p0, Lqs3;->j:Lts3;

    .line 24
    .line 25
    const-string v0, "Discarding data. Failed to send conditional user property to service"

    .line 26
    .line 27
    invoke-virtual {p0, v0}, Lts3;->c(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    goto :goto_2a

    .line 31
    :cond_1e
    if-eqz v3, :cond_21

    .line 32
    .line 33
    goto :goto_24

    .line 34
    :cond_21
    move-object v2, v1

    .line 35
    check-cast v2, Lll3;

    .line 36
    .line 37
    :goto_24
    invoke-virtual {v4, v0, v2, p0}, Lbx3;->R0(Las3;Lt0;Lhz3;)V

    .line 38
    .line 39
    .line 40
    invoke-virtual {v4}, Lbx3;->Z0()V

    .line 41
    .line 42
    .line 43
    :goto_2a
    return-void

    .line 44
    :pswitch_2b
    iget-object v0, v4, Lbx3;->f:Las3;

    .line 45
    .line 46
    if-nez v0, :cond_3b

    .line 47
    .line 48
    invoke-virtual {v4}, Lov;->l()Lqs3;

    .line 49
    .line 50
    .line 51
    move-result-object p0

    .line 52
    iget-object p0, p0, Lqs3;->j:Lts3;

    .line 53
    .line 54
    const-string v0, "Discarding data. Failed to send event to service"

    .line 55
    .line 56
    invoke-virtual {p0, v0}, Lts3;->c(Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    goto :goto_47

    .line 60
    :cond_3b
    if-eqz v3, :cond_3e

    .line 61
    .line 62
    goto :goto_41

    .line 63
    :cond_3e
    move-object v2, v1

    .line 64
    check-cast v2, Lhn3;

    .line 65
    .line 66
    :goto_41
    invoke-virtual {v4, v0, v2, p0}, Lbx3;->R0(Las3;Lt0;Lhz3;)V

    .line 67
    .line 68
    .line 69
    invoke-virtual {v4}, Lbx3;->Z0()V

    .line 70
    .line 71
    .line 72
    :goto_47
    return-void

    .line 73
    :pswitch_48
    iget-object v0, v4, Lbx3;->f:Las3;

    .line 74
    .line 75
    if-nez v0, :cond_58

    .line 76
    .line 77
    invoke-virtual {v4}, Lov;->l()Lqs3;

    .line 78
    .line 79
    .line 80
    move-result-object p0

    .line 81
    iget-object p0, p0, Lqs3;->j:Lts3;

    .line 82
    .line 83
    const-string v0, "Discarding data. Failed to set user property"

    .line 84
    .line 85
    invoke-virtual {p0, v0}, Lts3;->c(Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    goto :goto_64

    .line 89
    :cond_58
    if-eqz v3, :cond_5b

    .line 90
    .line 91
    goto :goto_5e

    .line 92
    :cond_5b
    move-object v2, v1

    .line 93
    check-cast v2, Lvz3;

    .line 94
    .line 95
    :goto_5e
    invoke-virtual {v4, v0, v2, p0}, Lbx3;->R0(Las3;Lt0;Lhz3;)V

    .line 96
    .line 97
    .line 98
    invoke-virtual {v4}, Lbx3;->Z0()V

    .line 99
    .line 100
    .line 101
    :goto_64
    return-void

    .line 102
    nop

    .line 103
    :pswitch_data_66
    .packed-switch 0x0
        :pswitch_48
        :pswitch_2b
    .end packed-switch
.end method
