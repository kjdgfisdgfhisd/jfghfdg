###### Class defpackage.nf3 (nf3)
.class public final Lnf3;
.super Landroidx/recyclerview/widget/c;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final i:Leq1;


# direct methods
.method public constructor <init>(Leq1;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Landroidx/recyclerview/widget/c;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lnf3;->i:Leq1;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final getItemCount()I
    .registers 1

    .line 1
    iget-object p0, p0, Lnf3;->i:Leq1;

    .line 2
    .line 3
    iget-object p0, p0, Leq1;->e:Lgo;

    .line 4
    .line 5
    iget p0, p0, Lgo;->f:I

    .line 6
    .line 7
    return p0
.end method

.method public final onBindViewHolder(Landroidx/recyclerview/widget/g;I)V
    .registers 11

    .line 1
    check-cast p1, Lmf3;

    .line 2
    .line 3
    iget-object v0, p0, Lnf3;->i:Leq1;

    .line 4
    .line 5
    iget-object v1, v0, Leq1;->e:Lgo;

    .line 6
    .line 7
    iget-object v1, v1, Lgo;->a:Lcu1;

    .line 8
    .line 9
    iget v1, v1, Lcu1;->c:I

    .line 10
    .line 11
    add-int/2addr v1, p2

    .line 12
    iget-object p2, p1, Lmf3;->c:Landroid/widget/TextView;

    .line 13
    .line 14
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    .line 15
    .line 16
    .line 17
    move-result-object v2

    .line 18
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 19
    .line 20
    .line 21
    move-result-object v3

    .line 22
    filled-new-array {v3}, [Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v3

    .line 26
    const-string v4, "%d"

    .line 27
    .line 28
    invoke-static {v2, v4, v3}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v2

    .line 32
    invoke-virtual {p2, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 33
    .line 34
    .line 35
    iget-object p1, p1, Lmf3;->c:Landroid/widget/TextView;

    .line 36
    .line 37
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 38
    .line 39
    .line 40
    move-result-object p2

    .line 41
    invoke-static {}, Lf63;->d()Ljava/util/Calendar;

    .line 42
    .line 43
    .line 44
    move-result-object v2

    .line 45
    const/4 v3, 0x1

    .line 46
    invoke-virtual {v2, v3}, Ljava/util/Calendar;->get(I)I

    .line 47
    .line 48
    .line 49
    move-result v2

    .line 50
    if-ne v2, v1, :cond_47

    .line 51
    .line 52
    const v2, 0x7f1200cb

    .line 53
    .line 54
    .line 55
    invoke-virtual {p2, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object p2

    .line 59
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 60
    .line 61
    .line 62
    move-result-object v2

    .line 63
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v2

    .line 67
    invoke-static {p2, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object p2

    .line 71
    goto :goto_5a

    .line 72
    :cond_47
    const v2, 0x7f1200cc

    .line 73
    .line 74
    .line 75
    invoke-virtual {p2, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object p2

    .line 79
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 80
    .line 81
    .line 82
    move-result-object v2

    .line 83
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v2

    .line 87
    invoke-static {p2, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 88
    .line 89
    .line 90
    move-result-object p2

    .line 91
    :goto_5a
    invoke-virtual {p1, p2}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 92
    .line 93
    .line 94
    iget-object p2, v0, Leq1;->l:Lcn0;

    .line 95
    .line 96
    invoke-static {}, Lf63;->d()Ljava/util/Calendar;

    .line 97
    .line 98
    .line 99
    move-result-object v2

    .line 100
    invoke-virtual {v2, v3}, Ljava/util/Calendar;->get(I)I

    .line 101
    .line 102
    .line 103
    move-result v4

    .line 104
    if-ne v4, v1, :cond_6e

    .line 105
    .line 106
    iget-object v4, p2, Lcn0;->f:Ljava/lang/Object;

    .line 107
    .line 108
    :goto_6b
    check-cast v4, La4;

    .line 109
    .line 110
    goto :goto_71

    .line 111
    :cond_6e
    iget-object v4, p2, Lcn0;->d:Ljava/lang/Object;

    .line 112
    .line 113
    goto :goto_6b

    .line 114
    :goto_71
    iget-object v0, v0, Leq1;->d:Lro2;

    .line 115
    .line 116
    invoke-virtual {v0}, Lro2;->a()Ljava/util/ArrayList;

    .line 117
    .line 118
    .line 119
    move-result-object v0

    .line 120
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 121
    .line 122
    .line 123
    move-result-object v0

    .line 124
    :cond_7b
    :goto_7b
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 125
    .line 126
    .line 127
    move-result v5

    .line 128
    if-eqz v5, :cond_99

    .line 129
    .line 130
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 131
    .line 132
    .line 133
    move-result-object v5

    .line 134
    check-cast v5, Ljava/lang/Long;

    .line 135
    .line 136
    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    .line 137
    .line 138
    .line 139
    move-result-wide v5

    .line 140
    invoke-virtual {v2, v5, v6}, Ljava/util/Calendar;->setTimeInMillis(J)V

    .line 141
    .line 142
    .line 143
    invoke-virtual {v2, v3}, Ljava/util/Calendar;->get(I)I

    .line 144
    .line 145
    .line 146
    move-result v5

    .line 147
    if-ne v5, v1, :cond_7b

    .line 148
    .line 149
    iget-object v4, p2, Lcn0;->e:Ljava/lang/Object;

    .line 150
    .line 151
    check-cast v4, La4;

    .line 152
    .line 153
    goto :goto_7b

    .line 154
    :cond_99
    invoke-virtual {v4, p1}, La4;->L(Landroid/widget/TextView;)V

    .line 155
    .line 156
    .line 157
    invoke-virtual {p1}, Landroid/view/View;->getForeground()Landroid/graphics/drawable/Drawable;

    .line 158
    .line 159
    .line 160
    move-result-object v0

    .line 161
    instance-of v0, v0, Lcom/google/android/material/focus/FocusRingDrawable;

    .line 162
    .line 163
    const/4 v2, 0x0

    .line 164
    if-eqz v0, :cond_a6

    .line 165
    .line 166
    goto :goto_de

    .line 167
    :cond_a6
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 168
    .line 169
    .line 170
    move-result-object v0

    .line 171
    invoke-virtual {p1}, Landroid/view/View;->getForeground()Landroid/graphics/drawable/Drawable;

    .line 172
    .line 173
    .line 174
    move-result-object v5

    .line 175
    sget-object v6, Lcom/google/android/material/focus/FocusRingDrawable;->s:Landroid/graphics/drawable/ColorDrawable;

    .line 176
    .line 177
    invoke-virtual {v0}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 178
    .line 179
    .line 180
    move-result-object v6

    .line 181
    const v7, 0x7f040259

    .line 182
    .line 183
    .line 184
    invoke-static {v6, v7, v2}, Llw0;->g0(Landroid/content/res/Resources$Theme;IZ)Z

    .line 185
    .line 186
    .line 187
    move-result v6

    .line 188
    if-nez v6, :cond_be

    .line 189
    .line 190
    goto :goto_c4

    .line 191
    :cond_be
    new-instance v6, Lcom/google/android/material/focus/FocusRingDrawable;

    .line 192
    .line 193
    invoke-direct {v6, v0, v5}, Lcom/google/android/material/focus/FocusRingDrawable;-><init>(Landroid/content/Context;Landroid/graphics/drawable/Drawable;)V

    .line 194
    .line 195
    .line 196
    move-object v5, v6

    .line 197
    :goto_c4
    instance-of v0, v5, Lcom/google/android/material/focus/FocusRingDrawable;

    .line 198
    .line 199
    if-eqz v0, :cond_de

    .line 200
    .line 201
    check-cast v5, Lcom/google/android/material/focus/FocusRingDrawable;

    .line 202
    .line 203
    iget-object v0, v4, La4;->g:Ljava/lang/Object;

    .line 204
    .line 205
    check-cast v0, Lvm2;

    .line 206
    .line 207
    iget-object v6, v5, Lcom/google/android/material/focus/FocusRingDrawable;->r:Lzp0;

    .line 208
    .line 209
    iput-object v0, v6, Lzp0;->t:Ltm2;

    .line 210
    .line 211
    iget-object v0, v4, La4;->c:Ljava/lang/Object;

    .line 212
    .line 213
    check-cast v0, Landroid/graphics/Rect;

    .line 214
    .line 215
    iget v0, v0, Landroid/graphics/Rect;->top:I

    .line 216
    .line 217
    int-to-float v0, v0

    .line 218
    iput v0, v6, Lzp0;->p:F

    .line 219
    .line 220
    invoke-virtual {p1, v5}, Landroid/view/View;->setForeground(Landroid/graphics/drawable/Drawable;)V

    .line 221
    .line 222
    .line 223
    :cond_de
    :goto_de
    iget-object p2, p2, Lcn0;->e:Ljava/lang/Object;

    .line 224
    .line 225
    check-cast p2, La4;

    .line 226
    .line 227
    if-ne v4, p2, :cond_e5

    .line 228
    .line 229
    goto :goto_e6

    .line 230
    :cond_e5
    move v3, v2

    .line 231
    :goto_e6
    invoke-virtual {p1, v3}, Landroid/widget/TextView;->setSelected(Z)V

    .line 232
    .line 233
    .line 234
    new-instance p2, Llf3;

    .line 235
    .line 236
    invoke-direct {p2, p0, v1}, Llf3;-><init>(Lnf3;I)V

    .line 237
    .line 238
    .line 239
    invoke-virtual {p1, p2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 240
    .line 241
    .line 242
    return-void
.end method

.method public final onCreateViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/g;
    .registers 4

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-static {p0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    const p2, 0x7f0c0066

    .line 10
    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-virtual {p0, p2, p1, v0}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    check-cast p0, Landroid/widget/TextView;

    .line 18
    .line 19
    new-instance p1, Lmf3;

    .line 20
    .line 21
    invoke-direct {p1, p0}, Lmf3;-><init>(Landroid/widget/TextView;)V

    .line 22
    .line 23
    .line 24
    return-object p1
.end method
