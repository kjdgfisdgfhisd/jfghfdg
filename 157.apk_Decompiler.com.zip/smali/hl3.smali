###### Class defpackage.hl3 (hl3)
.class public final Lhl3;
.super Lbm3;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final synthetic c:I


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;I)V
    .registers 3

    .line 1
    iput p2, p0, Lhl3;->c:I

    .line 2
    .line 3
    invoke-direct {p0, p1}, Lbm3;-><init>(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a(Lvd3;Ljava/util/List;)Lhm3;
    .registers 3

    .line 1
    iget p1, p0, Lhl3;->c:I

    .line 2
    .line 3
    sget-object p2, Lhm3;->h0:Lrm3;

    .line 4
    .line 5
    packed-switch p1, :pswitch_data_16

    .line 6
    .line 7
    .line 8
    return-object p2

    .line 9
    :pswitch_8
    return-object p0

    .line 10
    :pswitch_9
    return-object p2

    .line 11
    :pswitch_a
    new-instance p0, Lul3;

    .line 12
    .line 13
    const-wide/16 p1, 0x0

    .line 14
    .line 15
    invoke-static {p1, p2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    invoke-direct {p0, p1}, Lul3;-><init>(Ljava/lang/Double;)V

    .line 20
    .line 21
    .line 22
    return-object p0

    .line 23
    :pswitch_data_16
    .packed-switch 0x0
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_8
    .end packed-switch
.end method
