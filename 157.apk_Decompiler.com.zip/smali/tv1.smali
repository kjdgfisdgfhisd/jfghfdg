###### Class defpackage.tv1 (tv1)
.class public interface abstract Ltv1;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lsv1;


# virtual methods
.method public abstract e(Landroid/view/View;IIIII[I)V
.end method
