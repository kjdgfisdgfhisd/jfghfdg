###### Class defpackage.q42 (q42)
.class public final Lq42;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Ljava/util/Iterator;


# instance fields
.field public final synthetic a:I

.field public final b:Ljava/util/Iterator;

.field public c:Ljava/lang/Object;

.field public final synthetic d:Lw42;


# direct methods
.method public constructor <init>(Lw42;I)V
    .registers 3

    .line 1
    iput p2, p0, Lq42;->a:I

    .line 2
    .line 3
    packed-switch p2, :pswitch_data_3c

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, Lq42;->d:Lw42;

    .line 10
    .line 11
    iget-object p1, p1, Lw42;->a:Ljava/util/concurrent/ConcurrentHashMap;

    .line 12
    .line 13
    invoke-virtual {p1}, Ljava/util/concurrent/ConcurrentHashMap;->values()Ljava/util/Collection;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    iput-object p1, p0, Lq42;->b:Ljava/util/Iterator;

    .line 22
    .line 23
    return-void

    .line 24
    :pswitch_17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 25
    .line 26
    .line 27
    iput-object p1, p0, Lq42;->d:Lw42;

    .line 28
    .line 29
    iget-object p1, p1, Lw42;->a:Ljava/util/concurrent/ConcurrentHashMap;

    .line 30
    .line 31
    invoke-virtual {p1}, Ljava/util/concurrent/ConcurrentHashMap;->keySet()Ljava/util/Set;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 36
    .line 37
    .line 38
    move-result-object p1

    .line 39
    iput-object p1, p0, Lq42;->b:Ljava/util/Iterator;

    .line 40
    .line 41
    return-void

    .line 42
    :pswitch_29
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 43
    .line 44
    .line 45
    iput-object p1, p0, Lq42;->d:Lw42;

    .line 46
    .line 47
    iget-object p1, p1, Lw42;->a:Ljava/util/concurrent/ConcurrentHashMap;

    .line 48
    .line 49
    invoke-virtual {p1}, Ljava/util/concurrent/ConcurrentHashMap;->values()Ljava/util/Collection;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    iput-object p1, p0, Lq42;->b:Ljava/util/Iterator;

    .line 58
    .line 59
    return-void

    .line 60
    nop

    .line 61
    :pswitch_data_3c
    .packed-switch 0x1
        :pswitch_29
        :pswitch_17
    .end packed-switch
.end method


# virtual methods
.method public final hasNext()Z
    .registers 2

    .line 1
    iget v0, p0, Lq42;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_1a

    .line 4
    .line 5
    .line 6
    iget-object p0, p0, Lq42;->b:Ljava/util/Iterator;

    .line 7
    .line 8
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 9
    .line 10
    .line 11
    move-result p0

    .line 12
    return p0

    .line 13
    :pswitch_c
    iget-object p0, p0, Lq42;->b:Ljava/util/Iterator;

    .line 14
    .line 15
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    return p0

    .line 20
    :pswitch_13
    iget-object p0, p0, Lq42;->b:Ljava/util/Iterator;

    .line 21
    .line 22
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 23
    .line 24
    .line 25
    move-result p0

    .line 26
    return p0

    .line 27
    :pswitch_data_1a
    .packed-switch 0x0
        :pswitch_13
        :pswitch_c
    .end packed-switch
.end method

.method public final next()Ljava/lang/Object;
    .registers 3

    .line 1
    iget v0, p0, Lq42;->a:I

    .line 2
    .line 3
    iget-object v1, p0, Lq42;->b:Ljava/util/Iterator;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_30

    .line 6
    .line 7
    .line 8
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    iput-object v0, p0, Lq42;->c:Ljava/lang/Object;

    .line 13
    .line 14
    return-object v0

    .line 15
    :pswitch_e
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    check-cast v0, Ls42;

    .line 20
    .line 21
    iput-object v0, p0, Lq42;->c:Ljava/lang/Object;

    .line 22
    .line 23
    invoke-virtual {v0}, Ls42;->a()Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    return-object p0

    .line 28
    :pswitch_1b
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    check-cast v0, Ls42;

    .line 33
    .line 34
    iput-object v0, p0, Lq42;->c:Ljava/lang/Object;

    .line 35
    .line 36
    new-instance v0, Lv42;

    .line 37
    .line 38
    iget-object v1, p0, Lq42;->c:Ljava/lang/Object;

    .line 39
    .line 40
    check-cast v1, Ls42;

    .line 41
    .line 42
    iget-object p0, p0, Lq42;->d:Lw42;

    .line 43
    .line 44
    invoke-direct {v0, p0, v1}, Lv42;-><init>(Lw42;Ls42;)V

    .line 45
    .line 46
    .line 47
    return-object v0

    .line 48
    nop

    .line 49
    :pswitch_data_30
    .packed-switch 0x0
        :pswitch_1b
        :pswitch_e
    .end packed-switch
.end method

.method public final remove()V
    .registers 6

    .line 1
    iget v0, p0, Lq42;->a:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    iget-object v2, p0, Lq42;->d:Lw42;

    .line 5
    .line 6
    const/4 v3, 0x0

    .line 7
    const/4 v4, 0x1

    .line 8
    packed-switch v0, :pswitch_data_52

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, Lq42;->c:Ljava/lang/Object;

    .line 12
    .line 13
    if-eqz v0, :cond_f

    .line 14
    .line 15
    move v3, v4

    .line 16
    :cond_f
    sget v4, Lw42;->r:I

    .line 17
    .line 18
    if-eqz v3, :cond_19

    .line 19
    .line 20
    invoke-virtual {v2, v0}, Lw42;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    iput-object v1, p0, Lq42;->c:Ljava/lang/Object;

    .line 24
    .line 25
    return-void

    .line 26
    :cond_19
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 27
    .line 28
    invoke-direct {p0}, Ljava/lang/IllegalStateException;-><init>()V

    .line 29
    .line 30
    .line 31
    throw p0

    .line 32
    :pswitch_1f
    iget-object v0, p0, Lq42;->c:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast v0, Ls42;

    .line 35
    .line 36
    if-eqz v0, :cond_26

    .line 37
    .line 38
    move v3, v4

    .line 39
    :cond_26
    sget v4, Lw42;->r:I

    .line 40
    .line 41
    if-eqz v3, :cond_32

    .line 42
    .line 43
    iget-object v0, v0, Ls42;->a:Ljava/lang/Object;

    .line 44
    .line 45
    invoke-virtual {v2, v0}, Lw42;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    iput-object v1, p0, Lq42;->c:Ljava/lang/Object;

    .line 49
    .line 50
    return-void

    .line 51
    :cond_32
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 52
    .line 53
    invoke-direct {p0}, Ljava/lang/IllegalStateException;-><init>()V

    .line 54
    .line 55
    .line 56
    throw p0

    .line 57
    :pswitch_38
    iget-object v0, p0, Lq42;->c:Ljava/lang/Object;

    .line 58
    .line 59
    check-cast v0, Ls42;

    .line 60
    .line 61
    if-eqz v0, :cond_3f

    .line 62
    .line 63
    move v3, v4

    .line 64
    :cond_3f
    sget v4, Lw42;->r:I

    .line 65
    .line 66
    if-eqz v3, :cond_4b

    .line 67
    .line 68
    iget-object v0, v0, Ls42;->a:Ljava/lang/Object;

    .line 69
    .line 70
    invoke-virtual {v2, v0}, Lw42;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    iput-object v1, p0, Lq42;->c:Ljava/lang/Object;

    .line 74
    .line 75
    return-void

    .line 76
    :cond_4b
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 77
    .line 78
    invoke-direct {p0}, Ljava/lang/IllegalStateException;-><init>()V

    .line 79
    .line 80
    .line 81
    throw p0

    .line 82
    nop

    .line 83
    :pswitch_data_52
    .packed-switch 0x0
        :pswitch_38
        :pswitch_1f
    .end packed-switch
.end method
