###### Class defpackage.fu0 (fu0)
.class public final Lfu0;
.super Lo;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field public static final o:Lft;

.field public static final p:Lft;


# instance fields
.field public final e:Lcm1;

.field public final f:Lu02;

.field public final g:Ltu0;

.field public final j:I

.field public final l:Leu0;

.field public final m:Lhu0;

.field public final n:Ljava/util/List;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    new-instance v0, Lft;

    .line 2
    .line 3
    sget-object v1, Lrr2;->k:Lzq0;

    .line 4
    .line 5
    const-string v2, "Function"

    .line 6
    .line 7
    invoke-static {v2}, Ldv1;->e(Ljava/lang/String;)Ldv1;

    .line 8
    .line 9
    .line 10
    move-result-object v2

    .line 11
    invoke-direct {v0, v1, v2}, Lft;-><init>(Lzq0;Ldv1;)V

    .line 12
    .line 13
    .line 14
    sput-object v0, Lfu0;->o:Lft;

    .line 15
    .line 16
    new-instance v0, Lft;

    .line 17
    .line 18
    sget-object v1, Lrr2;->i:Lzq0;

    .line 19
    .line 20
    const-string v2, "KFunction"

    .line 21
    .line 22
    invoke-static {v2}, Ldv1;->e(Ljava/lang/String;)Ldv1;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    invoke-direct {v0, v1, v2}, Lft;-><init>(Lzq0;Ldv1;)V

    .line 27
    .line 28
    .line 29
    sput-object v0, Lfu0;->p:Lft;

    .line 30
    .line 31
    return-void
.end method

.method public constructor <init>(Lcm1;Lum;Ltu0;I)V
    .registers 8

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p3, p4}, Ltu0;->a(I)Ldv1;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-direct {p0, p1, v0}, Lo;-><init>(Lcm1;Ldv1;)V

    .line 9
    .line 10
    .line 11
    iput-object p1, p0, Lfu0;->e:Lcm1;

    .line 12
    .line 13
    iput-object p2, p0, Lfu0;->f:Lu02;

    .line 14
    .line 15
    iput-object p3, p0, Lfu0;->g:Ltu0;

    .line 16
    .line 17
    iput p4, p0, Lfu0;->j:I

    .line 18
    .line 19
    new-instance p2, Leu0;

    .line 20
    .line 21
    invoke-direct {p2, p0}, Leu0;-><init>(Lfu0;)V

    .line 22
    .line 23
    .line 24
    iput-object p2, p0, Lfu0;->l:Leu0;

    .line 25
    .line 26
    new-instance p2, Lhu0;

    .line 27
    .line 28
    invoke-direct {p2, p1, p0}, Lgw0;-><init>(Lcm1;Lo;)V

    .line 29
    .line 30
    .line 31
    iput-object p2, p0, Lfu0;->m:Lhu0;

    .line 32
    .line 33
    new-instance p1, Ljava/util/ArrayList;

    .line 34
    .line 35
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 36
    .line 37
    .line 38
    new-instance p2, Ll21;

    .line 39
    .line 40
    const/4 p3, 0x1

    .line 41
    invoke-direct {p2, p3, p4, p3}, Lj21;-><init>(III)V

    .line 42
    .line 43
    .line 44
    new-instance p3, Ljava/util/ArrayList;

    .line 45
    .line 46
    const/16 p4, 0xa

    .line 47
    .line 48
    invoke-static {p2, p4}, Liv;->M(Ljava/lang/Iterable;I)I

    .line 49
    .line 50
    .line 51
    move-result p4

    .line 52
    invoke-direct {p3, p4}, Ljava/util/ArrayList;-><init>(I)V

    .line 53
    .line 54
    .line 55
    invoke-virtual {p2}, Lj21;->iterator()Ljava/util/Iterator;

    .line 56
    .line 57
    .line 58
    move-result-object p2

    .line 59
    :goto_3a
    move-object p4, p2

    .line 60
    check-cast p4, Lk21;

    .line 61
    .line 62
    iget-boolean v0, p4, Lk21;->c:Z

    .line 63
    .line 64
    if-eqz v0, :cond_6c

    .line 65
    .line 66
    invoke-virtual {p4}, Lk21;->nextInt()I

    .line 67
    .line 68
    .line 69
    move-result p4

    .line 70
    new-instance v0, Ljava/lang/StringBuilder;

    .line 71
    .line 72
    const-string v1, "P"

    .line 73
    .line 74
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 75
    .line 76
    .line 77
    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 78
    .line 79
    .line 80
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 81
    .line 82
    .line 83
    move-result-object p4

    .line 84
    invoke-static {p4}, Ldv1;->e(Ljava/lang/String;)Ldv1;

    .line 85
    .line 86
    .line 87
    move-result-object p4

    .line 88
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    .line 89
    .line 90
    .line 91
    move-result v0

    .line 92
    iget-object v1, p0, Lfu0;->e:Lcm1;

    .line 93
    .line 94
    sget-object v2, Lf73;->d:Lf73;

    .line 95
    .line 96
    invoke-static {p0, v2, p4, v0, v1}, Lm23;->N0(Lo;Lf73;Ldv1;ILcm1;)Lm23;

    .line 97
    .line 98
    .line 99
    move-result-object p4

    .line 100
    invoke-virtual {p1, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 101
    .line 102
    .line 103
    sget-object p4, Lw43;->a:Lw43;

    .line 104
    .line 105
    invoke-virtual {p3, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 106
    .line 107
    .line 108
    goto :goto_3a

    .line 109
    :cond_6c
    const-string p2, "R"

    .line 110
    .line 111
    invoke-static {p2}, Ldv1;->e(Ljava/lang/String;)Ldv1;

    .line 112
    .line 113
    .line 114
    move-result-object p2

    .line 115
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    .line 116
    .line 117
    .line 118
    move-result p3

    .line 119
    iget-object p4, p0, Lfu0;->e:Lcm1;

    .line 120
    .line 121
    sget-object v0, Lf73;->e:Lf73;

    .line 122
    .line 123
    invoke-static {p0, v0, p2, p3, p4}, Lm23;->N0(Lo;Lf73;Ldv1;ILcm1;)Lm23;

    .line 124
    .line 125
    .line 126
    move-result-object p2

    .line 127
    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 128
    .line 129
    .line 130
    invoke-static {p1}, Lgv;->y0(Ljava/lang/Iterable;)Ljava/util/List;

    .line 131
    .line 132
    .line 133
    move-result-object p1

    .line 134
    iput-object p1, p0, Lfu0;->n:Ljava/util/List;

    .line 135
    .line 136
    iget-object p0, p0, Lfu0;->g:Ltu0;

    .line 137
    .line 138
    sget-object p1, Lgu0;->a:Lih2;

    .line 139
    .line 140
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 141
    .line 142
    .line 143
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 144
    .line 145
    .line 146
    sget-object p1, Lpu0;->c:Lpu0;

    .line 147
    .line 148
    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 149
    .line 150
    .line 151
    move-result p1

    .line 152
    if-eqz p1, :cond_9a

    .line 153
    .line 154
    goto :goto_ab

    .line 155
    :cond_9a
    sget-object p1, Lsu0;->c:Lsu0;

    .line 156
    .line 157
    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 158
    .line 159
    .line 160
    move-result p1

    .line 161
    if-eqz p1, :cond_a3

    .line 162
    .line 163
    goto :goto_ab

    .line 164
    :cond_a3
    sget-object p1, Lqu0;->c:Lqu0;

    .line 165
    .line 166
    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 167
    .line 168
    .line 169
    move-result p1

    .line 170
    if-eqz p1, :cond_ac

    .line 171
    .line 172
    :goto_ab
    return-void

    .line 173
    :cond_ac
    sget-object p1, Lru0;->c:Lru0;

    .line 174
    .line 175
    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 176
    .line 177
    .line 178
    return-void
.end method


# virtual methods
.method public final A0()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final B()Lvr1;
    .registers 1

    .line 1
    sget-object p0, Lur1;->b:Lur1;

    .line 2
    .line 3
    return-object p0
.end method

.method public final B0()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final C()Lp13;
    .registers 1

    .line 1
    iget-object p0, p0, Lfu0;->l:Leu0;

    .line 2
    .line 3
    return-object p0
.end method

.method public final D()Lot1;
    .registers 1

    .line 1
    sget-object p0, Lot1;->e:Lot1;

    .line 2
    .line 3
    return-object p0
.end method

.method public final Y()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final Z()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final a()Ljava/util/Collection;
    .registers 1

    .line 1
    sget-object p0, Lth0;->a:Lth0;

    .line 2
    .line 3
    return-object p0
.end method

.method public final d()Loq2;
    .registers 1

    .line 1
    sget-object p0, Loq2;->e0:Ll01;

    .line 2
    .line 3
    return-object p0
.end method

.method public final g()Lya0;
    .registers 1

    .line 1
    sget-object p0, Lza0;->e:Lya0;

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    return-object p0
.end method

.method public final getAnnotations()Ll7;
    .registers 1

    .line 1
    sget-object p0, Lwn0;->b:Lk7;

    .line 2
    .line 3
    return-object p0
.end method

.method public final i()Ljt;
    .registers 1

    .line 1
    sget-object p0, Ljt;->b:Ljt;

    .line 2
    .line 3
    return-object p0
.end method

.method public final o()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final o0()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final p()Lm60;
    .registers 1

    .line 1
    iget-object p0, p0, Lfu0;->f:Lu02;

    .line 2
    .line 3
    return-object p0
.end method

.method public final s0()Ljava/util/List;
    .registers 1

    .line 1
    iget-object p0, p0, Lfu0;->n:Ljava/util/List;

    .line 2
    .line 3
    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 1

    .line 1
    invoke-virtual {p0}, Lo;->getName()Ldv1;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0}, Ldv1;->b()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    return-object p0
.end method

.method public final u0(Llg1;)Lvr1;
    .registers 2

    .line 1
    iget-object p0, p0, Lfu0;->m:Lhu0;

    .line 2
    .line 3
    return-object p0
.end method

.method public final w0()Lvs;
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return-object p0
.end method

.method public final x0()Lu63;
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return-object p0
.end method

.method public final y()Ljava/util/Collection;
    .registers 1

    .line 1
    sget-object p0, Lth0;->a:Lth0;

    .line 2
    .line 3
    return-object p0
.end method

.method public final y0()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final z()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final z0()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method
