###### Class defpackage.gm2 (gm2)
.class public final Lgm2;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field public static final synthetic a:[Laf1;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    new-instance v0, Lu52;

    .line 2
    .line 3
    const-class v1, Lgm2;

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lu52;-><init>(Ljava/lang/Class;)V

    .line 6
    .line 7
    .line 8
    sget-object v1, Ltd2;->a:Lud2;

    .line 9
    .line 10
    invoke-virtual {v1, v0}, Lud2;->g(Lu52;)Lwe1;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    const/4 v1, 0x1

    .line 15
    new-array v1, v1, [Laf1;

    .line 16
    .line 17
    const/4 v2, 0x0

    .line 18
    aput-object v0, v1, v2

    .line 19
    .line 20
    sput-object v1, Lgm2;->a:[Laf1;

    .line 21
    .line 22
    return-void
.end method
