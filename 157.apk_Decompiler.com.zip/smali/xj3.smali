###### Class defpackage.xj3 (xj3)
.class public abstract Lxj3;
.super Landroid/os/Binder;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Landroid/os/IInterface;


# instance fields
.field public final synthetic d:I


# direct methods
.method public synthetic constructor <init>()V
    .registers 2

    .line 11
    const/4 v0, 0x0

    iput v0, p0, Lxj3;->d:I

    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .registers 3

    .line 1
    const/4 v0, 0x1

    .line 2
    iput v0, p0, Lxj3;->d:I

    .line 3
    .line 4
    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0, p0, p1}, Landroid/os/Binder;->attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public A(ILandroid/os/Parcel;Landroid/os/Parcel;)Z
    .registers 4

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final asBinder()Landroid/os/IBinder;
    .registers 2

    .line 1
    iget v0, p0, Lxj3;->d:I

    .line 2
    .line 3
    return-object p0
.end method

.method public final onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .registers 8

    .line 1
    iget v0, p0, Lxj3;->d:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    const v2, 0xffffff

    .line 5
    .line 6
    .line 7
    packed-switch v0, :pswitch_data_9e

    .line 8
    .line 9
    .line 10
    if-le p1, v2, :cond_12

    .line 11
    .line 12
    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    .line 13
    .line 14
    .line 15
    move-result p4

    .line 16
    if-eqz p4, :cond_19

    .line 17
    .line 18
    goto :goto_1d

    .line 19
    :cond_12
    invoke-virtual {p0}, Landroid/os/Binder;->getInterfaceDescriptor()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object p4

    .line 23
    invoke-virtual {p2, p4}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    :cond_19
    invoke-virtual {p0, p1, p2, p3}, Lxj3;->A(ILandroid/os/Parcel;Landroid/os/Parcel;)Z

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    :goto_1d
    return v1

    .line 31
    :pswitch_1e
    if-le p1, v2, :cond_28

    .line 32
    .line 33
    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    .line 34
    .line 35
    .line 36
    move-result p4

    .line 37
    if-eqz p4, :cond_2f

    .line 38
    .line 39
    goto/16 :goto_9d

    .line 40
    .line 41
    :cond_28
    invoke-virtual {p0}, Landroid/os/Binder;->getInterfaceDescriptor()Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object p4

    .line 45
    invoke-virtual {p2, p4}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    :cond_2f
    check-cast p0, Lik3;

    .line 49
    .line 50
    const/4 p4, 0x0

    .line 51
    packed-switch p1, :pswitch_data_a4

    .line 52
    .line 53
    .line 54
    :pswitch_35
    move v1, p4

    .line 55
    goto :goto_9d

    .line 56
    :pswitch_37
    sget-object p0, Lpk3;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 57
    .line 58
    invoke-static {p2, p0}, Lek3;->a(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    .line 59
    .line 60
    .line 61
    move-result-object p0

    .line 62
    check-cast p0, Lpk3;

    .line 63
    .line 64
    invoke-static {p2}, Lek3;->b(Landroid/os/Parcel;)V

    .line 65
    .line 66
    .line 67
    goto :goto_9a

    .line 68
    :pswitch_43
    sget-object p1, Ltk3;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 69
    .line 70
    invoke-static {p2, p1}, Lek3;->a(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    .line 71
    .line 72
    .line 73
    move-result-object p1

    .line 74
    check-cast p1, Ltk3;

    .line 75
    .line 76
    invoke-static {p2}, Lek3;->b(Landroid/os/Parcel;)V

    .line 77
    .line 78
    .line 79
    new-instance p2, Lyu0;

    .line 80
    .line 81
    const/16 v0, 0x12

    .line 82
    .line 83
    invoke-direct {p2, v0, p0, p1, p4}, Lyu0;-><init>(ILjava/lang/Object;Ljava/lang/Object;Z)V

    .line 84
    .line 85
    .line 86
    iget-object p0, p0, Lik3;->f:Landroid/os/Handler;

    .line 87
    .line 88
    invoke-virtual {p0, p2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 89
    .line 90
    .line 91
    goto :goto_9a

    .line 92
    :pswitch_5b
    sget-object p0, Lcom/google/android/gms/common/api/Status;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 93
    .line 94
    invoke-static {p2, p0}, Lek3;->a(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    .line 95
    .line 96
    .line 97
    move-result-object p0

    .line 98
    check-cast p0, Lcom/google/android/gms/common/api/Status;

    .line 99
    .line 100
    sget-object p0, Lcom/google/android/gms/auth/api/signin/GoogleSignInAccount;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 101
    .line 102
    invoke-static {p2, p0}, Lek3;->a(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    .line 103
    .line 104
    .line 105
    move-result-object p0

    .line 106
    check-cast p0, Lcom/google/android/gms/auth/api/signin/GoogleSignInAccount;

    .line 107
    .line 108
    invoke-static {p2}, Lek3;->b(Landroid/os/Parcel;)V

    .line 109
    .line 110
    .line 111
    goto :goto_9a

    .line 112
    :pswitch_6f
    sget-object p0, Lcom/google/android/gms/common/api/Status;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 113
    .line 114
    invoke-static {p2, p0}, Lek3;->a(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    .line 115
    .line 116
    .line 117
    move-result-object p0

    .line 118
    check-cast p0, Lcom/google/android/gms/common/api/Status;

    .line 119
    .line 120
    invoke-static {p2}, Lek3;->b(Landroid/os/Parcel;)V

    .line 121
    .line 122
    .line 123
    goto :goto_9a

    .line 124
    :pswitch_7b
    sget-object p0, Lcom/google/android/gms/common/api/Status;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 125
    .line 126
    invoke-static {p2, p0}, Lek3;->a(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    .line 127
    .line 128
    .line 129
    move-result-object p0

    .line 130
    check-cast p0, Lcom/google/android/gms/common/api/Status;

    .line 131
    .line 132
    invoke-static {p2}, Lek3;->b(Landroid/os/Parcel;)V

    .line 133
    .line 134
    .line 135
    goto :goto_9a

    .line 136
    :pswitch_87
    sget-object p0, Lgy;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 137
    .line 138
    invoke-static {p2, p0}, Lek3;->a(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    .line 139
    .line 140
    .line 141
    move-result-object p0

    .line 142
    check-cast p0, Lgy;

    .line 143
    .line 144
    sget-object p0, Luj3;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 145
    .line 146
    invoke-static {p2, p0}, Lek3;->a(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    .line 147
    .line 148
    .line 149
    move-result-object p0

    .line 150
    check-cast p0, Luj3;

    .line 151
    .line 152
    invoke-static {p2}, Lek3;->b(Landroid/os/Parcel;)V

    .line 153
    .line 154
    .line 155
    :goto_9a
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 156
    .line 157
    .line 158
    :goto_9d
    return v1

    .line 159
    :pswitch_data_9e
    .packed-switch 0x0
        :pswitch_1e
    .end packed-switch

    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    :pswitch_data_a4
    .packed-switch 0x3
        :pswitch_87
        :pswitch_7b
        :pswitch_35
        :pswitch_6f
        :pswitch_5b
        :pswitch_43
        :pswitch_37
    .end packed-switch
.end method
