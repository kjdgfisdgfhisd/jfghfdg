###### Class defpackage.zb1 (zb1)
.class public final Lzb1;
.super Lzd3;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final d:Lob1;

.field public final e:Lob1;


# direct methods
.method public constructor <init>(Lob1;Lob1;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lzb1;->d:Lob1;

    .line 5
    .line 6
    iput-object p2, p0, Lzb1;->e:Lob1;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .registers 1

    .line 1
    iget-object p0, p0, Lzb1;->d:Lob1;

    .line 2
    .line 3
    iget-object p0, p0, Lob1;->d:Ljava/lang/String;

    .line 4
    .line 5
    return-object p0
.end method
