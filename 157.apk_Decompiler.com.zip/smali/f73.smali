###### Class defpackage.f73 (f73)
.class public final enum Lf73;
.super Ljava/lang/Enum;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field public static final enum c:Lf73;

.field public static final enum d:Lf73;

.field public static final enum e:Lf73;

.field public static final synthetic f:[Lf73;


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Z


# direct methods
.method static constructor <clinit>()V
    .registers 7

    .line 1
    new-instance v0, Lf73;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const-string v2, "INVARIANT"

    .line 5
    .line 6
    const-string v3, ""

    .line 7
    .line 8
    const/4 v4, 0x1

    .line 9
    invoke-direct {v0, v1, v2, v3, v4}, Lf73;-><init>(ILjava/lang/String;Ljava/lang/String;Z)V

    .line 10
    .line 11
    .line 12
    sput-object v0, Lf73;->c:Lf73;

    .line 13
    .line 14
    new-instance v2, Lf73;

    .line 15
    .line 16
    const-string v3, "IN_VARIANCE"

    .line 17
    .line 18
    const-string v5, "in"

    .line 19
    .line 20
    invoke-direct {v2, v4, v3, v5, v1}, Lf73;-><init>(ILjava/lang/String;Ljava/lang/String;Z)V

    .line 21
    .line 22
    .line 23
    sput-object v2, Lf73;->d:Lf73;

    .line 24
    .line 25
    new-instance v1, Lf73;

    .line 26
    .line 27
    const/4 v3, 0x2

    .line 28
    const-string v5, "out"

    .line 29
    .line 30
    const-string v6, "OUT_VARIANCE"

    .line 31
    .line 32
    invoke-direct {v1, v3, v6, v5, v4}, Lf73;-><init>(ILjava/lang/String;Ljava/lang/String;Z)V

    .line 33
    .line 34
    .line 35
    sput-object v1, Lf73;->e:Lf73;

    .line 36
    .line 37
    filled-new-array {v0, v2, v1}, [Lf73;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    sput-object v0, Lf73;->f:[Lf73;

    .line 42
    .line 43
    return-void
.end method

.method public constructor <init>(ILjava/lang/String;Ljava/lang/String;Z)V
    .registers 5

    .line 1
    invoke-direct {p0, p2, p1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 2
    .line 3
    .line 4
    iput-object p3, p0, Lf73;->a:Ljava/lang/String;

    .line 5
    .line 6
    iput-boolean p4, p0, Lf73;->b:Z

    .line 7
    .line 8
    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lf73;
    .registers 2

    .line 1
    const-class v0, Lf73;

    .line 2
    .line 3
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lf73;

    .line 8
    .line 9
    return-object p0
.end method

.method public static values()[Lf73;
    .registers 1

    .line 1
    sget-object v0, Lf73;->f:[Lf73;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [Lf73;

    .line 8
    .line 9
    return-object v0
.end method


# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 1

    .line 1
    iget-object p0, p0, Lf73;->a:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method
