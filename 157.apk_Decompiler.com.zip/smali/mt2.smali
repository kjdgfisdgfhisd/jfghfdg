###### Class defpackage.mt2 (mt2)
.class public final Lmt2;
.super Lio2;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lx61;


# instance fields
.field public final m:Lb61;

.field public final n:Ljf3;

.field public final o:La4;

.field public p:I

.field public final q:Lf71;


# direct methods
.method public constructor <init>(Lb61;Ljf3;La4;Lwk2;)V
    .registers 5

    .line 1
    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lmt2;->m:Lb61;

    .line 8
    .line 9
    iput-object p2, p0, Lmt2;->n:Ljf3;

    .line 10
    .line 11
    iput-object p3, p0, Lmt2;->o:La4;

    .line 12
    .line 13
    const/4 p2, -0x1

    .line 14
    iput p2, p0, Lmt2;->p:I

    .line 15
    .line 16
    iget-object p1, p1, Lb61;->a:Lq61;

    .line 17
    .line 18
    iget-boolean p1, p1, Lq61;->b:Z

    .line 19
    .line 20
    if-eqz p1, :cond_17

    .line 21
    .line 22
    const/4 p1, 0x0

    .line 23
    goto :goto_1c

    .line 24
    :cond_17
    new-instance p1, Lf71;

    .line 25
    .line 26
    invoke-direct {p1, p4}, Lf71;-><init>(Lwk2;)V

    .line 27
    .line 28
    .line 29
    :goto_1c
    iput-object p1, p0, Lmt2;->q:Lf71;

    .line 30
    .line 31
    return-void
.end method


# virtual methods
.method public final A()F
    .registers 6

    .line 1
    iget-object p0, p0, Lmt2;->o:La4;

    .line 2
    .line 3
    invoke-virtual {p0}, La4;->m()Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const/4 v1, 0x0

    .line 8
    const/4 v2, 0x0

    .line 9
    :try_start_8
    invoke-static {v0}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    .line 10
    .line 11
    .line 12
    move-result v0
    :try_end_c
    .catch Ljava/lang/IllegalArgumentException; {:try_start_8 .. :try_end_c} :catch_25

    .line 13
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    .line 14
    .line 15
    .line 16
    move-result v3

    .line 17
    const v4, 0x7f7fffff    # Float.MAX_VALUE

    .line 18
    .line 19
    .line 20
    cmpg-float v3, v3, v4

    .line 21
    .line 22
    if-gtz v3, :cond_18

    .line 23
    .line 24
    return v0

    .line 25
    :cond_18
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-static {v0, v2}, Lsn2;->u(Ljava/lang/Number;Ljava/lang/String;)Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    const/4 v3, 0x2

    .line 34
    invoke-static {p0, v0, v1, v3}, La4;->s(La4;Ljava/lang/String;II)V

    .line 35
    .line 36
    .line 37
    throw v2

    .line 38
    :catch_25
    const-string v3, "Failed to parse type \'float\' for input \'"

    .line 39
    .line 40
    const/16 v4, 0x27

    .line 41
    .line 42
    invoke-static {v3, v0, v4}, Ls41;->q(Ljava/lang/String;Ljava/lang/String;C)Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    const/4 v3, 0x6

    .line 47
    invoke-static {p0, v0, v1, v3}, La4;->s(La4;Ljava/lang/String;II)V

    .line 48
    .line 49
    .line 50
    throw v2
.end method

.method public final C(Lwk2;)I
    .registers 5

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lmt2;->o:La4;

    .line 5
    .line 6
    invoke-virtual {v0}, La4;->l()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    iget-object v0, v0, La4;->d:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v0, Lvv;

    .line 13
    .line 14
    invoke-virtual {v0}, Lvv;->a()Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    const-string v2, " at path "

    .line 19
    .line 20
    invoke-virtual {v2, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    iget-object p0, p0, Lmt2;->m:Lb61;

    .line 25
    .line 26
    invoke-static {p1, p0, v1, v0}, Lc10;->q(Lwk2;Lb61;Ljava/lang/String;Ljava/lang/String;)I

    .line 27
    .line 28
    .line 29
    move-result p0

    .line 30
    return p0
.end method

.method public final D()D
    .registers 10

    .line 1
    iget-object p0, p0, Lmt2;->o:La4;

    .line 2
    .line 3
    invoke-virtual {p0}, La4;->m()Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const/4 v1, 0x0

    .line 8
    const/4 v2, 0x0

    .line 9
    :try_start_8
    invoke-static {v0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    .line 10
    .line 11
    .line 12
    move-result-wide v3
    :try_end_c
    .catch Ljava/lang/IllegalArgumentException; {:try_start_8 .. :try_end_c} :catch_27

    .line 13
    invoke-static {v3, v4}, Ljava/lang/Math;->abs(D)D

    .line 14
    .line 15
    .line 16
    move-result-wide v5

    .line 17
    const-wide v7, 0x7fefffffffffffffL    # Double.MAX_VALUE

    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    cmpg-double v0, v5, v7

    .line 23
    .line 24
    if-gtz v0, :cond_1a

    .line 25
    .line 26
    return-wide v3

    .line 27
    :cond_1a
    invoke-static {v3, v4}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    invoke-static {v0, v2}, Lsn2;->u(Ljava/lang/Number;Ljava/lang/String;)Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    const/4 v3, 0x2

    .line 36
    invoke-static {p0, v0, v1, v3}, La4;->s(La4;Ljava/lang/String;II)V

    .line 37
    .line 38
    .line 39
    throw v2

    .line 40
    :catch_27
    const-string v3, "Failed to parse type \'double\' for input \'"

    .line 41
    .line 42
    const/16 v4, 0x27

    .line 43
    .line 44
    invoke-static {v3, v0, v4}, Ls41;->q(Ljava/lang/String;Ljava/lang/String;C)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    const/4 v3, 0x6

    .line 49
    invoke-static {p0, v0, v1, v3}, La4;->s(La4;Ljava/lang/String;II)V

    .line 50
    .line 51
    .line 52
    throw v2
.end method

.method public final a(Lwk2;)V
    .registers 6

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-interface {p1}, Lwk2;->c()I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    const/4 v1, -0x1

    .line 9
    if-nez v0, :cond_18

    .line 10
    .line 11
    iget-object v0, p0, Lmt2;->m:Lb61;

    .line 12
    .line 13
    invoke-static {v0, p1}, Lc10;->t(Lb61;Lwk2;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_18

    .line 18
    .line 19
    :cond_12
    invoke-virtual {p0, p1}, Lmt2;->k(Lwk2;)I

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-ne v0, v1, :cond_12

    .line 24
    .line 25
    :cond_18
    iget-object p1, p0, Lmt2;->o:La4;

    .line 26
    .line 27
    invoke-virtual {p1}, La4;->M()Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-nez v0, :cond_40

    .line 32
    .line 33
    iget-object p0, p0, Lmt2;->n:Ljf3;

    .line 34
    .line 35
    iget-char p0, p0, Ljf3;->b:C

    .line 36
    .line 37
    invoke-virtual {p1, p0}, La4;->i(C)V

    .line 38
    .line 39
    .line 40
    iget-object p0, p1, La4;->d:Ljava/lang/Object;

    .line 41
    .line 42
    check-cast p0, Lvv;

    .line 43
    .line 44
    iget p1, p0, Lvv;->c:I

    .line 45
    .line 46
    iget-object v0, p0, Lvv;->b:[I

    .line 47
    .line 48
    aget v2, v0, p1

    .line 49
    .line 50
    const/4 v3, -0x2

    .line 51
    if-ne v2, v3, :cond_3a

    .line 52
    .line 53
    aput v1, v0, p1

    .line 54
    .line 55
    add-int/lit8 p1, p1, -0x1

    .line 56
    .line 57
    iput p1, p0, Lvv;->c:I

    .line 58
    .line 59
    :cond_3a
    if-eq p1, v1, :cond_3f

    .line 60
    .line 61
    add-int/2addr p1, v1

    .line 62
    iput p1, p0, Lvv;->c:I

    .line 63
    .line 64
    :cond_3f
    return-void

    .line 65
    :cond_40
    const-string p0, ""

    .line 66
    .line 67
    invoke-static {p1, p0}, Lsn2;->p(La4;Ljava/lang/String;)V

    .line 68
    .line 69
    .line 70
    const/4 p0, 0x0

    .line 71
    throw p0
.end method

.method public final b(Lwk2;)Lnx;
    .registers 9

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lmt2;->m:Lb61;

    .line 5
    .line 6
    invoke-static {v0, p1}, Lzd3;->t(Lb61;Lwk2;)Ljf3;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    iget-object v2, p0, Lmt2;->o:La4;

    .line 11
    .line 12
    iget-object v3, v2, La4;->d:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v3, Lvv;

    .line 15
    .line 16
    iget v4, v3, Lvv;->c:I

    .line 17
    .line 18
    const/4 v5, 0x1

    .line 19
    add-int/2addr v4, v5

    .line 20
    iput v4, v3, Lvv;->c:I

    .line 21
    .line 22
    iget-object v6, v3, Lvv;->e:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v6, [Ljava/lang/Object;

    .line 25
    .line 26
    array-length v6, v6

    .line 27
    if-ne v4, v6, :cond_1f

    .line 28
    .line 29
    invoke-virtual {v3}, Lvv;->b()V

    .line 30
    .line 31
    .line 32
    :cond_1f
    iget-object v3, v3, Lvv;->e:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast v3, [Ljava/lang/Object;

    .line 35
    .line 36
    aput-object p1, v3, v4

    .line 37
    .line 38
    iget-char v3, v1, Ljf3;->a:C

    .line 39
    .line 40
    invoke-virtual {v2, v3}, La4;->i(C)V

    .line 41
    .line 42
    .line 43
    invoke-virtual {v2}, La4;->C()B

    .line 44
    .line 45
    .line 46
    move-result v3

    .line 47
    const/4 v4, 0x4

    .line 48
    if-eq v3, v4, :cond_54

    .line 49
    .line 50
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 51
    .line 52
    .line 53
    move-result v3

    .line 54
    if-eq v3, v5, :cond_4e

    .line 55
    .line 56
    const/4 v4, 0x2

    .line 57
    if-eq v3, v4, :cond_4e

    .line 58
    .line 59
    const/4 v4, 0x3

    .line 60
    if-eq v3, v4, :cond_4e

    .line 61
    .line 62
    iget-object v3, p0, Lmt2;->n:Ljf3;

    .line 63
    .line 64
    if-ne v3, v1, :cond_48

    .line 65
    .line 66
    iget-object v3, v0, Lb61;->a:Lq61;

    .line 67
    .line 68
    iget-boolean v3, v3, Lq61;->b:Z

    .line 69
    .line 70
    if-eqz v3, :cond_48

    .line 71
    .line 72
    return-object p0

    .line 73
    :cond_48
    new-instance p0, Lmt2;

    .line 74
    .line 75
    invoke-direct {p0, v0, v1, v2, p1}, Lmt2;-><init>(Lb61;Ljf3;La4;Lwk2;)V

    .line 76
    .line 77
    .line 78
    return-object p0

    .line 79
    :cond_4e
    new-instance p0, Lmt2;

    .line 80
    .line 81
    invoke-direct {p0, v0, v1, v2, p1}, Lmt2;-><init>(Lb61;Ljf3;La4;Lwk2;)V

    .line 82
    .line 83
    .line 84
    return-object p0

    .line 85
    :cond_54
    const/4 p0, 0x0

    .line 86
    const/4 p1, 0x6

    .line 87
    const-string v0, "Unexpected leading comma"

    .line 88
    .line 89
    invoke-static {v2, v0, p0, p1}, La4;->s(La4;Ljava/lang/String;II)V

    .line 90
    .line 91
    .line 92
    const/4 p0, 0x0

    .line 93
    throw p0
.end method

.method public final c(Lif1;)Ljava/lang/Object;
    .registers 6

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    :try_start_3
    instance-of v0, p1, Lj0;

    .line 5
    .line 6
    if-nez v0, :cond_e

    .line 7
    .line 8
    invoke-interface {p1, p0}, Lif1;->deserialize(Lz60;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0

    .line 13
    :catch_c
    move-exception p1

    .line 14
    goto :goto_13

    .line 15
    :cond_e
    invoke-static {p1}, Ln10;->q(Ljava/lang/Object;)V
    :try_end_11
    .catch Lnt1; {:try_start_3 .. :try_end_11} :catch_c

    .line 16
    .line 17
    .line 18
    const/4 p0, 0x0

    .line 19
    throw p0

    .line 20
    :goto_13
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 25
    .line 26
    .line 27
    const/4 v1, 0x0

    .line 28
    const/4 v2, 0x2

    .line 29
    const-string v3, "at path"

    .line 30
    .line 31
    invoke-static {v2, v0, v3, v1}, Lxt2;->L(ILjava/lang/CharSequence;Ljava/lang/String;Z)Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    if-eqz v0, :cond_25

    .line 36
    .line 37
    throw p1

    .line 38
    :cond_25
    new-instance v0, Ljava/lang/StringBuilder;

    .line 39
    .line 40
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 41
    .line 42
    .line 43
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 48
    .line 49
    .line 50
    const-string v1, " at path: "

    .line 51
    .line 52
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 53
    .line 54
    .line 55
    iget-object p0, p0, Lmt2;->o:La4;

    .line 56
    .line 57
    iget-object p0, p0, La4;->d:Ljava/lang/Object;

    .line 58
    .line 59
    check-cast p0, Lvv;

    .line 60
    .line 61
    invoke-virtual {p0}, Lvv;->a()Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object p0

    .line 65
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 66
    .line 67
    .line 68
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object p0

    .line 72
    new-instance v0, Lnt1;

    .line 73
    .line 74
    iget-object v1, p1, Lnt1;->a:Ljava/util/ArrayList;

    .line 75
    .line 76
    iget-object v2, p1, Lnt1;->b:Ljava/lang/String;

    .line 77
    .line 78
    invoke-direct {v0, p0, p1, v1, v2}, Lnt1;-><init>(Ljava/lang/String;Lnt1;Ljava/util/ArrayList;Ljava/lang/String;)V

    .line 79
    .line 80
    .line 81
    throw v0
.end method

.method public final d()J
    .registers 3

    .line 1
    iget-object p0, p0, Lmt2;->o:La4;

    .line 2
    .line 3
    invoke-virtual {p0}, La4;->j()J

    .line 4
    .line 5
    .line 6
    move-result-wide v0

    .line 7
    return-wide v0
.end method

.method public final f()Z
    .registers 12

    .line 1
    iget-object p0, p0, Lmt2;->o:La4;

    .line 2
    .line 3
    invoke-virtual {p0}, La4;->K()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    iget-object v1, p0, La4;->g:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v1, Ljava/lang/String;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    const-string v3, "EOF"

    .line 16
    .line 17
    const/4 v4, 0x0

    .line 18
    const/4 v5, 0x6

    .line 19
    const/4 v6, 0x0

    .line 20
    if-eq v0, v2, :cond_8f

    .line 21
    .line 22
    invoke-virtual {v1, v0}, Ljava/lang/String;->charAt(I)C

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    const/16 v7, 0x22

    .line 27
    .line 28
    const/4 v8, 0x1

    .line 29
    if-ne v2, v7, :cond_22

    .line 30
    .line 31
    add-int/lit8 v0, v0, 0x1

    .line 32
    .line 33
    move v2, v8

    .line 34
    goto :goto_23

    .line 35
    :cond_22
    move v2, v6

    .line 36
    :goto_23
    invoke-virtual {p0, v0}, La4;->F(I)I

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 41
    .line 42
    .line 43
    move-result v9

    .line 44
    if-ge v0, v9, :cond_8b

    .line 45
    .line 46
    const/4 v9, -0x1

    .line 47
    if-eq v0, v9, :cond_8b

    .line 48
    .line 49
    add-int/lit8 v9, v0, 0x1

    .line 50
    .line 51
    invoke-virtual {v1, v0}, Ljava/lang/String;->charAt(I)C

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    or-int/lit8 v0, v0, 0x20

    .line 56
    .line 57
    const/16 v10, 0x66

    .line 58
    .line 59
    if-eq v0, v10, :cond_62

    .line 60
    .line 61
    const/16 v10, 0x74

    .line 62
    .line 63
    if-ne v0, v10, :cond_47

    .line 64
    .line 65
    const-string v0, "rue"

    .line 66
    .line 67
    invoke-virtual {p0, v9, v0}, La4;->e(ILjava/lang/String;)V

    .line 68
    .line 69
    .line 70
    move v0, v8

    .line 71
    goto :goto_68

    .line 72
    :cond_47
    new-instance v0, Ljava/lang/StringBuilder;

    .line 73
    .line 74
    const-string v1, "Expected valid boolean literal prefix, but had \'"

    .line 75
    .line 76
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 77
    .line 78
    .line 79
    invoke-virtual {p0}, La4;->m()Ljava/lang/String;

    .line 80
    .line 81
    .line 82
    move-result-object v1

    .line 83
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 84
    .line 85
    .line 86
    const/16 v1, 0x27

    .line 87
    .line 88
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 89
    .line 90
    .line 91
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 92
    .line 93
    .line 94
    move-result-object v0

    .line 95
    invoke-static {p0, v0, v6, v5}, La4;->s(La4;Ljava/lang/String;II)V

    .line 96
    .line 97
    .line 98
    throw v4

    .line 99
    :cond_62
    const-string v0, "alse"

    .line 100
    .line 101
    invoke-virtual {p0, v9, v0}, La4;->e(ILjava/lang/String;)V

    .line 102
    .line 103
    .line 104
    move v0, v6

    .line 105
    :goto_68
    if-eqz v2, :cond_8a

    .line 106
    .line 107
    iget v2, p0, La4;->b:I

    .line 108
    .line 109
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 110
    .line 111
    .line 112
    move-result v9

    .line 113
    if-eq v2, v9, :cond_86

    .line 114
    .line 115
    iget v2, p0, La4;->b:I

    .line 116
    .line 117
    invoke-virtual {v1, v2}, Ljava/lang/String;->charAt(I)C

    .line 118
    .line 119
    .line 120
    move-result v1

    .line 121
    if-ne v1, v7, :cond_80

    .line 122
    .line 123
    iget v1, p0, La4;->b:I

    .line 124
    .line 125
    add-int/2addr v1, v8

    .line 126
    iput v1, p0, La4;->b:I

    .line 127
    .line 128
    return v0

    .line 129
    :cond_80
    const-string v0, "Expected closing quotation mark"

    .line 130
    .line 131
    invoke-static {p0, v0, v6, v5}, La4;->s(La4;Ljava/lang/String;II)V

    .line 132
    .line 133
    .line 134
    throw v4

    .line 135
    :cond_86
    invoke-static {p0, v3, v6, v5}, La4;->s(La4;Ljava/lang/String;II)V

    .line 136
    .line 137
    .line 138
    throw v4

    .line 139
    :cond_8a
    return v0

    .line 140
    :cond_8b
    invoke-static {p0, v3, v6, v5}, La4;->s(La4;Ljava/lang/String;II)V

    .line 141
    .line 142
    .line 143
    throw v4

    .line 144
    :cond_8f
    invoke-static {p0, v3, v6, v5}, La4;->s(La4;Ljava/lang/String;II)V

    .line 145
    .line 146
    .line 147
    throw v4
.end method

.method public final g()Z
    .registers 10

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, Lmt2;->q:Lf71;

    .line 3
    .line 4
    if-eqz v1, :cond_8

    .line 5
    .line 6
    iget-boolean v1, v1, Lf71;->b:Z

    .line 7
    .line 8
    goto :goto_9

    .line 9
    :cond_8
    move v1, v0

    .line 10
    :goto_9
    if-nez v1, :cond_53

    .line 11
    .line 12
    iget-object p0, p0, Lmt2;->o:La4;

    .line 13
    .line 14
    invoke-virtual {p0}, La4;->K()I

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    invoke-virtual {p0, v1}, La4;->F(I)I

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    iget-object v2, p0, La4;->g:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v2, Ljava/lang/String;

    .line 25
    .line 26
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 27
    .line 28
    .line 29
    move-result v3

    .line 30
    sub-int/2addr v3, v1

    .line 31
    const/4 v4, 0x1

    .line 32
    const/4 v5, 0x4

    .line 33
    if-lt v3, v5, :cond_4f

    .line 34
    .line 35
    const/4 v6, -0x1

    .line 36
    if-ne v1, v6, :cond_26

    .line 37
    .line 38
    goto :goto_4f

    .line 39
    :cond_26
    move v6, v0

    .line 40
    :goto_27
    if-ge v6, v5, :cond_3b

    .line 41
    .line 42
    const-string v7, "null"

    .line 43
    .line 44
    invoke-virtual {v7, v6}, Ljava/lang/String;->charAt(I)C

    .line 45
    .line 46
    .line 47
    move-result v7

    .line 48
    add-int v8, v1, v6

    .line 49
    .line 50
    invoke-virtual {v2, v8}, Ljava/lang/String;->charAt(I)C

    .line 51
    .line 52
    .line 53
    move-result v8

    .line 54
    if-eq v7, v8, :cond_38

    .line 55
    .line 56
    goto :goto_4f

    .line 57
    :cond_38
    add-int/lit8 v6, v6, 0x1

    .line 58
    .line 59
    goto :goto_27

    .line 60
    :cond_3b
    if-le v3, v5, :cond_4a

    .line 61
    .line 62
    add-int/lit8 v3, v1, 0x4

    .line 63
    .line 64
    invoke-virtual {v2, v3}, Ljava/lang/String;->charAt(I)C

    .line 65
    .line 66
    .line 67
    move-result v2

    .line 68
    invoke-static {v2}, Lh23;->f(C)B

    .line 69
    .line 70
    .line 71
    move-result v2

    .line 72
    if-nez v2, :cond_4a

    .line 73
    .line 74
    goto :goto_4f

    .line 75
    :cond_4a
    add-int/2addr v1, v5

    .line 76
    iput v1, p0, La4;->b:I

    .line 77
    .line 78
    move p0, v4

    .line 79
    goto :goto_50

    .line 80
    :cond_4f
    :goto_4f
    move p0, v0

    .line 81
    :goto_50
    if-nez p0, :cond_53

    .line 82
    .line 83
    return v4

    .line 84
    :cond_53
    return v0
.end method

.method public final h()C
    .registers 5

    .line 1
    iget-object p0, p0, Lmt2;->o:La4;

    .line 2
    .line 3
    invoke-virtual {p0}, La4;->m()Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    const/4 v2, 0x1

    .line 12
    const/4 v3, 0x0

    .line 13
    if-ne v1, v2, :cond_13

    .line 14
    .line 15
    invoke-virtual {v0, v3}, Ljava/lang/String;->charAt(I)C

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    return p0

    .line 20
    :cond_13
    const-string v1, "Expected single char, but got \'"

    .line 21
    .line 22
    const/16 v2, 0x27

    .line 23
    .line 24
    invoke-static {v1, v0, v2}, Ls41;->q(Ljava/lang/String;Ljava/lang/String;C)Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    const/4 v1, 0x6

    .line 29
    invoke-static {p0, v0, v3, v1}, La4;->s(La4;Ljava/lang/String;II)V

    .line 30
    .line 31
    .line 32
    const/4 p0, 0x0

    .line 33
    throw p0
.end method

.method public final k(Lwk2;)I
    .registers 22

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    iget-object v2, v0, Lmt2;->o:La4;

    .line 6
    .line 7
    iget-object v3, v2, La4;->d:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v3, Lvv;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    iget-object v4, v0, Lmt2;->n:Ljf3;

    .line 15
    .line 16
    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    .line 17
    .line 18
    .line 19
    move-result v5

    .line 20
    const-string v6, "object"

    .line 21
    .line 22
    const/4 v7, 0x6

    .line 23
    const/4 v8, 0x0

    .line 24
    const/16 v9, 0x3a

    .line 25
    .line 26
    const/4 v10, 0x0

    .line 27
    const/4 v11, 0x1

    .line 28
    const/4 v12, -0x1

    .line 29
    if-eqz v5, :cond_8e

    .line 30
    .line 31
    const/4 v1, 0x2

    .line 32
    if-eq v5, v1, :cond_48

    .line 33
    .line 34
    invoke-virtual {v2}, La4;->M()Z

    .line 35
    .line 36
    .line 37
    move-result v1

    .line 38
    invoke-virtual {v2}, La4;->c()Z

    .line 39
    .line 40
    .line 41
    move-result v5

    .line 42
    if-eqz v5, :cond_3e

    .line 43
    .line 44
    iget v5, v0, Lmt2;->p:I

    .line 45
    .line 46
    if-eq v5, v12, :cond_38

    .line 47
    .line 48
    if-eqz v1, :cond_32

    .line 49
    .line 50
    goto :goto_38

    .line 51
    :cond_32
    const-string v0, "Expected end of the array or comma"

    .line 52
    .line 53
    invoke-static {v2, v0, v10, v7}, La4;->s(La4;Ljava/lang/String;II)V

    .line 54
    .line 55
    .line 56
    throw v8

    .line 57
    :cond_38
    :goto_38
    add-int/lit8 v12, v5, 0x1

    .line 58
    .line 59
    iput v12, v0, Lmt2;->p:I

    .line 60
    .line 61
    goto/16 :goto_1f8

    .line 62
    .line 63
    :cond_3e
    if-nez v1, :cond_42

    .line 64
    .line 65
    goto/16 :goto_1f8

    .line 66
    .line 67
    :cond_42
    const-string v0, "array"

    .line 68
    .line 69
    invoke-static {v2, v0}, Lsn2;->p(La4;Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    throw v8

    .line 73
    :cond_48
    iget v1, v0, Lmt2;->p:I

    .line 74
    .line 75
    rem-int/lit8 v5, v1, 0x2

    .line 76
    .line 77
    if-eqz v5, :cond_50

    .line 78
    .line 79
    move v5, v11

    .line 80
    goto :goto_51

    .line 81
    :cond_50
    move v5, v10

    .line 82
    :goto_51
    if-eqz v5, :cond_5a

    .line 83
    .line 84
    if-eq v1, v12, :cond_5d

    .line 85
    .line 86
    invoke-virtual {v2}, La4;->M()Z

    .line 87
    .line 88
    .line 89
    move-result v10

    .line 90
    goto :goto_5d

    .line 91
    :cond_5a
    invoke-virtual {v2, v9}, La4;->i(C)V

    .line 92
    .line 93
    .line 94
    :cond_5d
    :goto_5d
    invoke-virtual {v2}, La4;->c()Z

    .line 95
    .line 96
    .line 97
    move-result v1

    .line 98
    if-eqz v1, :cond_86

    .line 99
    .line 100
    if-eqz v5, :cond_7e

    .line 101
    .line 102
    iget v1, v0, Lmt2;->p:I

    .line 103
    .line 104
    iget v5, v2, La4;->b:I

    .line 105
    .line 106
    const/4 v6, 0x4

    .line 107
    if-ne v1, v12, :cond_75

    .line 108
    .line 109
    if-nez v10, :cond_6f

    .line 110
    .line 111
    goto :goto_7e

    .line 112
    :cond_6f
    const-string v0, "Unexpected leading comma"

    .line 113
    .line 114
    invoke-static {v2, v0, v5, v6}, La4;->s(La4;Ljava/lang/String;II)V

    .line 115
    .line 116
    .line 117
    throw v8

    .line 118
    :cond_75
    if-eqz v10, :cond_78

    .line 119
    .line 120
    goto :goto_7e

    .line 121
    :cond_78
    const-string v0, "Expected comma after the key-value pair"

    .line 122
    .line 123
    invoke-static {v2, v0, v5, v6}, La4;->s(La4;Ljava/lang/String;II)V

    .line 124
    .line 125
    .line 126
    throw v8

    .line 127
    :cond_7e
    :goto_7e
    iget v1, v0, Lmt2;->p:I

    .line 128
    .line 129
    add-int/lit8 v12, v1, 0x1

    .line 130
    .line 131
    iput v12, v0, Lmt2;->p:I

    .line 132
    .line 133
    goto/16 :goto_1f8

    .line 134
    .line 135
    :cond_86
    if-nez v10, :cond_8a

    .line 136
    .line 137
    goto/16 :goto_1f8

    .line 138
    .line 139
    :cond_8a
    invoke-static {v2, v6}, Lsn2;->p(La4;Ljava/lang/String;)V

    .line 140
    .line 141
    .line 142
    throw v8

    .line 143
    :cond_8e
    invoke-virtual {v2}, La4;->M()Z

    .line 144
    .line 145
    .line 146
    move-result v5

    .line 147
    :goto_92
    invoke-virtual {v2}, La4;->c()Z

    .line 148
    .line 149
    .line 150
    move-result v13

    .line 151
    const/16 v14, 0x40

    .line 152
    .line 153
    move-object/from16 v17, v8

    .line 154
    .line 155
    iget-object v8, v0, Lmt2;->q:Lf71;

    .line 156
    .line 157
    if-eqz v13, :cond_185

    .line 158
    .line 159
    invoke-virtual {v2}, La4;->f()Ljava/lang/String;

    .line 160
    .line 161
    .line 162
    move-result-object v5

    .line 163
    invoke-virtual {v2, v9}, La4;->i(C)V

    .line 164
    .line 165
    .line 166
    iget-object v13, v0, Lmt2;->m:Lb61;

    .line 167
    .line 168
    invoke-static {v1, v13, v5}, Lc10;->p(Lwk2;Lb61;Ljava/lang/String;)I

    .line 169
    .line 170
    .line 171
    move-result v9

    .line 172
    const-wide/16 v18, 0x1

    .line 173
    .line 174
    const/4 v15, -0x3

    .line 175
    if-eq v9, v15, :cond_d1

    .line 176
    .line 177
    if-eqz v8, :cond_bd

    .line 178
    .line 179
    iget-object v0, v8, Lf71;->a:Log0;

    .line 180
    .line 181
    if-ge v9, v14, :cond_c0

    .line 182
    .line 183
    iget-wide v1, v0, Log0;->b:J

    .line 184
    .line 185
    shl-long v5, v18, v9

    .line 186
    .line 187
    or-long/2addr v1, v5

    .line 188
    iput-wide v1, v0, Log0;->b:J

    .line 189
    .line 190
    :cond_bd
    :goto_bd
    move v12, v9

    .line 191
    goto/16 :goto_1f8

    .line 192
    .line 193
    :cond_c0
    ushr-int/lit8 v1, v9, 0x6

    .line 194
    .line 195
    sub-int/2addr v1, v11

    .line 196
    and-int/lit8 v2, v9, 0x3f

    .line 197
    .line 198
    iget-object v0, v0, Log0;->e:Ljava/lang/Object;

    .line 199
    .line 200
    check-cast v0, [J

    .line 201
    .line 202
    aget-wide v5, v0, v1

    .line 203
    .line 204
    shl-long v7, v18, v2

    .line 205
    .line 206
    or-long/2addr v5, v7

    .line 207
    aput-wide v5, v0, v1

    .line 208
    .line 209
    goto :goto_bd

    .line 210
    :cond_d1
    invoke-static {v13, v1}, Lc10;->t(Lb61;Lwk2;)Z

    .line 211
    .line 212
    .line 213
    move-result v8

    .line 214
    if-nez v8, :cond_10b

    .line 215
    .line 216
    iget v0, v3, Lvv;->c:I

    .line 217
    .line 218
    iget-object v1, v3, Lvv;->b:[I

    .line 219
    .line 220
    aget v4, v1, v0

    .line 221
    .line 222
    const/4 v6, -0x2

    .line 223
    if-ne v4, v6, :cond_e6

    .line 224
    .line 225
    aput v12, v1, v0

    .line 226
    .line 227
    add-int/lit8 v0, v0, -0x1

    .line 228
    .line 229
    iput v0, v3, Lvv;->c:I

    .line 230
    .line 231
    :cond_e6
    if-eq v0, v12, :cond_eb

    .line 232
    .line 233
    add-int/2addr v0, v12

    .line 234
    iput v0, v3, Lvv;->c:I

    .line 235
    .line 236
    :cond_eb
    iget v0, v2, La4;->b:I

    .line 237
    .line 238
    iget-object v1, v2, La4;->g:Ljava/lang/Object;

    .line 239
    .line 240
    check-cast v1, Ljava/lang/String;

    .line 241
    .line 242
    invoke-virtual {v1, v10, v0}, Ljava/lang/String;->subSequence(II)Ljava/lang/CharSequence;

    .line 243
    .line 244
    .line 245
    move-result-object v0

    .line 246
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 247
    .line 248
    .line 249
    move-result-object v0

    .line 250
    invoke-static {v10, v7, v0, v5}, Lxt2;->U(IILjava/lang/String;Ljava/lang/String;)I

    .line 251
    .line 252
    .line 253
    move-result v0

    .line 254
    const-string v1, "Encountered an unknown key \'"

    .line 255
    .line 256
    const/16 v3, 0x27

    .line 257
    .line 258
    invoke-static {v1, v5, v3}, Ls41;->q(Ljava/lang/String;Ljava/lang/String;C)Ljava/lang/String;

    .line 259
    .line 260
    .line 261
    move-result-object v1

    .line 262
    const-string v3, "Use \'ignoreUnknownKeys = true\' in \'Json {}\' builder or \'@JsonIgnoreUnknownKeys\' annotation to ignore unknown keys."

    .line 263
    .line 264
    invoke-virtual {v2, v1, v3, v0}, La4;->r(Ljava/lang/String;Ljava/lang/String;I)V

    .line 265
    .line 266
    .line 267
    throw v17

    .line 268
    :cond_10b
    new-instance v9, Ljava/util/ArrayList;

    .line 269
    .line 270
    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    .line 271
    .line 272
    .line 273
    invoke-virtual {v2}, La4;->C()B

    .line 274
    .line 275
    .line 276
    move-result v5

    .line 277
    const/16 v13, 0x8

    .line 278
    .line 279
    if-eq v5, v13, :cond_11e

    .line 280
    .line 281
    if-eq v5, v7, :cond_11e

    .line 282
    .line 283
    invoke-virtual {v2}, La4;->m()Ljava/lang/String;

    .line 284
    .line 285
    .line 286
    goto :goto_17b

    .line 287
    :cond_11e
    :goto_11e
    invoke-virtual {v2}, La4;->C()B

    .line 288
    .line 289
    .line 290
    move-result v5

    .line 291
    if-ne v5, v11, :cond_128

    .line 292
    .line 293
    invoke-virtual {v2}, La4;->f()Ljava/lang/String;

    .line 294
    .line 295
    .line 296
    goto :goto_11e

    .line 297
    :cond_128
    if-eq v5, v13, :cond_16b

    .line 298
    .line 299
    if-ne v5, v7, :cond_12d

    .line 300
    .line 301
    goto :goto_16b

    .line 302
    :cond_12d
    const/16 v8, 0x9

    .line 303
    .line 304
    if-ne v5, v8, :cond_147

    .line 305
    .line 306
    invoke-static {v9}, Lgv;->g0(Ljava/util/List;)Ljava/lang/Object;

    .line 307
    .line 308
    .line 309
    move-result-object v5

    .line 310
    check-cast v5, Ljava/lang/Number;

    .line 311
    .line 312
    invoke-virtual {v5}, Ljava/lang/Number;->byteValue()B

    .line 313
    .line 314
    .line 315
    move-result v5

    .line 316
    if-ne v5, v13, :cond_141

    .line 317
    .line 318
    invoke-static {v9}, Lmv;->R(Ljava/util/AbstractList;)Ljava/lang/Object;

    .line 319
    .line 320
    .line 321
    goto :goto_172

    .line 322
    :cond_141
    const-string v0, "found ] instead of }"

    .line 323
    .line 324
    invoke-static {v2, v0, v10, v7}, La4;->s(La4;Ljava/lang/String;II)V

    .line 325
    .line 326
    .line 327
    throw v17

    .line 328
    :cond_147
    const/4 v8, 0x7

    .line 329
    if-ne v5, v8, :cond_160

    .line 330
    .line 331
    invoke-static {v9}, Lgv;->g0(Ljava/util/List;)Ljava/lang/Object;

    .line 332
    .line 333
    .line 334
    move-result-object v5

    .line 335
    check-cast v5, Ljava/lang/Number;

    .line 336
    .line 337
    invoke-virtual {v5}, Ljava/lang/Number;->byteValue()B

    .line 338
    .line 339
    .line 340
    move-result v5

    .line 341
    if-ne v5, v7, :cond_15a

    .line 342
    .line 343
    invoke-static {v9}, Lmv;->R(Ljava/util/AbstractList;)Ljava/lang/Object;

    .line 344
    .line 345
    .line 346
    goto :goto_172

    .line 347
    :cond_15a
    const-string v0, "found } instead of ]"

    .line 348
    .line 349
    invoke-static {v2, v0, v10, v7}, La4;->s(La4;Ljava/lang/String;II)V

    .line 350
    .line 351
    .line 352
    throw v17

    .line 353
    :cond_160
    const/16 v8, 0xa

    .line 354
    .line 355
    if-eq v5, v8, :cond_165

    .line 356
    .line 357
    goto :goto_172

    .line 358
    :cond_165
    const-string v0, "Unexpected end of input due to malformed JSON during ignoring unknown keys"

    .line 359
    .line 360
    invoke-static {v2, v0, v10, v7}, La4;->s(La4;Ljava/lang/String;II)V

    .line 361
    .line 362
    .line 363
    throw v17

    .line 364
    :cond_16b
    :goto_16b
    invoke-static {v5}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    .line 365
    .line 366
    .line 367
    move-result-object v5

    .line 368
    invoke-virtual {v9, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 369
    .line 370
    .line 371
    :goto_172
    invoke-virtual {v2}, La4;->g()B

    .line 372
    .line 373
    .line 374
    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    .line 375
    .line 376
    .line 377
    move-result v5

    .line 378
    if-nez v5, :cond_11e

    .line 379
    .line 380
    :goto_17b
    invoke-virtual {v2}, La4;->M()Z

    .line 381
    .line 382
    .line 383
    move-result v5

    .line 384
    move-object/from16 v8, v17

    .line 385
    .line 386
    const/16 v9, 0x3a

    .line 387
    .line 388
    goto/16 :goto_92

    .line 389
    .line 390
    :cond_185
    const-wide/16 v18, 0x1

    .line 391
    .line 392
    if-nez v5, :cond_203

    .line 393
    .line 394
    if-eqz v8, :cond_1f8

    .line 395
    .line 396
    iget-object v0, v8, Lf71;->a:Log0;

    .line 397
    .line 398
    iget-object v1, v0, Log0;->d:Ljava/lang/Object;

    .line 399
    .line 400
    check-cast v1, Le71;

    .line 401
    .line 402
    iget-object v2, v0, Log0;->c:Ljava/lang/Object;

    .line 403
    .line 404
    check-cast v2, Lwk2;

    .line 405
    .line 406
    invoke-interface {v2}, Lwk2;->c()I

    .line 407
    .line 408
    .line 409
    move-result v5

    .line 410
    :cond_199
    iget-wide v6, v0, Log0;->b:J

    .line 411
    .line 412
    const-wide/16 v8, -0x1

    .line 413
    .line 414
    cmp-long v11, v6, v8

    .line 415
    .line 416
    if-eqz v11, :cond_1bf

    .line 417
    .line 418
    not-long v6, v6

    .line 419
    invoke-static {v6, v7}, Ljava/lang/Long;->numberOfTrailingZeros(J)I

    .line 420
    .line 421
    .line 422
    move-result v6

    .line 423
    iget-wide v7, v0, Log0;->b:J

    .line 424
    .line 425
    shl-long v15, v18, v6

    .line 426
    .line 427
    or-long/2addr v7, v15

    .line 428
    iput-wide v7, v0, Log0;->b:J

    .line 429
    .line 430
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 431
    .line 432
    .line 433
    move-result-object v7

    .line 434
    invoke-virtual {v1, v2, v7}, Le71;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 435
    .line 436
    .line 437
    move-result-object v7

    .line 438
    check-cast v7, Ljava/lang/Boolean;

    .line 439
    .line 440
    invoke-virtual {v7}, Ljava/lang/Boolean;->booleanValue()Z

    .line 441
    .line 442
    .line 443
    move-result v7

    .line 444
    if-eqz v7, :cond_199

    .line 445
    .line 446
    move v12, v6

    .line 447
    goto :goto_1f8

    .line 448
    :cond_1bf
    if-le v5, v14, :cond_1f8

    .line 449
    .line 450
    iget-object v0, v0, Log0;->e:Ljava/lang/Object;

    .line 451
    .line 452
    check-cast v0, [J

    .line 453
    .line 454
    array-length v5, v0

    .line 455
    :goto_1c6
    if-ge v10, v5, :cond_1f8

    .line 456
    .line 457
    add-int/lit8 v6, v10, 0x1

    .line 458
    .line 459
    mul-int/lit8 v7, v6, 0x40

    .line 460
    .line 461
    aget-wide v13, v0, v10

    .line 462
    .line 463
    :goto_1ce
    cmp-long v11, v13, v8

    .line 464
    .line 465
    if-eqz v11, :cond_1f2

    .line 466
    .line 467
    not-long v8, v13

    .line 468
    invoke-static {v8, v9}, Ljava/lang/Long;->numberOfTrailingZeros(J)I

    .line 469
    .line 470
    .line 471
    move-result v8

    .line 472
    shl-long v15, v18, v8

    .line 473
    .line 474
    or-long/2addr v13, v15

    .line 475
    add-int/2addr v8, v7

    .line 476
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 477
    .line 478
    .line 479
    move-result-object v9

    .line 480
    invoke-virtual {v1, v2, v9}, Le71;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 481
    .line 482
    .line 483
    move-result-object v9

    .line 484
    check-cast v9, Ljava/lang/Boolean;

    .line 485
    .line 486
    invoke-virtual {v9}, Ljava/lang/Boolean;->booleanValue()Z

    .line 487
    .line 488
    .line 489
    move-result v9

    .line 490
    if-eqz v9, :cond_1ef

    .line 491
    .line 492
    aput-wide v13, v0, v10

    .line 493
    .line 494
    move v12, v8

    .line 495
    goto :goto_1f8

    .line 496
    :cond_1ef
    const-wide/16 v8, -0x1

    .line 497
    .line 498
    goto :goto_1ce

    .line 499
    :cond_1f2
    aput-wide v13, v0, v10

    .line 500
    .line 501
    move v10, v6

    .line 502
    const-wide/16 v8, -0x1

    .line 503
    .line 504
    goto :goto_1c6

    .line 505
    :cond_1f8
    :goto_1f8
    sget-object v0, Ljf3;->e:Ljf3;

    .line 506
    .line 507
    if-eq v4, v0, :cond_202

    .line 508
    .line 509
    iget-object v0, v3, Lvv;->b:[I

    .line 510
    .line 511
    iget v1, v3, Lvv;->c:I

    .line 512
    .line 513
    aput v12, v0, v1

    .line 514
    .line 515
    :cond_202
    return v12

    .line 516
    :cond_203
    invoke-static {v2, v6}, Lsn2;->p(La4;Ljava/lang/String;)V

    .line 517
    .line 518
    .line 519
    throw v17
.end method

.method public final n()Lb61;
    .registers 1

    .line 1
    iget-object p0, p0, Lmt2;->m:Lb61;

    .line 2
    .line 3
    return-object p0
.end method

.method public final o()Lc71;
    .registers 3

    .line 1
    new-instance v0, Lo4;

    .line 2
    .line 3
    iget-object v1, p0, Lmt2;->m:Lb61;

    .line 4
    .line 5
    iget-object v1, v1, Lb61;->a:Lq61;

    .line 6
    .line 7
    iget-object p0, p0, Lmt2;->o:La4;

    .line 8
    .line 9
    invoke-direct {v0, v1, p0}, Lo4;-><init>(Lq61;La4;)V

    .line 10
    .line 11
    .line 12
    invoke-virtual {v0}, Lo4;->h()Lc71;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    return-object p0
.end method

.method public final r()I
    .registers 6

    .line 1
    iget-object p0, p0, Lmt2;->o:La4;

    .line 2
    .line 3
    invoke-virtual {p0}, La4;->j()J

    .line 4
    .line 5
    .line 6
    move-result-wide v0

    .line 7
    long-to-int v2, v0

    .line 8
    int-to-long v3, v2

    .line 9
    cmp-long v3, v0, v3

    .line 10
    .line 11
    if-nez v3, :cond_d

    .line 12
    .line 13
    return v2

    .line 14
    :cond_d
    new-instance v2, Ljava/lang/StringBuilder;

    .line 15
    .line 16
    const-string v3, "Failed to parse int for input \'"

    .line 17
    .line 18
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {v2, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 22
    .line 23
    .line 24
    const/16 v0, 0x27

    .line 25
    .line 26
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 27
    .line 28
    .line 29
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    const/4 v1, 0x0

    .line 34
    const/4 v2, 0x6

    .line 35
    invoke-static {p0, v0, v1, v2}, La4;->s(La4;Ljava/lang/String;II)V

    .line 36
    .line 37
    .line 38
    const/4 p0, 0x0

    .line 39
    throw p0
.end method

.method public final u()B
    .registers 6

    .line 1
    iget-object p0, p0, Lmt2;->o:La4;

    .line 2
    .line 3
    invoke-virtual {p0}, La4;->j()J

    .line 4
    .line 5
    .line 6
    move-result-wide v0

    .line 7
    long-to-int v2, v0

    .line 8
    int-to-byte v2, v2

    .line 9
    int-to-long v3, v2

    .line 10
    cmp-long v3, v0, v3

    .line 11
    .line 12
    if-nez v3, :cond_e

    .line 13
    .line 14
    return v2

    .line 15
    :cond_e
    new-instance v2, Ljava/lang/StringBuilder;

    .line 16
    .line 17
    const-string v3, "Failed to parse byte for input \'"

    .line 18
    .line 19
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {v2, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 23
    .line 24
    .line 25
    const/16 v0, 0x27

    .line 26
    .line 27
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    const/4 v1, 0x0

    .line 35
    const/4 v2, 0x6

    .line 36
    invoke-static {p0, v0, v1, v2}, La4;->s(La4;Ljava/lang/String;II)V

    .line 37
    .line 38
    .line 39
    const/4 p0, 0x0

    .line 40
    throw p0
.end method

.method public final v(Lwk2;)Lz60;
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-static {p1}, Lot2;->a(Lwk2;)Z

    .line 5
    .line 6
    .line 7
    move-result p1

    .line 8
    if-eqz p1, :cond_13

    .line 9
    .line 10
    new-instance p1, Ly61;

    .line 11
    .line 12
    iget-object v0, p0, Lmt2;->o:La4;

    .line 13
    .line 14
    iget-object p0, p0, Lmt2;->m:Lb61;

    .line 15
    .line 16
    invoke-direct {p1, v0, p0}, Ly61;-><init>(La4;Lb61;)V

    .line 17
    .line 18
    .line 19
    return-object p1

    .line 20
    :cond_13
    return-object p0
.end method

.method public final w(Lwk2;ILif1;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9

    .line 1
    iget-object p4, p0, Lmt2;->o:La4;

    .line 2
    .line 3
    iget-object p4, p4, La4;->d:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast p4, Lvv;

    .line 6
    .line 7
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    iget-object p1, p0, Lmt2;->n:Ljf3;

    .line 14
    .line 15
    sget-object v0, Ljf3;->e:Ljf3;

    .line 16
    .line 17
    const/4 v1, 0x1

    .line 18
    if-ne p1, v0, :cond_19

    .line 19
    .line 20
    and-int/lit8 p1, p2, 0x1

    .line 21
    .line 22
    if-nez p1, :cond_19

    .line 23
    .line 24
    move p1, v1

    .line 25
    goto :goto_1a

    .line 26
    :cond_19
    const/4 p1, 0x0

    .line 27
    :goto_1a
    const/4 p2, -0x2

    .line 28
    if-eqz p1, :cond_2d

    .line 29
    .line 30
    iget-object v0, p4, Lvv;->b:[I

    .line 31
    .line 32
    iget v2, p4, Lvv;->c:I

    .line 33
    .line 34
    aget v0, v0, v2

    .line 35
    .line 36
    if-ne v0, p2, :cond_2d

    .line 37
    .line 38
    iget-object v0, p4, Lvv;->e:Ljava/lang/Object;

    .line 39
    .line 40
    check-cast v0, [Ljava/lang/Object;

    .line 41
    .line 42
    sget-object v3, Lby0;->g:Lby0;

    .line 43
    .line 44
    aput-object v3, v0, v2

    .line 45
    .line 46
    :cond_2d
    invoke-virtual {p0, p3}, Lmt2;->c(Lif1;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object p0

    .line 50
    if-eqz p1, :cond_60

    .line 51
    .line 52
    iget-object p1, p4, Lvv;->b:[I

    .line 53
    .line 54
    iget p3, p4, Lvv;->c:I

    .line 55
    .line 56
    aget p1, p1, p3

    .line 57
    .line 58
    if-eq p1, p2, :cond_48

    .line 59
    .line 60
    add-int/2addr p3, v1

    .line 61
    iput p3, p4, Lvv;->c:I

    .line 62
    .line 63
    iget-object p1, p4, Lvv;->e:Ljava/lang/Object;

    .line 64
    .line 65
    check-cast p1, [Ljava/lang/Object;

    .line 66
    .line 67
    array-length p1, p1

    .line 68
    if-ne p3, p1, :cond_48

    .line 69
    .line 70
    invoke-virtual {p4}, Lvv;->b()V

    .line 71
    .line 72
    .line 73
    :cond_48
    iget-object p1, p4, Lvv;->e:Ljava/lang/Object;

    .line 74
    .line 75
    check-cast p1, [Ljava/lang/Object;

    .line 76
    .line 77
    iget p3, p4, Lvv;->c:I

    .line 78
    .line 79
    iget-object v0, p4, Lvv;->d:Ljava/lang/Object;

    .line 80
    .line 81
    check-cast v0, Lq61;

    .line 82
    .line 83
    iget-boolean v0, v0, Lq61;->g:Z

    .line 84
    .line 85
    if-eqz v0, :cond_58

    .line 86
    .line 87
    move-object v0, p0

    .line 88
    goto :goto_5a

    .line 89
    :cond_58
    sget-object v0, Lwn0;->g:Lwn0;

    .line 90
    .line 91
    :goto_5a
    aput-object v0, p1, p3

    .line 92
    .line 93
    iget-object p1, p4, Lvv;->b:[I

    .line 94
    .line 95
    aput p2, p1, p3

    .line 96
    .line 97
    :cond_60
    return-object p0
.end method

.method public final y()S
    .registers 6

    .line 1
    iget-object p0, p0, Lmt2;->o:La4;

    .line 2
    .line 3
    invoke-virtual {p0}, La4;->j()J

    .line 4
    .line 5
    .line 6
    move-result-wide v0

    .line 7
    long-to-int v2, v0

    .line 8
    int-to-short v2, v2

    .line 9
    int-to-long v3, v2

    .line 10
    cmp-long v3, v0, v3

    .line 11
    .line 12
    if-nez v3, :cond_e

    .line 13
    .line 14
    return v2

    .line 15
    :cond_e
    new-instance v2, Ljava/lang/StringBuilder;

    .line 16
    .line 17
    const-string v3, "Failed to parse short for input \'"

    .line 18
    .line 19
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {v2, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 23
    .line 24
    .line 25
    const/16 v0, 0x27

    .line 26
    .line 27
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    const/4 v1, 0x0

    .line 35
    const/4 v2, 0x6

    .line 36
    invoke-static {p0, v0, v1, v2}, La4;->s(La4;Ljava/lang/String;II)V

    .line 37
    .line 38
    .line 39
    const/4 p0, 0x0

    .line 40
    throw p0
.end method

.method public final z()Ljava/lang/String;
    .registers 1

    .line 1
    iget-object p0, p0, Lmt2;->o:La4;

    .line 2
    .line 3
    invoke-virtual {p0}, La4;->l()Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method
