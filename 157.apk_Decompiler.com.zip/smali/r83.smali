###### Class defpackage.r83 (r83)
.class public abstract Lr83;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field public static final synthetic a:I


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    sget-object v0, Lqc3;->b:Lqc3;

    .line 2
    .line 3
    invoke-virtual {v0}, Lqc3;->f()Landroid/view/WindowInsets;

    .line 4
    .line 5
    .line 6
    return-void
.end method
