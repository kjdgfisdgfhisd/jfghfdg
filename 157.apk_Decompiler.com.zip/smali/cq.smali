###### Class defpackage.cq (cq)
.class public final Lcq;
.super Lr13;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# virtual methods
.method public final g(Lp13;)Lq23;
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    instance-of p0, p1, Ldq;

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    if-eqz p0, :cond_b

    .line 8
    .line 9
    check-cast p1, Ldq;

    .line 10
    .line 11
    goto :goto_c

    .line 12
    :cond_b
    move-object p1, v0

    .line 13
    :goto_c
    if-nez p1, :cond_f

    .line 14
    .line 15
    return-object v0

    .line 16
    :cond_f
    invoke-interface {p1}, Ldq;->b()Lq23;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    invoke-virtual {p0}, Lq23;->c()Z

    .line 21
    .line 22
    .line 23
    move-result p0

    .line 24
    if-eqz p0, :cond_29

    .line 25
    .line 26
    new-instance p0, Ltr2;

    .line 27
    .line 28
    invoke-interface {p1}, Ldq;->b()Lq23;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    invoke-virtual {p1}, Lq23;->b()Lgg1;

    .line 33
    .line 34
    .line 35
    move-result-object p1

    .line 36
    sget-object v0, Lf73;->e:Lf73;

    .line 37
    .line 38
    invoke-direct {p0, p1, v0}, Ltr2;-><init>(Lgg1;Lf73;)V

    .line 39
    .line 40
    .line 41
    return-object p0

    .line 42
    :cond_29
    invoke-interface {p1}, Ldq;->b()Lq23;

    .line 43
    .line 44
    .line 45
    move-result-object p0

    .line 46
    return-object p0
.end method
