###### Class defpackage.ca (ca)
.class public final Lca;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final a:Landroid/widget/TextView;

.field public b:Liy;

.field public c:Liy;

.field public d:Liy;

.field public e:Liy;

.field public f:Liy;

.field public g:Liy;

.field public h:Liy;

.field public final i:Lja;

.field public j:I

.field public k:I

.field public l:Landroid/graphics/Typeface;

.field public m:Ljava/lang/String;

.field public n:Z


# direct methods
.method public constructor <init>(Landroid/widget/TextView;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput v0, p0, Lca;->j:I

    .line 6
    .line 7
    const/4 v0, -0x1

    .line 8
    iput v0, p0, Lca;->k:I

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    iput-object v0, p0, Lca;->m:Ljava/lang/String;

    .line 12
    .line 13
    iput-object p1, p0, Lca;->a:Landroid/widget/TextView;

    .line 14
    .line 15
    new-instance v0, Lja;

    .line 16
    .line 17
    invoke-direct {v0, p1}, Lja;-><init>(Landroid/widget/TextView;)V

    .line 18
    .line 19
    .line 20
    iput-object v0, p0, Lca;->i:Lja;

    .line 21
    .line 22
    return-void
.end method

.method public static d(Landroid/widget/TextView;Landroid/graphics/Typeface;I)V
    .registers 8

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/16 v2, 0x1a

    .line 5
    .line 6
    if-lt v0, v2, :cond_15

    .line 7
    .line 8
    invoke-static {p0}, Lz9;->c(Landroid/widget/TextView;)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v3

    .line 12
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 13
    .line 14
    .line 15
    move-result v4

    .line 16
    if-nez v4, :cond_14

    .line 17
    .line 18
    invoke-static {p0, v1}, Lz9;->f(Landroid/widget/TextView;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    :cond_14
    move-object v1, v3

    .line 22
    :cond_15
    invoke-virtual {p0, p1, p2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 23
    .line 24
    .line 25
    if-lt v0, v2, :cond_23

    .line 26
    .line 27
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 28
    .line 29
    .line 30
    move-result p1

    .line 31
    if-nez p1, :cond_23

    .line 32
    .line 33
    invoke-static {p0, v1}, Lz9;->f(Landroid/widget/TextView;Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    :cond_23
    return-void
.end method

.method public static e(Landroid/content/Context;Lz8;I)Liy;
    .registers 4

    .line 1
    monitor-enter p1

    .line 2
    :try_start_1
    iget-object v0, p1, Lz8;->a:Lzf2;

    .line 3
    .line 4
    invoke-virtual {v0, p0, p2}, Lzf2;->f(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    .line 5
    .line 6
    .line 7
    move-result-object p0
    :try_end_7
    .catchall {:try_start_1 .. :try_end_7} :catchall_17

    .line 8
    monitor-exit p1

    .line 9
    if-eqz p0, :cond_15

    .line 10
    .line 11
    new-instance p1, Liy;

    .line 12
    .line 13
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 14
    .line 15
    .line 16
    const/4 p2, 0x1

    .line 17
    iput-boolean p2, p1, Liy;->b:Z

    .line 18
    .line 19
    iput-object p0, p1, Liy;->c:Ljava/lang/Object;

    .line 20
    .line 21
    return-object p1

    .line 22
    :cond_15
    const/4 p0, 0x0

    .line 23
    return-object p0

    .line 24
    :catchall_17
    move-exception p0

    .line 25
    :try_start_18
    monitor-exit p1
    :try_end_19
    .catchall {:try_start_18 .. :try_end_19} :catchall_17

    .line 26
    throw p0
.end method

.method public static j(Landroid/view/inputmethod/EditorInfo;Landroid/view/inputmethod/InputConnection;Landroid/widget/TextView;)V
    .registers 13

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/16 v1, 0x1e

    .line 4
    .line 5
    if-ge v0, v1, :cond_c1

    .line 6
    .line 7
    if-eqz p1, :cond_c1

    .line 8
    .line 9
    invoke-virtual {p2}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    if-lt v0, v1, :cond_12

    .line 14
    .line 15
    invoke-static {p0, p1}, Lo1;->g(Landroid/view/inputmethod/EditorInfo;Ljava/lang/CharSequence;)V

    .line 16
    .line 17
    .line 18
    return-void

    .line 19
    :cond_12
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    if-lt v0, v1, :cond_1b

    .line 23
    .line 24
    invoke-static {p0, p1}, Lo1;->g(Landroid/view/inputmethod/EditorInfo;Ljava/lang/CharSequence;)V

    .line 25
    .line 26
    .line 27
    return-void

    .line 28
    :cond_1b
    iget p2, p0, Landroid/view/inputmethod/EditorInfo;->initialSelStart:I

    .line 29
    .line 30
    iget v0, p0, Landroid/view/inputmethod/EditorInfo;->initialSelEnd:I

    .line 31
    .line 32
    if-le p2, v0, :cond_23

    .line 33
    .line 34
    move v1, v0

    .line 35
    goto :goto_24

    .line 36
    :cond_23
    move v1, p2

    .line 37
    :goto_24
    if-le p2, v0, :cond_27

    .line 38
    .line 39
    goto :goto_28

    .line 40
    :cond_27
    move p2, v0

    .line 41
    :goto_28
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    const/4 v2, 0x0

    .line 46
    const/4 v3, 0x0

    .line 47
    if-ltz v1, :cond_be

    .line 48
    .line 49
    if-le p2, v0, :cond_34

    .line 50
    .line 51
    goto/16 :goto_be

    .line 52
    .line 53
    :cond_34
    iget v4, p0, Landroid/view/inputmethod/EditorInfo;->inputType:I

    .line 54
    .line 55
    and-int/lit16 v4, v4, 0xfff

    .line 56
    .line 57
    const/16 v5, 0x81

    .line 58
    .line 59
    if-eq v4, v5, :cond_ba

    .line 60
    .line 61
    const/16 v5, 0xe1

    .line 62
    .line 63
    if-eq v4, v5, :cond_ba

    .line 64
    .line 65
    const/16 v5, 0x12

    .line 66
    .line 67
    if-ne v4, v5, :cond_46

    .line 68
    .line 69
    goto/16 :goto_ba

    .line 70
    .line 71
    :cond_46
    const/16 v3, 0x800

    .line 72
    .line 73
    if-gt v0, v3, :cond_4e

    .line 74
    .line 75
    invoke-static {p0, p1, v1, p2}, Lh23;->r(Landroid/view/inputmethod/EditorInfo;Ljava/lang/CharSequence;II)V

    .line 76
    .line 77
    .line 78
    return-void

    .line 79
    :cond_4e
    sub-int v0, p2, v1

    .line 80
    .line 81
    const/16 v3, 0x400

    .line 82
    .line 83
    if-le v0, v3, :cond_56

    .line 84
    .line 85
    move v3, v2

    .line 86
    goto :goto_57

    .line 87
    :cond_56
    move v3, v0

    .line 88
    :goto_57
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    .line 89
    .line 90
    .line 91
    move-result v4

    .line 92
    sub-int/2addr v4, p2

    .line 93
    rsub-int v5, v3, 0x800

    .line 94
    .line 95
    const-wide v6, 0x3fe999999999999aL    # 0.8

    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    int-to-double v8, v5

    .line 101
    mul-double/2addr v8, v6

    .line 102
    double-to-int v6, v8

    .line 103
    invoke-static {v1, v6}, Ljava/lang/Math;->min(II)I

    .line 104
    .line 105
    .line 106
    move-result v6

    .line 107
    sub-int v6, v5, v6

    .line 108
    .line 109
    invoke-static {v4, v6}, Ljava/lang/Math;->min(II)I

    .line 110
    .line 111
    .line 112
    move-result v4

    .line 113
    sub-int/2addr v5, v4

    .line 114
    invoke-static {v1, v5}, Ljava/lang/Math;->min(II)I

    .line 115
    .line 116
    .line 117
    move-result v5

    .line 118
    sub-int/2addr v1, v5

    .line 119
    invoke-interface {p1, v1}, Ljava/lang/CharSequence;->charAt(I)C

    .line 120
    .line 121
    .line 122
    move-result v6

    .line 123
    invoke-static {v6}, Ljava/lang/Character;->isLowSurrogate(C)Z

    .line 124
    .line 125
    .line 126
    move-result v6

    .line 127
    if-eqz v6, :cond_84

    .line 128
    .line 129
    add-int/lit8 v1, v1, 0x1

    .line 130
    .line 131
    add-int/lit8 v5, v5, -0x1

    .line 132
    .line 133
    :cond_84
    add-int v6, p2, v4

    .line 134
    .line 135
    const/4 v7, 0x1

    .line 136
    sub-int/2addr v6, v7

    .line 137
    invoke-interface {p1, v6}, Ljava/lang/CharSequence;->charAt(I)C

    .line 138
    .line 139
    .line 140
    move-result v6

    .line 141
    invoke-static {v6}, Ljava/lang/Character;->isHighSurrogate(C)Z

    .line 142
    .line 143
    .line 144
    move-result v6

    .line 145
    if-eqz v6, :cond_94

    .line 146
    .line 147
    add-int/lit8 v4, v4, -0x1

    .line 148
    .line 149
    :cond_94
    add-int v6, v5, v3

    .line 150
    .line 151
    add-int v8, v6, v4

    .line 152
    .line 153
    if-eq v3, v0, :cond_b1

    .line 154
    .line 155
    add-int v0, v1, v5

    .line 156
    .line 157
    invoke-interface {p1, v1, v0}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    .line 158
    .line 159
    .line 160
    move-result-object v0

    .line 161
    add-int/2addr v4, p2

    .line 162
    invoke-interface {p1, p2, v4}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    .line 163
    .line 164
    .line 165
    move-result-object p1

    .line 166
    const/4 p2, 0x2

    .line 167
    new-array p2, p2, [Ljava/lang/CharSequence;

    .line 168
    .line 169
    aput-object v0, p2, v2

    .line 170
    .line 171
    aput-object p1, p2, v7

    .line 172
    .line 173
    invoke-static {p2}, Landroid/text/TextUtils;->concat([Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 174
    .line 175
    .line 176
    move-result-object p1

    .line 177
    goto :goto_b6

    .line 178
    :cond_b1
    add-int/2addr v8, v1

    .line 179
    invoke-interface {p1, v1, v8}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    .line 180
    .line 181
    .line 182
    move-result-object p1

    .line 183
    :goto_b6
    invoke-static {p0, p1, v5, v6}, Lh23;->r(Landroid/view/inputmethod/EditorInfo;Ljava/lang/CharSequence;II)V

    .line 184
    .line 185
    .line 186
    return-void

    .line 187
    :cond_ba
    :goto_ba
    invoke-static {p0, v3, v2, v2}, Lh23;->r(Landroid/view/inputmethod/EditorInfo;Ljava/lang/CharSequence;II)V

    .line 188
    .line 189
    .line 190
    return-void

    .line 191
    :cond_be
    :goto_be
    invoke-static {p0, v3, v2, v2}, Lh23;->r(Landroid/view/inputmethod/EditorInfo;Ljava/lang/CharSequence;II)V

    .line 192
    .line 193
    .line 194
    :cond_c1
    return-void
.end method


# virtual methods
.method public final a(Landroid/graphics/drawable/Drawable;Liy;)V
    .registers 4

    .line 1
    if-eqz p1, :cond_f

    .line 2
    .line 3
    if-eqz p2, :cond_f

    .line 4
    .line 5
    iget-object p0, p0, Lca;->a:Landroid/widget/TextView;

    .line 6
    .line 7
    invoke-virtual {p0}, Landroid/view/View;->getDrawableState()[I

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    sget-object v0, Lz8;->b:Landroid/graphics/PorterDuff$Mode;

    .line 12
    .line 13
    invoke-static {p1, p2, p0}, Lzf2;->h(Landroid/graphics/drawable/Drawable;Liy;[I)V

    .line 14
    .line 15
    .line 16
    :cond_f
    return-void
.end method

.method public final b()V
    .registers 7

    .line 1
    iget-object v0, p0, Lca;->b:Liy;

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    const/4 v2, 0x0

    .line 5
    iget-object v3, p0, Lca;->a:Landroid/widget/TextView;

    .line 6
    .line 7
    if-nez v0, :cond_14

    .line 8
    .line 9
    iget-object v0, p0, Lca;->c:Liy;

    .line 10
    .line 11
    if-nez v0, :cond_14

    .line 12
    .line 13
    iget-object v0, p0, Lca;->d:Liy;

    .line 14
    .line 15
    if-nez v0, :cond_14

    .line 16
    .line 17
    iget-object v0, p0, Lca;->e:Liy;

    .line 18
    .line 19
    if-eqz v0, :cond_36

    .line 20
    .line 21
    :cond_14
    invoke-virtual {v3}, Landroid/widget/TextView;->getCompoundDrawables()[Landroid/graphics/drawable/Drawable;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    aget-object v4, v0, v2

    .line 26
    .line 27
    iget-object v5, p0, Lca;->b:Liy;

    .line 28
    .line 29
    invoke-virtual {p0, v4, v5}, Lca;->a(Landroid/graphics/drawable/Drawable;Liy;)V

    .line 30
    .line 31
    .line 32
    const/4 v4, 0x1

    .line 33
    aget-object v4, v0, v4

    .line 34
    .line 35
    iget-object v5, p0, Lca;->c:Liy;

    .line 36
    .line 37
    invoke-virtual {p0, v4, v5}, Lca;->a(Landroid/graphics/drawable/Drawable;Liy;)V

    .line 38
    .line 39
    .line 40
    aget-object v4, v0, v1

    .line 41
    .line 42
    iget-object v5, p0, Lca;->d:Liy;

    .line 43
    .line 44
    invoke-virtual {p0, v4, v5}, Lca;->a(Landroid/graphics/drawable/Drawable;Liy;)V

    .line 45
    .line 46
    .line 47
    const/4 v4, 0x3

    .line 48
    aget-object v0, v0, v4

    .line 49
    .line 50
    iget-object v4, p0, Lca;->e:Liy;

    .line 51
    .line 52
    invoke-virtual {p0, v0, v4}, Lca;->a(Landroid/graphics/drawable/Drawable;Liy;)V

    .line 53
    .line 54
    .line 55
    :cond_36
    iget-object v0, p0, Lca;->f:Liy;

    .line 56
    .line 57
    if-nez v0, :cond_40

    .line 58
    .line 59
    iget-object v0, p0, Lca;->g:Liy;

    .line 60
    .line 61
    if-eqz v0, :cond_3f

    .line 62
    .line 63
    goto :goto_40

    .line 64
    :cond_3f
    return-void

    .line 65
    :cond_40
    :goto_40
    invoke-virtual {v3}, Landroid/widget/TextView;->getCompoundDrawablesRelative()[Landroid/graphics/drawable/Drawable;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    aget-object v2, v0, v2

    .line 70
    .line 71
    iget-object v3, p0, Lca;->f:Liy;

    .line 72
    .line 73
    invoke-virtual {p0, v2, v3}, Lca;->a(Landroid/graphics/drawable/Drawable;Liy;)V

    .line 74
    .line 75
    .line 76
    aget-object v0, v0, v1

    .line 77
    .line 78
    iget-object v1, p0, Lca;->g:Liy;

    .line 79
    .line 80
    invoke-virtual {p0, v0, v1}, Lca;->a(Landroid/graphics/drawable/Drawable;Liy;)V

    .line 81
    .line 82
    .line 83
    return-void
.end method

.method public final c(Z)V
    .registers 5

    .line 1
    iget-object v0, p0, Lca;->l:Landroid/graphics/Typeface;

    .line 2
    .line 3
    iget-object v1, p0, Lca;->a:Landroid/widget/TextView;

    .line 4
    .line 5
    if-eqz v0, :cond_15

    .line 6
    .line 7
    iget p1, p0, Lca;->k:I

    .line 8
    .line 9
    const/4 v2, -0x1

    .line 10
    if-ne p1, v2, :cond_11

    .line 11
    .line 12
    iget p1, p0, Lca;->j:I

    .line 13
    .line 14
    invoke-virtual {v1, v0, p1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 15
    .line 16
    .line 17
    goto :goto_1b

    .line 18
    :cond_11
    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 19
    .line 20
    .line 21
    goto :goto_1b

    .line 22
    :cond_15
    if-eqz p1, :cond_1b

    .line 23
    .line 24
    const/4 p1, 0x0

    .line 25
    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 26
    .line 27
    .line 28
    :cond_1b
    :goto_1b
    iget-object p0, p0, Lca;->m:Ljava/lang/String;

    .line 29
    .line 30
    if-eqz p0, :cond_28

    .line 31
    .line 32
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 33
    .line 34
    const/16 v0, 0x1a

    .line 35
    .line 36
    if-lt p1, v0, :cond_28

    .line 37
    .line 38
    invoke-static {v1, p0}, Lz9;->f(Landroid/widget/TextView;Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    :cond_28
    return-void
.end method

.method public final f()Landroid/content/res/ColorStateList;
    .registers 1

    .line 1
    iget-object p0, p0, Lca;->h:Liy;

    .line 2
    .line 3
    if-eqz p0, :cond_9

    .line 4
    .line 5
    iget-object p0, p0, Liy;->c:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast p0, Landroid/content/res/ColorStateList;

    .line 8
    .line 9
    return-object p0

    .line 10
    :cond_9
    const/4 p0, 0x0

    .line 11
    return-object p0
.end method

.method public final g()Landroid/graphics/PorterDuff$Mode;
    .registers 1

    .line 1
    iget-object p0, p0, Lca;->h:Liy;

    .line 2
    .line 3
    if-eqz p0, :cond_9

    .line 4
    .line 5
    iget-object p0, p0, Liy;->d:Ljava/io/Serializable;

    .line 6
    .line 7
    check-cast p0, Landroid/graphics/PorterDuff$Mode;

    .line 8
    .line 9
    return-object p0

    .line 10
    :cond_9
    const/4 p0, 0x0

    .line 11
    return-object p0
.end method

.method public final h(Landroid/util/AttributeSet;I)V
    .registers 26

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v3, p1

    .line 4
    .line 5
    move/from16 v5, p2

    .line 6
    .line 7
    iget-object v1, v0, Lca;->a:Landroid/widget/TextView;

    .line 8
    .line 9
    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 10
    .line 11
    .line 12
    move-result-object v7

    .line 13
    invoke-static {}, Lz8;->a()Lz8;

    .line 14
    .line 15
    .line 16
    move-result-object v8

    .line 17
    const/4 v9, 0x0

    .line 18
    sget-object v2, Laa2;->h:[I

    .line 19
    .line 20
    invoke-static {v5, v9, v7, v3, v2}, Lt51;->f(IILandroid/content/Context;Landroid/util/AttributeSet;[I)Lt51;

    .line 21
    .line 22
    .line 23
    move-result-object v10

    .line 24
    move-object v3, v2

    .line 25
    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 26
    .line 27
    .line 28
    move-result-object v2

    .line 29
    iget-object v4, v10, Lt51;->c:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast v4, Landroid/content/res/TypedArray;

    .line 32
    .line 33
    move v6, v5

    .line 34
    move-object v5, v4

    .line 35
    move-object/from16 v4, p1

    .line 36
    .line 37
    invoke-static/range {v1 .. v6}, Ln83;->m(Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;I)V

    .line 38
    .line 39
    .line 40
    move-object v3, v4

    .line 41
    move v5, v6

    .line 42
    move-object v6, v1

    .line 43
    iget-object v1, v10, Lt51;->c:Ljava/lang/Object;

    .line 44
    .line 45
    check-cast v1, Landroid/content/res/TypedArray;

    .line 46
    .line 47
    const/4 v11, -0x1

    .line 48
    invoke-virtual {v1, v9, v11}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 49
    .line 50
    .line 51
    move-result v2

    .line 52
    const/4 v12, 0x3

    .line 53
    invoke-virtual {v1, v12}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 54
    .line 55
    .line 56
    move-result v4

    .line 57
    if-eqz v4, :cond_44

    .line 58
    .line 59
    invoke-virtual {v1, v12, v9}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 60
    .line 61
    .line 62
    move-result v4

    .line 63
    invoke-static {v7, v8, v4}, Lca;->e(Landroid/content/Context;Lz8;I)Liy;

    .line 64
    .line 65
    .line 66
    move-result-object v4

    .line 67
    iput-object v4, v0, Lca;->b:Liy;

    .line 68
    .line 69
    :cond_44
    const/4 v13, 0x1

    .line 70
    invoke-virtual {v1, v13}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 71
    .line 72
    .line 73
    move-result v4

    .line 74
    if-eqz v4, :cond_55

    .line 75
    .line 76
    invoke-virtual {v1, v13, v9}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 77
    .line 78
    .line 79
    move-result v4

    .line 80
    invoke-static {v7, v8, v4}, Lca;->e(Landroid/content/Context;Lz8;I)Liy;

    .line 81
    .line 82
    .line 83
    move-result-object v4

    .line 84
    iput-object v4, v0, Lca;->c:Liy;

    .line 85
    .line 86
    :cond_55
    const/4 v14, 0x4

    .line 87
    invoke-virtual {v1, v14}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 88
    .line 89
    .line 90
    move-result v4

    .line 91
    if-eqz v4, :cond_66

    .line 92
    .line 93
    invoke-virtual {v1, v14, v9}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 94
    .line 95
    .line 96
    move-result v4

    .line 97
    invoke-static {v7, v8, v4}, Lca;->e(Landroid/content/Context;Lz8;I)Liy;

    .line 98
    .line 99
    .line 100
    move-result-object v4

    .line 101
    iput-object v4, v0, Lca;->d:Liy;

    .line 102
    .line 103
    :cond_66
    const/4 v15, 0x2

    .line 104
    invoke-virtual {v1, v15}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 105
    .line 106
    .line 107
    move-result v4

    .line 108
    if-eqz v4, :cond_77

    .line 109
    .line 110
    invoke-virtual {v1, v15, v9}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 111
    .line 112
    .line 113
    move-result v4

    .line 114
    invoke-static {v7, v8, v4}, Lca;->e(Landroid/content/Context;Lz8;I)Liy;

    .line 115
    .line 116
    .line 117
    move-result-object v4

    .line 118
    iput-object v4, v0, Lca;->e:Liy;

    .line 119
    .line 120
    :cond_77
    const/4 v4, 0x5

    .line 121
    invoke-virtual {v1, v4}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 122
    .line 123
    .line 124
    move-result v16

    .line 125
    if-eqz v16, :cond_88

    .line 126
    .line 127
    invoke-virtual {v1, v4, v9}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 128
    .line 129
    .line 130
    move-result v12

    .line 131
    invoke-static {v7, v8, v12}, Lca;->e(Landroid/content/Context;Lz8;I)Liy;

    .line 132
    .line 133
    .line 134
    move-result-object v12

    .line 135
    iput-object v12, v0, Lca;->f:Liy;

    .line 136
    .line 137
    :cond_88
    const/4 v12, 0x6

    .line 138
    invoke-virtual {v1, v12}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 139
    .line 140
    .line 141
    move-result v17

    .line 142
    if-eqz v17, :cond_99

    .line 143
    .line 144
    invoke-virtual {v1, v12, v9}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 145
    .line 146
    .line 147
    move-result v1

    .line 148
    invoke-static {v7, v8, v1}, Lca;->e(Landroid/content/Context;Lz8;I)Liy;

    .line 149
    .line 150
    .line 151
    move-result-object v1

    .line 152
    iput-object v1, v0, Lca;->g:Liy;

    .line 153
    .line 154
    :cond_99
    invoke-virtual {v10}, Lt51;->h()V

    .line 155
    .line 156
    .line 157
    invoke-virtual {v6}, Landroid/widget/TextView;->getTransformationMethod()Landroid/text/method/TransformationMethod;

    .line 158
    .line 159
    .line 160
    move-result-object v1

    .line 161
    instance-of v1, v1, Landroid/text/method/PasswordTransformationMethod;

    .line 162
    .line 163
    sget-object v10, Laa2;->w:[I

    .line 164
    .line 165
    const/16 v4, 0xe

    .line 166
    .line 167
    const/16 v12, 0xf

    .line 168
    .line 169
    if-eq v2, v11, :cond_db

    .line 170
    .line 171
    new-instance v13, Lt51;

    .line 172
    .line 173
    invoke-virtual {v7, v2, v10}, Landroid/content/Context;->obtainStyledAttributes(I[I)Landroid/content/res/TypedArray;

    .line 174
    .line 175
    .line 176
    move-result-object v2

    .line 177
    invoke-direct {v13, v7, v2}, Lt51;-><init>(Landroid/content/Context;Landroid/content/res/TypedArray;)V

    .line 178
    .line 179
    .line 180
    if-nez v1, :cond_c4

    .line 181
    .line 182
    invoke-virtual {v2, v4}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 183
    .line 184
    .line 185
    move-result v19

    .line 186
    if-eqz v19, :cond_c4

    .line 187
    .line 188
    invoke-virtual {v2, v4, v9}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 189
    .line 190
    .line 191
    move-result v19

    .line 192
    move/from16 v20, v19

    .line 193
    .line 194
    const/16 v19, 0x1

    .line 195
    .line 196
    goto :goto_c8

    .line 197
    :cond_c4
    move/from16 v19, v9

    .line 198
    .line 199
    move/from16 v20, v19

    .line 200
    .line 201
    :goto_c8
    invoke-virtual {v0, v7, v13}, Lca;->p(Landroid/content/Context;Lt51;)Z

    .line 202
    .line 203
    .line 204
    invoke-virtual {v2, v12}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 205
    .line 206
    .line 207
    move-result v21

    .line 208
    if-eqz v21, :cond_d6

    .line 209
    .line 210
    invoke-virtual {v2, v12}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    .line 211
    .line 212
    .line 213
    move-result-object v2

    .line 214
    goto :goto_d7

    .line 215
    :cond_d6
    const/4 v2, 0x0

    .line 216
    :goto_d7
    invoke-virtual {v13}, Lt51;->h()V

    .line 217
    .line 218
    .line 219
    goto :goto_e0

    .line 220
    :cond_db
    move/from16 v19, v9

    .line 221
    .line 222
    move/from16 v20, v19

    .line 223
    .line 224
    const/4 v2, 0x0

    .line 225
    :goto_e0
    new-instance v13, Lt51;

    .line 226
    .line 227
    invoke-virtual {v7, v3, v10, v5, v9}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    .line 228
    .line 229
    .line 230
    move-result-object v10

    .line 231
    invoke-direct {v13, v7, v10}, Lt51;-><init>(Landroid/content/Context;Landroid/content/res/TypedArray;)V

    .line 232
    .line 233
    .line 234
    if-nez v1, :cond_f7

    .line 235
    .line 236
    invoke-virtual {v10, v4}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 237
    .line 238
    .line 239
    move-result v21

    .line 240
    if-eqz v21, :cond_f7

    .line 241
    .line 242
    invoke-virtual {v10, v4, v9}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 243
    .line 244
    .line 245
    move-result v20

    .line 246
    const/16 v19, 0x1

    .line 247
    .line 248
    :cond_f7
    move/from16 v4, v20

    .line 249
    .line 250
    invoke-virtual {v10, v12}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 251
    .line 252
    .line 253
    move-result v20

    .line 254
    if-eqz v20, :cond_103

    .line 255
    .line 256
    invoke-virtual {v10, v12}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    .line 257
    .line 258
    .line 259
    move-result-object v2

    .line 260
    :cond_103
    sget v12, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 261
    .line 262
    const/16 v15, 0x1c

    .line 263
    .line 264
    if-lt v12, v15, :cond_119

    .line 265
    .line 266
    invoke-virtual {v10, v9}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 267
    .line 268
    .line 269
    move-result v12

    .line 270
    if-eqz v12, :cond_119

    .line 271
    .line 272
    invoke-virtual {v10, v9, v11}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 273
    .line 274
    .line 275
    move-result v10

    .line 276
    if-nez v10, :cond_119

    .line 277
    .line 278
    const/4 v10, 0x0

    .line 279
    invoke-virtual {v6, v9, v10}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 280
    .line 281
    .line 282
    :cond_119
    invoke-virtual {v0, v7, v13}, Lca;->p(Landroid/content/Context;Lt51;)Z

    .line 283
    .line 284
    .line 285
    invoke-virtual {v13}, Lt51;->h()V

    .line 286
    .line 287
    .line 288
    if-nez v1, :cond_126

    .line 289
    .line 290
    if-eqz v19, :cond_126

    .line 291
    .line 292
    invoke-virtual {v6, v4}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 293
    .line 294
    .line 295
    :cond_126
    invoke-virtual {v0, v9}, Lca;->c(Z)V

    .line 296
    .line 297
    .line 298
    if-eqz v2, :cond_132

    .line 299
    .line 300
    invoke-static {v2}, Landroid/os/LocaleList;->forLanguageTags(Ljava/lang/String;)Landroid/os/LocaleList;

    .line 301
    .line 302
    .line 303
    move-result-object v1

    .line 304
    invoke-virtual {v6, v1}, Landroid/widget/TextView;->setTextLocales(Landroid/os/LocaleList;)V

    .line 305
    .line 306
    .line 307
    :cond_132
    iget-object v10, v0, Lca;->i:Lja;

    .line 308
    .line 309
    iget-object v12, v10, Lja;->j:Landroid/content/Context;

    .line 310
    .line 311
    sget-object v2, Laa2;->i:[I

    .line 312
    .line 313
    invoke-virtual {v12, v3, v2, v5, v9}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    .line 314
    .line 315
    .line 316
    move-result-object v4

    .line 317
    iget-object v0, v10, Lja;->i:Landroid/widget/TextView;

    .line 318
    .line 319
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 320
    .line 321
    .line 322
    move-result-object v1

    .line 323
    const/4 v13, 0x5

    .line 324
    invoke-static/range {v0 .. v5}, Ln83;->m(Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;I)V

    .line 325
    .line 326
    .line 327
    invoke-virtual {v4, v13}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 328
    .line 329
    .line 330
    move-result v0

    .line 331
    if-eqz v0, :cond_152

    .line 332
    .line 333
    invoke-virtual {v4, v13, v9}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 334
    .line 335
    .line 336
    move-result v0

    .line 337
    iput v0, v10, Lja;->a:I

    .line 338
    .line 339
    :cond_152
    invoke-virtual {v4, v14}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 340
    .line 341
    .line 342
    move-result v0

    .line 343
    const/high16 v1, -0x40800000    # -1.0f

    .line 344
    .line 345
    if-eqz v0, :cond_160

    .line 346
    .line 347
    invoke-virtual {v4, v14, v1}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 348
    .line 349
    .line 350
    move-result v0

    .line 351
    :goto_15e
    const/4 v5, 0x2

    .line 352
    goto :goto_162

    .line 353
    :cond_160
    move v0, v1

    .line 354
    goto :goto_15e

    .line 355
    :goto_162
    invoke-virtual {v4, v5}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 356
    .line 357
    .line 358
    move-result v14

    .line 359
    if-eqz v14, :cond_16e

    .line 360
    .line 361
    invoke-virtual {v4, v5, v1}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 362
    .line 363
    .line 364
    move-result v14

    .line 365
    :goto_16c
    const/4 v5, 0x1

    .line 366
    goto :goto_170

    .line 367
    :cond_16e
    move v14, v1

    .line 368
    goto :goto_16c

    .line 369
    :goto_170
    invoke-virtual {v4, v5}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 370
    .line 371
    .line 372
    move-result v15

    .line 373
    if-eqz v15, :cond_17c

    .line 374
    .line 375
    invoke-virtual {v4, v5, v1}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 376
    .line 377
    .line 378
    move-result v15

    .line 379
    :goto_17a
    const/4 v5, 0x3

    .line 380
    goto :goto_17e

    .line 381
    :cond_17c
    move v15, v1

    .line 382
    goto :goto_17a

    .line 383
    :goto_17e
    invoke-virtual {v4, v5}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 384
    .line 385
    .line 386
    move-result v16

    .line 387
    move/from16 p0, v1

    .line 388
    .line 389
    if-eqz v16, :cond_1b3

    .line 390
    .line 391
    invoke-virtual {v4, v5, v9}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 392
    .line 393
    .line 394
    move-result v1

    .line 395
    if-lez v1, :cond_1b3

    .line 396
    .line 397
    invoke-virtual {v4}, Landroid/content/res/TypedArray;->getResources()Landroid/content/res/Resources;

    .line 398
    .line 399
    .line 400
    move-result-object v5

    .line 401
    invoke-virtual {v5, v1}, Landroid/content/res/Resources;->obtainTypedArray(I)Landroid/content/res/TypedArray;

    .line 402
    .line 403
    .line 404
    move-result-object v1

    .line 405
    invoke-virtual {v1}, Landroid/content/res/TypedArray;->length()I

    .line 406
    .line 407
    .line 408
    move-result v5

    .line 409
    new-array v13, v5, [I

    .line 410
    .line 411
    if-lez v5, :cond_1b0

    .line 412
    .line 413
    :goto_19c
    if-ge v9, v5, :cond_1a7

    .line 414
    .line 415
    invoke-virtual {v1, v9, v11}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 416
    .line 417
    .line 418
    move-result v22

    .line 419
    aput v22, v13, v9

    .line 420
    .line 421
    add-int/lit8 v9, v9, 0x1

    .line 422
    .line 423
    goto :goto_19c

    .line 424
    :cond_1a7
    invoke-static {v13}, Lja;->b([I)[I

    .line 425
    .line 426
    .line 427
    move-result-object v5

    .line 428
    iput-object v5, v10, Lja;->f:[I

    .line 429
    .line 430
    invoke-virtual {v10}, Lja;->i()Z

    .line 431
    .line 432
    .line 433
    :cond_1b0
    invoke-virtual {v1}, Landroid/content/res/TypedArray;->recycle()V

    .line 434
    .line 435
    .line 436
    :cond_1b3
    invoke-virtual {v4}, Landroid/content/res/TypedArray;->recycle()V

    .line 437
    .line 438
    .line 439
    invoke-virtual {v10}, Lja;->j()Z

    .line 440
    .line 441
    .line 442
    move-result v1

    .line 443
    if-eqz v1, :cond_1f1

    .line 444
    .line 445
    iget v1, v10, Lja;->a:I

    .line 446
    .line 447
    const/4 v5, 0x1

    .line 448
    if-ne v1, v5, :cond_1f4

    .line 449
    .line 450
    iget-boolean v1, v10, Lja;->g:Z

    .line 451
    .line 452
    if-nez v1, :cond_1ed

    .line 453
    .line 454
    invoke-virtual {v12}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 455
    .line 456
    .line 457
    move-result-object v1

    .line 458
    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 459
    .line 460
    .line 461
    move-result-object v1

    .line 462
    cmpl-float v4, v14, p0

    .line 463
    .line 464
    if-nez v4, :cond_1d9

    .line 465
    .line 466
    const/high16 v4, 0x41400000    # 12.0f

    .line 467
    .line 468
    const/4 v5, 0x2

    .line 469
    invoke-static {v5, v4, v1}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 470
    .line 471
    .line 472
    move-result v14

    .line 473
    goto :goto_1da

    .line 474
    :cond_1d9
    const/4 v5, 0x2

    .line 475
    :goto_1da
    cmpl-float v4, v15, p0

    .line 476
    .line 477
    if-nez v4, :cond_1e4

    .line 478
    .line 479
    const/high16 v4, 0x42e00000    # 112.0f

    .line 480
    .line 481
    invoke-static {v5, v4, v1}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 482
    .line 483
    .line 484
    move-result v15

    .line 485
    :cond_1e4
    cmpl-float v1, v0, p0

    .line 486
    .line 487
    if-nez v1, :cond_1ea

    .line 488
    .line 489
    const/high16 v0, 0x3f800000    # 1.0f

    .line 490
    .line 491
    :cond_1ea
    invoke-virtual {v10, v14, v15, v0}, Lja;->k(FFF)V

    .line 492
    .line 493
    .line 494
    :cond_1ed
    invoke-virtual {v10}, Lja;->h()Z

    .line 495
    .line 496
    .line 497
    goto :goto_1f4

    .line 498
    :cond_1f1
    const/4 v0, 0x0

    .line 499
    iput v0, v10, Lja;->a:I

    .line 500
    .line 501
    :cond_1f4
    :goto_1f4
    sget-boolean v0, Lv93;->c:Z

    .line 502
    .line 503
    if-eqz v0, :cond_223

    .line 504
    .line 505
    iget v0, v10, Lja;->a:I

    .line 506
    .line 507
    if-eqz v0, :cond_223

    .line 508
    .line 509
    iget-object v0, v10, Lja;->f:[I

    .line 510
    .line 511
    array-length v1, v0

    .line 512
    if-lez v1, :cond_223

    .line 513
    .line 514
    invoke-static {v6}, Lz9;->b(Landroid/widget/TextView;)I

    .line 515
    .line 516
    .line 517
    move-result v1

    .line 518
    int-to-float v1, v1

    .line 519
    cmpl-float v1, v1, p0

    .line 520
    .line 521
    if-eqz v1, :cond_220

    .line 522
    .line 523
    iget v0, v10, Lja;->d:F

    .line 524
    .line 525
    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    .line 526
    .line 527
    .line 528
    move-result v0

    .line 529
    iget v1, v10, Lja;->e:F

    .line 530
    .line 531
    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    .line 532
    .line 533
    .line 534
    move-result v1

    .line 535
    iget v4, v10, Lja;->c:F

    .line 536
    .line 537
    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    .line 538
    .line 539
    .line 540
    move-result v4

    .line 541
    invoke-static {v6, v0, v1, v4}, Lz9;->d(Landroid/widget/TextView;III)V

    .line 542
    .line 543
    .line 544
    goto :goto_223

    .line 545
    :cond_220
    invoke-static {v6, v0}, Lz9;->e(Landroid/widget/TextView;[I)V

    .line 546
    .line 547
    .line 548
    :cond_223
    :goto_223
    invoke-virtual {v7, v3, v2}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    .line 549
    .line 550
    .line 551
    move-result-object v0

    .line 552
    const/16 v1, 0x8

    .line 553
    .line 554
    invoke-virtual {v0, v1, v11}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 555
    .line 556
    .line 557
    move-result v1

    .line 558
    if-eq v1, v11, :cond_234

    .line 559
    .line 560
    invoke-virtual {v8, v7, v1}, Lz8;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 561
    .line 562
    .line 563
    move-result-object v1

    .line 564
    goto :goto_235

    .line 565
    :cond_234
    const/4 v1, 0x0

    .line 566
    :goto_235
    const/16 v2, 0xd

    .line 567
    .line 568
    invoke-virtual {v0, v2, v11}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 569
    .line 570
    .line 571
    move-result v2

    .line 572
    if-eq v2, v11, :cond_242

    .line 573
    .line 574
    invoke-virtual {v8, v7, v2}, Lz8;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 575
    .line 576
    .line 577
    move-result-object v2

    .line 578
    goto :goto_243

    .line 579
    :cond_242
    const/4 v2, 0x0

    .line 580
    :goto_243
    const/16 v3, 0x9

    .line 581
    .line 582
    invoke-virtual {v0, v3, v11}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 583
    .line 584
    .line 585
    move-result v3

    .line 586
    if-eq v3, v11, :cond_251

    .line 587
    .line 588
    invoke-virtual {v8, v7, v3}, Lz8;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 589
    .line 590
    .line 591
    move-result-object v3

    .line 592
    :goto_24f
    const/4 v4, 0x6

    .line 593
    goto :goto_253

    .line 594
    :cond_251
    const/4 v3, 0x0

    .line 595
    goto :goto_24f

    .line 596
    :goto_253
    invoke-virtual {v0, v4, v11}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 597
    .line 598
    .line 599
    move-result v4

    .line 600
    if-eq v4, v11, :cond_25e

    .line 601
    .line 602
    invoke-virtual {v8, v7, v4}, Lz8;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 603
    .line 604
    .line 605
    move-result-object v4

    .line 606
    goto :goto_25f

    .line 607
    :cond_25e
    const/4 v4, 0x0

    .line 608
    :goto_25f
    const/16 v5, 0xa

    .line 609
    .line 610
    invoke-virtual {v0, v5, v11}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 611
    .line 612
    .line 613
    move-result v5

    .line 614
    if-eq v5, v11, :cond_26c

    .line 615
    .line 616
    invoke-virtual {v8, v7, v5}, Lz8;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 617
    .line 618
    .line 619
    move-result-object v5

    .line 620
    goto :goto_26d

    .line 621
    :cond_26c
    const/4 v5, 0x0

    .line 622
    :goto_26d
    const/4 v9, 0x7

    .line 623
    invoke-virtual {v0, v9, v11}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 624
    .line 625
    .line 626
    move-result v9

    .line 627
    if-eq v9, v11, :cond_279

    .line 628
    .line 629
    invoke-virtual {v8, v7, v9}, Lz8;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 630
    .line 631
    .line 632
    move-result-object v8

    .line 633
    goto :goto_27a

    .line 634
    :cond_279
    const/4 v8, 0x0

    .line 635
    :goto_27a
    if-nez v5, :cond_2d1

    .line 636
    .line 637
    if-eqz v8, :cond_27f

    .line 638
    .line 639
    goto :goto_2d1

    .line 640
    :cond_27f
    if-nez v1, :cond_287

    .line 641
    .line 642
    if-nez v2, :cond_287

    .line 643
    .line 644
    if-nez v3, :cond_287

    .line 645
    .line 646
    if-eqz v4, :cond_2f4

    .line 647
    .line 648
    :cond_287
    invoke-virtual {v6}, Landroid/widget/TextView;->getCompoundDrawablesRelative()[Landroid/graphics/drawable/Drawable;

    .line 649
    .line 650
    .line 651
    move-result-object v5

    .line 652
    const/16 v19, 0x0

    .line 653
    .line 654
    aget-object v8, v5, v19

    .line 655
    .line 656
    if-nez v8, :cond_297

    .line 657
    .line 658
    const/16 v21, 0x2

    .line 659
    .line 660
    aget-object v9, v5, v21

    .line 661
    .line 662
    if-eqz v9, :cond_29a

    .line 663
    .line 664
    :cond_297
    const/16 v16, 0x3

    .line 665
    .line 666
    goto :goto_2bc

    .line 667
    :cond_29a
    invoke-virtual {v6}, Landroid/widget/TextView;->getCompoundDrawables()[Landroid/graphics/drawable/Drawable;

    .line 668
    .line 669
    .line 670
    move-result-object v5

    .line 671
    if-eqz v1, :cond_2a1

    .line 672
    .line 673
    goto :goto_2a3

    .line 674
    :cond_2a1
    aget-object v1, v5, v19

    .line 675
    .line 676
    :goto_2a3
    if-eqz v2, :cond_2a6

    .line 677
    .line 678
    goto :goto_2aa

    .line 679
    :cond_2a6
    const/16 v18, 0x1

    .line 680
    .line 681
    aget-object v2, v5, v18

    .line 682
    .line 683
    :goto_2aa
    if-eqz v3, :cond_2ad

    .line 684
    .line 685
    goto :goto_2b1

    .line 686
    :cond_2ad
    const/16 v21, 0x2

    .line 687
    .line 688
    aget-object v3, v5, v21

    .line 689
    .line 690
    :goto_2b1
    if-eqz v4, :cond_2b4

    .line 691
    .line 692
    goto :goto_2b8

    .line 693
    :cond_2b4
    const/16 v16, 0x3

    .line 694
    .line 695
    aget-object v4, v5, v16

    .line 696
    .line 697
    :goto_2b8
    invoke-virtual {v6, v1, v2, v3, v4}, Landroid/widget/TextView;->setCompoundDrawablesWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 698
    .line 699
    .line 700
    goto :goto_2f4

    .line 701
    :goto_2bc
    if-eqz v2, :cond_2bf

    .line 702
    .line 703
    goto :goto_2c3

    .line 704
    :cond_2bf
    const/16 v18, 0x1

    .line 705
    .line 706
    aget-object v2, v5, v18

    .line 707
    .line 708
    :goto_2c3
    if-eqz v4, :cond_2c8

    .line 709
    .line 710
    :goto_2c5
    const/16 v21, 0x2

    .line 711
    .line 712
    goto :goto_2cb

    .line 713
    :cond_2c8
    aget-object v4, v5, v16

    .line 714
    .line 715
    goto :goto_2c5

    .line 716
    :goto_2cb
    aget-object v1, v5, v21

    .line 717
    .line 718
    invoke-virtual {v6, v8, v2, v1, v4}, Landroid/widget/TextView;->setCompoundDrawablesRelativeWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 719
    .line 720
    .line 721
    goto :goto_2f4

    .line 722
    :cond_2d1
    :goto_2d1
    invoke-virtual {v6}, Landroid/widget/TextView;->getCompoundDrawablesRelative()[Landroid/graphics/drawable/Drawable;

    .line 723
    .line 724
    .line 725
    move-result-object v1

    .line 726
    if-eqz v5, :cond_2d8

    .line 727
    .line 728
    goto :goto_2dc

    .line 729
    :cond_2d8
    const/16 v19, 0x0

    .line 730
    .line 731
    aget-object v5, v1, v19

    .line 732
    .line 733
    :goto_2dc
    if-eqz v2, :cond_2df

    .line 734
    .line 735
    goto :goto_2e3

    .line 736
    :cond_2df
    const/16 v18, 0x1

    .line 737
    .line 738
    aget-object v2, v1, v18

    .line 739
    .line 740
    :goto_2e3
    if-eqz v8, :cond_2e6

    .line 741
    .line 742
    goto :goto_2ea

    .line 743
    :cond_2e6
    const/16 v21, 0x2

    .line 744
    .line 745
    aget-object v8, v1, v21

    .line 746
    .line 747
    :goto_2ea
    if-eqz v4, :cond_2ed

    .line 748
    .line 749
    goto :goto_2f1

    .line 750
    :cond_2ed
    const/16 v16, 0x3

    .line 751
    .line 752
    aget-object v4, v1, v16

    .line 753
    .line 754
    :goto_2f1
    invoke-virtual {v6, v5, v2, v8, v4}, Landroid/widget/TextView;->setCompoundDrawablesRelativeWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 755
    .line 756
    .line 757
    :cond_2f4
    :goto_2f4
    const/16 v1, 0xb

    .line 758
    .line 759
    invoke-virtual {v0, v1}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 760
    .line 761
    .line 762
    move-result v2

    .line 763
    if-eqz v2, :cond_317

    .line 764
    .line 765
    invoke-virtual {v0, v1}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 766
    .line 767
    .line 768
    move-result v2

    .line 769
    if-eqz v2, :cond_310

    .line 770
    .line 771
    const/4 v2, 0x0

    .line 772
    invoke-virtual {v0, v1, v2}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 773
    .line 774
    .line 775
    move-result v2

    .line 776
    if-eqz v2, :cond_310

    .line 777
    .line 778
    invoke-static {v7, v2}, Lpf3;->m(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    .line 779
    .line 780
    .line 781
    move-result-object v2

    .line 782
    if-eqz v2, :cond_310

    .line 783
    .line 784
    goto :goto_314

    .line 785
    :cond_310
    invoke-virtual {v0, v1}, Landroid/content/res/TypedArray;->getColorStateList(I)Landroid/content/res/ColorStateList;

    .line 786
    .line 787
    .line 788
    move-result-object v2

    .line 789
    :goto_314
    invoke-virtual {v6, v2}, Landroid/widget/TextView;->setCompoundDrawableTintList(Landroid/content/res/ColorStateList;)V

    .line 790
    .line 791
    .line 792
    :cond_317
    const/16 v1, 0xc

    .line 793
    .line 794
    invoke-virtual {v0, v1}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 795
    .line 796
    .line 797
    move-result v2

    .line 798
    if-eqz v2, :cond_32b

    .line 799
    .line 800
    invoke-virtual {v0, v1, v11}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 801
    .line 802
    .line 803
    move-result v1

    .line 804
    const/4 v2, 0x0

    .line 805
    invoke-static {v1, v2}, Lte0;->c(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;

    .line 806
    .line 807
    .line 808
    move-result-object v1

    .line 809
    invoke-virtual {v6, v1}, Landroid/widget/TextView;->setCompoundDrawableTintMode(Landroid/graphics/PorterDuff$Mode;)V

    .line 810
    .line 811
    .line 812
    :cond_32b
    const/16 v1, 0xf

    .line 813
    .line 814
    invoke-virtual {v0, v1, v11}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 815
    .line 816
    .line 817
    move-result v1

    .line 818
    const/16 v2, 0x12

    .line 819
    .line 820
    invoke-virtual {v0, v2, v11}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 821
    .line 822
    .line 823
    move-result v2

    .line 824
    const/16 v3, 0x13

    .line 825
    .line 826
    invoke-virtual {v0, v3}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 827
    .line 828
    .line 829
    move-result v4

    .line 830
    if-eqz v4, :cond_35a

    .line 831
    .line 832
    invoke-virtual {v0, v3}, Landroid/content/res/TypedArray;->peekValue(I)Landroid/util/TypedValue;

    .line 833
    .line 834
    .line 835
    move-result-object v4

    .line 836
    if-eqz v4, :cond_353

    .line 837
    .line 838
    iget v5, v4, Landroid/util/TypedValue;->type:I

    .line 839
    .line 840
    const/4 v13, 0x5

    .line 841
    if-ne v5, v13, :cond_353

    .line 842
    .line 843
    iget v3, v4, Landroid/util/TypedValue;->data:I

    .line 844
    .line 845
    and-int/lit8 v4, v3, 0xf

    .line 846
    .line 847
    invoke-static {v3}, Landroid/util/TypedValue;->complexToFloat(I)F

    .line 848
    .line 849
    .line 850
    move-result v3

    .line 851
    goto :goto_35d

    .line 852
    :cond_353
    invoke-virtual {v0, v3, v11}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 853
    .line 854
    .line 855
    move-result v3

    .line 856
    int-to-float v3, v3

    .line 857
    :goto_358
    move v4, v11

    .line 858
    goto :goto_35d

    .line 859
    :cond_35a
    move/from16 v3, p0

    .line 860
    .line 861
    goto :goto_358

    .line 862
    :goto_35d
    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    .line 863
    .line 864
    .line 865
    if-eq v1, v11, :cond_365

    .line 866
    .line 867
    invoke-static {v6, v1}, La30;->p(Landroid/widget/TextView;I)V

    .line 868
    .line 869
    .line 870
    :cond_365
    if-eq v2, v11, :cond_36a

    .line 871
    .line 872
    invoke-static {v6, v2}, La30;->q(Landroid/widget/TextView;I)V

    .line 873
    .line 874
    .line 875
    :cond_36a
    cmpl-float v0, v3, p0

    .line 876
    .line 877
    if-eqz v0, :cond_392

    .line 878
    .line 879
    if-ne v4, v11, :cond_375

    .line 880
    .line 881
    float-to-int v0, v3

    .line 882
    invoke-static {v6, v0}, La30;->r(Landroid/widget/TextView;I)V

    .line 883
    .line 884
    .line 885
    return-void

    .line 886
    :cond_375
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 887
    .line 888
    const/16 v1, 0x22

    .line 889
    .line 890
    if-lt v0, v1, :cond_37f

    .line 891
    .line 892
    invoke-static {v6, v4, v3}, Lq1;->h(Landroid/widget/TextView;IF)V

    .line 893
    .line 894
    .line 895
    return-void

    .line 896
    :cond_37f
    invoke-virtual {v6}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 897
    .line 898
    .line 899
    move-result-object v0

    .line 900
    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 901
    .line 902
    .line 903
    move-result-object v0

    .line 904
    invoke-static {v4, v3, v0}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 905
    .line 906
    .line 907
    move-result v0

    .line 908
    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    .line 909
    .line 910
    .line 911
    move-result v0

    .line 912
    invoke-static {v6, v0}, La30;->r(Landroid/widget/TextView;I)V

    .line 913
    .line 914
    .line 915
    :cond_392
    return-void
.end method

.method public final i(Landroid/content/Context;I)V
    .registers 8

    .line 1
    new-instance v0, Lt51;

    .line 2
    .line 3
    sget-object v1, Laa2;->w:[I

    .line 4
    .line 5
    invoke-virtual {p1, p2, v1}, Landroid/content/Context;->obtainStyledAttributes(I[I)Landroid/content/res/TypedArray;

    .line 6
    .line 7
    .line 8
    move-result-object p2

    .line 9
    invoke-direct {v0, p1, p2}, Lt51;-><init>(Landroid/content/Context;Landroid/content/res/TypedArray;)V

    .line 10
    .line 11
    .line 12
    const/16 v1, 0xe

    .line 13
    .line 14
    invoke-virtual {p2, v1}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 15
    .line 16
    .line 17
    move-result v2

    .line 18
    iget-object v3, p0, Lca;->a:Landroid/widget/TextView;

    .line 19
    .line 20
    const/4 v4, 0x0

    .line 21
    if-eqz v2, :cond_1d

    .line 22
    .line 23
    invoke-virtual {p2, v1, v4}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    invoke-virtual {v3, v1}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 28
    .line 29
    .line 30
    :cond_1d
    invoke-virtual {p2, v4}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 31
    .line 32
    .line 33
    move-result v1

    .line 34
    if-eqz v1, :cond_2e

    .line 35
    .line 36
    const/4 v1, -0x1

    .line 37
    invoke-virtual {p2, v4, v1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 38
    .line 39
    .line 40
    move-result p2

    .line 41
    if-nez p2, :cond_2e

    .line 42
    .line 43
    const/4 p2, 0x0

    .line 44
    invoke-virtual {v3, v4, p2}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 45
    .line 46
    .line 47
    :cond_2e
    invoke-virtual {p0, p1, v0}, Lca;->p(Landroid/content/Context;Lt51;)Z

    .line 48
    .line 49
    .line 50
    move-result p1

    .line 51
    invoke-virtual {v0}, Lt51;->h()V

    .line 52
    .line 53
    .line 54
    invoke-virtual {p0, p1}, Lca;->c(Z)V

    .line 55
    .line 56
    .line 57
    return-void
.end method

.method public final k(IIII)V
    .registers 6

    .line 1
    iget-object p0, p0, Lca;->i:Lja;

    .line 2
    .line 3
    invoke-virtual {p0}, Lja;->j()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_2d

    .line 8
    .line 9
    iget-object v0, p0, Lja;->j:Landroid/content/Context;

    .line 10
    .line 11
    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    int-to-float p1, p1

    .line 20
    invoke-static {p4, p1, v0}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 21
    .line 22
    .line 23
    move-result p1

    .line 24
    int-to-float p2, p2

    .line 25
    invoke-static {p4, p2, v0}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 26
    .line 27
    .line 28
    move-result p2

    .line 29
    int-to-float p3, p3

    .line 30
    invoke-static {p4, p3, v0}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 31
    .line 32
    .line 33
    move-result p3

    .line 34
    invoke-virtual {p0, p1, p2, p3}, Lja;->k(FFF)V

    .line 35
    .line 36
    .line 37
    invoke-virtual {p0}, Lja;->h()Z

    .line 38
    .line 39
    .line 40
    move-result p1

    .line 41
    if-eqz p1, :cond_2d

    .line 42
    .line 43
    invoke-virtual {p0}, Lja;->a()V

    .line 44
    .line 45
    .line 46
    :cond_2d
    return-void
.end method

.method public final l([II)V
    .registers 8

    .line 1
    iget-object p0, p0, Lca;->i:Lja;

    .line 2
    .line 3
    invoke-virtual {p0}, Lja;->j()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_53

    .line 8
    .line 9
    array-length v0, p1

    .line 10
    const/4 v1, 0x0

    .line 11
    if-lez v0, :cond_48

    .line 12
    .line 13
    new-array v2, v0, [I

    .line 14
    .line 15
    if-nez p2, :cond_15

    .line 16
    .line 17
    invoke-static {p1, v0}, Ljava/util/Arrays;->copyOf([II)[I

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    goto :goto_31

    .line 22
    :cond_15
    iget-object v3, p0, Lja;->j:Landroid/content/Context;

    .line 23
    .line 24
    invoke-virtual {v3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 25
    .line 26
    .line 27
    move-result-object v3

    .line 28
    invoke-virtual {v3}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 29
    .line 30
    .line 31
    move-result-object v3

    .line 32
    :goto_1f
    if-ge v1, v0, :cond_31

    .line 33
    .line 34
    aget v4, p1, v1

    .line 35
    .line 36
    int-to-float v4, v4

    .line 37
    invoke-static {p2, v4, v3}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 38
    .line 39
    .line 40
    move-result v4

    .line 41
    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    .line 42
    .line 43
    .line 44
    move-result v4

    .line 45
    aput v4, v2, v1

    .line 46
    .line 47
    add-int/lit8 v1, v1, 0x1

    .line 48
    .line 49
    goto :goto_1f

    .line 50
    :cond_31
    :goto_31
    invoke-static {v2}, Lja;->b([I)[I

    .line 51
    .line 52
    .line 53
    move-result-object p2

    .line 54
    iput-object p2, p0, Lja;->f:[I

    .line 55
    .line 56
    invoke-virtual {p0}, Lja;->i()Z

    .line 57
    .line 58
    .line 59
    move-result p2

    .line 60
    if-eqz p2, :cond_3e

    .line 61
    .line 62
    goto :goto_4a

    .line 63
    :cond_3e
    const-string p0, "None of the preset sizes is valid: "

    .line 64
    .line 65
    invoke-static {p1}, Ljava/util/Arrays;->toString([I)Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    invoke-static {p1, p0}, Lvn0;->m(Ljava/lang/Object;Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    return-void

    .line 73
    :cond_48
    iput-boolean v1, p0, Lja;->g:Z

    .line 74
    .line 75
    :goto_4a
    invoke-virtual {p0}, Lja;->h()Z

    .line 76
    .line 77
    .line 78
    move-result p1

    .line 79
    if-eqz p1, :cond_53

    .line 80
    .line 81
    invoke-virtual {p0}, Lja;->a()V

    .line 82
    .line 83
    .line 84
    :cond_53
    return-void
.end method

.method public final m(I)V
    .registers 5

    .line 1
    iget-object p0, p0, Lca;->i:Lja;

    .line 2
    .line 3
    invoke-virtual {p0}, Lja;->j()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_4e

    .line 8
    .line 9
    if-eqz p1, :cond_3d

    .line 10
    .line 11
    const/4 v0, 0x1

    .line 12
    if-ne p1, v0, :cond_33

    .line 13
    .line 14
    iget-object p1, p0, Lja;->j:Landroid/content/Context;

    .line 15
    .line 16
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    invoke-virtual {p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    const/high16 v0, 0x41400000    # 12.0f

    .line 25
    .line 26
    const/4 v1, 0x2

    .line 27
    invoke-static {v1, v0, p1}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    const/high16 v2, 0x42e00000    # 112.0f

    .line 32
    .line 33
    invoke-static {v1, v2, p1}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 34
    .line 35
    .line 36
    move-result p1

    .line 37
    const/high16 v1, 0x3f800000    # 1.0f

    .line 38
    .line 39
    invoke-virtual {p0, v0, p1, v1}, Lja;->k(FFF)V

    .line 40
    .line 41
    .line 42
    invoke-virtual {p0}, Lja;->h()Z

    .line 43
    .line 44
    .line 45
    move-result p1

    .line 46
    if-eqz p1, :cond_4e

    .line 47
    .line 48
    invoke-virtual {p0}, Lja;->a()V

    .line 49
    .line 50
    .line 51
    return-void

    .line 52
    :cond_33
    const-string p0, "Unknown auto-size text type: "

    .line 53
    .line 54
    invoke-static {p1, p0}, Ls41;->l(ILjava/lang/String;)Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object p0

    .line 58
    invoke-static {p0}, Lm03;->g(Ljava/lang/String;)V

    .line 59
    .line 60
    .line 61
    return-void

    .line 62
    :cond_3d
    const/4 p1, 0x0

    .line 63
    iput p1, p0, Lja;->a:I

    .line 64
    .line 65
    const/high16 v0, -0x40800000    # -1.0f

    .line 66
    .line 67
    iput v0, p0, Lja;->d:F

    .line 68
    .line 69
    iput v0, p0, Lja;->e:F

    .line 70
    .line 71
    iput v0, p0, Lja;->c:F

    .line 72
    .line 73
    new-array v0, p1, [I

    .line 74
    .line 75
    iput-object v0, p0, Lja;->f:[I

    .line 76
    .line 77
    iput-boolean p1, p0, Lja;->b:Z

    .line 78
    .line 79
    :cond_4e
    return-void
.end method

.method public final n(Landroid/content/res/ColorStateList;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lca;->h:Liy;

    .line 2
    .line 3
    if-nez v0, :cond_b

    .line 4
    .line 5
    new-instance v0, Liy;

    .line 6
    .line 7
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Lca;->h:Liy;

    .line 11
    .line 12
    :cond_b
    move-object v1, v0

    .line 13
    iput-object p1, v0, Liy;->c:Ljava/lang/Object;

    .line 14
    .line 15
    if-eqz p1, :cond_12

    .line 16
    .line 17
    const/4 p1, 0x1

    .line 18
    goto :goto_13

    .line 19
    :cond_12
    const/4 p1, 0x0

    .line 20
    :goto_13
    iput-boolean p1, v0, Liy;->b:Z

    .line 21
    .line 22
    iput-object v1, p0, Lca;->b:Liy;

    .line 23
    .line 24
    iput-object v1, p0, Lca;->c:Liy;

    .line 25
    .line 26
    iput-object v1, p0, Lca;->d:Liy;

    .line 27
    .line 28
    iput-object v1, p0, Lca;->e:Liy;

    .line 29
    .line 30
    iput-object v1, p0, Lca;->f:Liy;

    .line 31
    .line 32
    iput-object v1, p0, Lca;->g:Liy;

    .line 33
    .line 34
    return-void
.end method

.method public final o(Landroid/graphics/PorterDuff$Mode;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lca;->h:Liy;

    .line 2
    .line 3
    if-nez v0, :cond_b

    .line 4
    .line 5
    new-instance v0, Liy;

    .line 6
    .line 7
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Lca;->h:Liy;

    .line 11
    .line 12
    :cond_b
    move-object v1, v0

    .line 13
    iput-object p1, v0, Liy;->d:Ljava/io/Serializable;

    .line 14
    .line 15
    if-eqz p1, :cond_12

    .line 16
    .line 17
    const/4 p1, 0x1

    .line 18
    goto :goto_13

    .line 19
    :cond_12
    const/4 p1, 0x0

    .line 20
    :goto_13
    iput-boolean p1, v0, Liy;->a:Z

    .line 21
    .line 22
    iput-object v1, p0, Lca;->b:Liy;

    .line 23
    .line 24
    iput-object v1, p0, Lca;->c:Liy;

    .line 25
    .line 26
    iput-object v1, p0, Lca;->d:Liy;

    .line 27
    .line 28
    iput-object v1, p0, Lca;->e:Liy;

    .line 29
    .line 30
    iput-object v1, p0, Lca;->f:Liy;

    .line 31
    .line 32
    iput-object v1, p0, Lca;->g:Liy;

    .line 33
    .line 34
    return-void
.end method

.method public final p(Landroid/content/Context;Lt51;)Z
    .registers 14

    .line 1
    iget v0, p0, Lca;->j:I

    .line 2
    .line 3
    iget-object v1, p2, Lt51;->c:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Landroid/content/res/TypedArray;

    .line 6
    .line 7
    const/4 v2, 0x2

    .line 8
    invoke-virtual {v1, v2, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    iput v0, p0, Lca;->j:I

    .line 13
    .line 14
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 15
    .line 16
    const/4 v3, -0x1

    .line 17
    const/16 v4, 0x1c

    .line 18
    .line 19
    if-lt v0, v4, :cond_23

    .line 20
    .line 21
    const/16 v5, 0xb

    .line 22
    .line 23
    invoke-virtual {v1, v5, v3}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 24
    .line 25
    .line 26
    move-result v5

    .line 27
    iput v5, p0, Lca;->k:I

    .line 28
    .line 29
    if-eq v5, v3, :cond_23

    .line 30
    .line 31
    iget v5, p0, Lca;->j:I

    .line 32
    .line 33
    and-int/2addr v5, v2

    .line 34
    iput v5, p0, Lca;->j:I

    .line 35
    .line 36
    :cond_23
    const/16 v5, 0x1a

    .line 37
    .line 38
    if-lt v0, v5, :cond_35

    .line 39
    .line 40
    const/16 v5, 0xd

    .line 41
    .line 42
    invoke-virtual {v1, v5}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 43
    .line 44
    .line 45
    move-result v6

    .line 46
    if-eqz v6, :cond_35

    .line 47
    .line 48
    invoke-virtual {v1, v5}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object v5

    .line 52
    iput-object v5, p0, Lca;->m:Ljava/lang/String;

    .line 53
    .line 54
    :cond_35
    const/16 v5, 0xa

    .line 55
    .line 56
    invoke-virtual {v1, v5}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 57
    .line 58
    .line 59
    move-result v6

    .line 60
    const/16 v7, 0xc

    .line 61
    .line 62
    const/4 v8, 0x0

    .line 63
    const/4 v9, 0x1

    .line 64
    if-nez v6, :cond_84

    .line 65
    .line 66
    invoke-virtual {v1, v7}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 67
    .line 68
    .line 69
    move-result v6

    .line 70
    if-eqz v6, :cond_48

    .line 71
    .line 72
    goto :goto_84

    .line 73
    :cond_48
    invoke-virtual {v1, v9}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 74
    .line 75
    .line 76
    move-result p1

    .line 77
    if-eqz p1, :cond_6c

    .line 78
    .line 79
    iput-boolean v8, p0, Lca;->n:Z

    .line 80
    .line 81
    invoke-virtual {v1, v9, v9}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 82
    .line 83
    .line 84
    move-result p1

    .line 85
    if-eq p1, v9, :cond_67

    .line 86
    .line 87
    if-eq p1, v2, :cond_62

    .line 88
    .line 89
    const/4 p2, 0x3

    .line 90
    if-eq p1, p2, :cond_5d

    .line 91
    .line 92
    goto/16 :goto_ff

    .line 93
    .line 94
    :cond_5d
    sget-object p1, Landroid/graphics/Typeface;->MONOSPACE:Landroid/graphics/Typeface;

    .line 95
    .line 96
    iput-object p1, p0, Lca;->l:Landroid/graphics/Typeface;

    .line 97
    .line 98
    return v9

    .line 99
    :cond_62
    sget-object p1, Landroid/graphics/Typeface;->SERIF:Landroid/graphics/Typeface;

    .line 100
    .line 101
    iput-object p1, p0, Lca;->l:Landroid/graphics/Typeface;

    .line 102
    .line 103
    return v9

    .line 104
    :cond_67
    sget-object p1, Landroid/graphics/Typeface;->SANS_SERIF:Landroid/graphics/Typeface;

    .line 105
    .line 106
    iput-object p1, p0, Lca;->l:Landroid/graphics/Typeface;

    .line 107
    .line 108
    return v9

    .line 109
    :cond_6c
    if-lt v0, v4, :cond_83

    .line 110
    .line 111
    iget p1, p0, Lca;->k:I

    .line 112
    .line 113
    if-eq p1, v3, :cond_83

    .line 114
    .line 115
    iget-object p2, p0, Lca;->l:Landroid/graphics/Typeface;

    .line 116
    .line 117
    if-eqz p2, :cond_83

    .line 118
    .line 119
    iget v0, p0, Lca;->j:I

    .line 120
    .line 121
    and-int/2addr v0, v2

    .line 122
    if-eqz v0, :cond_7c

    .line 123
    .line 124
    move v8, v9

    .line 125
    :cond_7c
    invoke-static {p2, p1, v8}, Ls7;->a(Landroid/graphics/Typeface;IZ)Landroid/graphics/Typeface;

    .line 126
    .line 127
    .line 128
    move-result-object p1

    .line 129
    iput-object p1, p0, Lca;->l:Landroid/graphics/Typeface;

    .line 130
    .line 131
    return v9

    .line 132
    :cond_83
    return v8

    .line 133
    :cond_84
    :goto_84
    const/4 v6, 0x0

    .line 134
    iput-object v6, p0, Lca;->l:Landroid/graphics/Typeface;

    .line 135
    .line 136
    invoke-virtual {v1, v7}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 137
    .line 138
    .line 139
    move-result v6

    .line 140
    if-eqz v6, :cond_8e

    .line 141
    .line 142
    move v5, v7

    .line 143
    :cond_8e
    iget v6, p0, Lca;->k:I

    .line 144
    .line 145
    iget v7, p0, Lca;->j:I

    .line 146
    .line 147
    invoke-virtual {p1}, Landroid/content/Context;->isRestricted()Z

    .line 148
    .line 149
    .line 150
    move-result p1

    .line 151
    if-nez p1, :cond_d2

    .line 152
    .line 153
    new-instance p1, Ljava/lang/ref/WeakReference;

    .line 154
    .line 155
    iget-object v10, p0, Lca;->a:Landroid/widget/TextView;

    .line 156
    .line 157
    invoke-direct {p1, v10}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 158
    .line 159
    .line 160
    new-instance v10, Lw9;

    .line 161
    .line 162
    invoke-direct {v10, p0, v6, v7, p1}, Lw9;-><init>(Lca;IILjava/lang/ref/WeakReference;)V

    .line 163
    .line 164
    .line 165
    :try_start_a4
    iget p1, p0, Lca;->j:I

    .line 166
    .line 167
    invoke-virtual {p2, v5, p1, v10}, Lt51;->e(IILw9;)Landroid/graphics/Typeface;

    .line 168
    .line 169
    .line 170
    move-result-object p1

    .line 171
    if-eqz p1, :cond_c9

    .line 172
    .line 173
    if-lt v0, v4, :cond_c7

    .line 174
    .line 175
    iget p2, p0, Lca;->k:I

    .line 176
    .line 177
    if-eq p2, v3, :cond_c7

    .line 178
    .line 179
    invoke-static {p1, v8}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    .line 180
    .line 181
    .line 182
    move-result-object p1

    .line 183
    iget p2, p0, Lca;->k:I

    .line 184
    .line 185
    iget v0, p0, Lca;->j:I

    .line 186
    .line 187
    and-int/2addr v0, v2

    .line 188
    if-eqz v0, :cond_bf

    .line 189
    .line 190
    move v0, v9

    .line 191
    goto :goto_c0

    .line 192
    :cond_bf
    move v0, v8

    .line 193
    :goto_c0
    invoke-static {p1, p2, v0}, Ls7;->a(Landroid/graphics/Typeface;IZ)Landroid/graphics/Typeface;

    .line 194
    .line 195
    .line 196
    move-result-object p1

    .line 197
    iput-object p1, p0, Lca;->l:Landroid/graphics/Typeface;

    .line 198
    .line 199
    goto :goto_c9

    .line 200
    :cond_c7
    iput-object p1, p0, Lca;->l:Landroid/graphics/Typeface;

    .line 201
    .line 202
    :cond_c9
    :goto_c9
    iget-object p1, p0, Lca;->l:Landroid/graphics/Typeface;

    .line 203
    .line 204
    if-nez p1, :cond_cf

    .line 205
    .line 206
    move p1, v9

    .line 207
    goto :goto_d0

    .line 208
    :cond_cf
    move p1, v8

    .line 209
    :goto_d0
    iput-boolean p1, p0, Lca;->n:Z
    :try_end_d2
    .catch Ljava/lang/UnsupportedOperationException; {:try_start_a4 .. :try_end_d2} :catch_d2
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_a4 .. :try_end_d2} :catch_d2

    .line 210
    .line 211
    :catch_d2
    :cond_d2
    iget-object p1, p0, Lca;->l:Landroid/graphics/Typeface;

    .line 212
    .line 213
    if-nez p1, :cond_ff

    .line 214
    .line 215
    invoke-virtual {v1, v5}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    .line 216
    .line 217
    .line 218
    move-result-object p1

    .line 219
    if-eqz p1, :cond_ff

    .line 220
    .line 221
    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 222
    .line 223
    if-lt p2, v4, :cond_f7

    .line 224
    .line 225
    iget p2, p0, Lca;->k:I

    .line 226
    .line 227
    if-eq p2, v3, :cond_f7

    .line 228
    .line 229
    invoke-static {p1, v8}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    .line 230
    .line 231
    .line 232
    move-result-object p1

    .line 233
    iget p2, p0, Lca;->k:I

    .line 234
    .line 235
    iget v0, p0, Lca;->j:I

    .line 236
    .line 237
    and-int/2addr v0, v2

    .line 238
    if-eqz v0, :cond_f0

    .line 239
    .line 240
    move v8, v9

    .line 241
    :cond_f0
    invoke-static {p1, p2, v8}, Ls7;->a(Landroid/graphics/Typeface;IZ)Landroid/graphics/Typeface;

    .line 242
    .line 243
    .line 244
    move-result-object p1

    .line 245
    iput-object p1, p0, Lca;->l:Landroid/graphics/Typeface;

    .line 246
    .line 247
    goto :goto_ff

    .line 248
    :cond_f7
    iget p2, p0, Lca;->j:I

    .line 249
    .line 250
    invoke-static {p1, p2}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    .line 251
    .line 252
    .line 253
    move-result-object p1

    .line 254
    iput-object p1, p0, Lca;->l:Landroid/graphics/Typeface;

    .line 255
    .line 256
    :cond_ff
    :goto_ff
    return v9
.end method
