###### Class defpackage.ru3 (ru3)
.class public final Lru3;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic a:Lhz3;

.field public final synthetic b:Landroid/os/Bundle;

.field public final synthetic c:Lfu3;


# direct methods
.method public constructor <init>(Lfu3;Lhz3;Landroid/os/Bundle;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, Lru3;->a:Lhz3;

    .line 5
    .line 6
    iput-object p3, p0, Lru3;->b:Landroid/os/Bundle;

    .line 7
    .line 8
    iput-object p1, p0, Lru3;->c:Lfu3;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .registers 15

    .line 1
    iget-object v0, p0, Lru3;->c:Lfu3;

    .line 2
    .line 3
    iget-object v1, v0, Lfu3;->d:Laz3;

    .line 4
    .line 5
    invoke-virtual {v1}, Laz3;->d0()V

    .line 6
    .line 7
    .line 8
    invoke-virtual {v1}, Laz3;->y()Lvt3;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-virtual {v0}, Lvt3;->H0()V

    .line 13
    .line 14
    .line 15
    invoke-static {}, Lq04;->a()V

    .line 16
    .line 17
    .line 18
    invoke-virtual {v1}, Laz3;->S()Lrl3;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    iget-object v2, p0, Lru3;->a:Lhz3;

    .line 23
    .line 24
    iget-object v2, v2, Lhz3;->a:Ljava/lang/String;

    .line 25
    .line 26
    sget-object v3, Ljn3;->G0:Lxr3;

    .line 27
    .line 28
    invoke-virtual {v0, v2, v3}, Lrl3;->R0(Ljava/lang/String;Lxr3;)Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-eqz v0, :cond_134

    .line 33
    .line 34
    if-nez v2, :cond_25

    .line 35
    .line 36
    goto/16 :goto_134

    .line 37
    .line 38
    :cond_25
    const/4 v3, 0x0

    .line 39
    iget-object p0, p0, Lru3;->b:Landroid/os/Bundle;

    .line 40
    .line 41
    if-eqz p0, :cond_b0

    .line 42
    .line 43
    const-string v0, "uriSources"

    .line 44
    .line 45
    invoke-virtual {p0, v0}, Landroid/os/BaseBundle;->getIntArray(Ljava/lang/String;)[I

    .line 46
    .line 47
    .line 48
    move-result-object v4

    .line 49
    const-string v0, "uriTimestamps"

    .line 50
    .line 51
    invoke-virtual {p0, v0}, Landroid/os/BaseBundle;->getLongArray(Ljava/lang/String;)[J

    .line 52
    .line 53
    .line 54
    move-result-object p0

    .line 55
    if-eqz v4, :cond_b0

    .line 56
    .line 57
    if-eqz p0, :cond_a5

    .line 58
    .line 59
    array-length v0, p0

    .line 60
    array-length v5, v4

    .line 61
    if-eq v0, v5, :cond_3f

    .line 62
    .line 63
    goto :goto_a5

    .line 64
    :cond_3f
    move v5, v3

    .line 65
    :goto_40
    array-length v0, v4

    .line 66
    if-ge v5, v0, :cond_b0

    .line 67
    .line 68
    iget-object v6, v1, Laz3;->c:Lam3;

    .line 69
    .line 70
    invoke-static {v6}, Laz3;->x(Lsy3;)V

    .line 71
    .line 72
    .line 73
    aget v0, v4, v5

    .line 74
    .line 75
    aget-wide v7, p0, v5

    .line 76
    .line 77
    invoke-static {v2}, Lmw1;->g(Ljava/lang/String;)V

    .line 78
    .line 79
    .line 80
    invoke-virtual {v6}, Lov;->H0()V

    .line 81
    .line 82
    .line 83
    invoke-virtual {v6}, Lsy3;->L0()V

    .line 84
    .line 85
    .line 86
    :try_start_55
    invoke-virtual {v6}, Lam3;->O0()Landroid/database/sqlite/SQLiteDatabase;

    .line 87
    .line 88
    .line 89
    move-result-object v9

    .line 90
    const-string v10, "trigger_uris"

    .line 91
    .line 92
    const-string v11, "app_id=? and source=? and timestamp_millis<=?"

    .line 93
    .line 94
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 95
    .line 96
    .line 97
    move-result-object v12

    .line 98
    invoke-static {v7, v8}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 99
    .line 100
    .line 101
    move-result-object v13

    .line 102
    filled-new-array {v2, v12, v13}, [Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object v12

    .line 106
    invoke-virtual {v9, v10, v11, v12}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    .line 107
    .line 108
    .line 109
    move-result v9

    .line 110
    invoke-virtual {v6}, Lov;->l()Lqs3;

    .line 111
    .line 112
    .line 113
    move-result-object v10

    .line 114
    iget-object v10, v10, Lqs3;->s:Lts3;

    .line 115
    .line 116
    new-instance v11, Ljava/lang/StringBuilder;

    .line 117
    .line 118
    const-string v12, "Pruned "

    .line 119
    .line 120
    invoke-direct {v11, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 121
    .line 122
    .line 123
    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 124
    .line 125
    .line 126
    const-string v9, " trigger URIs. appId, source, timestamp"

    .line 127
    .line 128
    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 129
    .line 130
    .line 131
    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 132
    .line 133
    .line 134
    move-result-object v9

    .line 135
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 136
    .line 137
    .line 138
    move-result-object v0

    .line 139
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 140
    .line 141
    .line 142
    move-result-object v7

    .line 143
    invoke-virtual {v10, v9, v2, v0, v7}, Lts3;->d(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_91
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_55 .. :try_end_91} :catch_92

    .line 144
    .line 145
    .line 146
    goto :goto_a2

    .line 147
    :catch_92
    move-exception v0

    .line 148
    invoke-virtual {v6}, Lov;->l()Lqs3;

    .line 149
    .line 150
    .line 151
    move-result-object v6

    .line 152
    iget-object v6, v6, Lqs3;->j:Lts3;

    .line 153
    .line 154
    const-string v7, "Error pruning trigger URIs. appId"

    .line 155
    .line 156
    invoke-static {v2}, Lqs3;->N0(Ljava/lang/String;)Lrs3;

    .line 157
    .line 158
    .line 159
    move-result-object v8

    .line 160
    invoke-virtual {v6, v8, v0, v7}, Lts3;->a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    .line 161
    .line 162
    .line 163
    :goto_a2
    add-int/lit8 v5, v5, 0x1

    .line 164
    .line 165
    goto :goto_40

    .line 166
    :cond_a5
    :goto_a5
    invoke-virtual {v1}, Laz3;->l()Lqs3;

    .line 167
    .line 168
    .line 169
    move-result-object p0

    .line 170
    iget-object p0, p0, Lqs3;->j:Lts3;

    .line 171
    .line 172
    const-string v0, "Uri sources and timestamps do not match"

    .line 173
    .line 174
    invoke-virtual {p0, v0}, Lts3;->c(Ljava/lang/String;)V

    .line 175
    .line 176
    .line 177
    :cond_b0
    iget-object p0, v1, Laz3;->c:Lam3;

    .line 178
    .line 179
    invoke-static {p0}, Laz3;->x(Lsy3;)V

    .line 180
    .line 181
    .line 182
    invoke-static {v2}, Lmw1;->g(Ljava/lang/String;)V

    .line 183
    .line 184
    .line 185
    invoke-virtual {p0}, Lov;->H0()V

    .line 186
    .line 187
    .line 188
    invoke-virtual {p0}, Lsy3;->L0()V

    .line 189
    .line 190
    .line 191
    new-instance v0, Ljava/util/ArrayList;

    .line 192
    .line 193
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 194
    .line 195
    .line 196
    const/4 v1, 0x0

    .line 197
    :try_start_c4
    invoke-virtual {p0}, Lam3;->O0()Landroid/database/sqlite/SQLiteDatabase;

    .line 198
    .line 199
    .line 200
    move-result-object v4

    .line 201
    const-string v5, "trigger_uris"

    .line 202
    .line 203
    const-string v6, "trigger_uri"

    .line 204
    .line 205
    const-string v7, "timestamp_millis"

    .line 206
    .line 207
    const-string v8, "source"

    .line 208
    .line 209
    filled-new-array {v6, v7, v8}, [Ljava/lang/String;

    .line 210
    .line 211
    .line 212
    move-result-object v6

    .line 213
    const-string v7, "app_id=?"

    .line 214
    .line 215
    filled-new-array {v2}, [Ljava/lang/String;

    .line 216
    .line 217
    .line 218
    move-result-object v8

    .line 219
    const-string v11, "rowid"

    .line 220
    .line 221
    const/4 v12, 0x0

    .line 222
    const/4 v9, 0x0

    .line 223
    const/4 v10, 0x0

    .line 224
    invoke-virtual/range {v4 .. v12}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    .line 225
    .line 226
    .line 227
    move-result-object v1

    .line 228
    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z

    .line 229
    .line 230
    .line 231
    move-result v4
    :try_end_e7
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_c4 .. :try_end_e7} :catch_f9
    .catchall {:try_start_c4 .. :try_end_e7} :catchall_f6

    .line 232
    if-nez v4, :cond_ed

    .line 233
    .line 234
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 235
    .line 236
    .line 237
    goto :goto_12d

    .line 238
    :cond_ed
    :try_start_ed
    invoke-interface {v1, v3}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 239
    .line 240
    .line 241
    move-result-object v4

    .line 242
    if-nez v4, :cond_fb

    .line 243
    .line 244
    const-string v4, ""

    .line 245
    .line 246
    goto :goto_fb

    .line 247
    :catchall_f6
    move-exception v0

    .line 248
    move-object p0, v0

    .line 249
    goto :goto_12e

    .line 250
    :catch_f9
    move-exception v0

    .line 251
    goto :goto_117

    .line 252
    :cond_fb
    :goto_fb
    const/4 v5, 0x1

    .line 253
    invoke-interface {v1, v5}, Landroid/database/Cursor;->getLong(I)J

    .line 254
    .line 255
    .line 256
    move-result-wide v5

    .line 257
    const/4 v7, 0x2

    .line 258
    invoke-interface {v1, v7}, Landroid/database/Cursor;->getInt(I)I

    .line 259
    .line 260
    .line 261
    move-result v7

    .line 262
    new-instance v8, Lpy3;

    .line 263
    .line 264
    invoke-direct {v8, v7, v5, v6, v4}, Lpy3;-><init>(IJLjava/lang/String;)V

    .line 265
    .line 266
    .line 267
    invoke-virtual {v0, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 268
    .line 269
    .line 270
    invoke-interface {v1}, Landroid/database/Cursor;->moveToNext()Z

    .line 271
    .line 272
    .line 273
    move-result v4
    :try_end_111
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_ed .. :try_end_111} :catch_f9
    .catchall {:try_start_ed .. :try_end_111} :catchall_f6

    .line 274
    if-nez v4, :cond_ed

    .line 275
    .line 276
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 277
    .line 278
    .line 279
    goto :goto_12d

    .line 280
    :goto_117
    :try_start_117
    invoke-virtual {p0}, Lov;->l()Lqs3;

    .line 281
    .line 282
    .line 283
    move-result-object p0

    .line 284
    iget-object p0, p0, Lqs3;->j:Lts3;

    .line 285
    .line 286
    const-string v3, "Error querying trigger uris. appId"

    .line 287
    .line 288
    invoke-static {v2}, Lqs3;->N0(Ljava/lang/String;)Lrs3;

    .line 289
    .line 290
    .line 291
    move-result-object v2

    .line 292
    invoke-virtual {p0, v2, v0, v3}, Lts3;->a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    .line 293
    .line 294
    .line 295
    sget-object v0, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;
    :try_end_128
    .catchall {:try_start_117 .. :try_end_128} :catchall_f6

    .line 296
    .line 297
    if-eqz v1, :cond_12d

    .line 298
    .line 299
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 300
    .line 301
    .line 302
    :cond_12d
    :goto_12d
    return-object v0

    .line 303
    :goto_12e
    if-eqz v1, :cond_133

    .line 304
    .line 305
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 306
    .line 307
    .line 308
    :cond_133
    throw p0

    .line 309
    :cond_134
    :goto_134
    new-instance p0, Ljava/util/ArrayList;

    .line 310
    .line 311
    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    .line 312
    .line 313
    .line 314
    return-object p0
.end method
