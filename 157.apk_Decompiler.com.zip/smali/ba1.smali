###### Class defpackage.ba1 (ba1)
.class public final Lba1;
.super Lz91;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final j:Ly81;

.field public final k:Ljava/util/List;

.field public final l:I

.field public m:I


# direct methods
.method public constructor <init>(Lb61;Ly81;)V
    .registers 5

    .line 1
    const/4 v0, 0x0

    .line 2
    const/16 v1, 0xc

    .line 3
    .line 4
    invoke-direct {p0, p1, p2, v0, v1}, Lz91;-><init>(Lb61;Ly81;Ljava/lang/String;I)V

    .line 5
    .line 6
    .line 7
    iput-object p2, p0, Lba1;->j:Ly81;

    .line 8
    .line 9
    iget-object p1, p2, Ly81;->a:Ljava/util/Map;

    .line 10
    .line 11
    invoke-interface {p1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    invoke-static {p1}, Lgv;->y0(Ljava/lang/Iterable;)Ljava/util/List;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    iput-object p1, p0, Lba1;->k:Ljava/util/List;

    .line 20
    .line 21
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 22
    .line 23
    .line 24
    move-result p1

    .line 25
    mul-int/lit8 p1, p1, 0x2

    .line 26
    .line 27
    iput p1, p0, Lba1;->l:I

    .line 28
    .line 29
    const/4 p1, -0x1

    .line 30
    iput p1, p0, Lba1;->m:I

    .line 31
    .line 32
    return-void
.end method


# virtual methods
.method public final E(Ljava/lang/String;)Lc71;
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget v0, p0, Lba1;->m:I

    .line 5
    .line 6
    rem-int/lit8 v0, v0, 0x2

    .line 7
    .line 8
    if-nez v0, :cond_12

    .line 9
    .line 10
    sget-object p0, Ld71;->a:Lh11;

    .line 11
    .line 12
    new-instance p0, Lk81;

    .line 13
    .line 14
    const/4 v0, 0x1

    .line 15
    invoke-direct {p0, p1, v0}, Lk81;-><init>(Ljava/lang/Object;Z)V

    .line 16
    .line 17
    .line 18
    return-object p0

    .line 19
    :cond_12
    iget-object p0, p0, Lba1;->j:Ly81;

    .line 20
    .line 21
    invoke-static {p0, p1}, Lyo1;->w(Ljava/util/Map;Ljava/lang/Object;)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object p0

    .line 25
    check-cast p0, Lc71;

    .line 26
    .line 27
    return-object p0
.end method

.method public final Q(Lwk2;I)Ljava/lang/String;
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    div-int/lit8 p2, p2, 0x2

    .line 5
    .line 6
    iget-object p0, p0, Lba1;->k:Ljava/util/List;

    .line 7
    .line 8
    invoke-interface {p0, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    check-cast p0, Ljava/lang/String;

    .line 13
    .line 14
    return-object p0
.end method

.method public final S()Lc71;
    .registers 1

    .line 1
    iget-object p0, p0, Lba1;->j:Ly81;

    .line 2
    .line 3
    return-object p0
.end method

.method public final X()Ly81;
    .registers 1

    .line 1
    iget-object p0, p0, Lba1;->j:Ly81;

    .line 2
    .line 3
    return-object p0
.end method

.method public final a(Lwk2;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final k(Lwk2;)I
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget p1, p0, Lba1;->m:I

    .line 5
    .line 6
    iget v0, p0, Lba1;->l:I

    .line 7
    .line 8
    add-int/lit8 v0, v0, -0x1

    .line 9
    .line 10
    if-ge p1, v0, :cond_10

    .line 11
    .line 12
    add-int/lit8 p1, p1, 0x1

    .line 13
    .line 14
    iput p1, p0, Lba1;->m:I

    .line 15
    .line 16
    return p1

    .line 17
    :cond_10
    const/4 p0, -0x1

    .line 18
    return p0
.end method
