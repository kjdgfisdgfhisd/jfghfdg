###### Class defpackage.n92 (n92)
.class public final Ln92;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lym0;


# static fields
.field public static final c:Ljava/nio/charset/Charset;


# instance fields
.field public final a:Ljava/io/File;

.field public b:Ll92;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    const-string v0, "UTF-8"

    .line 2
    .line 3
    invoke-static {v0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    sput-object v0, Ln92;->c:Ljava/nio/charset/Charset;

    .line 8
    .line 9
    return-void
.end method

.method public constructor <init>(Ljava/io/File;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Ln92;->a:Ljava/io/File;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a()V
    .registers 4

    .line 1
    iget-object v0, p0, Ln92;->a:Ljava/io/File;

    .line 2
    .line 3
    iget-object v1, p0, Ln92;->b:Ll92;

    .line 4
    .line 5
    if-nez v1, :cond_22

    .line 6
    .line 7
    :try_start_6
    new-instance v1, Ll92;

    .line 8
    .line 9
    invoke-direct {v1, v0}, Ll92;-><init>(Ljava/io/File;)V

    .line 10
    .line 11
    .line 12
    iput-object v1, p0, Ln92;->b:Ll92;
    :try_end_d
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_d} :catch_e

    .line 13
    .line 14
    return-void

    .line 15
    :catch_e
    move-exception p0

    .line 16
    new-instance v1, Ljava/lang/StringBuilder;

    .line 17
    .line 18
    const-string v2, "Could not open log file: "

    .line 19
    .line 20
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 24
    .line 25
    .line 26
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    const-string v1, "FirebaseCrashlytics"

    .line 31
    .line 32
    invoke-static {v1, v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 33
    .line 34
    .line 35
    :cond_22
    return-void
.end method

.method public final b()V
    .registers 3

    .line 1
    iget-object v0, p0, Ln92;->b:Ll92;

    .line 2
    .line 3
    const-string v1, "There was a problem closing the Crashlytics log file."

    .line 4
    .line 5
    invoke-static {v0, v1}, Lfw;->h(Ljava/io/Closeable;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    iput-object v0, p0, Ln92;->b:Ll92;

    .line 10
    .line 11
    return-void
.end method

.method public final c()Ljava/lang/String;
    .registers 7

    .line 1
    iget-object v0, p0, Ln92;->a:Ljava/io/File;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/4 v1, 0x0

    .line 8
    const/4 v2, 0x0

    .line 9
    if-nez v0, :cond_c

    .line 10
    .line 11
    :goto_a
    move-object p0, v2

    .line 12
    goto :goto_38

    .line 13
    :cond_c
    invoke-virtual {p0}, Ln92;->a()V

    .line 14
    .line 15
    .line 16
    iget-object v0, p0, Ln92;->b:Ll92;

    .line 17
    .line 18
    if-nez v0, :cond_14

    .line 19
    .line 20
    goto :goto_a

    .line 21
    :cond_14
    filled-new-array {v1}, [I

    .line 22
    .line 23
    .line 24
    move-result-object v3

    .line 25
    invoke-virtual {v0}, Ll92;->D()I

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    new-array v0, v0, [B

    .line 30
    .line 31
    :try_start_1e
    iget-object p0, p0, Ln92;->b:Ll92;

    .line 32
    .line 33
    new-instance v4, Lm92;

    .line 34
    .line 35
    invoke-direct {v4, v0, v3}, Lm92;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    invoke-virtual {p0, v4}, Ll92;->j(Lk92;)V
    :try_end_28
    .catch Ljava/io/IOException; {:try_start_1e .. :try_end_28} :catch_29

    .line 39
    .line 40
    .line 41
    goto :goto_31

    .line 42
    :catch_29
    move-exception p0

    .line 43
    const-string v4, "A problem occurred while reading the Crashlytics log file."

    .line 44
    .line 45
    const-string v5, "FirebaseCrashlytics"

    .line 46
    .line 47
    invoke-static {v5, v4, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 48
    .line 49
    .line 50
    :goto_31
    new-instance p0, Lie0;

    .line 51
    .line 52
    aget v3, v3, v1

    .line 53
    .line 54
    invoke-direct {p0, v3, v0}, Lie0;-><init>(I[B)V

    .line 55
    .line 56
    .line 57
    :goto_38
    if-nez p0, :cond_3c

    .line 58
    .line 59
    move-object v3, v2

    .line 60
    goto :goto_45

    .line 61
    :cond_3c
    iget v0, p0, Lie0;->c:I

    .line 62
    .line 63
    new-array v3, v0, [B

    .line 64
    .line 65
    iget-object p0, p0, Lie0;->b:[B

    .line 66
    .line 67
    invoke-static {p0, v1, v3, v1, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 68
    .line 69
    .line 70
    :goto_45
    if-eqz v3, :cond_4f

    .line 71
    .line 72
    new-instance p0, Ljava/lang/String;

    .line 73
    .line 74
    sget-object v0, Ln92;->c:Ljava/nio/charset/Charset;

    .line 75
    .line 76
    invoke-direct {p0, v3, v0}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    .line 77
    .line 78
    .line 79
    return-object p0

    .line 80
    :cond_4f
    return-object v2
.end method

.method public final e(Ljava/lang/String;J)V
    .registers 8

    .line 1
    invoke-virtual {p0}, Ln92;->a()V

    .line 2
    .line 3
    .line 4
    const-string v0, " "

    .line 5
    .line 6
    const-string v1, "..."

    .line 7
    .line 8
    iget-object v2, p0, Ln92;->b:Ll92;

    .line 9
    .line 10
    if-nez v2, :cond_c

    .line 11
    .line 12
    goto :goto_60

    .line 13
    :cond_c
    :try_start_c
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 14
    .line 15
    .line 16
    move-result v2

    .line 17
    const/16 v3, 0x4000

    .line 18
    .line 19
    if-le v2, v3, :cond_21

    .line 20
    .line 21
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 22
    .line 23
    .line 24
    move-result v2

    .line 25
    sub-int/2addr v2, v3

    .line 26
    invoke-virtual {p1, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    :cond_21
    const-string v1, "\r"

    .line 35
    .line 36
    invoke-virtual {p1, v1, v0}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    const-string v1, "\n"

    .line 41
    .line 42
    invoke-virtual {p1, v1, v0}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object p1

    .line 46
    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 47
    .line 48
    const-string v1, "%d %s%n"

    .line 49
    .line 50
    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 51
    .line 52
    .line 53
    move-result-object p2

    .line 54
    filled-new-array {p2, p1}, [Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    invoke-static {v0, v1, p1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 59
    .line 60
    .line 61
    move-result-object p1

    .line 62
    sget-object p2, Ln92;->c:Ljava/nio/charset/Charset;

    .line 63
    .line 64
    invoke-virtual {p1, p2}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 65
    .line 66
    .line 67
    move-result-object p1

    .line 68
    iget-object p2, p0, Ln92;->b:Ll92;

    .line 69
    .line 70
    invoke-virtual {p2, p1}, Ll92;->a([B)V

    .line 71
    .line 72
    .line 73
    :goto_48
    iget-object p1, p0, Ln92;->b:Ll92;

    .line 74
    .line 75
    invoke-virtual {p1}, Ll92;->l()Z

    .line 76
    .line 77
    .line 78
    move-result p1

    .line 79
    if-nez p1, :cond_60

    .line 80
    .line 81
    iget-object p1, p0, Ln92;->b:Ll92;

    .line 82
    .line 83
    invoke-virtual {p1}, Ll92;->D()I

    .line 84
    .line 85
    .line 86
    move-result p1

    .line 87
    const/high16 p2, 0x10000

    .line 88
    .line 89
    if-le p1, p2, :cond_60

    .line 90
    .line 91
    iget-object p1, p0, Ln92;->b:Ll92;

    .line 92
    .line 93
    invoke-virtual {p1}, Ll92;->r()V
    :try_end_5f
    .catch Ljava/io/IOException; {:try_start_c .. :try_end_5f} :catch_61

    .line 94
    .line 95
    .line 96
    goto :goto_48

    .line 97
    :cond_60
    :goto_60
    return-void

    .line 98
    :catch_61
    move-exception p0

    .line 99
    const-string p1, "There was a problem writing to the Crashlytics log."

    .line 100
    .line 101
    const-string p2, "FirebaseCrashlytics"

    .line 102
    .line 103
    invoke-static {p2, p1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 104
    .line 105
    .line 106
    return-void
.end method
