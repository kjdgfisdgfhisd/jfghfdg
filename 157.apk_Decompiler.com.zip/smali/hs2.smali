###### Class defpackage.hs2 (hs2)
.class public interface abstract Lhs2;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# virtual methods
.method public abstract a(Ljava/lang/Exception;)Z
.end method

.method public abstract b(Lah;)Z
.end method
