###### Class defpackage.dc0 (dc0)
.class public final Ldc0;
.super Ly;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final p:Ltg;

.field public final q:Lx72;

.field public final r:Ldb0;


# direct methods
.method public constructor <init>(Ltg;Lx72;I)V
    .registers 15

    .line 1
    iget-object v0, p1, Ltg;->a:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lab0;

    .line 4
    .line 5
    iget-object v5, v0, Lab0;->a:Lcm1;

    .line 6
    .line 7
    iget-object v0, p1, Ltg;->c:Ljava/lang/Object;

    .line 8
    .line 9
    move-object v4, v0

    .line 10
    check-cast v4, Lm60;

    .line 11
    .line 12
    sget-object v3, Lwn0;->b:Lk7;

    .line 13
    .line 14
    iget-object v0, p1, Ltg;->b:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v0, Lev1;

    .line 17
    .line 18
    iget v1, p2, Lx72;->e:I

    .line 19
    .line 20
    invoke-static {v0, v1}, Lfw;->q(Lev1;I)Ldv1;

    .line 21
    .line 22
    .line 23
    move-result-object v6

    .line 24
    iget-object v0, p2, Lx72;->g:Lw72;

    .line 25
    .line 26
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 27
    .line 28
    .line 29
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    const/4 v9, 0x0

    .line 34
    const/4 v10, 0x1

    .line 35
    if-eqz v0, :cond_34

    .line 36
    .line 37
    if-eq v0, v10, :cond_31

    .line 38
    .line 39
    const/4 v1, 0x2

    .line 40
    if-ne v0, v1, :cond_2d

    .line 41
    .line 42
    sget-object v0, Lf73;->c:Lf73;

    .line 43
    .line 44
    :goto_2b
    move-object v7, v0

    .line 45
    goto :goto_37

    .line 46
    :cond_2d
    invoke-static {}, Lm03;->a()V

    .line 47
    .line 48
    .line 49
    throw v9

    .line 50
    :cond_31
    sget-object v0, Lf73;->e:Lf73;

    .line 51
    .line 52
    goto :goto_2b

    .line 53
    :cond_34
    sget-object v0, Lf73;->d:Lf73;

    .line 54
    .line 55
    goto :goto_2b

    .line 56
    :goto_37
    iget-boolean v8, p2, Lx72;->f:Z

    .line 57
    .line 58
    if-eqz v5, :cond_59

    .line 59
    .line 60
    if-eqz v4, :cond_55

    .line 61
    .line 62
    move-object v1, p0

    .line 63
    move v2, p3

    .line 64
    invoke-direct/range {v1 .. v8}, Ld1;-><init>(ILl7;Lm60;Lcm1;Ldv1;Lf73;Z)V

    .line 65
    .line 66
    .line 67
    iput-object p1, v1, Ldc0;->p:Ltg;

    .line 68
    .line 69
    iput-object p2, v1, Ldc0;->q:Lx72;

    .line 70
    .line 71
    new-instance p0, Ldb0;

    .line 72
    .line 73
    new-instance p1, Lw0;

    .line 74
    .line 75
    const/16 p2, 0xa

    .line 76
    .line 77
    invoke-direct {p1, p2, v1}, Lw0;-><init>(ILjava/lang/Object;)V

    .line 78
    .line 79
    .line 80
    invoke-direct {p0, v5, p1}, Ldb0;-><init>(Lcm1;Ldt0;)V

    .line 81
    .line 82
    .line 83
    iput-object p0, v1, Ldc0;->r:Ldb0;

    .line 84
    .line 85
    return-void

    .line 86
    :cond_55
    invoke-static {v10}, Ly;->w0(I)V

    .line 87
    .line 88
    .line 89
    throw v9

    .line 90
    :cond_59
    const/4 p0, 0x0

    .line 91
    invoke-static {p0}, Ly;->w0(I)V

    .line 92
    .line 93
    .line 94
    throw v9
.end method


# virtual methods
.method public final L0()Ljava/util/List;
    .registers 7

    .line 1
    iget-object v0, p0, Ldc0;->p:Ltg;

    .line 2
    .line 3
    iget-object v1, v0, Ltg;->d:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Lkd0;

    .line 6
    .line 7
    iget-object v2, p0, Ldc0;->q:Lx72;

    .line 8
    .line 9
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    iget-object v3, v2, Lx72;->j:Ljava/util/List;

    .line 13
    .line 14
    move-object v4, v3

    .line 15
    check-cast v4, Ljava/util/Collection;

    .line 16
    .line 17
    invoke-interface {v4}, Ljava/util/Collection;->isEmpty()Z

    .line 18
    .line 19
    .line 20
    move-result v4

    .line 21
    if-nez v4, :cond_17

    .line 22
    .line 23
    goto :goto_18

    .line 24
    :cond_17
    const/4 v3, 0x0

    .line 25
    :goto_18
    const/16 v4, 0xa

    .line 26
    .line 27
    if-nez v3, :cond_4b

    .line 28
    .line 29
    iget-object v2, v2, Lx72;->l:Ljava/util/List;

    .line 30
    .line 31
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 32
    .line 33
    .line 34
    check-cast v2, Ljava/lang/Iterable;

    .line 35
    .line 36
    new-instance v3, Ljava/util/ArrayList;

    .line 37
    .line 38
    invoke-static {v2, v4}, Liv;->M(Ljava/lang/Iterable;I)I

    .line 39
    .line 40
    .line 41
    move-result v5

    .line 42
    invoke-direct {v3, v5}, Ljava/util/ArrayList;-><init>(I)V

    .line 43
    .line 44
    .line 45
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 46
    .line 47
    .line 48
    move-result-object v2

    .line 49
    :goto_30
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 50
    .line 51
    .line 52
    move-result v5

    .line 53
    if-eqz v5, :cond_4b

    .line 54
    .line 55
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v5

    .line 59
    check-cast v5, Ljava/lang/Integer;

    .line 60
    .line 61
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 62
    .line 63
    .line 64
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    .line 65
    .line 66
    .line 67
    move-result v5

    .line 68
    invoke-virtual {v1, v5}, Lkd0;->a(I)Ls72;

    .line 69
    .line 70
    .line 71
    move-result-object v5

    .line 72
    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 73
    .line 74
    .line 75
    goto :goto_30

    .line 76
    :cond_4b
    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    .line 77
    .line 78
    .line 79
    move-result v1

    .line 80
    if-eqz v1, :cond_5e

    .line 81
    .line 82
    invoke-static {p0}, Lxa0;->e(Lm60;)Lxf1;

    .line 83
    .line 84
    .line 85
    move-result-object p0

    .line 86
    invoke-virtual {p0}, Lxf1;->m()Lko2;

    .line 87
    .line 88
    .line 89
    move-result-object p0

    .line 90
    invoke-static {p0}, Lia1;->u(Ljava/lang/Object;)Ljava/util/List;

    .line 91
    .line 92
    .line 93
    move-result-object p0

    .line 94
    return-object p0

    .line 95
    :cond_5e
    check-cast v3, Ljava/lang/Iterable;

    .line 96
    .line 97
    iget-object p0, v0, Ltg;->h:Ljava/lang/Object;

    .line 98
    .line 99
    check-cast p0, Ljx;

    .line 100
    .line 101
    new-instance v0, Ljava/util/ArrayList;

    .line 102
    .line 103
    invoke-static {v3, v4}, Liv;->M(Ljava/lang/Iterable;I)I

    .line 104
    .line 105
    .line 106
    move-result v1

    .line 107
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 108
    .line 109
    .line 110
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 111
    .line 112
    .line 113
    move-result-object v1

    .line 114
    :goto_71
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 115
    .line 116
    .line 117
    move-result v2

    .line 118
    if-eqz v2, :cond_85

    .line 119
    .line 120
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    move-result-object v2

    .line 124
    check-cast v2, Ls72;

    .line 125
    .line 126
    invoke-virtual {p0, v2}, Ljx;->x(Ls72;)Lgg1;

    .line 127
    .line 128
    .line 129
    move-result-object v2

    .line 130
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 131
    .line 132
    .line 133
    goto :goto_71

    .line 134
    :cond_85
    return-object v0
.end method

.method public final getAnnotations()Ll7;
    .registers 1

    .line 1
    iget-object p0, p0, Ldc0;->r:Ldb0;

    .line 2
    .line 3
    return-object p0
.end method
