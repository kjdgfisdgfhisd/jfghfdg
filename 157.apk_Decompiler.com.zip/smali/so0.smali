###### Class defpackage.so0 (so0)
.class public final Lso0;
.super Lto0;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final c:[Lu21;


# direct methods
.method public constructor <init>(I[Lu21;)V
    .registers 8

    .line 1
    const/4 v0, 0x0

    .line 2
    if-eqz p2, :cond_26

    .line 3
    .line 4
    array-length v1, p2

    .line 5
    const/4 v2, 0x1

    .line 6
    sub-int/2addr v1, v2

    .line 7
    if-nez v1, :cond_9

    .line 8
    .line 9
    goto :goto_13

    .line 10
    :cond_9
    const/16 v3, 0x1f

    .line 11
    .line 12
    :goto_b
    if-ltz v3, :cond_1c

    .line 13
    .line 14
    shl-int v4, v2, v3

    .line 15
    .line 16
    and-int/2addr v4, v1

    .line 17
    if-eqz v4, :cond_19

    .line 18
    .line 19
    add-int/2addr v2, v3

    .line 20
    :goto_13
    invoke-direct {p0, p1, v2}, Lto0;-><init>(II)V

    .line 21
    .line 22
    .line 23
    iput-object p2, p0, Lso0;->c:[Lu21;

    .line 24
    .line 25
    return-void

    .line 26
    :cond_19
    add-int/lit8 v3, v3, -0x1

    .line 27
    .line 28
    goto :goto_b

    .line 29
    :cond_1c
    const-string p0, "Empty enum: "

    .line 30
    .line 31
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    invoke-static {p1, p0}, Lvn0;->s(Ljava/lang/Object;Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    throw v0

    .line 39
    :cond_26
    const-string p0, "Argument for @NotNull parameter \'enumEntries\' of kotlin/reflect/jvm/internal/impl/metadata/deserialization/Flags$EnumLiteFlagField.bitWidth must not be null"

    .line 40
    .line 41
    invoke-static {p0}, Lm03;->g(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    throw v0
.end method


# virtual methods
.method public final c(I)Ljava/lang/Object;
    .registers 6

    .line 1
    iget v0, p0, Lto0;->b:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    shl-int v0, v1, v0

    .line 5
    .line 6
    sub-int/2addr v0, v1

    .line 7
    iget v1, p0, Lto0;->a:I

    .line 8
    .line 9
    shl-int/2addr v0, v1

    .line 10
    and-int/2addr p1, v0

    .line 11
    shr-int/2addr p1, v1

    .line 12
    iget-object p0, p0, Lso0;->c:[Lu21;

    .line 13
    .line 14
    array-length v0, p0

    .line 15
    const/4 v1, 0x0

    .line 16
    :goto_f
    if-ge v1, v0, :cond_1d

    .line 17
    .line 18
    aget-object v2, p0, v1

    .line 19
    .line 20
    invoke-interface {v2}, Lu21;->a()I

    .line 21
    .line 22
    .line 23
    move-result v3

    .line 24
    if-ne v3, p1, :cond_1a

    .line 25
    .line 26
    return-object v2

    .line 27
    :cond_1a
    add-int/lit8 v1, v1, 0x1

    .line 28
    .line 29
    goto :goto_f

    .line 30
    :cond_1d
    const/4 p0, 0x0

    .line 31
    return-object p0
.end method
