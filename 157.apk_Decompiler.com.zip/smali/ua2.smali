###### Class defpackage.ua2 (ua2)
.class public final Lua2;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final a:Lqo;

.field public volatile b:Ljava/util/concurrent/atomic/AtomicInteger;

.field public final synthetic c:Lxa2;


# direct methods
.method public constructor <init>(Lxa2;Lqo;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lua2;->c:Lxa2;

    .line 8
    .line 9
    iput-object p2, p0, Lua2;->a:Lqo;

    .line 10
    .line 11
    new-instance p1, Ljava/util/concurrent/atomic/AtomicInteger;

    .line 12
    .line 13
    const/4 p2, 0x0

    .line 14
    invoke-direct {p1, p2}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    .line 15
    .line 16
    .line 17
    iput-object p1, p0, Lua2;->b:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 18
    .line 19
    return-void
.end method


# virtual methods
.method public final run()V
    .registers 11

    .line 1
    const-string v0, "Callback failure for "

    .line 2
    .line 3
    const-string v1, "canceled due to "

    .line 4
    .line 5
    iget-object v2, p0, Lua2;->c:Lxa2;

    .line 6
    .line 7
    iget-object v2, v2, Lxa2;->b:Lwe2;

    .line 8
    .line 9
    iget-object v2, v2, Lwe2;->a:Ltz0;

    .line 10
    .line 11
    invoke-virtual {v2}, Ltz0;->g()Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    const-string v3, "OkHttp "

    .line 16
    .line 17
    invoke-virtual {v3, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    iget-object v3, p0, Lua2;->c:Lxa2;

    .line 22
    .line 23
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 24
    .line 25
    .line 26
    move-result-object v4

    .line 27
    invoke-virtual {v4}, Ljava/lang/Thread;->getName()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v5

    .line 31
    invoke-virtual {v4, v2}, Ljava/lang/Thread;->setName(Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    :try_start_21
    iget-object v2, v3, Lxa2;->e:Lwa2;

    .line 35
    .line 36
    invoke-virtual {v2}, Lic;->h()V
    :try_end_26
    .catchall {:try_start_21 .. :try_end_26} :catchall_3f

    .line 37
    .line 38
    .line 39
    const/4 v2, 0x3

    .line 40
    const/4 v6, 0x0

    .line 41
    const/4 v7, 0x0

    .line 42
    :try_start_29
    invoke-virtual {v3}, Lxa2;->g()Lfg2;

    .line 43
    .line 44
    .line 45
    move-result-object v7
    :try_end_2d
    .catch Ljava/io/IOException; {:try_start_29 .. :try_end_2d} :catch_7b
    .catchall {:try_start_29 .. :try_end_2d} :catchall_48

    .line 46
    const/4 v8, 0x1

    .line 47
    :try_start_2e
    iget-object v9, p0, Lua2;->a:Lqo;

    .line 48
    .line 49
    invoke-interface {v9, v3, v7}, Lqo;->onResponse(Lio;Lfg2;)V
    :try_end_33
    .catch Ljava/io/IOException; {:try_start_2e .. :try_end_33} :catch_45
    .catchall {:try_start_2e .. :try_end_33} :catchall_42

    .line 50
    .line 51
    .line 52
    :try_start_33
    iget-object v0, v3, Lxa2;->a:Laz1;

    .line 53
    .line 54
    iget-object v0, v0, Laz1;->a:Lyx2;

    .line 55
    .line 56
    :goto_37
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 57
    .line 58
    .line 59
    invoke-static {v0, v6, v6, p0, v2}, Lyx2;->N(Lyx2;Lua2;Lxa2;Lua2;I)V
    :try_end_3d
    .catchall {:try_start_33 .. :try_end_3d} :catchall_3f

    .line 60
    .line 61
    .line 62
    goto/16 :goto_c5

    .line 63
    .line 64
    :catchall_3f
    move-exception p0

    .line 65
    goto/16 :goto_d4

    .line 66
    .line 67
    :catchall_42
    move-exception v0

    .line 68
    move v7, v8

    .line 69
    goto :goto_49

    .line 70
    :catch_45
    move-exception v1

    .line 71
    move v7, v8

    .line 72
    goto :goto_7c

    .line 73
    :catchall_48
    move-exception v0

    .line 74
    :goto_49
    :try_start_49
    invoke-virtual {v3}, Lxa2;->c()V

    .line 75
    .line 76
    .line 77
    if-nez v7, :cond_6a

    .line 78
    .line 79
    new-instance v7, Ljava/io/IOException;

    .line 80
    .line 81
    new-instance v8, Ljava/lang/StringBuilder;

    .line 82
    .line 83
    invoke-direct {v8, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 84
    .line 85
    .line 86
    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 87
    .line 88
    .line 89
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object v1

    .line 93
    invoke-direct {v7, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 94
    .line 95
    .line 96
    invoke-virtual {v7, v0}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    .line 97
    .line 98
    .line 99
    iget-object v1, p0, Lua2;->a:Lqo;

    .line 100
    .line 101
    invoke-interface {v1, v3, v7}, Lqo;->onFailure(Lio;Ljava/io/IOException;)V

    .line 102
    .line 103
    .line 104
    goto :goto_6a

    .line 105
    :catchall_68
    move-exception v0

    .line 106
    goto :goto_c9

    .line 107
    :cond_6a
    :goto_6a
    instance-of v1, v0, Ljava/lang/InterruptedException;

    .line 108
    .line 109
    if-eqz v1, :cond_7a

    .line 110
    .line 111
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 112
    .line 113
    .line 114
    move-result-object v0

    .line 115
    invoke-virtual {v0}, Ljava/lang/Thread;->interrupt()V
    :try_end_75
    .catchall {:try_start_49 .. :try_end_75} :catchall_68

    .line 116
    .line 117
    .line 118
    :try_start_75
    iget-object v0, v3, Lxa2;->a:Laz1;

    .line 119
    .line 120
    iget-object v0, v0, Laz1;->a:Lyx2;
    :try_end_79
    .catchall {:try_start_75 .. :try_end_79} :catchall_3f

    .line 121
    .line 122
    goto :goto_37

    .line 123
    :cond_7a
    :try_start_7a
    throw v0

    .line 124
    :catch_7b
    move-exception v1

    .line 125
    :goto_7c
    if-eqz v7, :cond_ba

    .line 126
    .line 127
    sget-object v7, Lu12;->a:Lu12;

    .line 128
    .line 129
    sget-object v7, Lu12;->a:Lu12;

    .line 130
    .line 131
    new-instance v8, Ljava/lang/StringBuilder;

    .line 132
    .line 133
    invoke-direct {v8, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 134
    .line 135
    .line 136
    new-instance v0, Ljava/lang/StringBuilder;

    .line 137
    .line 138
    iget-boolean v9, v3, Lxa2;->t:Z

    .line 139
    .line 140
    if-eqz v9, :cond_90

    .line 141
    .line 142
    const-string v9, "canceled "

    .line 143
    .line 144
    goto :goto_92

    .line 145
    :cond_90
    const-string v9, ""

    .line 146
    .line 147
    :goto_92
    invoke-direct {v0, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 148
    .line 149
    .line 150
    const-string v9, "call"

    .line 151
    .line 152
    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 153
    .line 154
    .line 155
    const-string v9, " to "

    .line 156
    .line 157
    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 158
    .line 159
    .line 160
    iget-object v9, v3, Lxa2;->b:Lwe2;

    .line 161
    .line 162
    iget-object v9, v9, Lwe2;->a:Ltz0;

    .line 163
    .line 164
    invoke-virtual {v9}, Ltz0;->g()Ljava/lang/String;

    .line 165
    .line 166
    .line 167
    move-result-object v9

    .line 168
    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 169
    .line 170
    .line 171
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 172
    .line 173
    .line 174
    move-result-object v0

    .line 175
    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 176
    .line 177
    .line 178
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 179
    .line 180
    .line 181
    move-result-object v0

    .line 182
    const/4 v8, 0x4

    .line 183
    invoke-virtual {v7, v0, v8, v1}, Lu12;->j(Ljava/lang/String;ILjava/lang/Throwable;)V

    .line 184
    .line 185
    .line 186
    goto :goto_bf

    .line 187
    :cond_ba
    iget-object v0, p0, Lua2;->a:Lqo;

    .line 188
    .line 189
    invoke-interface {v0, v3, v1}, Lqo;->onFailure(Lio;Ljava/io/IOException;)V
    :try_end_bf
    .catchall {:try_start_7a .. :try_end_bf} :catchall_68

    .line 190
    .line 191
    .line 192
    :goto_bf
    :try_start_bf
    iget-object v0, v3, Lxa2;->a:Laz1;

    .line 193
    .line 194
    iget-object v0, v0, Laz1;->a:Lyx2;
    :try_end_c3
    .catchall {:try_start_bf .. :try_end_c3} :catchall_3f

    .line 195
    .line 196
    goto/16 :goto_37

    .line 197
    .line 198
    :goto_c5
    invoke-virtual {v4, v5}, Ljava/lang/Thread;->setName(Ljava/lang/String;)V

    .line 199
    .line 200
    .line 201
    return-void

    .line 202
    :goto_c9
    :try_start_c9
    iget-object v1, v3, Lxa2;->a:Laz1;

    .line 203
    .line 204
    iget-object v1, v1, Laz1;->a:Lyx2;

    .line 205
    .line 206
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 207
    .line 208
    .line 209
    invoke-static {v1, v6, v6, p0, v2}, Lyx2;->N(Lyx2;Lua2;Lxa2;Lua2;I)V

    .line 210
    .line 211
    .line 212
    throw v0
    :try_end_d4
    .catchall {:try_start_c9 .. :try_end_d4} :catchall_3f

    .line 213
    :goto_d4
    invoke-virtual {v4, v5}, Ljava/lang/Thread;->setName(Ljava/lang/String;)V

    .line 214
    .line 215
    .line 216
    throw p0
.end method
