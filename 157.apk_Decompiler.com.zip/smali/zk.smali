###### Class defpackage.zk (zk)
.class public final Lzk;
.super Loy2;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lv00;


# instance fields
.field public final synthetic d:I

.field public final e:Z


# direct methods
.method public constructor <init>(IZ)V
    .registers 5

    .line 1
    iput p1, p0, Lzk;->d:I

    .line 2
    .line 3
    packed-switch p1, :pswitch_data_2e

    .line 4
    .line 5
    .line 6
    if-eqz p2, :cond_a

    .line 7
    .line 8
    sget-object p1, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    .line 9
    .line 10
    goto :goto_c

    .line 11
    :cond_a
    const-class p1, Ljava/lang/Boolean;

    .line 12
    .line 13
    :goto_c
    const/4 v0, 0x2

    .line 14
    const/4 v1, 0x0

    .line 15
    invoke-direct {p0, p1, v0, v1}, Loy2;-><init>(Ljava/lang/Class;IB)V

    .line 16
    .line 17
    .line 18
    iput-boolean p2, p0, Lzk;->e:Z

    .line 19
    .line 20
    return-void

    .line 21
    :pswitch_14
    const/4 p1, 0x2

    .line 22
    const/4 v0, 0x0

    .line 23
    const-class v1, Ljava/net/InetAddress;

    .line 24
    .line 25
    invoke-direct {p0, v1, p1, v0}, Loy2;-><init>(Ljava/lang/Class;IB)V

    .line 26
    .line 27
    .line 28
    iput-boolean p2, p0, Lzk;->e:Z

    .line 29
    .line 30
    return-void

    .line 31
    :pswitch_1e
    if-eqz p2, :cond_23

    .line 32
    .line 33
    sget-object p1, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    .line 34
    .line 35
    goto :goto_25

    .line 36
    :cond_23
    const-class p1, Ljava/lang/Boolean;

    .line 37
    .line 38
    :goto_25
    const/4 v0, 0x2

    .line 39
    const/4 v1, 0x0

    .line 40
    invoke-direct {p0, p1, v0, v1}, Loy2;-><init>(Ljava/lang/Class;IB)V

    .line 41
    .line 42
    .line 43
    iput-boolean p2, p0, Lzk;->e:Z

    .line 44
    .line 45
    return-void

    .line 46
    nop

    .line 47
    :pswitch_data_2e
    .packed-switch 0x1
        :pswitch_1e
        :pswitch_14
    .end packed-switch
.end method


# virtual methods
.method public final a(Lfl2;Lwj;)Lt91;
    .registers 8

    .line 1
    iget v0, p0, Lzk;->d:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    iget-object v2, p0, Lbt2;->a:Ljava/lang/Class;

    .line 5
    .line 6
    iget-boolean v3, p0, Lzk;->e:Z

    .line 7
    .line 8
    const/4 v4, 0x0

    .line 9
    packed-switch v0, :pswitch_data_5c

    .line 10
    .line 11
    .line 12
    invoke-static {p1, p2, v2}, Lbt2;->j(Lfl2;Lwj;Ljava/lang/Class;)Lp71;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    if-eqz p1, :cond_1e

    .line 17
    .line 18
    iget-object p1, p1, Lp71;->b:Lo71;

    .line 19
    .line 20
    invoke-virtual {p1}, Lo71;->a()Z

    .line 21
    .line 22
    .line 23
    move-result p2

    .line 24
    if-nez p2, :cond_1f

    .line 25
    .line 26
    sget-object p2, Lo71;->d:Lo71;

    .line 27
    .line 28
    if-ne p1, p2, :cond_1e

    .line 29
    .line 30
    goto :goto_1f

    .line 31
    :cond_1e
    move v1, v4

    .line 32
    :cond_1f
    :goto_1f
    if-eq v1, v3, :cond_27

    .line 33
    .line 34
    new-instance p0, Lzk;

    .line 35
    .line 36
    const/4 p1, 0x2

    .line 37
    invoke-direct {p0, p1, v1}, Lzk;-><init>(IZ)V

    .line 38
    .line 39
    .line 40
    :cond_27
    return-object p0

    .line 41
    :pswitch_28
    invoke-static {p1, p2, v2}, Lbt2;->j(Lfl2;Lwj;Ljava/lang/Class;)Lp71;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    if-eqz p1, :cond_45

    .line 46
    .line 47
    iget-object p1, p1, Lp71;->b:Lo71;

    .line 48
    .line 49
    invoke-virtual {p1}, Lo71;->a()Z

    .line 50
    .line 51
    .line 52
    move-result p2

    .line 53
    if-eqz p2, :cond_3c

    .line 54
    .line 55
    new-instance p0, Lzk;

    .line 56
    .line 57
    invoke-direct {p0, v4, v3}, Lzk;-><init>(IZ)V

    .line 58
    .line 59
    .line 60
    goto :goto_45

    .line 61
    :cond_3c
    sget-object p2, Lo71;->l:Lo71;

    .line 62
    .line 63
    if-ne p1, p2, :cond_45

    .line 64
    .line 65
    new-instance p0, Lay1;

    .line 66
    .line 67
    invoke-direct {p0, v4, v2}, Lay1;-><init>(ILjava/lang/Class;)V

    .line 68
    .line 69
    .line 70
    :cond_45
    :goto_45
    return-object p0

    .line 71
    :pswitch_46
    const-class v0, Ljava/lang/Boolean;

    .line 72
    .line 73
    invoke-static {p1, p2, v0}, Lbt2;->j(Lfl2;Lwj;Ljava/lang/Class;)Lp71;

    .line 74
    .line 75
    .line 76
    move-result-object p1

    .line 77
    if-eqz p1, :cond_5b

    .line 78
    .line 79
    iget-object p1, p1, Lp71;->b:Lo71;

    .line 80
    .line 81
    invoke-virtual {p1}, Lo71;->a()Z

    .line 82
    .line 83
    .line 84
    move-result p1

    .line 85
    if-nez p1, :cond_5b

    .line 86
    .line 87
    new-instance p0, Lzk;

    .line 88
    .line 89
    invoke-direct {p0, v1, v3}, Lzk;-><init>(IZ)V

    .line 90
    .line 91
    .line 92
    :cond_5b
    return-object p0

    .line 93
    :pswitch_data_5c
    .packed-switch 0x0
        :pswitch_46
        :pswitch_28
    .end packed-switch
.end method

.method public final e(Ljava/lang/Object;Lt71;Lfl2;)V
    .registers 4

    .line 1
    iget p3, p0, Lzk;->d:I

    .line 2
    .line 3
    packed-switch p3, :pswitch_data_22

    .line 4
    .line 5
    .line 6
    check-cast p1, Ljava/net/InetAddress;

    .line 7
    .line 8
    invoke-virtual {p0, p1, p2}, Lzk;->q(Ljava/net/InetAddress;Lt71;)V

    .line 9
    .line 10
    .line 11
    return-void

    .line 12
    :pswitch_b
    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 13
    .line 14
    invoke-virtual {p0, p1}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result p0

    .line 18
    invoke-virtual {p2, p0}, Lt71;->n(Z)V

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    :pswitch_15
    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 23
    .line 24
    invoke-virtual {p0, p1}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result p0

    .line 28
    xor-int/lit8 p0, p0, 0x1

    .line 29
    .line 30
    invoke-virtual {p2, p0}, Lt71;->H(I)V

    .line 31
    .line 32
    .line 33
    return-void

    .line 34
    nop

    .line 35
    :pswitch_data_22
    .packed-switch 0x0
        :pswitch_15
        :pswitch_b
    .end packed-switch
.end method

.method public final f(Ljava/lang/Object;Lt71;Lfl2;Ls23;)V
    .registers 6

    .line 1
    iget p3, p0, Lzk;->d:I

    .line 2
    .line 3
    packed-switch p3, :pswitch_data_30

    .line 4
    .line 5
    .line 6
    check-cast p1, Ljava/net/InetAddress;

    .line 7
    .line 8
    sget-object p3, Ly91;->g:Ly91;

    .line 9
    .line 10
    invoke-virtual {p4, p1, p3}, Ls23;->d(Ljava/lang/Object;Ly91;)Lvh2;

    .line 11
    .line 12
    .line 13
    move-result-object p3

    .line 14
    const-class v0, Ljava/net/InetAddress;

    .line 15
    .line 16
    iput-object v0, p3, Lvh2;->d:Ljava/lang/Object;

    .line 17
    .line 18
    invoke-virtual {p4, p2, p3}, Ls23;->e(Lt71;Lvh2;)Lvh2;

    .line 19
    .line 20
    .line 21
    move-result-object p3

    .line 22
    invoke-virtual {p0, p1, p2}, Lzk;->q(Ljava/net/InetAddress;Lt71;)V

    .line 23
    .line 24
    .line 25
    invoke-virtual {p4, p2, p3}, Ls23;->f(Lt71;Lvh2;)Lvh2;

    .line 26
    .line 27
    .line 28
    return-void

    .line 29
    :pswitch_1c
    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 30
    .line 31
    invoke-virtual {p0, p1}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    .line 32
    .line 33
    .line 34
    move-result p0

    .line 35
    invoke-virtual {p2, p0}, Lt71;->n(Z)V

    .line 36
    .line 37
    .line 38
    return-void

    .line 39
    :pswitch_26
    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 40
    .line 41
    invoke-virtual {p0, p1}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    move-result p0

    .line 45
    invoke-virtual {p2, p0}, Lt71;->n(Z)V

    .line 46
    .line 47
    .line 48
    return-void

    .line 49
    :pswitch_data_30
    .packed-switch 0x0
        :pswitch_26
        :pswitch_1c
    .end packed-switch
.end method

.method public q(Ljava/net/InetAddress;Lt71;)V
    .registers 4

    .line 1
    iget-boolean p0, p0, Lzk;->e:Z

    .line 2
    .line 3
    if-eqz p0, :cond_9

    .line 4
    .line 5
    invoke-virtual {p1}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    goto :goto_26

    .line 10
    :cond_9
    invoke-virtual {p1}, Ljava/net/InetAddress;->toString()Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    const/16 p1, 0x2f

    .line 19
    .line 20
    invoke-virtual {p0, p1}, Ljava/lang/String;->indexOf(I)I

    .line 21
    .line 22
    .line 23
    move-result p1

    .line 24
    if-ltz p1, :cond_26

    .line 25
    .line 26
    if-nez p1, :cond_21

    .line 27
    .line 28
    const/4 p1, 0x1

    .line 29
    invoke-virtual {p0, p1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    goto :goto_26

    .line 34
    :cond_21
    const/4 v0, 0x0

    .line 35
    invoke-virtual {p0, v0, p1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object p0

    .line 39
    :cond_26
    :goto_26
    invoke-virtual {p2, p0}, Lt71;->R(Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    return-void
.end method
