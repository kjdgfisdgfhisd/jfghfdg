###### Class defpackage.it0 (it0)
.class public interface abstract Lit0;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lpt0;
