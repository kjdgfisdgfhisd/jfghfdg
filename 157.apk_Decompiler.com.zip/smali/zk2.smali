###### Class defpackage.zk2 (zk2)
.class public final Lzk2;
.super Lg70;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field public static final i:Lzk2;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lzk2;

    .line 2
    .line 3
    const/16 v1, 0xc

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lg70;-><init>(I)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lzk2;->i:Lzk2;

    .line 9
    .line 10
    return-void
.end method
