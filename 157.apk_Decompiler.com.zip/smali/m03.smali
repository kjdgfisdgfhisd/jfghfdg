###### Class defpackage.m03 (m03)
.class public final synthetic Lm03;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lfx;
.implements Lbu0;


# direct methods
.method public static synthetic a()V
    .registers 1

    .line 1
    new-instance v0, Llw;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 4
    .line 5
    .line 6
    throw v0
.end method

.method public static synthetic b(Ljava/lang/Object;ILjava/lang/Object;)V
    .registers 5

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "Cannot create TypeBindings for class "

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 9
    .line 10
    .line 11
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 12
    .line 13
    .line 14
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 15
    .line 16
    .line 17
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 22
    .line 23
    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    throw p1
.end method

.method public static synthetic c(Ljava/lang/Object;Ljava/lang/String;)V
    .registers 4

    .line 1
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    .line 2
    .line 3
    new-instance v1, Ljava/lang/StringBuilder;

    .line 4
    .line 5
    invoke-direct {v1, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 9
    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    invoke-direct {v0, p0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    throw v0
.end method

.method public static synthetic d(Ljava/lang/String;)V
    .registers 2

    .line 1
    new-instance v0, Ljava/io/IOException;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    throw v0
.end method

.method public static synthetic e(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 5

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 7
    .line 8
    .line 9
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 10
    .line 11
    .line 12
    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 13
    .line 14
    .line 15
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 20
    .line 21
    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    throw p1
.end method

.method public static synthetic f(Ljava/lang/Object;Ljava/lang/String;)V
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    invoke-direct {v0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 7
    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 14
    .line 15
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    throw p1
.end method

.method public static synthetic g(Ljava/lang/String;)V
    .registers 2

    .line 1
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    throw v0
.end method

.method public static synthetic h(Ljava/lang/String;)V
    .registers 2

    .line 1
    new-instance v0, Ljava/lang/IndexOutOfBoundsException;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    throw v0
.end method

.method public static synthetic i(Ljava/lang/String;)V
    .registers 2

    .line 1
    new-instance v0, Ljava/lang/NullPointerException;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    throw v0
.end method

.method public static synthetic j(Ljava/lang/String;)V
    .registers 2

    .line 1
    new-instance v0, Ljava/util/NoSuchElementException;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Ljava/util/NoSuchElementException;-><init>(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    throw v0
.end method

.method public static synthetic k(Ljava/lang/String;)V
    .registers 2

    .line 1
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    throw v0
.end method


# virtual methods
.method public apply(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 34

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    check-cast v0, Ljava/util/List;

    .line 4
    .line 5
    if-eqz v0, :cond_e7

    .line 6
    .line 7
    check-cast v0, Ljava/lang/Iterable;

    .line 8
    .line 9
    new-instance v2, Ljava/util/ArrayList;

    .line 10
    .line 11
    const/16 v3, 0xa

    .line 12
    .line 13
    invoke-static {v0, v3}, Liv;->M(Ljava/lang/Iterable;I)I

    .line 14
    .line 15
    .line 16
    move-result v3

    .line 17
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 18
    .line 19
    .line 20
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    :goto_17
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 25
    .line 26
    .line 27
    move-result v3

    .line 28
    if-eqz v3, :cond_e5

    .line 29
    .line 30
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v3

    .line 34
    check-cast v3, Lie3;

    .line 35
    .line 36
    iget-object v4, v3, Lie3;->q:Ljava/util/List;

    .line 37
    .line 38
    iget-object v7, v3, Lie3;->b:Ltd3;

    .line 39
    .line 40
    move-object v5, v4

    .line 41
    check-cast v5, Ljava/util/Collection;

    .line 42
    .line 43
    invoke-interface {v5}, Ljava/util/Collection;->isEmpty()Z

    .line 44
    .line 45
    .line 46
    move-result v5

    .line 47
    const/4 v6, 0x0

    .line 48
    if-nez v5, :cond_39

    .line 49
    .line 50
    invoke-interface {v4, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v4

    .line 54
    check-cast v4, Lc50;

    .line 55
    .line 56
    :goto_37
    move-object v10, v4

    .line 57
    goto :goto_3c

    .line 58
    :cond_39
    sget-object v4, Lc50;->b:Lc50;

    .line 59
    .line 60
    goto :goto_37

    .line 61
    :goto_3c
    new-instance v5, Lud3;

    .line 62
    .line 63
    iget-object v4, v3, Lie3;->a:Ljava/lang/String;

    .line 64
    .line 65
    invoke-static {v4}, Ljava/util/UUID;->fromString(Ljava/lang/String;)Ljava/util/UUID;

    .line 66
    .line 67
    .line 68
    move-result-object v4

    .line 69
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 70
    .line 71
    .line 72
    new-instance v8, Ljava/util/HashSet;

    .line 73
    .line 74
    iget-object v9, v3, Lie3;->p:Ljava/util/List;

    .line 75
    .line 76
    check-cast v9, Ljava/util/Collection;

    .line 77
    .line 78
    invoke-direct {v8, v9}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    .line 79
    .line 80
    .line 81
    iget-object v9, v3, Lie3;->c:Lc50;

    .line 82
    .line 83
    iget v11, v3, Lie3;->h:I

    .line 84
    .line 85
    iget v12, v3, Lie3;->m:I

    .line 86
    .line 87
    iget-object v13, v3, Lie3;->g:La00;

    .line 88
    .line 89
    iget-wide v14, v3, Lie3;->d:J

    .line 90
    .line 91
    move-object/from16 p1, v2

    .line 92
    .line 93
    const/16 p0, 0x0

    .line 94
    .line 95
    iget-wide v1, v3, Lie3;->e:J

    .line 96
    .line 97
    const-wide/16 v16, 0x0

    .line 98
    .line 99
    cmp-long v16, v1, v16

    .line 100
    .line 101
    if-eqz v16, :cond_72

    .line 102
    .line 103
    new-instance v6, Lsd3;

    .line 104
    .line 105
    move-object/from16 v29, v4

    .line 106
    .line 107
    move-object/from16 v28, v5

    .line 108
    .line 109
    iget-wide v4, v3, Lie3;->f:J

    .line 110
    .line 111
    invoke-direct {v6, v1, v2, v4, v5}, Lsd3;-><init>(JJ)V

    .line 112
    .line 113
    .line 114
    goto :goto_78

    .line 115
    :cond_72
    move-object/from16 v29, v4

    .line 116
    .line 117
    move-object/from16 v28, v5

    .line 118
    .line 119
    move-object/from16 v6, p0

    .line 120
    .line 121
    :goto_78
    sget-object v4, Ltd3;->a:Ltd3;

    .line 122
    .line 123
    if-ne v7, v4, :cond_ba

    .line 124
    .line 125
    sget-object v5, Lje3;->z:Lm03;

    .line 126
    .line 127
    if-ne v7, v4, :cond_88

    .line 128
    .line 129
    if-lez v11, :cond_88

    .line 130
    .line 131
    move v4, v12

    .line 132
    move v12, v11

    .line 133
    const/4 v11, 0x1

    .line 134
    :goto_85
    move-object/from16 v18, v13

    .line 135
    .line 136
    goto :goto_8c

    .line 137
    :cond_88
    move v4, v12

    .line 138
    move v12, v11

    .line 139
    const/4 v11, 0x0

    .line 140
    goto :goto_85

    .line 141
    :goto_8c
    iget-object v13, v3, Lie3;->i:Lqh;

    .line 142
    .line 143
    move-wide/from16 v20, v14

    .line 144
    .line 145
    iget-wide v14, v3, Lie3;->j:J

    .line 146
    .line 147
    move-object/from16 v30, v6

    .line 148
    .line 149
    iget-wide v5, v3, Lie3;->k:J

    .line 150
    .line 151
    move-object/from16 v31, v0

    .line 152
    .line 153
    iget v0, v3, Lie3;->l:I

    .line 154
    .line 155
    if-eqz v16, :cond_a2

    .line 156
    .line 157
    const/16 v19, 0x1

    .line 158
    .line 159
    :goto_9e
    move-wide/from16 v24, v1

    .line 160
    .line 161
    move v2, v0

    .line 162
    goto :goto_a5

    .line 163
    :cond_a2
    const/16 v19, 0x0

    .line 164
    .line 165
    goto :goto_9e

    .line 166
    :goto_a5
    iget-wide v0, v3, Lie3;->f:J

    .line 167
    .line 168
    move-wide/from16 v22, v0

    .line 169
    .line 170
    iget-wide v0, v3, Lie3;->n:J

    .line 171
    .line 172
    move-wide/from16 v26, v0

    .line 173
    .line 174
    move-wide/from16 v16, v5

    .line 175
    .line 176
    move-object/from16 v0, v18

    .line 177
    .line 178
    move/from16 v18, v2

    .line 179
    .line 180
    invoke-static/range {v11 .. v27}, Lio2;->E(ZILqh;JJIZJJJJ)J

    .line 181
    .line 182
    .line 183
    move-result-wide v1

    .line 184
    :goto_b7
    move-wide/from16 v17, v1

    .line 185
    .line 186
    goto :goto_c9

    .line 187
    :cond_ba
    move-object/from16 v31, v0

    .line 188
    .line 189
    move-object/from16 v30, v6

    .line 190
    .line 191
    move v4, v12

    .line 192
    move-object v0, v13

    .line 193
    move-wide/from16 v20, v14

    .line 194
    .line 195
    move v12, v11

    .line 196
    const-wide v1, 0x7fffffffffffffffL

    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    goto :goto_b7

    .line 202
    :goto_c9
    iget v1, v3, Lie3;->o:I

    .line 203
    .line 204
    move-object v13, v0

    .line 205
    move/from16 v19, v1

    .line 206
    .line 207
    move v11, v12

    .line 208
    move-wide/from16 v14, v20

    .line 209
    .line 210
    move-object/from16 v5, v28

    .line 211
    .line 212
    move-object/from16 v6, v29

    .line 213
    .line 214
    move-object/from16 v16, v30

    .line 215
    .line 216
    move v12, v4

    .line 217
    invoke-direct/range {v5 .. v19}, Lud3;-><init>(Ljava/util/UUID;Ltd3;Ljava/util/HashSet;Lc50;Lc50;IILa00;JLsd3;JI)V

    .line 218
    .line 219
    .line 220
    move-object/from16 v0, p1

    .line 221
    .line 222
    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 223
    .line 224
    .line 225
    move-object v2, v0

    .line 226
    move-object/from16 v0, v31

    .line 227
    .line 228
    goto/16 :goto_17

    .line 229
    .line 230
    :cond_e5
    move-object v0, v2

    .line 231
    return-object v0

    .line 232
    :cond_e7
    const/16 p0, 0x0

    .line 233
    .line 234
    return-object p0
.end method

.method public k0(Ly8;)Ljava/lang/Object;
    .registers 2

    .line 1
    invoke-static {p1}, Lcom/google/firebase/datatransport/TransportRegistrar;->a(Ly8;)Lk03;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
