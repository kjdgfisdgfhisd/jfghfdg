###### Class defpackage.um (um)
.class public final Lum;
.super Lv02;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"

# interfaces
.implements Lu02;


# instance fields
.field public final l:Lpm;

.field public final m:Leh0;

.field public final n:Lyx2;

.field public o:Lg72;

.field public p:Lzb0;


# direct methods
.method public constructor <init>(Lzq0;Lcm1;Lzt1;Lg72;Lpm;)V
    .registers 7

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    invoke-direct {p0, p3, p1}, Lv02;-><init>(Lzt1;Lzq0;)V

    .line 8
    .line 9
    .line 10
    iput-object p5, p0, Lum;->l:Lpm;

    .line 11
    .line 12
    new-instance p1, Leh0;

    .line 13
    .line 14
    iget-object p2, p4, Lg72;->d:Ln72;

    .line 15
    .line 16
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    iget-object p3, p4, Lg72;->e:Lm72;

    .line 20
    .line 21
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    .line 23
    .line 24
    invoke-direct {p1, p2, p3}, Leh0;-><init>(Ln72;Lm72;)V

    .line 25
    .line 26
    .line 27
    iput-object p1, p0, Lum;->m:Leh0;

    .line 28
    .line 29
    new-instance p2, Lyx2;

    .line 30
    .line 31
    new-instance p3, Lp23;

    .line 32
    .line 33
    const/4 v0, 0x5

    .line 34
    invoke-direct {p3, v0, p0}, Lp23;-><init>(ILjava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    invoke-direct {p2, p4, p1, p5, p3}, Lyx2;-><init>(Lg72;Leh0;Lpm;Lp23;)V

    .line 38
    .line 39
    .line 40
    iput-object p2, p0, Lum;->n:Lyx2;

    .line 41
    .line 42
    iput-object p4, p0, Lum;->o:Lg72;

    .line 43
    .line 44
    return-void
.end method


# virtual methods
.method public final L0(Lab0;)V
    .registers 13

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lum;->o:Lg72;

    .line 5
    .line 6
    if-eqz v0, :cond_33

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    iput-object v1, p0, Lum;->o:Lg72;

    .line 10
    .line 11
    new-instance v2, Lzb0;

    .line 12
    .line 13
    iget-object v4, v0, Lg72;->f:Le72;

    .line 14
    .line 15
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 16
    .line 17
    .line 18
    new-instance v0, Ljava/lang/StringBuilder;

    .line 19
    .line 20
    const-string v1, "scope of "

    .line 21
    .line 22
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v9

    .line 32
    new-instance v10, Lw0;

    .line 33
    .line 34
    const/16 v0, 0x9

    .line 35
    .line 36
    invoke-direct {v10, v0, p0}, Lw0;-><init>(ILjava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    iget-object v5, p0, Lum;->m:Leh0;

    .line 40
    .line 41
    iget-object v6, p0, Lum;->l:Lpm;

    .line 42
    .line 43
    const/4 v7, 0x0

    .line 44
    move-object v3, p0

    .line 45
    move-object v8, p1

    .line 46
    invoke-direct/range {v2 .. v10}, Lzb0;-><init>(Lu02;Le72;Lev1;Lgk;Ltb1;Lab0;Ljava/lang/String;Ldt0;)V

    .line 47
    .line 48
    .line 49
    iput-object v2, v3, Lum;->p:Lzb0;

    .line 50
    .line 51
    return-void

    .line 52
    :cond_33
    const-string p0, "Repeated call to DeserializedPackageFragmentImpl::initialize"

    .line 53
    .line 54
    invoke-static {p0}, Ly0;->h(Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    return-void
.end method

.method public final p0()Lvr1;
    .registers 1

    .line 1
    iget-object p0, p0, Lum;->p:Lzb0;

    .line 2
    .line 3
    if-eqz p0, :cond_5

    .line 4
    .line 5
    return-object p0

    .line 6
    :cond_5
    const-string p0, "_memberScope"

    .line 7
    .line 8
    invoke-static {p0}, Ld31;->A(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const/4 p0, 0x0

    .line 12
    throw p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "builtins package fragment for "

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, Lv02;->g:Lzq0;

    .line 9
    .line 10
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    const-string v1, " from "

    .line 14
    .line 15
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    sget v1, Lxa0;->a:I

    .line 19
    .line 20
    invoke-static {p0}, Lva0;->d(Lm60;)Lzt1;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 25
    .line 26
    .line 27
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object p0

    .line 34
    return-object p0
.end method
