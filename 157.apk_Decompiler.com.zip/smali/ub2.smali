###### Class defpackage.ub2 (ub2)
.class public abstract Lub2;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# virtual methods
.method public a(Landroidx/recyclerview/widget/RecyclerView;I)V
    .registers 3

    .line 1
    return-void
.end method

.method public abstract b(Landroidx/recyclerview/widget/RecyclerView;II)V
.end method
