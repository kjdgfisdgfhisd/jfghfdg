###### Class defpackage.m82 (m82)
.class public abstract synthetic Lm82;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field public static final synthetic a:[I

.field public static final synthetic b:[I


# direct methods
.method static constructor <clinit>()V
    .registers 6

    .line 1
    invoke-static {}, Lb72;->values()[Lb72;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    array-length v0, v0

    .line 6
    new-array v0, v0, [I

    .line 7
    .line 8
    const/4 v1, 0x1

    .line 9
    const/4 v2, 0x0

    .line 10
    :try_start_9
    aput v1, v0, v2
    :try_end_b
    .catch Ljava/lang/NoSuchFieldError; {:try_start_9 .. :try_end_b} :catch_b

    .line 11
    .line 12
    :catch_b
    const/4 v3, 0x2

    .line 13
    :try_start_c
    aput v3, v0, v1
    :try_end_e
    .catch Ljava/lang/NoSuchFieldError; {:try_start_c .. :try_end_e} :catch_e

    .line 14
    .line 15
    :catch_e
    const/4 v4, 0x3

    .line 16
    :try_start_f
    aput v4, v0, v3
    :try_end_11
    .catch Ljava/lang/NoSuchFieldError; {:try_start_f .. :try_end_11} :catch_11

    .line 17
    .line 18
    :catch_11
    const/4 v5, 0x4

    .line 19
    :try_start_12
    aput v5, v0, v4
    :try_end_14
    .catch Ljava/lang/NoSuchFieldError; {:try_start_12 .. :try_end_14} :catch_14

    .line 20
    .line 21
    :catch_14
    sput-object v0, Lm82;->a:[I

    .line 22
    .line 23
    invoke-static {v5}, Ln10;->x(I)[I

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    array-length v0, v0

    .line 28
    new-array v0, v0, [I

    .line 29
    .line 30
    :try_start_1d
    aput v1, v0, v2
    :try_end_1f
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1d .. :try_end_1f} :catch_1f

    .line 31
    .line 32
    :catch_1f
    :try_start_1f
    aput v3, v0, v1
    :try_end_21
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1f .. :try_end_21} :catch_21

    .line 33
    .line 34
    :catch_21
    :try_start_21
    aput v4, v0, v3
    :try_end_23
    .catch Ljava/lang/NoSuchFieldError; {:try_start_21 .. :try_end_23} :catch_23

    .line 35
    .line 36
    :catch_23
    :try_start_23
    aput v5, v0, v4
    :try_end_25
    .catch Ljava/lang/NoSuchFieldError; {:try_start_23 .. :try_end_25} :catch_25

    .line 37
    .line 38
    :catch_25
    invoke-static {}, Lg82;->values()[Lg82;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    array-length v0, v0

    .line 43
    new-array v0, v0, [I

    .line 44
    .line 45
    :try_start_2c
    aput v1, v0, v2
    :try_end_2e
    .catch Ljava/lang/NoSuchFieldError; {:try_start_2c .. :try_end_2e} :catch_2e

    .line 46
    .line 47
    :catch_2e
    :try_start_2e
    aput v3, v0, v1
    :try_end_30
    .catch Ljava/lang/NoSuchFieldError; {:try_start_2e .. :try_end_30} :catch_30

    .line 48
    .line 49
    :catch_30
    :try_start_30
    aput v4, v0, v5
    :try_end_32
    .catch Ljava/lang/NoSuchFieldError; {:try_start_30 .. :try_end_32} :catch_32

    .line 50
    .line 51
    :catch_32
    :try_start_32
    aput v5, v0, v3
    :try_end_34
    .catch Ljava/lang/NoSuchFieldError; {:try_start_32 .. :try_end_34} :catch_34

    .line 52
    .line 53
    :catch_34
    const/4 v1, 0x5

    .line 54
    :try_start_35
    aput v1, v0, v4
    :try_end_37
    .catch Ljava/lang/NoSuchFieldError; {:try_start_35 .. :try_end_37} :catch_37

    .line 55
    .line 56
    :catch_37
    const/4 v2, 0x6

    .line 57
    :try_start_38
    aput v2, v0, v1
    :try_end_3a
    .catch Ljava/lang/NoSuchFieldError; {:try_start_38 .. :try_end_3a} :catch_3a

    .line 58
    .line 59
    :catch_3a
    sput-object v0, Lm82;->b:[I

    .line 60
    .line 61
    return-void
.end method
