###### Class defpackage.ab1 (ab1)
.class public final Lab1;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# instance fields
.field public final a:Lau1;


# direct methods
.method public constructor <init>(Lau1;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lab1;->a:Lau1;

    .line 5
    .line 6
    return-void
.end method
