###### Class defpackage.z9 (z9)
.class public abstract Lz9;
.super Ljava/lang/Object;
.source "r8-map-id-35ff943a7b433345151432d8ce1938542cdc2587978d120850b3f565402b8392"


# static fields
.field public static final a:Ljn1;

.field public static b:Landroid/graphics/Paint;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Ljn1;

    .line 2
    .line 3
    const/16 v1, 0x1e

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljn1;-><init>(I)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lz9;->a:Ljn1;

    .line 9
    .line 10
    return-void
.end method

.method public static a(Landroid/graphics/Typeface;Ljava/lang/String;I)Landroid/graphics/Typeface;
    .registers 15

    .line 1
    new-instance v0, Ly9;

    .line 2
    .line 3
    invoke-direct {v0, p0, p1, p2}, Ly9;-><init>(Landroid/graphics/Typeface;Ljava/lang/String;I)V

    .line 4
    .line 5
    .line 6
    sget-object v1, Lz9;->a:Ljn1;

    .line 7
    .line 8
    invoke-virtual {v1, v0}, Ljn1;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v2

    .line 12
    check-cast v2, Landroid/graphics/Typeface;

    .line 13
    .line 14
    if-eqz v2, :cond_10

    .line 15
    .line 16
    return-object v2

    .line 17
    :cond_10
    sget-object v2, Lz9;->b:Landroid/graphics/Paint;

    .line 18
    .line 19
    if-eqz v2, :cond_15

    .line 20
    .line 21
    goto :goto_1c

    .line 22
    :cond_15
    new-instance v2, Landroid/graphics/Paint;

    .line 23
    .line 24
    invoke-direct {v2}, Landroid/graphics/Paint;-><init>()V

    .line 25
    .line 26
    .line 27
    sput-object v2, Lz9;->b:Landroid/graphics/Paint;

    .line 28
    .line 29
    :goto_1c
    if-nez p2, :cond_20

    .line 30
    .line 31
    goto/16 :goto_87

    .line 32
    .line 33
    :cond_20
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 34
    .line 35
    .line 36
    move-result v3

    .line 37
    const/4 v4, 0x0

    .line 38
    if-eqz v3, :cond_2a

    .line 39
    .line 40
    new-array p1, v4, [Landroid/graphics/fonts/FontVariationAxis;

    .line 41
    .line 42
    goto :goto_32

    .line 43
    :cond_2a
    invoke-static {p1}, Landroid/graphics/fonts/FontVariationAxis;->fromFontVariationSettings(Ljava/lang/String;)[Landroid/graphics/fonts/FontVariationAxis;

    .line 44
    .line 45
    .line 46
    move-result-object v3

    .line 47
    if-nez v3, :cond_31

    .line 48
    .line 49
    goto :goto_87

    .line 50
    :cond_31
    move-object p1, v3

    .line 51
    :goto_32
    move v3, v4

    .line 52
    move v5, v3

    .line 53
    :goto_34
    array-length v6, p1

    .line 54
    const/high16 v7, 0x447a0000    # 1000.0f

    .line 55
    .line 56
    const/high16 v8, 0x3f800000    # 1.0f

    .line 57
    .line 58
    const/4 v9, 0x1

    .line 59
    const-string v10, "wght"

    .line 60
    .line 61
    if-ge v3, v6, :cond_64

    .line 62
    .line 63
    aget-object v6, p1, v3

    .line 64
    .line 65
    invoke-virtual {v6}, Landroid/graphics/fonts/FontVariationAxis;->getTag()Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v11

    .line 69
    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 70
    .line 71
    .line 72
    move-result v11

    .line 73
    if-eqz v11, :cond_61

    .line 74
    .line 75
    new-instance v5, Landroid/graphics/fonts/FontVariationAxis;

    .line 76
    .line 77
    invoke-virtual {v6}, Landroid/graphics/fonts/FontVariationAxis;->getStyleValue()F

    .line 78
    .line 79
    .line 80
    move-result v6

    .line 81
    int-to-float v11, p2

    .line 82
    add-float/2addr v6, v11

    .line 83
    cmpg-float v11, v6, v8

    .line 84
    .line 85
    if-gez v11, :cond_57

    .line 86
    .line 87
    goto :goto_5b

    .line 88
    :cond_57
    invoke-static {v6, v7}, Ljava/lang/Math;->min(FF)F

    .line 89
    .line 90
    .line 91
    move-result v8

    .line 92
    :goto_5b
    invoke-direct {v5, v10, v8}, Landroid/graphics/fonts/FontVariationAxis;-><init>(Ljava/lang/String;F)V

    .line 93
    .line 94
    .line 95
    aput-object v5, p1, v3

    .line 96
    .line 97
    move v5, v9

    .line 98
    :cond_61
    add-int/lit8 v3, v3, 0x1

    .line 99
    .line 100
    goto :goto_34

    .line 101
    :cond_64
    if-nez v5, :cond_83

    .line 102
    .line 103
    array-length v3, p1

    .line 104
    add-int/2addr v3, v9

    .line 105
    new-array v3, v3, [Landroid/graphics/fonts/FontVariationAxis;

    .line 106
    .line 107
    array-length v5, p1

    .line 108
    invoke-static {p1, v4, v3, v4, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 109
    .line 110
    .line 111
    array-length p1, p1

    .line 112
    new-instance v4, Landroid/graphics/fonts/FontVariationAxis;

    .line 113
    .line 114
    add-int/lit16 p2, p2, 0x190

    .line 115
    .line 116
    int-to-float p2, p2

    .line 117
    cmpg-float v5, p2, v8

    .line 118
    .line 119
    if-gez v5, :cond_79

    .line 120
    .line 121
    goto :goto_7d

    .line 122
    :cond_79
    invoke-static {p2, v7}, Ljava/lang/Math;->min(FF)F

    .line 123
    .line 124
    .line 125
    move-result v8

    .line 126
    :goto_7d
    invoke-direct {v4, v10, v8}, Landroid/graphics/fonts/FontVariationAxis;-><init>(Ljava/lang/String;F)V

    .line 127
    .line 128
    .line 129
    aput-object v4, v3, p1

    .line 130
    .line 131
    move-object p1, v3

    .line 132
    :cond_83
    invoke-static {p1}, Landroid/graphics/fonts/FontVariationAxis;->toFontVariationSettings([Landroid/graphics/fonts/FontVariationAxis;)Ljava/lang/String;

    .line 133
    .line 134
    .line 135
    move-result-object p1

    .line 136
    :goto_87
    invoke-virtual {v2}, Landroid/graphics/Paint;->getFontVariationSettings()Ljava/lang/String;

    .line 137
    .line 138
    .line 139
    move-result-object p2

    .line 140
    invoke-static {p2, p1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 141
    .line 142
    .line 143
    move-result p2

    .line 144
    const/4 v3, 0x0

    .line 145
    if-eqz p2, :cond_95

    .line 146
    .line 147
    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setFontVariationSettings(Ljava/lang/String;)Z

    .line 148
    .line 149
    .line 150
    :cond_95
    invoke-virtual {v2, p0}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 151
    .line 152
    .line 153
    invoke-virtual {v2, p1}, Landroid/graphics/Paint;->setFontVariationSettings(Ljava/lang/String;)Z

    .line 154
    .line 155
    .line 156
    move-result p0

    .line 157
    if-eqz p0, :cond_a6

    .line 158
    .line 159
    invoke-virtual {v2}, Landroid/graphics/Paint;->getTypeface()Landroid/graphics/Typeface;

    .line 160
    .line 161
    .line 162
    move-result-object p0

    .line 163
    invoke-virtual {v1, v0, p0}, Ljn1;->k(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 164
    .line 165
    .line 166
    return-object p0

    .line 167
    :cond_a6
    return-object v3
.end method

.method public static b(Landroid/widget/TextView;)I
    .registers 1

    .line 1
    invoke-virtual {p0}, Landroid/widget/TextView;->getAutoSizeStepGranularity()I

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method

.method public static c(Landroid/widget/TextView;)Ljava/lang/String;
    .registers 1

    .line 1
    invoke-virtual {p0}, Landroid/widget/TextView;->getFontVariationSettings()Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public static d(Landroid/widget/TextView;III)V
    .registers 5

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-virtual {p0, p1, p2, p3, v0}, Landroid/widget/TextView;->setAutoSizeTextTypeUniformWithConfiguration(IIII)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public static e(Landroid/widget/TextView;[I)V
    .registers 3

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-virtual {p0, p1, v0}, Landroid/widget/TextView;->setAutoSizeTextTypeUniformWithPresetSizes([II)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public static f(Landroid/widget/TextView;Ljava/lang/String;)V
    .registers 3

    .line 1
    invoke-virtual {p0}, Landroid/widget/TextView;->getFontVariationSettings()Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0, p1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_f

    .line 10
    .line 11
    const-string v0, ""

    .line 12
    .line 13
    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setFontVariationSettings(Ljava/lang/String;)Z

    .line 14
    .line 15
    .line 16
    :cond_f
    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setFontVariationSettings(Ljava/lang/String;)Z

    .line 17
    .line 18
    .line 19
    return-void
.end method
